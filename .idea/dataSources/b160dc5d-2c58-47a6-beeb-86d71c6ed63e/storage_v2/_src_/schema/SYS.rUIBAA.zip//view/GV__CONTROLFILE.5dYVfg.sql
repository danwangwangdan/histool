create view GV_$CONTROLFILE as
  select "INST_ID","STATUS","NAME","IS_RECOVERY_DEST_FILE","BLOCK_SIZE","FILE_SIZE_BLKS" from gv$controlfile
/

