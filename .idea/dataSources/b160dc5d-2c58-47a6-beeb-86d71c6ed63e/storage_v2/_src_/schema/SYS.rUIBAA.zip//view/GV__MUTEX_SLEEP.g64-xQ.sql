create view GV_$MUTEX_SLEEP as
  select "INST_ID","MUTEX_TYPE","LOCATION","SLEEPS","WAIT_TIME" from gv$mutex_sleep
/

