create view GV_$RESOURCE as
  select "INST_ID","ADDR","TYPE","ID1","ID2" from gv$resource
/

