create view GV_$SQLTEXT_WITH_NEWLINES as
  select "INST_ID","ADDRESS","HASH_VALUE","SQL_ID","COMMAND_TYPE","PIECE","SQL_TEXT" from gv$sqltext_with_newlines
/

