create view VIEW_QUEUE_INFO as
  select 科室ID officeId,
           DECODE(科室ID,152,'DR室',153,'CT室',147,'胃镜室',155,'B超室','未知') office,
           排队号码 sn,
           患者姓名 patientName,
           排队状态 status,
           排队时间 queueTime,
           呼叫时间 callTime,
           诊室 room
    from ZLHIS.排队叫号队列 t where 业务类型 = 1 and to_char(排队时间,'yyyy-mm-dd') = to_char(sysdate,'yyyy-mm-dd')
WITH READ ONLY
/

