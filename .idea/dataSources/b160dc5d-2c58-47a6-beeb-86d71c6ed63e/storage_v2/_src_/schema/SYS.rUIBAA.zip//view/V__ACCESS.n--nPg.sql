create view V_$ACCESS as
  select "SID","OWNER","OBJECT","TYPE" from v$access
/

