create view V_$ARCHIVE_PROCESSES as
  select "PROCESS","STATUS","LOG_SEQUENCE","STATE" from v$archive_processes
/

