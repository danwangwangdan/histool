create view V_$AW_ALLOCATE_OP as
  select "NAME","LONGNAME" from v$aw_allocate_op
/

