create view V_$BACKUP_DEVICE as
  select "DEVICE_TYPE","DEVICE_NAME" from v$backup_device
/

