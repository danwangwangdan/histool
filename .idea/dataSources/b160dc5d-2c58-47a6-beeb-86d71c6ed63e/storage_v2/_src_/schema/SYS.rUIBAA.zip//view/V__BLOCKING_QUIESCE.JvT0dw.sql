create view V_$BLOCKING_QUIESCE as
  select "SID" from v$blocking_quiesce
/

