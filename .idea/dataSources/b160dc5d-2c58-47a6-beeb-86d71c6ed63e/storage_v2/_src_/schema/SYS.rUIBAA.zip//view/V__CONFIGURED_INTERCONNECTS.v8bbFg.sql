create view V_$CONFIGURED_INTERCONNECTS as
  select "NAME","IP_ADDRESS","IS_PUBLIC","SOURCE" from v$configured_interconnects
/

