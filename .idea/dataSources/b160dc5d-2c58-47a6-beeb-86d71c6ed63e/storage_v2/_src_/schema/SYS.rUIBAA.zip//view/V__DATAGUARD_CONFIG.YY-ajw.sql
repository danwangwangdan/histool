create view V_$DATAGUARD_CONFIG as
  select "DB_UNIQUE_NAME" from v$dataguard_config
/

