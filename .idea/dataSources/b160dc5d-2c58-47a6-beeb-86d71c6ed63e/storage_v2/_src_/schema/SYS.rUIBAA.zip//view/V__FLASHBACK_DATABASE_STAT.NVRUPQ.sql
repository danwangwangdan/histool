create view V_$FLASHBACK_DATABASE_STAT as
  select "BEGIN_TIME","END_TIME","FLASHBACK_DATA","DB_DATA","REDO_DATA","ESTIMATED_FLASHBACK_SIZE" from v$flashback_database_stat
/

