create view V_$METRICGROUP as
  select "GROUP_ID","NAME","INTERVAL_SIZE","MAX_INTERVAL" from v$metricgroup
/

