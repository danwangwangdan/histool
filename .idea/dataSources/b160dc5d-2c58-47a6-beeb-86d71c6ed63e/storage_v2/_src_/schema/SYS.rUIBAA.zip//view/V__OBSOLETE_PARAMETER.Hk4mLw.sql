create view V_$OBSOLETE_PARAMETER as
  select "NAME","ISSPECIFIED" from v$obsolete_parameter
/

