create view V_$POLICY_HISTORY as
  select "INST_ID","POLICY_EVENT","DATA_OBJECT_ID","TARGET_INSTANCE_NUMBER","EVENT_DATE" from v$policy_history
/

