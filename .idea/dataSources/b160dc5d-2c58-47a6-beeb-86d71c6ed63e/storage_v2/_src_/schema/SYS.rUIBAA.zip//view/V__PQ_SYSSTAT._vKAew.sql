create view V_$PQ_SYSSTAT as
  select "STATISTIC","VALUE" from v$pq_sysstat
/

