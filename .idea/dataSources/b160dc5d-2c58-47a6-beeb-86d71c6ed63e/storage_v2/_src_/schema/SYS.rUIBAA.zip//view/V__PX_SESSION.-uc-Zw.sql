create view V_$PX_SESSION as
  select "SADDR","SID","SERIAL#","QCSID","QCSERIAL#","QCINST_ID","SERVER_GROUP","SERVER_SET","SERVER#","DEGREE","REQ_DEGREE" from v$px_session
/

