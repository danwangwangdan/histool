create view V_$REQDIST as
  select "BUCKET","COUNT" from v$reqdist
/

