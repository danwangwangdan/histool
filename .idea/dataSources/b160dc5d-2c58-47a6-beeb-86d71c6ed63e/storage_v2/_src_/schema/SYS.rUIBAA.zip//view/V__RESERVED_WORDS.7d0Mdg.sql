create view V_$RESERVED_WORDS as
  select "KEYWORD","LENGTH","RESERVED","RES_TYPE","RES_ATTR","RES_SEMI","DUPLICATE" from v$reserved_words
/

