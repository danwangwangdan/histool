create view V_$SEGSTAT as
  select "TS#","OBJ#","DATAOBJ#","STATISTIC_NAME","STATISTIC#","VALUE" from v$segstat
/

