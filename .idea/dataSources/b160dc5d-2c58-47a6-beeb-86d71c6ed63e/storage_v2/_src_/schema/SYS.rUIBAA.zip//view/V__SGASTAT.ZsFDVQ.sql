create view V_$SGASTAT as
  select "POOL","NAME","BYTES" from v$sgastat
/

