create view V_$SGA_DYNAMIC_FREE_MEMORY as
  select "CURRENT_SIZE" from v$sga_dynamic_free_memory
/

