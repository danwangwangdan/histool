create view V_$SQL_JOIN_FILTER as
  select "QC_SESSION_ID","QC_INSTANCE_ID","SQL_PLAN_HASH_VALUE","LENGTH","BITS_SET","FILTERED","PROBED","ACTIVE" from v$sql_join_filter
/

