create Package b_Emr_Interface Is
  ---------------------------------------------------------------------------
  -----------------------通过当前部门查询部门中所有人员-------------------
  Procedure p_Get_Person_By_Depts
  (
    Val      Out Sys_Refcursor,
    Depts_In Varchar2
  );
  --用于获取部门人员信息
  Procedure p_Get_Dept_Person(Val Out Sys_Refcursor);
  --单独提取病人信息
  Procedure p_Get_Patientinfo
  (
    Val       Out Sys_Refcursor,
    Patiid_In In 病人信息.病人id%Type
  );
  --提取指定时间后的所有活动记录
  Procedure p_Get_Actioninfo_In
  (
    Val       Out Sys_Refcursor,
    Patiid_In In Number,
    Begin_In  Date,
    Pageid_In In Number
  );
  --获取门诊活动信息
  Procedure p_Get_Actioninfo_Out
  (
    Val       Out Sys_Refcursor,
    Patiid_In In Number,
    Regid_In  In Number
  );
  --确认ID是否存在
  Procedure p_Validation_Exist
  (
    Val        Out Sys_Refcursor,
    Content_In In Xmltype
  );
  --读取HIS片段   
  PROCEDURE p_Get_His_Fragment(Val OUT SYS_REFCURSOR);
  --获取zlparamters参数值
  Procedure p_Get_Zlparameters
  (
    Sysnum_In     Zlparameters.系统%Type,
    Paramename_In Zlparameters.参数名%Type,
    Val           Out Sys_Refcursor
  );
  --按照诊断标准获取诊断信息
  Procedure p_Get_Diagnose_By_Standard
  (
    Diagnosetype_In 疾病诊断目录.类别%Type,
    Input_In        Varchar2,
    Val             Out Sys_Refcursor
  );
  --按照疾病编码获取诊断信息
  Procedure p_Get_Diagnose_By_Code
  (
    Diagnosetype_In 疾病编码目录.类别%Type,
    Input_In        Varchar2,
    Val             Out Sys_Refcursor
  );
  --按照诊断标准获取中医征候信息
  Procedure p_Get_Chn_Sign_By_Standard
  (
    Diagnoseid_In 疾病诊断参考.诊断id%Type,
    Input_In      Varchar2,
    Val           Out Sys_Refcursor
  );
  --按照疾病编码获取中医征候信息
  Procedure p_Get_Chn_Sign_By_Code
  (
    Input_In Varchar2,
    Val      Out Sys_Refcursor
  );
  --获取his诊断
  Procedure p_Get_Diagnosis
  (
    Patiid_In  病人诊断记录.病人id%Type,
    Page_Id_In 病人诊断记录.主页id%Type,
    Type_In    病人诊断记录.诊断类型%Type,
    Val        Out Sys_Refcursor
  );
  --删除病人诊断记录
  Procedure p_病人诊断记录_Delete
  (
    --功能：删除病人诊断记录 
    --参数：诊断类型_IN=为空时表示所有类型,否则为字符串,如'1,2,3...' 
    --      诊断s_In=需要删除的诊断ID串 ,格式为 'ID1,ID2,ID3...' 
    病人id_In   病人诊断记录.病人id%Type,
    主页id_In   病人诊断记录.主页id%Type,
    诊断类型_In Varchar2 := Null
  );
  --新增病人诊断记录
  Procedure p_病人诊断记录_Insert
  (
    病人id_In   病人诊断记录.病人id%Type,
    主页id_In   病人诊断记录.主页id%Type,
    诊断类型_In 病人诊断记录.诊断类型%Type,
    疾病id_In   病人诊断记录.疾病id%Type,
    诊断id_In   病人诊断记录.诊断id%Type,
    证候id_In   病人诊断记录.证候id%Type,
    诊断描述_In 病人诊断记录.诊断描述%Type,
    出院情况_In 病人诊断记录.出院情况%Type,
    是否未治_In 病人诊断记录.是否未治%Type,
    是否疑诊_In 病人诊断记录.是否疑诊%Type,
    诊断次序_In 病人诊断记录.诊断次序%Type := 1,
    备注_In     病人诊断记录.备注%Type := Null,
    入院病情_In 病人诊断记录.入院病情%Type := Null,
    记录人_In   病人诊断记录.记录人%Type := Null
  );
  --判断部门是否有中医科性质
  Procedure p_Get_Is_Tcm
  (
    部门id_In 部门性质说明.部门id%Type,
    Val       Out Sys_Refcursor
  );
  --获取治疗结果表数据
  Procedure p_Get_Treat_Result(Val Out Sys_Refcursor);
  --获取病案主页是否签名
  Procedure p_Get_Mainpage_Isgign
  (
    病人id_In 病案主页从表.病人id%Type,
    主页id_In 病案主页从表.主页id%Type,
    Val       Out Sys_Refcursor
  );
  --病历首次签名或撤销所有签名时更新ZLHIS数据,为兼容早期版本，不能使用表结构定义
  Procedure p_病人危急值病历_Insert
  (
    危急值id_In Number,
    文档id_In   Varchar2,
    子文档id_In Varchar2,
    标题_In     Varchar2,
    完成人_In   Varchar2,
    完成时间_In Date
  );
End b_Emr_Interface;
/

