create Package Body b_Emr_Interface Is
  --用于判断ZLHIS版本大于等于传入值返回1，否则返回0
  Function f_Version
  (
    Version_One_In Number,
    Version_Two_In Number
  ) Return Number As
    Version_Tmp   Varchar2(100);
    n_Version_One Number(5);
    n_Version_Two Number(5);
  Begin
    Select Substr(版本号, Instr(版本号, '.') + 1) Into Version_Tmp From zlSystems Where 名称 = '医院系统标准版';
    Select Substr(Version_Tmp, 0, Instr(Version_Tmp, '.') - 1) Into n_Version_One From Dual;
    Select Substr(Version_Tmp, Instr(Version_Tmp, '.') + 1) Into Version_Tmp From Dual;
    If Instr(Version_Tmp, '.') > 0 Then
      Select Substr(Version_Tmp, 0, Instr(Version_Tmp, '.') - 1) Into n_Version_Two From Dual;
    Else
      n_Version_Two := Version_Tmp;
    End If;
    If n_Version_One > Version_One_In Then
      Return 1;
    Elsif n_Version_One = Version_One_In Then
      If n_Version_Two >= Version_Two_In Then
        Return 1;
      Else
        Return 0;
      End If;
    Else
      Return 0;
    End If;
  End f_Version;
  ---------------------------------------------------------------------------
  -----------------------通过当前部门查询部门中所有人员-------------------
  Procedure p_Get_Person_By_Depts
  (
    Val      Out Sys_Refcursor,
    Depts_In Varchar2
  ) As
  Begin
    Open Val For
      Select a.Id 部门id, a.编码 部门编码, a.名称 部门名称, c.姓名 人员姓名, c.编号 人员编号, c.Id 人员id
      From 部门表 A, 部门人员 B, 人员表 C
      Where Instr(Depts_In, ',' || a.Id || ',') > 0 And b.部门id = a.Id And c.Id = b.人员id;
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_Get_Person_By_Depts;
  ------------------------------------------------------------------------------
  --用于获取部门人员信息
  Procedure p_Get_Dept_Person(Val Out Sys_Refcursor) As
    x_p Xmltype;
    x_d Xmltype;
  Begin
    Select Xmlelement("personnal",
                       Xmlagg(Xmlelement("item", Xmlforest(a.Id As "ID", a.姓名 As "姓名", Substr(a.简码, 1, 10) As "简码")))) Content
    Into x_p
    From 人员表 A, (Select Distinct 人员id From 人员性质说明 Where 人员性质 = '医生' Or 人员性质 = '护士') B
    Where a.Id = b.人员id And Nvl(a.撤档时间, To_Date('3000-01-01', 'yyyy-mm-dd')) = To_Date('3000-01-01', 'yyyy-mm-dd')
    Order By a.Id;
    Select Xmlelement("dept",
                       Xmlagg(Xmlelement("item",
                                          Xmlforest(a.Id As "ID", a.名称, Substr(a.简码, 1, 10) As "简码", a.工作性质 As "工作性质",
                                                     a.服务对象 As "服务对象", a.所属学科)))) As Content
    Into x_d
    From (Select a.Id, a.名称, a.简码, b.工作性质, b.服务对象, c.所属学科
           From 部门表 A, 部门性质说明 B,
                (Select A1.Id As 部门id, Xmlelement("subject", Xmlagg(Xmlelement("item", C1.工作性质))) As 所属学科
                  From 部门表 A1, 临床部门 C1
                  Where A1.Id = C1.部门id
                  Group By A1.Id) C
           Where a.Id = b.部门id And b.工作性质 In ('临床', '护理') And a.Id = c.部门id And
                 Nvl(a.撤档时间, To_Date('3000-01-01', 'yyyy-mm-dd')) = To_Date('3000-01-01', 'yyyy-mm-dd')
           Order By a.Id) A;
    Open Val For
      Select Xmlelement("root", Xmlconcat(x_p, x_d)) Content From Dual;
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_Get_Dept_Person;
  Procedure p_Get_Patientinfo
  (
    Val       Out Sys_Refcursor,
    Patiid_In In 病人信息.病人id%Type
  ) Is
    x_p Xmltype;
    x_m Xmltype;
  Begin
    Select Xmlelement("pati",
                       Xmlforest(a.病人id As "病人ID", a.门诊号, a.住院号, a.身份证号, a.就诊卡号, a.健康号, a.医保号, a.姓名, a.性别,
                                  Decode(a.性别, '男', 1, '女', 2, 9) 性别编码, a.年龄, To_Char(a.出生日期, 'yyyymmdd') 出生日期, a.婚姻状况, a.费别,
                                  a.国籍, a.民族, Decode(Ascii(Substr(a.职业, 1, 1)), 30, Substr(a.职业, 2), a.职业) As "职业", a.学历,
                                  a.家庭地址, a.家庭电话, a.联系人电话, a.联系人关系, a.联系人姓名, a.联系人地址, a.工作单位, a.单位电话, a.单位邮编,
                                  Decode(a.险类, Null, '01', '07') 付款方式编码, a.其他证件, a.出生地点, a.监护人, '' 身高, '' 体重, 家庭地址邮编 家庭邮编,
                                  户口地址 户籍地址, 户口地址邮编 户籍邮编, '' 单位地址, 籍贯 籍贯, To_Char(Nvl(入院时间, 登记时间), 'yyyymmddhh24miss') 入院时间,
                                  Decode(a.险类, Null, '全自费', '城镇职工基本医疗保险') 医疗付款方式, Nvl(住院次数, 0) 住院次数,
                                  Decode(a.婚姻状况, '已婚', '20', '10') 婚姻状况编码)) As Content
    Into x_p
    From 病人信息 A
    Where a.病人id = Patiid_In;
    Select Xmlelement("merge", Xmlagg(Xmlforest(Substr(原信息, 1, Instr(原信息, ',') - 1) As "被合并ID"))) As Content
    Into x_m
    From 病人合并记录
    Where 病人id = Patiid_In
    Order By 合并时间;
    Open Val For
      Select Xmlelement("root", Xmlconcat(x_p, x_m)) Content From Dual;
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_Get_Patientinfo;
  --读取入院
  Procedure p_住院入院
  (
    病人id_In In 病人变动记录.病人id%Type,
    主页id_In In 病人变动记录.主页id%Type,
    a_List    In Out Xmltype
  ) Is
    v_开始时间 Varchar2(20);
    x_Detail   Xmltype;
  Begin
    If f_Version(35, 0) = 1 Then
      Select To_Char(b.开始时间, 'yyyymmddhh24miss') As 开始时间,
             Xmlforest('BD_' || a.Id As "ID", b.病人id As "病人ID", d.Id As "门诊医师ID", c.门诊医师, e.编码 As 入院方式编码, c.入院方式,
                        f.编码 As 病情编码, c.入院病况 As "病况", b.科室id As "入院科室ID", g.名称 入院科室, b.病区id As "入院病区ID", h.名称 入院病区,
                        i.Id As "住院医师ID", b.经治医师 住院医师, j.Id As "主治医师ID", b.主治医师, k.Id As "主任医师ID", b.主任医师,
                        l.Id As "责任护士ID", b.责任护士, Decode(c.再入院, 1, '是', '否') 再入院, b.操作员姓名, Nvl(c.入院病床, b.床号) As 入院病床,
                        Nvl(c.出院病床, b.床号) As 床号, To_Char(c.入院日期, 'yyyymmddhh24miss') 入院日期, c.住院号, b.主页id As "主页ID", c.留观号,
                        To_Char(b.开始时间, 'yyyymmddhh24miss') "发生时间", b.操作员姓名 As "记录人") As Content
      Into v_开始时间, x_Detail
      From (Select Nvl(a.Id, b.Id) ID
             From (Select Max(ID) ID
                    From 病人变动记录
                    Where 病人id = 病人id_In And 主页id = 主页id_In And 开始原因 = 2 And Nvl(附加床位, 0) = 0) A,
                  (Select Max(ID) ID
                    From 病人变动记录
                    Where 病人id = 病人id_In And 主页id = 主页id_In And 开始原因 = 1 And Nvl(附加床位, 0) = 0) B) A, 病人变动记录 B, 病案主页 C,
           人员表 D, 入院方式 E, 病情 F, 部门表 G, 部门表 H, 人员表 I, 人员表 J, 人员表 K, 人员表 L
      Where a.Id = b.Id And b.病人id = c.病人id And b.主页id = c.主页id And Nvl(c.状态, 1) <> 1 And c.门诊医师 = d.姓名(+) And
            c.入院方式 = e.名称(+) And c.入院病况 = f.名称(+) And b.科室id = g.Id And b.病区id = h.Id(+) And b.经治医师 = i.姓名(+) And
            b.主治医师 = j.姓名(+) And b.主任医师 = k.姓名(+) And b.责任护士 = l.姓名(+);
    Else
      Select To_Char(b.开始时间, 'yyyymmddhh24miss') As 开始时间,
             Xmlforest('BD_' || a.Id As "ID", b.病人id As "病人ID", d.Id As "门诊医师ID", c.门诊医师, e.编码 As 入院方式编码, c.入院方式,
                        f.编码 As 病情编码, c.入院病况 As "病况", b.科室id As "入院科室ID", g.名称 入院科室, b.病区id As "入院病区ID", h.名称 入院病区,
                        i.Id As "住院医师ID", b.经治医师 住院医师, j.Id As "主治医师ID", b.主治医师, k.Id As "主任医师ID", b.主任医师,
                        l.Id As "责任护士ID", b.责任护士, Decode(c.再入院, 1, '是', '否') 再入院, b.操作员姓名, Nvl(c.入院病床, b.床号) As 入院病床,
                        Nvl(c.出院病床, b.床号) As 床号, To_Char(c.入院日期, 'yyyymmddhh24miss') 入院日期, c.住院号, b.主页id As "主页ID",
                        To_Char(b.开始时间, 'yyyymmddhh24miss') "发生时间", b.操作员姓名 As "记录人") As Content
      Into v_开始时间, x_Detail
      From (Select Nvl(a.Id, b.Id) ID
             From (Select Max(ID) ID
                    From 病人变动记录
                    Where 病人id = 病人id_In And 主页id = 主页id_In And 开始原因 = 2 And Nvl(附加床位, 0) = 0) A,
                  (Select Max(ID) ID
                    From 病人变动记录
                    Where 病人id = 病人id_In And 主页id = 主页id_In And 开始原因 = 1 And Nvl(附加床位, 0) = 0) B) A, 病人变动记录 B, 病案主页 C,
           人员表 D, 入院方式 E, 病情 F, 部门表 G, 部门表 H, 人员表 I, 人员表 J, 人员表 K, 人员表 L
      Where a.Id = b.Id And b.病人id = c.病人id And b.主页id = c.主页id And Nvl(c.状态, 1) <> 1 And c.门诊医师 = d.姓名(+) And
            c.入院方式 = e.名称(+) And c.入院病况 = f.名称(+) And b.科室id = g.Id And b.病区id = h.Id(+) And b.经治医师 = i.姓名(+) And
            b.主治医师 = j.姓名(+) And b.主任医师 = k.姓名(+) And b.责任护士 = l.姓名(+);
    End If;
    Select Appendchildxml(a_List, 'root',
                           Xmlelement("item",
                                       Xmlforest(v_开始时间 As "开始时间", '住院入院' As "活动名称", x_Detail As "detail", 0 As "序号")))
    Into a_List
    From Dual;
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_住院入院;
  --读取会诊事件
  Procedure p_会诊
  (
    病人id_In   In 病人医嘱记录.病人id%Type,
    主页id_In   In 病人医嘱记录.主页id%Type,
    开始时间_In In Date,
    a_List      In Out Xmltype
  ) Is
    v_申请序号   Varchar2(500) := ',';
    x_Detail     Xmltype;
    n_单一任务   Number(1);
    v_代表科室id 部门表.Id%Type;
    v_会诊范围   病人医嘱附件.内容%Type;
    v_邀请医院   病人医嘱附件.内容%Type;
    v_邀请科室   病人医嘱附件.内容%Type;
    v_医生级别   病人医嘱附件.内容%Type;
    v_邀请医生   病人医嘱附件.内容%Type;
    v_代表科室   病人医嘱附件.内容%Type;
    v_会诊诊断   病人医嘱附件.内容%Type;
    v_会诊目的   病人医嘱附件.内容%Type;
    v_会诊意见   病人医嘱附件.内容%Type;
    v_完成时间   病人医嘱附件.内容%Type;
    v_完成科室   病人医嘱附件.内容%Type;
    v_会诊医生   病人医嘱附件.内容%Type;
  Begin
    --多科会诊单一任务=1时生效,
    Select Nvl(zl_GetSysParameter('多科会诊意见书写要求'), 0) Into n_单一任务 From Dual;
    For r_Row In (Select To_Char(b.开始执行时间, 'yyyymmddhh24miss') As 开始时间, b.Id, b.申请序号,
                         Xmlforest('YZ_' || b.Id As "ID", b.病人id As "病人ID", b.主页id As "主页ID", b.紧急标志 As "紧急", b.申请序号,
                                    To_Char(b.开始执行时间, 'yyyymmddhh24miss') "发生时间", b.开嘱科室id As "开嘱科室ID", e.名称 As "开嘱科室",
                                    f.Id As "开嘱医生ID", b.开嘱医生, b.执行科室id As "会诊科室ID", d.名称 会诊科室, c.发送人 As "记录人") As Content
                  From 诊疗项目目录 A, 病人医嘱记录 B, 病人医嘱发送 C, 部门表 D, 部门表 E, 人员表 F
                  Where (a.类别 = 'Z' And a.操作类型 = '7') And a.Id = b.诊疗项目id And b.Id = c.医嘱id And b.相关id Is Null And
                        b.病人id = 病人id_In And b.主页id = 主页id_In And b.执行科室id = d.Id And b.开嘱科室id = e.Id And
                        Decode(Instr(b.开嘱医生, '/'), 0, b.开嘱医生, Substr(b.开嘱医生, 0, Instr(b.开嘱医生, '/') - 1)) = f.姓名 And
                        b.开始执行时间 + 0 > 开始时间_In
                  Order By b.病人id, b.主页id, b.开始执行时间) Loop
      If n_单一任务 = 0 Or Instr(v_申请序号, ',' || r_Row.申请序号 || ',') = 0 Then
        If r_Row.申请序号 Is Not Null Then
          v_申请序号 := v_申请序号 || r_Row.申请序号 || ',';
        End If;
        x_Detail := r_Row.Content;
        Select Zl_Replace_Element_Value('会诊范围', 病人id_In, 主页id_In, 2, r_Row.Id) Into v_会诊范围 From Dual;
        If v_会诊范围 Is Not Null Then
          Select Zl_Replace_Element_Value('会诊邀请医院', 病人id_In, 主页id_In, 2, r_Row.Id) Into v_邀请医院 From Dual;
          Select Zl_Replace_Element_Value('会诊邀请科室', 病人id_In, 主页id_In, 2, r_Row.Id) Into v_邀请科室 From Dual;
          Select Zl_Replace_Element_Value('会诊医生级别', 病人id_In, 主页id_In, 2, r_Row.Id) Into v_医生级别 From Dual;
          Select Zl_Replace_Element_Value('会诊邀请医生', 病人id_In, 主页id_In, 2, r_Row.Id) Into v_邀请医生 From Dual;
          Select Zl_Replace_Element_Value('会诊诊断', 病人id_In, 主页id_In, 2, r_Row.Id) Into v_会诊诊断 From Dual;
          Select Zl_Replace_Element_Value('会诊目的', 病人id_In, 主页id_In, 2, r_Row.Id) Into v_会诊目的 From Dual;
          Select Zl_Replace_Element_Value('会诊代表科室', 病人id_In, 主页id_In, 2, r_Row.Id) Into v_代表科室 From Dual;
          If v_代表科室 Is Not Null Then
            Select ID Into v_代表科室id From 部门表 Where 名称 = v_代表科室;
          End If;
        End If;
        Select Xmlelement("item",
                           Xmlforest(r_Row.开始时间 As "开始时间", '会诊' As "活动名称", v_邀请医院 As "会诊邀请医院", v_邀请科室 As "会诊邀请科室",
                                      v_医生级别 As "会诊医生级别", v_邀请医生 As "会诊邀请医生", v_会诊诊断 As "会诊诊断", v_会诊目的 As "会诊目的",
                                      v_会诊意见 As "会诊意见", v_完成时间 As "会诊完成时间", v_完成科室 As "会诊完成科室", v_会诊医生 As "会诊医生",
                                      x_Detail As "detail", 1 As "序号"))
        Into x_Detail
        From Dual;
        If v_代表科室 Is Not Null Then
          Select Updatexml(x_Detail, '/item/会诊科室', v_代表科室) Into x_Detail From Dual;
          Select Updatexml(x_Detail, '/item/会诊科室ID', v_代表科室id) Into x_Detail From Dual;
        End If;
        Select Appendchildxml(a_List, 'root', x_Detail) Into a_List From Dual;
      End If;
    End Loop;
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_会诊;
  --读取转科事件
  Procedure p_转科
  (
    病人id_In   In 病人变动记录.病人id%Type,
    主页id_In   In 病人变动记录.主页id%Type,
    开始时间_In In Date,
    a_List      In Out Xmltype
  ) Is
  Begin
    For r_Row In (Select To_Char(a.开始时间, 'yyyymmddhh24miss') As 开始时间,
                         Xmlforest('BD_' || a.Id As "ID", a.病人id As "病人ID", a.科室id As "转入科室ID", f.名称 As "转入科室",
                                    a.经治医师 As "新经治", b.Id As "新经治ID", a.主治医师 As "新主治", c.Id As "新主治ID", a.主任医师 As "新主任",
                                    d.Id As "新主任ID", a.病区id As "新病区ID", g.名称 As "新病区", e.Id As "新护士ID", a.责任护士 As "新护士",
                                    a.床号, To_Char(a.开始时间, 'yyyymmddhh24miss') "发生时间", a.操作员姓名 As "记录人") As Content
                  From 病人变动记录 A, 人员表 B, 人员表 C, 人员表 D, 部门表 F, 人员表 E, 部门表 G
                  Where a.病人id = 病人id_In And a.主页id = 主页id_In And a.开始原因 = 3 And Nvl(a.附加床位, 0) = 0 And
                        a.开始时间 Is Not Null And a.科室id = f.Id And a.经治医师 = b.姓名(+) And a.主治医师 = c.姓名(+) And
                        a.主任医师 = d.姓名(+) And a.病区id = g.Id(+) And a.责任护士 = e.姓名(+) And a.开始时间 + 0 > 开始时间_In
                  Order By a.病人id, a.主页id, a.终止时间) Loop
      Select Appendchildxml(a_List, 'root',
                             Xmlelement("item",
                                         Xmlforest(r_Row.开始时间 As "开始时间", '转科' As "活动名称", r_Row.Content As "detail",
                                                    2 As "序号")))
      Into a_List
      From Dual;
    End Loop;
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_转科;
  --读取出院事件
  Procedure p_出院
  (
    病人id_In   In 病人变动记录.病人id%Type,
    主页id_In   In 病人变动记录.主页id%Type,
    开始时间_In In Date,
    a_List      In Out Xmltype
  ) Is
    x_Detail  Xmltype;
    n_Feature Number;
  Begin
    For r_Row In (Select To_Char(Decode(e.开始原因, 10, e.开始时间, e.终止时间), 'yyyymmddhh24miss') As 开始时间,
                         Xmlforest('CY_' || e.Id As "ID", a.病人id As "病人ID", e.操作员姓名 As "记录人",
                                    To_Char(Decode(e.开始原因, 10, e.开始时间, e.终止时间), 'yyyymmddhh24miss') As "发生时间",
                                    e.科室id As "病人科室ID", b.名称 病人科室, f.Id As "经治医师ID", e.经治医师, g.Id As "主治医师ID", e.主治医师, e.床号,
                                    h.Id As "主任医师ID", e.主任医师, a.出院科室id As "开嘱科室ID", b.名称 开嘱科室, a.住院医师 开嘱医生, a.出院方式, a.住院天数,
                                    Decode(Trunc(Decode(e.开始原因, 10, e.开始时间, e.终止时间) - a.入院日期), 0, '是', '否') 当天出院) As Content
                  From (Select Nvl(a.Id, b.Id) ID
                         From (Select Max(ID) ID
                                From 病人变动记录
                                Where 病人id = 病人id_In And 主页id = 主页id_In And 开始原因 = 10 And Nvl(附加床位, 0) = 0 And
                                      开始时间 <> 开始时间_In) A,
                              (Select Max(ID) ID
                                From 病人变动记录
                                Where 病人id = 病人id_In And 主页id = 主页id_In And 终止原因 = 1 And Nvl(附加床位, 0) = 0 And
                                      终止时间 <> 开始时间_In) B) C, 病人变动记录 E, 部门表 B, 病案主页 A, 人员表 F, 人员表 G, 人员表 H
                  Where e.Id = c.Id And e.科室id = b.Id And a.病人id = e.病人id And a.主页id = e.主页id And e.经治医师 = f.姓名(+) And
                        e.主治医师 = g.姓名(+) And e.主任医师 = h.姓名(+)
                  Order By e.开始时间) Loop
      x_Detail  := r_Row.Content;
      n_Feature := 0;
      Select Count(b.出院情况)
      Into n_Feature
      From 病案主页 A, 病人诊断记录 B
      Where a.病人id = 病人id_In And a.主页id = 主页id_In And a.病人id = b.病人id And a.主页id = b.主页id And b.记录来源 = 3 And
            b.诊断类型 In (3, 13) And b.出院情况 = '死亡' And b.编码序号 = 1 And Rownum < 2;
      If n_Feature = 0 Then
        Select Count(b.切口)
        Into n_Feature
        From 病案主页 A, 病人手麻记录 B
        Where a.病人id = 病人id_In And a.主页id = 主页id_In And a.病人id = b.病人id And a.主页id = b.主页id And b.记录来源 = 3 And
              b.切口 = 'Ⅰ' And Rownum < 2;
        If n_Feature = 1 Then
          --手术I类切口特征标志
          n_Feature := 2;
        End If;
      End If;
      Select Xmlconcat(x_Detail, Xmlelement("特征信息", n_Feature)) Into x_Detail From Dual;
      Select Appendchildxml(a_List, 'root',
                             Xmlelement("item",
                                         Xmlforest(r_Row.开始时间 As "开始时间", '出院' As "活动名称", x_Detail As "detail", 99 As "序号")))
      Into a_List
      From Dual;
    End Loop;
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_出院;
  --读取医护变更事件
  Procedure p_医护变更
  (
    病人id_In   In 病人变动记录.病人id%Type,
    主页id_In   In 病人变动记录.主页id%Type,
    开始时间_In In Date,
    a_List      In Out Xmltype
  ) Is
    x_Detail Xmltype;
  Begin
    For r_Row In (Select a.病人id, a.主页id, a.终止时间 As 开始时间, a.终止原因, a.科室id, a.护理等级id,
                         Xmlforest(a.病人id As "病人ID", a.主页id As "主页ID", To_Char(a.终止时间, 'yyyymmddhh24miss') "发生时间",
                                    a.操作员姓名 As "记录人", a.科室id As "科室ID", b.名称 病人科室, a.经治医师, c.Id As "经治医师ID", a.主治医师,
                                    d.Id As "主治医师ID", a.主任医师, e.Id As "主任医师ID") As Content
                  From 病人变动记录 A, 部门表 B, 人员表 C, 人员表 D, 人员表 E
                  Where a.病人id = 病人id_In And a.主页id = 主页id_In And a.终止原因 In (7, 8, 11, 12) And Nvl(a.附加床位, 0) = 0 And
                        a.科室id = b.Id(+) And a.经治医师 = c.姓名(+) And a.主治医师 = d.姓名(+) And a.主任医师 = e.姓名(+) And
                        a.终止时间 > 开始时间_In
                  Order By a.终止时间) Loop
      x_Detail := r_Row.Content;
      Select Xmlconcat(Xmlforest('BD_' || a.Id As "ID", a.经治医师 As "新经治", b.Id As "新经治ID", a.主治医师 As "新主治",
                                  c.Id As "新主治ID", a.主任医师 As "新主任", d.Id As "新主任ID", a.责任护士 As "新护士", e.Id As "新护士ID",
                                  a.病区id As "新病区ID", a.床号, f.名称 As "新病区"), x_Detail)
      Into x_Detail
      From 病人变动记录 A, 人员表 B, 人员表 C, 人员表 D, 人员表 E, 部门表 F
      Where a.病人id = r_Row.病人id And a.主页id = r_Row.主页id And a.开始原因 = r_Row.终止原因 And a.开始时间 = r_Row.开始时间 And
            a.科室id = r_Row.科室id And Nvl(a.附加床位, 0) = 0 And Nvl(a.护理等级id, 0) = Nvl(r_Row.护理等级id, 0) And a.经治医师 = b.姓名(+) And
            a.主治医师 = c.姓名(+) And a.主任医师 = d.姓名(+) And a.责任护士 = e.姓名(+) And a.病区id = f.Id(+) And Rownum = 1
      Order By a.病人id, a.主页id, a.终止时间;
      Select Appendchildxml(a_List, 'root',
                             Xmlelement("item",
                                         Xmlforest(To_Char(r_Row.开始时间, 'yyyymmddhh24miss') As "开始时间", '医护变更' As "活动名称",
                                                    x_Detail As "detail", 3 As "序号")))
      Into a_List
      From Dual;
    End Loop;
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_医护变更;
  --读取病情变更活动
  Procedure p_病情变更
  (
    病人id_In   In 病人变动记录.病人id%Type,
    主页id_In   In 病人变动记录.主页id%Type,
    开始时间_In In Date,
    a_List      In Out Xmltype
  ) Is
    x_Detail Xmltype;
  Begin
    For r_Row In (Select a.病人id, a.主页id, a.开始时间 As 开始时间, a.科室id, a.护理等级id,
                         Xmlforest('BD_' || a.Id As "ID", a.病人id As "病人ID", a.主页id As "主页ID",
                                    To_Char(a.开始时间, 'yyyymmddhh24miss') As "发生时间", a.科室id "病人科室ID", b.名称 病人科室,
                                    c.Id As "经治医师ID", a.经治医师, d.Id As "主治医师ID", a.主治医师, e.Id As "主任医师ID", a.主任医师,
                                    f.编码 As "新病情编码", a.病情 As "新病情", a.操作员姓名 As "记录人") As Content
                  From 病人变动记录 A, 部门表 B, 人员表 C, 人员表 D, 人员表 E, 病情 F
                  Where a.开始原因 = 13 And a.病人id = 病人id_In And a.主页id = 主页id_In And Nvl(a.附加床位, 0) = 0 And a.科室id = b.Id And
                        a.经治医师 = c.姓名(+) And a.主治医师 = d.姓名(+) And a.主任医师 = e.姓名(+) And a.病情 = f.名称(+) And
                        a.开始时间 + 0 > 开始时间_In
                  Order By a.病人id, a.主页id, a.开始时间) Loop
      x_Detail := r_Row.Content;
      Select Xmlconcat(x_Detail, Xmlforest(b.编码 病情编码, a.病情))
      Into x_Detail
      From 病人变动记录 A, 病情 B
      Where a.终止原因 = 13 And a.病人id = r_Row.病人id And a.主页id = r_Row.主页id And a.终止时间 = r_Row.开始时间 And Nvl(a.附加床位, 0) = 0 And
            a.科室id = r_Row.科室id And Nvl(a.护理等级id, 0) = Nvl(r_Row.护理等级id, 0) And a.病情 = b.名称(+) And Rownum = 1
      Order By a.病人id, a.主页id;
      Select Appendchildxml(a_List, 'root',
                             Xmlelement("item",
                                         Xmlforest(To_Char(r_Row.开始时间, 'yyyymmddhh24miss') As "开始时间", '病情变更' As "活动名称",
                                                    x_Detail As "detail", 4 As "序号")))
      Into a_List
      From Dual;
    End Loop;
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_病情变更;
  --读取抢救事件
  Procedure p_抢救
  (
    病人id_In   In 病人医嘱记录.病人id%Type,
    主页id_In   In 病人医嘱记录.主页id%Type,
    开始时间_In In Date,
    a_List      In Out Xmltype
  ) Is
    x_Detail Xmltype;
  Begin
    For r_Row In (Select a.病人id, a.主页id, h.医嘱id, h.发送号, a.病人来源, a.挂号单, To_Char(a.开始执行时间, 'yyyymmddhh24miss') As 开始时间,
                         Xmlforest('YZ_' || a.Id As "ID", a.病人id As "病人ID", To_Char(a.开始执行时间, 'yyyymmddhh24miss') "发生时间",
                                    a.执行科室id As "执行科室ID", g.名称 执行科室, a.开嘱科室id As "开嘱科室ID", i.名称 As "开嘱科室", j.Id As "开嘱医生ID",
                                    a.开嘱医生, l.Id As "项目ID", l.名称 As 项目名称, h.发送人 As "记录人") As Content
                  From 诊疗项目目录 L, 病人医嘱记录 A, 病人医嘱发送 H, 部门表 G, 部门表 I, 人员表 J
                  Where (l.类别 = 'Z' And l.操作类型 = '8') And l.Id = a.诊疗项目id And a.Id = h.医嘱id And a.病人id = 病人id_In And
                        a.主页id = 主页id_In And a.执行科室id = g.Id And a.开嘱科室id = i.Id And
                        Decode(Instr(a.开嘱医生, '/'), 0, a.开嘱医生, Substr(a.开嘱医生, 0, Instr(a.开嘱医生, '/') - 1)) = j.姓名 And
                        a.开始执行时间 + 0 > 开始时间_In
                  Order By a.病人id, a.主页id) Loop
      x_Detail := r_Row.Content;
      Begin
        Select Xmlconcat(x_Detail, Xmlforest(b.Id "执行人ID", a.执行人 As "执行人"))
        Into x_Detail
        From 病人医嘱执行 A, 人员表 B
        Where a.医嘱id = r_Row.医嘱id And a.发送号 = r_Row.发送号 And a.执行人 = b.姓名;
      Exception
        When Others Then
          Null;
      End;
      If r_Row.病人来源 = 2 Then
        Select Xmlconcat(x_Detail, Xmlforest('否' As "急诊"))
        Into x_Detail
        From 病案主页
        Where 病人id = r_Row.病人id And 主页id = r_Row.主页id;
      Else
        Select Xmlconcat(x_Detail, Xmlforest(Decode(急诊, 0, '否', '是') As "急诊"))
        Into x_Detail
        From 病人挂号记录
        Where 病人id = r_Row.病人id And NO = r_Row.挂号单;
      End If;
      Select Appendchildxml(a_List, 'root',
                             Xmlelement("item",
                                         Xmlforest(r_Row.开始时间 As "开始时间", '抢救' As "活动名称", x_Detail As "detail", 5 As "序号")))
      Into a_List
      From Dual;
    End Loop;
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_抢救;
  --读取死亡事件
  Procedure p_死亡
  (
    病人id_In   In 病人医嘱记录.病人id%Type,
    主页id_In   In 病人医嘱记录.主页id%Type,
    开始时间_In In Date,
    a_List      In Out Xmltype
  ) Is
    x_Detail Xmltype;
  Begin
    For r_Row In (Select a.病人id, a.主页id, a.病人来源, a.挂号单, To_Char(a.开始执行时间, 'yyyymmddhh24miss') As 开始时间,
                         Xmlforest('YZ_' || a.Id As "ID", a.病人id As "病人ID", To_Char(a.开始执行时间, 'yyyymmddhh24miss') "发生时间",
                                    a.开嘱科室id As "开嘱科室ID", i.名称 As "开嘱科室", j.Id As "开嘱医生ID", a.开嘱医生, h.发送人 As "记录人") As Content
                  From 诊疗项目目录 L, 病人医嘱记录 A, 病人医嘱发送 H, 部门表 I, 人员表 J
                  Where (l.类别 = 'Z' And l.操作类型 = '11') And l.Id = a.诊疗项目id And a.Id = h.医嘱id And a.病人id = 病人id_In And
                        a.主页id = 主页id_In And a.开嘱科室id = i.Id And
                        Decode(Instr(a.开嘱医生, '/'), 0, a.开嘱医生, Substr(a.开嘱医生, 0, Instr(a.开嘱医生, '/') - 1)) = j.姓名 And
                        a.开始执行时间 + 0 > 开始时间_In
                  Order By a.病人id, a.主页id) Loop
      x_Detail := r_Row.Content;
      If r_Row.病人来源 = 2 Then
        Select Xmlconcat(x_Detail, Xmlforest(Decode(Trunc(Sysdate - 入院日期), 0, '是', '否') As "入院当天死亡", '否' As "急诊"))
        Into x_Detail
        From 病案主页
        Where 病人id = r_Row.病人id And 主页id = r_Row.主页id;
      Else
        Select Xmlconcat(x_Detail,
                          Xmlforest(Decode(Trunc(Sysdate - 登记时间), 0, '是', '否') As "入院当天死亡",
                                     Decode(急诊, 0, '否', '是') As "急诊"))
        Into x_Detail
        From 病人挂号记录
        Where 病人id = r_Row.病人id And NO = r_Row.挂号单;
      End If;
      Select Appendchildxml(a_List, 'root',
                             Xmlelement("item",
                                         Xmlforest(r_Row.开始时间 As "开始时间", '死亡' As "活动名称", x_Detail As "detail", 6 As "序号")))
      Into a_List
      From Dual;
    End Loop;
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_死亡;
  --读取分娩事件
  Procedure p_新生儿
  (
    病人id_In   In 病人新生儿记录.病人id%Type,
    主页id_In   In 病人新生儿记录.主页id%Type,
    开始时间_In In Date,
    a_List      In Out Xmltype
  ) Is
    v_Sql Varchar2(2000);
    Type Cutype Is Ref Cursor;
    Cv         Cutype;
    v_开始时间 Varchar2(20);
    x_Content  Xmltype;
  Begin
    --兼容原来无登记时间字段的his版本，使用动态sql
    v_Sql := 'Select To_Char(Nvl(a.登记时间, a.出生时间),' || Chr(39) || 'yyyymmddhh24miss' || Chr(39) ||
             ') As 开始时间,
       Xmlforest(a.病人id ||' || Chr(39) || '_' || Chr(39) || '|| a.主页id ||' || Chr(39) || '_' || Chr(39) ||
             '|| a.序号 As ID, a.病人id As 病人ID,
                  To_Char(Nvl(a.登记时间, a.出生时间),' || Chr(39) || 'yyyymmddhh24miss' || Chr(39) ||
             ') As 发生时间, To_Char(a.出生时间,' || Chr(39) || 'yyyymmddhh24miss' || Chr(39) ||
             ') As 出生时间,
                  a.婴儿姓名, g.编码 婴儿性别编码, a.婴儿性别, a.分娩次数, a.分娩方式, b.编码 As 分娩方式编码) As Content
                  From 病人新生儿记录 A, 性别 G, 分娩方式 B
                  Where a.病人id = :Patiid And a.主页id = :Pageid And a.婴儿性别 = g.名称 And a.分娩方式 = b.名称 And Nvl(a.登记时间, a.出生时间) > :begintime
                  Order By a.病人id';
    Open Cv For v_Sql
      Using 病人id_In, 主页id_In, 开始时间_In;
    Loop
      Fetch Cv
        Into v_开始时间, x_Content;
      Exit When Cv%NotFound;
      Select Appendchildxml(a_List, 'root',
                             Xmlelement("item",
                                         Xmlforest(v_开始时间 As "开始时间", '新生儿' As "活动名称", x_Content As "detail", 7 As "序号")))
      Into a_List
      From Dual;
    End Loop;
  Exception
    When Others Then
      Begin
        For r_Row In (Select To_Char(a.出生时间, 'yyyymmddhh24miss') As 开始时间,
                             Xmlforest(a.病人id || '_' || a.主页id || '_' || a.序号 As "ID", a.病人id As "病人ID",
                                        To_Char(a.出生时间, 'yyyymmddhh24miss') As "发生时间",
                                        To_Char(a.出生时间, 'yyyymmddhh24miss') As "出生时间", a.婴儿姓名, g.编码 婴儿性别编码, a.婴儿性别, a.分娩次数,
                                        a.分娩方式, b.编码 As "分娩方式编码") As Content
                      From 病人新生儿记录 A, 性别 G, 分娩方式 B
                      Where a.病人id = 病人id_In And a.主页id = 主页id_In And a.婴儿性别 = g.名称 And a.分娩方式 = b.名称 And
                            a.出生时间 > 开始时间_In
                      Order By a.病人id) Loop
          Select Appendchildxml(a_List, 'root',
                                 Xmlelement("item",
                                             Xmlforest(r_Row.开始时间 As "开始时间", '新生儿' As "活动名称", r_Row.Content As "detail",
                                                        7 As "序号")))
          Into a_List
          From Dual;
        End Loop;
      Exception
        When Others Then
          zl_ErrorCenter(SQLCode, SQLErrM);
      End;
  End p_新生儿;
  --读取手术事件
  Procedure p_手术
  (
    病人id_In   In 病人医嘱记录.病人id%Type,
    主页id_In   In 病人医嘱记录.主页id%Type,
    开始时间_In In Date,
    a_List      In Out Xmltype
  ) Is
    d_Start  Date := Sysdate;
    x_Detail Xmltype;
  Begin
    For r_Row In (Select a.病人id, a.主页id, a.病人来源, a.挂号单, To_Char(a.开始执行时间, 'yyyymmddhh24miss') As 开始时间, a.开始执行时间,
                         Xmlforest('YZ_' || a.Id As "ID", a.病人id As "病人ID",
                                    To_Char(a.开始执行时间, 'yyyymmddhh24miss') As "发生时间", a.开嘱科室id As "开嘱科室ID", d.名称 As "开嘱科室",
                                    a.执行科室id As "执行科室ID", f.名称 As "执行科室", a.开嘱医生, e.Id As "开嘱医生ID", a.诊疗项目id As "诊疗项目ID",
                                    c.名称 As "诊疗项目", b.发送人 As "记录人") As Content
                  From 病人医嘱记录 A, 病人医嘱发送 B, 诊疗项目目录 C, 部门表 D, 人员表 E, 部门表 F
                  Where a.病人id = 病人id_In And a.主页id = 主页id_In And a.Id = b.医嘱id And a.相关id Is Null And a.诊疗项目id = c.Id And
                        c.类别 = 'F' And a.开嘱科室id = d.Id And a.执行科室id = f.Id And
                        Decode(Instr(a.开嘱医生, '/'), 0, a.开嘱医生, Substr(a.开嘱医生, 0, Instr(a.开嘱医生, '/') - 1)) = e.姓名 And
                        a.开始执行时间 + 0 > 开始时间_In
                  Order By a.开始执行时间, a.手术时间) Loop
      --相同执行时间的认为是一台手术
      If d_Start <> r_Row.开始执行时间 Then
        x_Detail := r_Row.Content;
        If r_Row.病人来源 = 2 Then
          Select Xmlconcat(x_Detail, Xmlforest('否' As "急诊"))
          Into x_Detail
          From 病案主页
          Where 病人id = r_Row.病人id And 主页id = r_Row.主页id;
        Else
          Select Xmlconcat(x_Detail, Xmlforest(Decode(急诊, 0, '否', '是') As "急诊"))
          Into x_Detail
          From 病人挂号记录
          Where 病人id = r_Row.病人id And NO = r_Row.挂号单;
        End If;
        Select Appendchildxml(a_List, 'root',
                               Xmlelement("item",
                                           Xmlforest(r_Row.开始时间 As "开始时间", '手术' As "活动名称", x_Detail As "detail", 8 As "序号")))
        Into a_List
        From Dual;
      End If;
      d_Start := r_Row.开始执行时间;
    End Loop;
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_手术;
  --读取治疗事件
  Procedure p_特殊治疗
  (
    病人id_In   In 病人医嘱记录.病人id%Type,
    主页id_In   In 病人医嘱记录.主页id%Type,
    开始时间_In In Date,
    a_List      In Out Xmltype
  ) Is
    x_Detail Xmltype;
  Begin
    For r_Row In (Select a.病人id, a.主页id, a.病人来源, a.挂号单, To_Char(a.开始执行时间, 'yyyymmddhh24miss') As 开始时间,
                         Xmlforest('YZ_' || a.Id As "ID", a.病人id As "病人ID", To_Char(a.开始执行时间, 'yyyymmddhh24miss') "发生时间",
                                    g.Id As "治疗项目ID", g.名称 治疗项目, a.开嘱科室id As "开嘱科室ID", i.名称 As "开嘱科室", j.Id As "开嘱医生ID",
                                    a.开嘱医生, h.执行部门id As "执行科室ID", b.名称 As 执行科室, h.发送人 As "记录人") As Content
                  From 病人医嘱发送 H, 病人医嘱记录 A, 诊疗项目目录 G, 部门表 I, 人员表 J, 部门表 B
                  Where a.病人id = 病人id_In And a.主页id = 主页id_In And h.医嘱id = a.Id And a.诊疗项目id = g.Id And
                        (g.类别 = 'E' And g.操作类型 = '5') And
                        Nvl(g.撤档时间, To_Date('3000-01-01', 'yyyy-mm-dd')) = To_Date('3000-01-01', 'yyyy-mm-dd') And
                        a.开嘱科室id = i.Id And
                        Decode(Instr(a.开嘱医生, '/'), 0, a.开嘱医生, Substr(a.开嘱医生, 0, Instr(a.开嘱医生, '/') - 1)) = j.姓名 And
                        h.执行部门id = b.Id And a.开始执行时间 + 0 > 开始时间_In And a.相关id Is Null
                  Order By a.病人id, a.开始执行时间) Loop
      x_Detail := r_Row.Content;
      If r_Row.病人来源 = 2 Then
        Select Xmlconcat(x_Detail, Xmlforest('否' As "急诊"))
        Into x_Detail
        From 病案主页
        Where 病人id = r_Row.病人id And 主页id = r_Row.主页id;
      Else
        Select Xmlconcat(x_Detail, Xmlforest(Decode(急诊, 0, '否', '是') As "急诊"))
        Into x_Detail
        From 病人挂号记录
        Where 病人id = r_Row.病人id And NO = r_Row.挂号单;
      End If;
      Select Appendchildxml(a_List, 'root',
                             Xmlelement("item",
                                         Xmlforest(r_Row.开始时间 As "开始时间", '特殊治疗' As "活动名称", x_Detail As "detail", 9 As "序号")))
      Into a_List
      From Dual;
    End Loop;
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_特殊治疗;
  --读取麻醉事件
  Procedure p_麻醉
  (
    病人id_In   In 病人医嘱记录.病人id%Type,
    主页id_In   In 病人医嘱记录.主页id%Type,
    开始时间_In In Date,
    a_List      In Out Xmltype
  ) Is
    x_Detail Xmltype;
  Begin
    For r_Row In (Select a.病人id, a.主页id, a.病人来源, a.挂号单, To_Char(a.开始执行时间, 'yyyymmddhh24miss') As 开始时间,
                         Xmlforest('YZ_' || a.Id As "ID", a.病人id As "病人ID",
                                    To_Char(a.开始执行时间, 'yyyymmddhh24miss') As "发生时间", a.开嘱科室id As "开嘱科室ID", d.名称 As "开嘱科室",
                                    a.开嘱医生, e.Id As "开嘱医生ID", a.执行科室id As "执行科室ID", f.名称 As 执行科室, a.诊疗项目id As "诊疗项目ID",
                                    c.名称 As "诊疗项目", b.发送人 As "记录人") As Content
                  From 病人医嘱记录 A, 病人医嘱发送 B, 诊疗项目目录 C, 部门表 D, 人员表 E, 部门表 F
                  Where a.病人id = 病人id_In And a.主页id = 主页id_In And a.Id = b.医嘱id And a.诊疗项目id = c.Id And c.类别 = 'G' And
                        a.开嘱科室id = d.Id And
                        Decode(Instr(a.开嘱医生, '/'), 0, a.开嘱医生, Substr(a.开嘱医生, 0, Instr(a.开嘱医生, '/') - 1)) = e.姓名 And
                        a.执行科室id = f.Id And a.开始执行时间 + 0 > 开始时间_In
                  Order By a.病人id) Loop
      x_Detail := r_Row.Content;
      If r_Row.病人来源 = 2 Then
        Select Xmlconcat(x_Detail, Xmlforest('否' As "急诊"))
        Into x_Detail
        From 病案主页
        Where 病人id = r_Row.病人id And 主页id = r_Row.主页id;
      Else
        Select Xmlconcat(x_Detail, Xmlforest(Decode(急诊, 0, '否', '是') As "急诊"))
        Into x_Detail
        From 病人挂号记录
        Where 病人id = r_Row.病人id And NO = r_Row.挂号单;
      End If;
      Select Appendchildxml(a_List, 'root',
                             Xmlelement("item",
                                         Xmlforest(r_Row.开始时间 As "开始时间", '麻醉' As "活动名称", x_Detail As "detail", 10 As "序号")))
      Into a_List
      From Dual;
    End Loop;
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_麻醉;
  --读取检查事件
  Procedure p_检查
  (
    病人id_In   In 病人医嘱记录.病人id%Type,
    主页id_In   In 病人医嘱记录.主页id%Type,
    开始时间_In In Date,
    a_List      In Out Xmltype
  ) Is
    x_Detail Xmltype;
  Begin
    For r_Row In (Select b.病人id, b.主页id, b.病人来源, b.挂号单, To_Char(b.开始执行时间, 'yyyymmddhh24miss') As 开始时间,
                         Xmlforest('YZ_' || b.Id As "ID", b.病人id As "病人ID", To_Char(b.开始执行时间, 'yyyymmddhh24miss') "发生时间",
                                    b.开嘱科室id As "开嘱科室ID", d.名称 开嘱科室, b.开嘱医生, f.Id As "开嘱医生ID", a.执行科室id As "执行科室ID",
                                    e.名称 执行科室, a.检查技师, g.Id As "检查技师ID", b.医嘱内容, a.检查号, a.影像类别, Nvl(h.名称, 'CR') 检查类型,
                                    a.检查设备, j.发送人 As "记录人") As Content
                  From 影像检查记录 A, 病人医嘱记录 B, 病人医嘱发送 J, 部门表 D, 部门表 E, 人员表 F, 人员表 G, 影像检查类别 H
                  Where b.病人id = 病人id_In And b.主页id = 主页id_In And j.医嘱id = b.Id And b.相关id Is Null And a.医嘱id = b.Id And
                        b.开嘱科室id = d.Id And a.执行科室id = e.Id And
                        Decode(Instr(b.开嘱医生, '/'), 0, b.开嘱医生, Substr(b.开嘱医生, 0, Instr(b.开嘱医生, '/') - 1)) = f.姓名 And
                        a.检查技师 = g.姓名 And a.影像类别 = h.编码(+) And b.开始执行时间 + 0 > 开始时间_In
                  Order By b.开嘱时间) Loop
      x_Detail := r_Row.Content;
      If r_Row.病人来源 = 2 Then
        Select Xmlconcat(x_Detail, Xmlforest('否' As "急诊"))
        Into x_Detail
        From 病案主页
        Where 病人id = r_Row.病人id And 主页id = r_Row.主页id;
      Else
        Select Xmlconcat(x_Detail, Xmlforest(Decode(急诊, 0, '否', '是') As "急诊"))
        Into x_Detail
        From 病人挂号记录
        Where 病人id = r_Row.病人id And NO = r_Row.挂号单;
      End If;
      Select Appendchildxml(a_List, 'root',
                             Xmlelement("item",
                                         Xmlforest(r_Row.开始时间 As "开始时间", '检查' As "活动名称", x_Detail As "detail", 11 As "序号")))
      Into a_List
      From Dual;
    End Loop;
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_检查;
  Procedure p_换床
  (
    病人id_In   In 病人变动记录.病人id%Type,
    主页id_In   In 病人变动记录.主页id%Type,
    开始时间_In In Date,
    a_List      In Out Xmltype
  ) Is
  Begin
    For r_Row In (Select a.病人id, a.主页id, To_Char(a.开始时间, 'yyyymmddhh24miss') As 开始时间,
                         Xmlforest('BD_' || a.Id As "ID", a.病人id As "病人ID", a.床号, a.病区id As "当前病区ID", b.名称 As "当前病区",
                                    a.责任护士, c.Id As "责任护士ID", To_Char(a.开始时间, 'yyyymmddhh24miss') As "发生时间",
                                    a.操作员姓名 As "记录人") As Content
                  From 病人变动记录 A, 部门表 B, 人员表 C
                  Where a.病人id = 病人id_In And a.主页id = 主页id_In And a.开始原因 In (4, 15) And Nvl(a.附加床位, 0) = 0 And
                        a.开始时间 + 0 > 开始时间_In And a.病区id = b.Id(+) And a.责任护士 = c.姓名(+)
                  Order By a.开始时间) Loop
      Select Appendchildxml(a_List, 'root',
                             Xmlelement("item",
                                         Xmlforest(r_Row.开始时间 As "开始时间", '换床' As "活动名称", r_Row.Content As "detail",
                                                    13 As "序号")))
      Into a_List
      From Dual;
    End Loop;
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_换床;
  Procedure p_诊断
  (
    病人id_In   In 病人变动记录.病人id%Type,
    主页id_In   In 病人变动记录.主页id%Type,
    开始时间_In In Date,
    a_List      In Out Xmltype
  ) Is
    x_Detail Xmltype;
    n_Count  Number;
  Begin
    For r_Row In (Select 病人id, 主页id, 疾病id, 诊断id, 证候id, To_Char(记录日期, 'yyyymmddhh24miss') As 开始时间,
                         Xmlforest('ZD_' || ID As "ID", 病人id As "病人ID", 诊断类型, 是否疑诊, 诊断次序,
                                    To_Char(记录日期, 'yyyymmddhh24miss') "发生时间", 记录人) As Content
                  From 病人诊断记录
                  Where 病人id = 病人id_In And 主页id = 主页id_In And 记录来源 = 3 And 编码序号 = 1 And 记录日期 > 开始时间_In
                  Order By 诊断次序) Loop
      If (Not r_Row.疾病id Is Null) Or (Not r_Row.诊断id Is Null) Then
        x_Detail := r_Row.Content;
        Begin
          If Not r_Row.疾病id Is Null Then
            Select Xmlconcat(x_Detail, Xmlforest(编码 As "疾病编码", 附码 As "疾病附码", 序号 As "序号", 类别 As "疾病类别"))
            Into x_Detail
            From 疾病编码目录
            Where ID = r_Row.疾病id;
            If Not r_Row.证候id Is Null Then
              Select Xmlconcat(x_Detail, Xmlforest(编码 As "证候编码", 名称 As "证候名称"))
              Into x_Detail
              From 疾病编码目录
              Where ID = r_Row.证候id;
            End If;
          Else
            Select Count(疾病id) Into n_Count From 疾病诊断对照 Where 诊断id = r_Row.诊断id;
            If n_Count <> 0 Then
              Select Xmlconcat(x_Detail, Xmlforest(编码 As "疾病编码", 附码 As "疾病附码", 序号 As "序号", 类别 As "疾病类别"))
              Into x_Detail
              From 疾病编码目录 A, 疾病诊断对照 B
              Where b.诊断id = r_Row.诊断id And a.Id = b.疾病id;
            Else
              Select Xmlconcat(x_Detail, Xmlforest(编码 As "诊断编码"))
              Into x_Detail
              From 疾病诊断目录
              Where ID = r_Row.诊断id;
            End If;
          End If;
          Select Appendchildxml(a_List, 'root',
                                 Xmlelement("item",
                                             Xmlforest(r_Row.开始时间 As "开始时间", '诊断' As "活动名称", x_Detail As "detail",
                                                        14 As "序号")))
          Into a_List
          From Dual;
        Exception
          When No_Data_Found Then
            Null; --下达诊断后，疾病编码被删除
        End;
      End If;
    End Loop;
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_诊断;
  --读取输血事件
  Procedure p_输血
  (
    病人id_In   In 病人医嘱记录.病人id%Type,
    主页id_In   In 病人医嘱记录.主页id%Type,
    开始时间_In In Date,
    a_List      In Out Xmltype
  ) As
    x_Detail Xmltype;
  Begin
    For r_Row In (Select b.病人id, b.主页id, b.病人来源, To_Char(b.开始执行时间, 'yyyymmddhh24miss') As 开始时间,
                         Xmlforest('YZ_' || b.Id As "ID", b.病人id As "病人ID", To_Char(b.开始执行时间, 'yyyymmddhh24miss') "发生时间",
                                    b.开嘱科室id As "开嘱科室ID", d.名称 开嘱科室, b.开嘱医生, f.Id As "开嘱医生ID", e.名称 执行科室, e.Id 执行科室id,
                                    b.医嘱内容, j.发送人 As "记录人", b.医嘱内容 As "诊疗项目", g.姓名 "执行人", g.Id "执行人ID") As Content
                  From 病人医嘱记录 B, 病人医嘱发送 J, 部门表 D, 部门表 E, 人员表 F, 人员表 G
                  Where b.病人id = 病人id_In And b.主页id = 主页id_In And j.医嘱id = b.Id And b.相关id Is Null And b.开嘱科室id = d.Id And
                        j.执行部门id = e.Id And
                        Decode(Instr(b.开嘱医生, '/'), 0, b.开嘱医生, Substr(b.开嘱医生, 0, Instr(b.开嘱医生, '/') - 1)) = f.姓名 And
                        b.开始执行时间 + 0 > 开始时间_In And j.完成人 = g.姓名 And b.诊疗类别 = 'K'
                  Order By b.开嘱时间) Loop
      x_Detail := r_Row.Content;
      Select Appendchildxml(a_List, 'root',
                             Xmlelement("item",
                                         Xmlforest(r_Row.开始时间 As "开始时间", '输血' As "活动名称", x_Detail As "detail", 15 As "序号")))
      Into a_List
      From Dual;
    End Loop;
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_输血;
  --读取危急值
  Procedure p_危急值
  (
    病人id_In   In 病人医嘱记录.病人id%Type,
    主页id_In   In 病人医嘱记录.主页id%Type,
    开始时间_In In Date,
    a_List      In Out Xmltype
  ) As
    x_Detail Xmltype;
    v_Sql    Varchar2(2000);
    Type Cutype Is Ref Cursor;
    Cv         Cutype;
    v_开始时间 Varchar2(20);
    x_Content  Xmltype;
  Begin
    --为保证低版HIS的兼容性 使用动态SQL
    v_Sql := 'Select To_Char(a.确认时间, ' || Chr(39) || 'yyyymmddhh24miss' || Chr(39) || ') As 开始时间,
                     Xmlforest(' || Chr(39) || 'WJ_' || Chr(39) ||
             ' || a.Id As "ID", a.病人id As "病人ID", a.主页id As "主页ID", Nvl(a.婴儿, 0) 婴儿, b.诊疗项目id As "诊疗项目ID",
                                c.名称 As "诊疗项目名称", a.危急值描述, a.报告科室id As "报告科室ID", d.名称 As "报告科室", f.Id As "报告人ID", a.报告人,
                                To_Char(a.报告时间, ' || Chr(39) || 'yyyymmddhh24miss' || Chr(39) ||
             ') As "报告时间", To_Char(a.确认时间, ' || Chr(39) || 'yyyymmddhh24miss' || Chr(39) ||
             ') As "发生时间", g.Id As "确认人ID", a.确认人, a.确认科室id As "确认科室ID", e.名称 As "确认科室", a.处理情况) As Content
              From 病人危急值记录 A, 病人医嘱记录 B, 诊疗项目目录 C, 部门表 D, 部门表 E, 人员表 F, 人员表 G
              Where a.病人id = :Patiid And a.主页id = :Pageid And a.是否危急值 = 1 And a.确认时间 > :Confirmtime And a.医嘱id = b.Id And
                    b.诊疗项目id = c.Id And a.报告科室id = d.Id And a.确认科室id = e.Id And a.报告人 = f.姓名 And a.确认人 = g.姓名';
    Open Cv For v_Sql
      Using 病人id_In, 主页id_In, 开始时间_In;
    Loop
      Fetch Cv
        Into v_开始时间, x_Content;
      Exit When Cv%NotFound;
      x_Detail := x_Content;
      Select Appendchildxml(a_List, 'root',
                             Xmlelement("item",
                                         Xmlforest(v_开始时间 As "开始时间", '危急值' As "活动名称", x_Detail As "detail", 16 As "序号")))
      Into a_List
      From Dual;
    End Loop;
    Close Cv;
  Exception
    When Others Then
      --为保证低版HIS的兼容性不抛出错误
      Null;
  End p_危急值;
  --提取病人活动记录
  Procedure p_Get_Action_List
  (
    病人id_In   In Number,
    主页id_In   In Number,
    开始时间_In In Date,
    a_List      In Out Xmltype
  ) As
  Begin
    --读取会诊事件
    p_会诊(病人id_In, 主页id_In, 开始时间_In, a_List);
    --读取转科事件
    p_转科(病人id_In, 主页id_In, 开始时间_In, a_List);
    --读取医护变更事件
    p_医护变更(病人id_In, 主页id_In, 开始时间_In, a_List);
    --读取病情变更活动
    p_病情变更(病人id_In, 主页id_In, 开始时间_In, a_List);
    --读取死亡事件
    p_死亡(病人id_In, 主页id_In, 开始时间_In, a_List);
    --读取抢救事件
    p_抢救(病人id_In, 主页id_In, 开始时间_In, a_List);
    --读取分娩事件
    p_新生儿(病人id_In, 主页id_In, 开始时间_In, a_List);
    --读取手术事件
    p_手术(病人id_In, 主页id_In, 开始时间_In, a_List);
    --读取换床事件，仅用于更新入院活动中的当前床号
    p_换床(病人id_In, 主页id_In, 开始时间_In, a_List);
    --读取治疗事件
    p_特殊治疗(病人id_In, 主页id_In, 开始时间_In, a_List);
    --读取诊断
    p_诊断(病人id_In, 主页id_In, 开始时间_In, a_List);
    --读取输血
    p_输血(病人id_In, 主页id_In, 开始时间_In, a_List);
    --读取麻醉
    p_麻醉(病人id_In, 主页id_In, 开始时间_In, a_List);
    --读取危急值
    p_危急值(病人id_In, 主页id_In, 开始时间_In, a_List);
    --读取出院事件
    p_出院(病人id_In, 主页id_In, 开始时间_In, a_List);
  End p_Get_Action_List;
  --提取指定时间之后的活动
  Procedure p_Get_Actioninfo_In
  (
    Val       Out Sys_Refcursor,
    Patiid_In In Number,
    Begin_In  Date,
    Pageid_In In Number
  ) As
    d_入科时间 Date;
    Ac_List    Xmltype := Xmltype('<root></root>');
  Begin
    If Begin_In Is Null Then
      --EMR无任何活动
      p_住院入院(Patiid_In, Pageid_In, Ac_List);
      Select To_Date(Extractvalue(Ac_List, '/root/item[活动名称="住院入院"][last()]/开始时间'), 'yyyy-mm-dd hh24:mi:ss')
      Into d_入科时间
      From Dual;
      p_Get_Action_List(Patiid_In, Pageid_In, d_入科时间, Ac_List);
    Else
      p_Get_Action_List(Patiid_In, Pageid_In, Begin_In, Ac_List);
    End If;
    Open Val For
      Select Ac_List As Content From Dual;
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_Get_Actioninfo_In;
  --获取门诊活动信息
  Procedure p_Get_Actioninfo_Out
  (
    Val       Out Sys_Refcursor,
    Patiid_In In Number,
    Regid_In  In Number
  ) Is
    Ac_List     Xmltype := Xmltype('<root></root>');
    Is_Transfer Number;
    --读取门诊接诊完成接诊列表,在指定时间内接诊并且完成接诊的
  Begin
    For r_Row In (Select a.登记时间 开始时间, a.病人id, a.Id,
                         Xmlforest('MZ_' || a.Id As "ID", 病人id As "病人ID", Decode(复诊, 1, '是', '否') 复诊,
                                    Decode(急诊, 1, '是', '否') 急诊, Nvl(a.转诊科室id, a.执行部门id) As "接诊科室ID", b.名称 接诊科室,
                                    c.Id As "就诊医生ID", Nvl(a.转诊医生, a.执行人) "就诊医生", To_Char(a.执行时间, 'yyyymmddhh24miss') "发生时间",
                                    To_Char(a.完成时间, 'yyyymmddhh24miss') 完成时间, a.操作员姓名 As "记录人") As Content
                  From 病人挂号记录 A, 部门表 B, 人员表 C
                  Where a.病人id = Patiid_In And a.Id = Regid_In And a.记录状态 = 1 And a.执行状态 <> -1 And
                        Nvl(a.转诊科室id, a.执行部门id) = b.Id And Nvl(a.转诊医生, a.执行人) = c.姓名) Loop
      Select Appendchildxml(Ac_List, 'root',
                             Xmlelement("item",
                                         Xmlforest(r_Row.开始时间 As "开始时间", '门诊接诊' As "活动名称", r_Row.Content As "detail",
                                                    0 As "序号")))
      Into Ac_List
      From Dual;
      p_诊断(r_Row.病人id, r_Row.Id, r_Row.开始时间, Ac_List);
    End Loop;
    Open Val For
      Select Ac_List As Content From Dual;
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_Get_Actioninfo_Out;
  --确认ID是否存在
  Procedure p_Validation_Exist
  (
    Val        Out Sys_Refcursor,
    Content_In In Xmltype
  ) As
    Pt_List Xmltype := Xmltype('<root><delete></delete><update></update></root>');
    n_Hisid Number;
  Begin
    For Rs In (Select To_Number(Substr(Nvl(b.Hisid, 'BD_0'), 4)) Hisid, b.Emrid, To_Number(Nvl(b.病人id, 0)) Patiid
               From (Select Content_In As Content From Dual) A,
                    Xmltable('/root/item' Passing a.Content Columns "HISID" Varchar2(32) Path '/item/hisid',
                              "EMRID" Varchar2(32) Path '/item/emrid', "病人ID" Varchar2(32) Path '/item/patiid') B) Loop
      If Rs.Patiid <> 0 Then
        Select Nvl(Nvl(a.Id, b.Id), 0) ID
        Into n_Hisid
        From (Select Max(ID) ID From 病人变动记录 Where 病人id = Rs.Patiid And 开始原因 = 2 And Nvl(附加床位, 0) = 0) A,
             (Select Max(ID) ID From 病人变动记录 Where 病人id = Rs.Patiid And 开始原因 = 1 And Nvl(附加床位, 0) = 0) B;
        If n_Hisid = 0 Then
          --该病人删除，或撤销入院
          Select Appendchildxml(Pt_List, 'root/delete', Xmlelement("item", Xmlforest(Rs.Emrid As "emrid")))
          Into Pt_List
          From Dual;
        Elsif Rs.Hisid <> n_Hisid Then
          --该病人撤销入院再入院,ID变更
          Select Appendchildxml(Pt_List, 'root/update',
                                 Xmlelement("item", Xmlforest(Rs.Emrid As "emrid", 'BD_' || n_Hisid As "hisid")))
          Into Pt_List
          From Dual;
        End If;
      End If;
    End Loop;
    Open Val For
      Select Pt_List As Content From Dual;
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_Validation_Exist;
  --读取HIS片段
  Procedure p_Get_His_Fragment(Val Out Sys_Refcursor) As
    v_Classtitle Clob;
    v_Class      Clob;
    v_Sentence   Clob;
    v_Title      Clob;
    v_Content    Clob;
    v_Leaf       Clob;
    v_Utext      Clob;
    v_Element    Clob;
    v_Preoutline Clob;
    v_Author     Clob;
    v_Subject    Clob;
    n_Prenum     Number;
    n_Contentnum Number;
    n_Iselement  Number;
    v_Phrtitle   Varchar2(1000);
    --因为HIS片段会有些特殊字符，需要替换
    --替换词句分类，和词句名称中的特殊符号 ~,!,@,#,$,%,^,&,*,(,),[,],{,},_,+,|,=,-,`,;,'',",:,/,.,<,>,?
    Function Get_Title(Title_In In Varchar2) Return Varchar2 Is
      v_Title Varchar2(60);
    Begin
      If Length(Title_In) > 0 Then
        v_Title := Replace(Title_In, Chr(38), '');
        v_Title := Replace(v_Title, '<', '');
        v_Title := Replace(v_Title, '"', '');
        v_Title := Replace(v_Title, '~', '');
        v_Title := Replace(v_Title, '!', '');
        v_Title := Replace(v_Title, '@', '');
        v_Title := Replace(v_Title, '#', '');
        v_Title := Replace(v_Title, '$', '');
        v_Title := Replace(v_Title, '%', '');
        v_Title := Replace(v_Title, '^', '');
        v_Title := Replace(v_Title, '*', '');
        v_Title := Replace(v_Title, '(', '');
        v_Title := Replace(v_Title, ')', '');
        v_Title := Replace(v_Title, '[', '');
        v_Title := Replace(v_Title, ']', '');
        v_Title := Replace(v_Title, '_', '');
        v_Title := Replace(v_Title, '+', '');
        v_Title := Replace(v_Title, '=', '');
        v_Title := Replace(v_Title, '|', '');
        v_Title := Replace(v_Title, '-', '');
        v_Title := Replace(v_Title, '`', '');
        v_Title := Replace(v_Title, ';', '');
        v_Title := Replace(v_Title, '''', '');
        v_Title := Replace(v_Title, ':', '');
        v_Title := Replace(v_Title, '/', '');
        v_Title := Replace(v_Title, '\', '');
        v_Title := Replace(v_Title, '.', '');
        v_Title := Replace(v_Title, '>', '');
        v_Title := Replace(v_Title, '?', '');
        v_Title := Replace(v_Title, '{', '');
        v_Title := Replace(v_Title, '}', '');
        Return Replace(v_Title, ',', '');
      End If;
    End;
    --替换词句内容中的特殊符号
    Function Get_Content(Content_In In Clob) Return Clob Is
      v_Utext Clob;
    Begin
      If Length(Content_In) > 0 Then
        v_Utext := Regexp_Replace(Content_In, Chr(38), Chr(38) || 'amp;');
        v_Utext := Regexp_Replace(v_Utext, '<', Chr(38) || 'lt;');
        Return v_Utext;
      End If;
    End;
  Begin
    For Rs_Class In (Select ID, 上级id, 编码, 名称, 说明, 范围 From 病历词句分类) Loop
      v_Sentence := '';
      For Rs_List In (Select a.Id, a.名称, Decode(Nvl(a.通用级, 0), 0, 2, 1, 1, 2, 0) 范围, 科室id, b.姓名
                      From 病历词句示范 A, 人员表 B
                      Where a.分类id = Rs_Class.Id And a.人员id = b.Id) Loop
        v_Content    := '';
        n_Contentnum := 0;
        n_Iselement  := 0;
        If v_Phrtitle Is Null Then
          v_Phrtitle := Rs_List.名称;
        Else
          If v_Phrtitle = Rs_List.名称 Then
            v_Phrtitle := Rs_List.名称 || '1';
          Else
            v_Phrtitle := Rs_List.名称;
          End If;
        End If;
        For Rs_Content In (Select 内容文本, 要素名称 From 病历词句组成 Where 词句id = Rs_List.Id Order By 排列次序) Loop
          n_Contentnum := n_Contentnum + 1;
          If Rs_Content.内容文本 Is Not Null Then
            v_Utext   := '<utext type="text">' || Get_Content(Rs_Content.内容文本) || '</utext>';
            v_Content := v_Content || v_Utext;
          Elsif Rs_Content.要素名称 Is Not Null Then
            v_Element   := '<utext type="element">' || Rs_Content.要素名称 || '</utext>';
            v_Content   := v_Content || v_Element;
            n_Iselement := 1;
          End If;
        End Loop;
        Select Count(*)
        Into n_Prenum
        From 病历提纲词句 A, 病历文件结构 B
        Where a.提纲id = b.Id And a.词句分类id = Rs_Class.Id;
        If n_Prenum > 1 Then
          v_Preoutline := Null;
          For Rs_Pre In (Select b.内容文本
                         From 病历提纲词句 A, 病历文件结构 B
                         Where a.提纲id = b.Id And a.词句分类id = Rs_Class.Id) Loop
            If Rs_Pre.内容文本 Is Not Null Then
              --v_Preoutline := v_Preoutline || ',' || Rs_Pre.内容文本;
              If v_Preoutline Is Not Null Then
                v_Preoutline := Rs_Pre.内容文本;
              Else
                v_Preoutline := v_Preoutline || ',' || Rs_Pre.内容文本;
              End If;
            End If;
          End Loop;
        Elsif n_Prenum = 1 Then
          Select b.内容文本
          Into v_Preoutline
          From 病历提纲词句 A, 病历文件结构 B
          Where a.提纲id = b.Id And a.词句分类id = Rs_Class.Id;
        Else
          v_Preoutline := Null;
        End If;
        v_Preoutline := '<preoutline>' || v_Preoutline || '</preoutline>';
        v_Title      := '<title>' || Rs_List.名称 || '</title>';
        v_Content    := '<content type="' || n_Iselement || '" num="' || n_Contentnum || '">' || v_Content ||
                        '</content>';
        v_Leaf       := '<leaf>' || Rs_List.范围 || '</leaf>';
        v_Subject    := '<subject>' || Rs_List.科室id || '</subject>';
        v_Author     := '<author>' || Rs_List.姓名 || '</author>';
        v_Sentence   := v_Sentence || '<sentence name="' || Get_Title(v_Phrtitle) || '">' || v_Content || v_Leaf ||
                        v_Subject || v_Author || v_Preoutline || '</sentence>';
      End Loop;
      If v_Sentence Is Not Null Then
        v_Classtitle := '<class name="' || Get_Title(Rs_Class.名称) || '">' || v_Sentence || '</class>';
        v_Class      := v_Class || v_Classtitle;
      End If;
    End Loop;
    Open Val For
      Select '<root>' || v_Class || '</root>' As x_Hisfragment From Dual;
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_Get_His_Fragment;
  --获取zlparamters参数值
  Procedure p_Get_Zlparameters
  (
    Sysnum_In     Zlparameters.系统%Type,
    Paramename_In Zlparameters.参数名%Type,
    Val           Out Sys_Refcursor
  ) As
  Begin
    Open Val For
      Select 参数值 From zlParameters Where 系统 = Sysnum_In And 参数名 = Paramename_In;
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_Get_Zlparameters;
  --按照诊断标准获取诊断信息
  Procedure p_Get_Diagnose_By_Standard
  (
    Diagnosetype_In 疾病诊断目录.类别%Type,
    Input_In        Varchar2,
    Val             Out Sys_Refcursor
  ) As
    v_Sqlstr Varchar2(500);
  Begin
    If f_Version(35, 10) = 0 Then
      --如果版本小于35.10那么直接使用sql进行查询，用于兼容老版本HIS
      If Input_In Is Not Null Then
        Open Val For
          Select Distinct r.疾病id, n.诊断id, l.编码, n.名称
          From 疾病诊断目录 L, 疾病诊断别名 N, (Select 诊断id, Min(疾病id) As 疾病id From 疾病诊断对照 Group By 诊断id) R
          Where l.Id = n.诊断id And l.类别 = Diagnosetype_In And l.Id = r.诊断id(+) And
                (l.编码 Like '%' || Input_In || '%' Or n.名称 Like '%' || Input_In || '%' Or
                n.简码 Like '%' || Input_In || '%')
          Order By l.编码;
      Else
        Open Val For
          Select Distinct r.疾病id, n.诊断id, l.编码, n.名称
          From 疾病诊断目录 L, 疾病诊断别名 N, (Select 诊断id, Min(疾病id) As 疾病id From 疾病诊断对照 Group By 诊断id) R
          Where l.Id = n.诊断id And l.类别 = Diagnosetype_In And l.Id = r.诊断id(+)
          Order By l.编码;
      End If;
    Else
      --如果版本大于等于35.10使用动态sql进行查询，用于兼容老版本HIS
      If Input_In Is Not Null Then
        v_Sqlstr := 'Select distinct r.疾病id, n.诊断id, l.编码, n.名称
        From 疾病诊断目录 L, 疾病诊断别名 N, (Select 诊断id, Min(疾病id) As 疾病id From 疾病诊断对照 Group By 诊断id) R
        Where l.Id = n.诊断id And l.类别 =:1 And l.Id = r.诊断id(+) And
              (instr(l.编码,:2)>0 Or instr(n.名称,:3)>0 Or instr(n.简码,:4)>0) And
              (l.撤档时间 Is Null Or l.撤档时间 >= To_Date(''3000-01-01'', ''YYYY-MM-DD''))
        Order By l.编码';
        Open Val For v_Sqlstr
          Using Diagnosetype_In, Input_In, Input_In, Input_In;
      Else
        v_Sqlstr := 'Select distinct r.疾病id, n.诊断id, l.编码, n.名称
        From 疾病诊断目录 L, 疾病诊断别名 N, (Select 诊断id, Min(疾病id) As 疾病id From 疾病诊断对照 Group By 诊断id) R
        Where l.Id = n.诊断id And l.类别 = :1 And l.Id = r.诊断id(+) And
              (l.撤档时间 Is Null Or l.撤档时间 >= To_Date(''3000-01-01'', ''YYYY-MM-DD''))
        Order By l.编码';
        Open Val For v_Sqlstr
          Using Diagnosetype_In;
      End If;
    End If;
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_Get_Diagnose_By_Standard;
  --按照疾病编码获取诊断信息
  Procedure p_Get_Diagnose_By_Code
  (
    Diagnosetype_In 疾病编码目录.类别%Type,
    Input_In        Varchar2,
    Val             Out Sys_Refcursor
  ) As
  Begin
    If Input_In Is Not Null Then
      Open Val For
        Select l.Id As 疾病id, r.诊断id, l.编码, l.名称
        From 疾病编码目录 L, (Select 疾病id, Min(诊断id) As 诊断id From 疾病诊断对照 Group By 疾病id) R
        Where l.类别 = Diagnosetype_In And l.Id = r.疾病id(+) And
              (l.编码 Like '%' || Input_In || '%' Or l.名称 Like '%' || Input_In || '%' Or l.简码 Like '%' || Input_In || '%') And
              (l.撤档时间 Is Null Or l.撤档时间 >= To_Date('3000-01-01', 'YYYY-MM-DD'))
        Order By l.编码;
    Else
      Open Val For
        Select l.Id As 疾病id, r.诊断id, l.编码, l.名称
        From 疾病编码目录 L, (Select 疾病id, Min(诊断id) As 诊断id From 疾病诊断对照 Group By 疾病id) R
        Where l.类别 = Diagnosetype_In And l.Id = r.疾病id(+) And
              (l.撤档时间 Is Null Or l.撤档时间 >= To_Date('3000-01-01', 'YYYY-MM-DD'))
        Order By l.编码;
    End If;
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_Get_Diagnose_By_Code;
  --按照诊断标准获取中医征候信息
  Procedure p_Get_Chn_Sign_By_Standard
  (
    Diagnoseid_In 疾病诊断参考.诊断id%Type,
    Input_In      Varchar2,
    Val           Out Sys_Refcursor
  ) As
  Begin
    If Input_In Is Not Null Then
      Open Val For
        Select Distinct 证候id, 证候序号 As 编码, 证候名称 As 名称
        From 疾病诊断参考
        Where 诊断id = Diagnoseid_In And 证候序号 Is Not Null And 证候序号 <> 0 And
              (证候名称 Like '%' || Input_In || '%' Or zlSpellCode(证候名称) Like '%' || Input_In || '%')
        Order By 证候序号;
    Else
      Open Val For
        Select Distinct 证候id, 证候序号 As 编码, 证候名称 As 名称
        From 疾病诊断参考
        Where 诊断id = Diagnoseid_In And 证候序号 Is Not Null And 证候序号 <> 0
        Order By 证候序号;
    End If;
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_Get_Chn_Sign_By_Standard;
  --按照疾病编码获取中医征候信息
  Procedure p_Get_Chn_Sign_By_Code
  (
    Input_In Varchar2,
    Val      Out Sys_Refcursor
  ) As
  Begin
    If Input_In Is Not Null Then
      Open Val For
        Select ID As 证候id, 编码, 名称
        From 疾病编码目录
        Where 类别 = 'Z' And
              (编码 Like '%' || Input_In || '%' Or 名称 Like '%' || Input_In || '%' Or 简码 Like '%' || Input_In || '%') And
              (撤档时间 Is Null Or 撤档时间 >= To_Date('3000-01-01', 'YYYY-MM-DD'))
        Order By 编码;
    Else
      Open Val For
        Select ID As 证候id, 编码, 名称
        From 疾病编码目录
        Where 类别 = 'Z' And (撤档时间 Is Null Or 撤档时间 >= To_Date('3000-01-01', 'YYYY-MM-DD'))
        Order By 编码;
    End If;
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_Get_Chn_Sign_By_Code;
  --获取his诊断
  Procedure p_Get_Diagnosis
  (
    Patiid_In  病人诊断记录.病人id%Type,
    Page_Id_In 病人诊断记录.主页id%Type,
    Type_In    病人诊断记录.诊断类型%Type,
    Val        Out Sys_Refcursor
  ) As
    v_Sql Varchar2(1000);
    v_Num Number;
  Begin
    If Type_In = 2 Or Type_In = 12 Then
      Select Count(1) Into v_Num From 病人诊断记录 A Where 病人id = Patiid_In And 主页id = Page_Id_In And 记录来源 = 3;
      If v_Num = 0 Then
        Begin
          v_Sql := 'begin Zl_病人诊断记录_首次同步(:1, :2); end;';
          Execute Immediate v_Sql
            Using In Patiid_In, In Page_Id_In;
          Commit;
        Exception
          When Others Then
            Null;
        End;
      End If;
    End If;
    Open Val For
      Select 疾病id, 诊断id, 证候id, b.编码 As 证候编码, 诊断描述, '' As 中医证候, '' As 诊断编码, 备注, 入院病情, 出院情况,
             Decode(是否未治, 0, '', 1, '√') 是否未治, Decode(是否疑诊, 0, '', 1, '?') 是否疑诊
      From 病人诊断记录 A, 疾病编码目录 B
      Where 病人id = Patiid_In And 主页id = Page_Id_In And 记录来源 = 3 And 诊断类型 = Type_In And b.类别(+) = 'Z' And
            b.Id(+) = a.证候id And Nvl(编码序号, 1) = 1
      Order By 编码序号, 诊断次序;
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_Get_Diagnosis;
  --删除病人诊断记录
  Procedure p_病人诊断记录_Delete
  (
    --功能：删除病人诊断记录
    --参数：诊断类型_IN=为空时表示所有类型,否则为字符串,如'1,2,3...'
    --      诊断s_In=需要删除的诊断ID串 ,格式为 'ID1,ID2,ID3...'
    病人id_In   病人诊断记录.病人id%Type,
    主页id_In   病人诊断记录.主页id%Type,
    诊断类型_In Varchar2 := Null
  ) Is
  Begin
    Zl_病人诊断记录_Delete(病人id_In, 主页id_In, 3, Null, 诊断类型_In);
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_病人诊断记录_Delete;
  --新增病人诊断记录
  Procedure p_病人诊断记录_Insert
  (
    病人id_In   病人诊断记录.病人id%Type,
    主页id_In   病人诊断记录.主页id%Type,
    诊断类型_In 病人诊断记录.诊断类型%Type,
    疾病id_In   病人诊断记录.疾病id%Type,
    诊断id_In   病人诊断记录.诊断id%Type,
    证候id_In   病人诊断记录.证候id%Type,
    诊断描述_In 病人诊断记录.诊断描述%Type,
    出院情况_In 病人诊断记录.出院情况%Type,
    是否未治_In 病人诊断记录.是否未治%Type,
    是否疑诊_In 病人诊断记录.是否疑诊%Type,
    诊断次序_In 病人诊断记录.诊断次序%Type := 1,
    备注_In     病人诊断记录.备注%Type := Null,
    入院病情_In 病人诊断记录.入院病情%Type := Null,
    记录人_In   病人诊断记录.记录人%Type := Null
  ) Is
  Begin
    Zl_病人诊断记录_Insert(病人id_In, 主页id_In, 3, Null, 诊断类型_In, 疾病id_In, 诊断id_In, 证候id_In, 诊断描述_In, 出院情况_In, 是否未治_In, 是否疑诊_In,
                     Sysdate(), Null, 诊断次序_In, 备注_In, 入院病情_In, Null, 记录人_In);
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_病人诊断记录_Insert;
  --判断部门是否有中医科性质
  Procedure p_Get_Is_Tcm
  (
    部门id_In 部门性质说明.部门id%Type,
    Val       Out Sys_Refcursor
  ) As
  Begin
    Open Val For
      Select 1 From 部门性质说明 Where 工作性质 = '中医科' And 部门id = 部门id_In;
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_Get_Is_Tcm;
  --获取治疗结果表数据
  Procedure p_Get_Treat_Result(Val Out Sys_Refcursor) As
  Begin
    Open Val For
      Select 编码, 名称 From 治疗结果 Order By 编码;
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_Get_Treat_Result;
  --获取病案主页是否签名
  Procedure p_Get_Mainpage_Isgign
  (
    病人id_In 病案主页从表.病人id%Type,
    主页id_In 病案主页从表.主页id%Type,
    Val       Out Sys_Refcursor
  ) As
  Begin
    Open Val For
      Select Count(*) As Issign
      From 病案主页从表
      Where 病人id = 病人id_In And 主页id = 主页id_In And
            信息名 In (Select /*+cardinality(a,4)*/
                     *
                    From Table(f_Str2list('住院医师签名,主治医师签名,主任医师签名,科主任签名')) A) And Rownum < 2;
  Exception
    When Others Then
      zl_ErrorCenter(SQLCode, SQLErrM);
  End p_Get_Mainpage_Isgign;
  --病历首次签名或撤销所有签名时更新ZLHIS数据,为兼容早期版本，不能使用表结构定义
  Procedure p_病人危急值病历_Insert
  (
    危急值id_In Number,
    文档id_In   Varchar2,
    子文档id_In Varchar2,
    标题_In     Varchar2,
    完成人_In   Varchar2,
    完成时间_In Date
  ) As
    v_Sql Varchar2(2000);
  Begin
    If 标题_In Is Null Then
      v_Sql := 'Delete 病人危急值病历 Where 危急值id = :Col1 And 文档id = :Col2 And Nvl(子文档id,' || Chr(39) || 'NL' || Chr(39) ||
               ') = :Col3';
      Execute Immediate v_Sql
        Using 危急值id_In, 文档id_In, Nvl(子文档id_In, 'NL');
    Else
      v_Sql := 'Update 病人危急值病历 Set 标题 = :Col1, 完成人 = :Col2, 完成时间 = :Col3 Where 危急值id = :Col4 And 文档id = :Col5 And Nvl(子文档id,' ||
               Chr(39) || 'NL' || Chr(39) || ') = :Col6';
      Execute Immediate v_Sql
        Using 标题_In, 完成人_In, 完成时间_In, 危急值id_In, 文档id_In, Nvl(子文档id_In, 'NL');
      If Sql%RowCount = 0 Then
        v_Sql := 'Insert Into 病人危急值病历 (危急值id, 文档id, 子文档id, 标题, 完成人, 完成时间) Values (:Col1, :Col2, :Col3, :Col4, :Col5, :Col6)';
        Execute Immediate v_Sql
          Using 危急值id_In, 文档id_In, 子文档id_In, 标题_In, 完成人_In, 完成时间_In;
      End If;
    End If;
  Exception
    When Others Then
      --为保证低版HIS的兼容性不抛出错误
      Null;
  End p_病人危急值病历_Insert;
Begin
  -- Initialization
  Null;
End b_Emr_Interface;
/

