create Package b_PACS_Common Is 
  Type t_Refcur Is Ref Cursor; 
 
--1 获取参数的缓冲数据 
Procedure p_GetParInfBuf( 
  Val           Out t_Refcur, 
  系统_In In 影像参数说明.系统%Type, 
  模块_In  In 影像参数说明.模块%Type 
  ); 
 
--2 功能：将由逗号分隔的不带引号的字符序列转换为单列数据表 
  Function f_Str2list 
  ( 
    Str_In   In Varchar2, 
    Split_In In Varchar2 := ',' 
  ) Return t_Strlist 
    Pipelined; 
 
--3  获取参数值的缓冲数据 
--当前用户所在计算机的参数值 
Procedure p_GetParValueBuf( 
  Val           Out t_Refcur, 
  系统_In In 影像参数说明.系统%Type, 
  模块_In In 影像参数说明.模块%Type, 
  科室ID_In In Varchar2, 
  机器名_In In Varchar2, 
  用户ID_In In Number); 
 
--4  获取权限的缓冲数据 
Procedure p_GetPopedomBuf( 
  Val           Out t_Refcur, 
  系统_In In 影像参数说明.系统%Type, 
  模块_IN In 影像参数说明.模块%Type, 
  用户名_In In Varchar2); 
 
--5  设置参数值 
Procedure p_SetParameterValue( 
  参数ID_In    In 影像参数取值.参数ID%Type, 
  参数标识_In In 影像参数取值.参数标识%Type, 
  参数值_In    In 影像参数取值.参数值%Type); 
 
--6  获取用户账号信息 
Function f_Get_Personal_Info_By_Account( 
	Account_In In Varchar2 
) Return Xmltype; 
 
end b_PACS_Common ;
/

