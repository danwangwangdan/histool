create Package Body b_PACS_Common  Is 
 
--1 获取参数的缓冲数据 
Procedure p_GetParInfBuf( 
  Val           Out t_Refcur, 
  系统_In In 影像参数说明.系统%Type, 
  模块_In  In 影像参数说明.模块%Type 
) Is 
Begin 
Open  Val For 
   Select RawToHex(ID) As ID,RawToHex(PID) As PID,系统,模块,参数名,默认值,参数级别,启用条件 
   From 影像参数说明 
   Where 系统=系统_In And 模块=模块_In; 
Exception 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
End p_GetParInfBuf; 
 
--2 功能：将由逗号分隔的不带引号的字符序列转换为单列数据表 
Function f_Str2list( 
    Str_In   In Varchar2, 
    Split_In In Varchar2 := ',' 
  ) Return t_Strlist 
    Pipelined As 
    v_Str Long; 
    P     Number; 
    --功能：将由逗号分隔的不带引号的字符序列转换为单列数据表 
    --参数：Str_In,如:甲抗,胃溃疡,胃出血...,Split_In,分隔符,缺省为,号 
    --说明： 
    --1．当SQL语句中涉及“IN(常量1, 常量2,…) ”子句时使用这种方式以便利用绑定变量。 
    --2．使用这两个函数时，需要在SQL语句中加入“/*+ Rule*/”提示，因为Cbo下临时内存表没有统计数据,。 
    --3．两种调用示例 
    --Select /*+ Rule*/ * From Sample_List Where Title In (Select * From Table(f_Str2list('甲抗,胃溃疡,胃出血')); 
    --Select /*+ Rule*/ A.* From Sample_List A, Table(f_Str2list('甲抗,胃溃疡,胃出血')) B Where A.Title = B.Column_Value; 
  Begin 
    If Str_In Is Null Then 
      Return; 
    End If; 
    v_Str := Str_In || Split_In; 
    Loop 
      P := Instr(v_Str, Split_In); 
      Exit When(Nvl(P, 0) = 0); 
      Pipe Row(Trim(Substr(v_Str, 1, P - 1))); 
      v_Str := Substr(v_Str, P + 1); 
    End Loop; 
    Return; 
  End; 
 
--3  获取参数值的缓冲数据 
--当前用户所在计算机的参数值 
Procedure p_GetParValueBuf( 
  Val           Out t_Refcur, 
  系统_In In 影像参数说明.系统%Type, 
  模块_In In 影像参数说明.模块%Type, 
  科室ID_In In Varchar2, 
  机器名_In In Varchar2, 
  用户ID_In In Number 
) Is 
Begin 
	Open  Val For 
	    Select RawToHex(b.ID) As ID, RawToHex(b.参数ID) As 参数ID,b.参数标识,b.参数值 
		From 影像参数说明 a, 影像参数取值 b 
		Where  a.id=b.参数id And a.系统=系统_In And a.模块=模块_In and (a.参数级别=0 or a.参数级别=1 or (a.参数级别=2 and b.参数标识=科室ID_In) or (a.参数级别=3 and b.参数标识=用户ID_In) or (a.参数级别=4 and b.参数标识=机器名_In)); 
Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
End 	p_GetParValueBuf; 
 
--4  获取权限的缓冲数据 
Procedure p_GetPopedomBuf( 
  Val           Out t_Refcur, 
  系统_In In 影像参数说明.系统%Type, 
  模块_In In 影像参数说明.模块%Type, 
  用户名_In In Varchar2 
)Is 
Begin 
    --返回用户, 模块号,功能 
	Open  Val For 
	    Select a.用户,b.系统, b.序号 as 模块, b.功能 
		From zluserroles a, zlrolegrant b 
		Where a.角色=b.角色 And a.用户=用户名_In And b.系统=系统_In And b.序号=模块_In; 
Exception 
  When Others Then 
  Zl_Errorcenter(Sqlcode, Sqlerrm); 
End p_GetPopedomBuf; 
 
--5  更新参数值 
Procedure p_SetParameterValue( 
  参数ID_In    In 影像参数取值.参数ID%Type, 
  参数标识_In In 影像参数取值.参数标识%Type, 
  参数值_In    In 影像参数取值.参数值%Type 
)Is 
Begin 
	Update 影像参数取值 Set 参数值=参数值_In Where 参数ID=参数ID_In And 参数标识=参数标识_In; 
	If Sql%RowCount = 0 Then 
	  Insert Into 影像参数取值(ID, 参数ID,参数标识,参数值) 
	  Values(sys_guid(), 参数ID_In,参数标识_In,参数值_In); 
	End If; 
Exception 
  When Others Then 
  Zl_Errorcenter(Sqlcode, Sqlerrm); 
End p_SetParameterValue; 
 
--6  获取用户账号信息 
Function f_Get_Personal_Info_By_Account( 
	Account_In In Varchar2 
) Return Xmltype Is 
  Docxml   Xmltype; 
Begin 
  Select Xmltype('<root></root>') Into Docxml From Dual; 
  Select Appendchildxml(Docxml, '/root', 
                         Xmlconcat(Xmlelement("code", a.Id), Xmlelement("full_name", a.姓名), 
                                    Xmlelement("sex", Xmlattributes(a.性别 As "display"), 
                                                Decode(a.性别, '男', '1', '女', '2', '未知', '0', '9')), 
                                    Xmlelement("birthday", To_Char(a.出生日期, 'yyyy-mm-dd')), 
                                    Xmlelement("idcard_num", a.身份证号))) 
  Into Docxml 
  From 人员表 A, 上机人员表 B 
  Where b.用户名 = Account_In And b.人员id = a.Id And Nvl(a.撤档时间, To_Date('3000-01-01', 'yyyy-mm-dd')) > Sysdate; 
 
  Select Appendchildxml(Docxml, '/root', 
                         Xmlelement("departments", 
                                     Xmlagg(Xmlelement("department", Xmlattributes(c.名称 As "display", d.缺省 As "current"), 
                                                        Xmlelement("dept_value", c.Id))))) 
  Into Docxml 
  From 上机人员表 B, 部门表 C, 部门人员 D 
  Where b.用户名 = Account_In And b.人员id = d.人员id And d.部门id = c.Id; 
 
  For r_Record In (Select d.部门id, Xmlelement("subjects", Xmlagg(Xmlelement("subject", c.名称))) As 部门学科 
                   From 临床部门 A, 上机人员表 B, 部门人员 D, 临床性质 C 
                   Where b.用户名 = Account_In And b.人员id = d.人员id And a.部门id = d.部门id And a.工作性质 = c.编码 
                   Group By d.部门id 
                   Order By d.部门id) Loop 
    Select Appendchildxml(Docxml, '/root/departments/department[dept_value=' || r_Record.部门id || ']', r_Record.部门学科) 
    Into Docxml 
    From Dual; 
  End Loop; 
 
  Return Docxml; 
Exception 
  When Others Then 
    Return Null; 
End f_Get_Personal_Info_By_Account; 
 
End b_PACS_Common;
/

