create Package b_PACS_Config Is 
  Type t_Refcur Is Ref Cursor; 
 
  -- 功    能：获取影像字典清单 
  Procedure p_GetAllDictList( 
	Val			Out t_Refcur 
  ); 
 
  -- 功    能：获取影像字典内容 
  Procedure p_GetAllDictItems( 
    Val           Out t_Refcur, 
	字典ID_In	In 影像字典内容.字典ID%Type 
  ); 
 
  -- 功    能：新增或修改影像字典内容 
  Procedure p_EditDictItem( 
	字典ID_In		In 影像字典内容.字典ID%Type, 
	旧编号_In		In 影像字典内容.编号%Type, 
	编号_In			In 影像字典内容.编号%Type, 
	名称_In			In 影像字典内容.名称%Type, 
	简码_In			In 影像字典内容.简码%Type, 
	说明_In			In 影像字典内容.说明%Type 
  ); 
 
  -- 功    能：删除影像字典内容 
  Procedure p_DelDictItem( 
	字典ID_In		In 影像字典内容.字典ID%Type, 
	编号_In			In 影像字典内容.编号%Type 
  ); 
End b_PACS_Config;
/

