create Package Body b_PACS_Config  Is 
  -- 功    能：获取影像字典清单 
  Procedure p_GetAllDictList( 
	Val			Out t_Refcur 
  ) 
  Is 
	strSql varchar2(100); 
  Begin 
	strSql := 'select Rawtohex(ID) ID,编号,名称,说明,是否系统,分组 From 影像字典清单'; 
	Open Val For strSql; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_GetAllDictList; 
 
  -- 功    能：获取影像字典内容 
  Procedure p_GetAllDictItems( 
    Val           Out t_Refcur, 
	字典ID_In		In 影像字典内容.字典ID%Type 
  ) 
  Is 
	strSql varchar2(200); 
  Begin 
	strSql := 'Select Rawtohex(A.字典id) Rid, A.编号, A.名称, A.简码, A.说明 '|| 
			  'From 影像字典内容 A Where A.字典id = '''|| 字典ID_In ||''''; 
	Open Val For strSql; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_GetAllDictItems; 
 
  -- 功    能：新增或修改影像字典内容 
  Procedure p_EditDictItem( 
	字典ID_In		In 影像字典内容.字典ID%Type, 
	旧编号_In		In 影像字典内容.编号%Type, 
	编号_In			In 影像字典内容.编号%Type, 
	名称_In			In 影像字典内容.名称%Type, 
	简码_In			In 影像字典内容.简码%Type, 
	说明_In			In 影像字典内容.说明%Type 
  ) 
  Is 
	n_Num Number; 
	v_Msg Varchar2(50); 
	Err	  Exception; 
  Begin 
	If 旧编号_In<>'-1' Then 
	  Select Count(字典ID) Into n_Num From 影像字典内容 Where 字典ID = 字典ID_In And 编号 = 编号_In And 编号<>旧编号_In; 
	  If n_Num > 0 Then 
		v_Msg:='所属字典ID和编号重复!'; 
		Raise Err; 
	  End IF; 
 
	  Update 影像字典内容 A 
	  Set A.编号 = 编号_In,A.名称 = 名称_In,A.简码 = 简码_In,A.说明 = 说明_In 
	  Where A.字典ID = 字典ID_In And A.编号 = 旧编号_In; 
	Else 
	  Select Count(字典ID) Into n_Num From 影像字典内容 Where 字典ID = 字典ID_In And 编号 = 编号_In; 
	  If n_Num > 0 Then 
		v_Msg:='所属字典ID和编号重复!'; 
		Raise Err; 
	  End IF; 
	 
	  Insert Into 影像字典内容(字典ID,编号,名称,简码,说明) 
	  Values(字典ID_In,编号_In,名称_In,简码_In,说明_In); 
	End If; 
  Exception 
	When Err Then 
	  Raise_Application_Error(-20101,v_Msg); 
	When Others Then 
	  Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_EditDictItem; 
 
  -- 功    能：删除影像字典内容 
  Procedure p_DelDictItem( 
	字典ID_In		In 影像字典内容.字典ID%Type, 
	编号_In			In 影像字典内容.编号%Type 
  ) 
  Is 
  Begin 
	Delete From 影像字典内容 Where 字典ID = 字典ID_In And 编号 = 编号_In; 
  Exception 
	When Others Then 
	  Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_DelDictItem; 
End b_PACS_Config;
/

