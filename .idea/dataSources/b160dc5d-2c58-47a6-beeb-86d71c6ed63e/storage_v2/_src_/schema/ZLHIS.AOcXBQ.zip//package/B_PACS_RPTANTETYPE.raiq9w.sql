create Package b_PACS_RptAntetype Is 
  --Create By Hwei; 
  --2014/11/25 
  Type t_Refcur Is Ref Cursor; 
 
  --1.获取文件原型类别 
  Procedure p_Get_Antetypelistkind( 
    Val Out t_Refcur 
	); 
  --2.根据文档类型获取文档信息 
  Procedure p_Get_Antetypelis_By_Kind( 
	Val           Out t_Refcur, 
	种类_In      影像报告原型清单.种类%Type, 
	Stop_Flag    Number, 
	Condition_In Varchar2 
	); 
  --3.添加一个文档原型 
  Procedure p_Add_Antetypelist( 
    Id_In           影像报告原型清单.ID%Type, 
	种类_In         影像报告原型清单.种类%Type, 
	编码_In         影像报告原型清单.编码%Type, 
	名称_In         影像报告原型清单.名称%Type, 
    设备号_In		影像设备目录.设备号%Type, 
	说明_In         影像报告原型清单.说明%Type, 
	可否重置页面_In 影像报告原型清单.可否重置页面%Type, 
	可否重置格式_In 影像报告原型清单.可否重置格式%Type, 
    可否书写多份_In 影像报告原型清单.可否书写多份%Type, 
	是否禁用_In     影像报告原型清单.是否禁用%Type, 
	创建人_In       影像报告原型清单.创建人%Type, 
	内容_In         影像报告原型清单.内容%Type, 
	控制选项_In     影像报告原型清单.控制选项%Type, 
	词句加载时机_In 影像报告原型清单.词句加载时机%Type, 
	插件加载时机_In 影像报告原型清单.插件加载时机%Type, 
	专用插件_In     影像报告原型清单.专用插件%Type, 
	Copy_Id_In      影像报告原型清单.ID%Type, 
	Only_Head_In    Varchar2, 
	分组_In         影像报告原型清单.分组%Type 
	); 
  --4.修改一个文档原型 
  Procedure p_Edit_Antetypelist( 
    Id_In           影像报告原型清单.ID%Type, 
    种类_In         影像报告原型清单.种类%Type, 
    编码_In         影像报告原型清单.编码%Type, 
    名称_In         影像报告原型清单.名称%Type, 
    设备号_In		影像设备目录.设备号%Type, 
    说明_In         影像报告原型清单.说明%Type, 
    可否重置页面_In 影像报告原型清单.可否重置页面%Type, 
    可否重置格式_In 影像报告原型清单.可否重置格式%Type, 
    可否书写多份_In 影像报告原型清单.可否书写多份%Type, 
    是否禁用_In     影像报告原型清单.是否禁用%Type, 
    修改人_In       影像报告原型清单.修改人%Type, 
    内容_In         影像报告原型清单.内容%Type, 
    控制选项_In     影像报告原型清单.控制选项%Type, 
	词句加载时机_In 影像报告原型清单.词句加载时机%Type, 
	插件加载时机_In 影像报告原型清单.插件加载时机%Type, 
    专用插件_In     影像报告原型清单.专用插件%Type, 
    Copy_Id_In      影像报告原型清单.ID%Type, 
    Only_Head_In    Varchar2, 
    分组_In         影像报告原型清单.分组%Type 
	); 
  --5.删除一个文件原型 
  Procedure p_Del_Antetypelist( 
    Id_In 影像报告原型清单.Id%Type 
	); 
  --6.根据ID获取文件原型 
  Procedure p_Get_Antetypelist_By_Id( 
	Val           Out t_Refcur, 
	Id_In 影像报告原型清单.Id%Type 
	); 
  --7.获取原型XML内容 
  Procedure p_Get_Antetypelist_Content( 
	Val           Out t_Refcur, 
	Id_In 影像报告原型清单.Id%Type 
	); 
  --8.停用或启用文件原型 
  Procedure p_Stop_Antetypelist( 
    Id_In 影像报告原型清单.Id%Type 
	); 
 
  --9.新增文档种类信息 
  Procedure p_Add_Doc_Kind( 
    编码_In 影像报告种类.编码%Type, 
    名称_In 影像报告种类.名称%Type, 
    说明_In 影像报告种类.说明%Type 
	); 
  --10.删除文档种类信息 
  Procedure p_Del_Doc_Kind; 
  --11.获取预备提纲信息 
  Procedure p_Get_Pre_Outline( 
    Val Out t_Refcur 
	); 
  --12.添加预备提纲信息 
  Procedure p_Add_Pre_Outline( 
    ID_In   影像报告预备提纲.ID%Type, 
	编码_In 影像报告预备提纲.编码%Type, 
	名称_In 影像报告预备提纲.名称%Type, 
	说明_In 影像报告预备提纲.说明%Type 
	); 
  --13.删除预备提纲信息 
  Procedure p_Del_Pre_Outline; 
  --14.获取导出的文档原型信息 
  Procedure p_Output_Antetypelist( 
    Val Out t_Refcur 
	); 
  --15.添加原型片段 
  Procedure p_Add_Antetype_Fragments( 
    原型ID_In 影像报告原型片段.原型ID%Type, 
	片段ID_In 影像报告原型片段.片段ID%Type 
	); 
  --16.删除原型片段 
  Procedure p_Del_Antetype_Fragments( 
    原型ID_In 影像报告原型片段.原型ID%Type 
	); 
  --17.获取原型片段 
  Procedure p_Get_Antetype_Fragments( 
    Val           Out t_Refcur, 
	原型ID_In 影像报告原型片段.原型ID%Type 
	); 
  --18.获取某个原型关联的某个片段分类 
  Procedure p_Get_Antetype_f_Byaidfid( 
    Val           Out t_Refcur,		 
	原型ID_In 影像报告原型片段.原型ID%Type, 
    片段ID_In 影像报告原型片段.片段ID%Type 
	); 
  --19.插入文档原型XML内容 
  Procedure p_Edit_Antetypelist_Content( 
    Id_In     影像报告原型清单.Id%Type, 
	内容_In   影像报告原型清单.内容%Type, 
	修改人_In 影像报告原型清单.修改人%Type 
	); 
  --20.获取所有原型 
  Procedure p_Get_All_Antetype_Lists( 
    Val Out t_Refcur 
	); 
  --21.获取已经设置了关联的原型片段类别的信息 
 
  Procedure p_Get_Antetype_Fragments_Info( 
	Val           Out t_Refcur, 
	原型ID_In 影像报告原型片段.原型ID%Type 
	); 
  --22.获取选择的类别下面的短语名称 
  Procedure p_Get_Selected_Fragments( 
	Val           Out t_Refcur, 
	原型id_In Varchar2 
	); 
  --23.获取能复制的原型名称 
 
  Procedure p_Get_Copy_Antetype( 
	Val           Out t_Refcur, 
	种类_In 影像报告原型清单.种类%Type 
	); 
  --24.获取原型的分组信息 
  Procedure p_Get_Antetype_Category( 
	Val           Out t_Refcur, 
	种类_In 影像报告原型清单.种类%Type 
	); 
  --25.根据原型同步范文提纲 
  Procedure p_Synchronous_Sample( 
    原型id_In 影像报告原型清单.Id%Type 
	); 
  --26.获取导出的原型列表 
  Procedure p_Get_Out_Antetypelist( 
    Val Out t_Refcur 
	); 
  --27.通过编码获取原型种类信息 
  Procedure p_Get_Antetype_Kind_By_Code( 
	Val           Out t_Refcur, 
	编码_In 影像报告种类.编码%Type 
	); 
  --28.获取事件信息，不包含固定事件 
  Procedure p_Get_Doc_Event( 
    Val Out t_Refcur 
	); 
  --29.获取关于原型导出的重复信息 
 
  Procedure p_Get_Antetypelist_Same_Info( 
	Val           Out t_Refcur, 
	Tablename_In Varchar2, 
    Id_In        影像报告原型清单.Id%Type, 
    编码_In      Varchar2, 
    名称_In      Varchar2 
	); 
  --30.获取事件重复的信息 
  Procedure p_Event_Same_Info( 
	Val           Out t_Refcur,	 
	Id_In      影像报告事件.Id%Type, 
    原型ID_In  影像报告事件.原型ID%Type, 
    元素IID_In 影像报告事件.元素IID%Type, 
    种类_In    影像报告事件.种类%Type, 
    名称_In    影像报告事件.名称%Type, 
    编号_In    影像报告事件.编号%Type 
	); 
  --31.获取原型校验的类别集合 
  Procedure p_Get_Process_Kind( 
    Val Out t_Refcur 
	); 
 
  ----32.获取元素或者提纲的名称集合 
  --Procedure p_Get_Antetype_Ele_Section( 
  --原型ID_In  影像报告原型清单.Id%Type, 
  --Val     Out t_Refcur); 
 
  --33.获取指定原型的文档处理 
  Procedure p_Get_Doc_Process_Of_Antetype( 
	Val           Out t_Refcur, 
	原型id_In 影像报告动作.原型id%Type 
	); 
 
  --34. 根据字典名称获取相应子项 
  Procedure p_Get_Dictitems_By_Title( 
	Val           Out t_Refcur, 
	名称_In 影像字典清单.名称%Type 
	); 
  --35.获得所有的预备提纲 
  Procedure p_Get_All_Phr_Onlines( 
    Val Out t_Refcur 
	); 
  --36.获取所有词句信息 
  Procedure p_Get_All_Fragment( 
	Val           Out t_Refcur, 
	学科_In Varchar2 
	); 
 
  --37.获取词句信息 
  Procedure p_Get_Fragment_Filter( 
	Val           Out t_Refcur, 
	原型id_In 影像报告原型片段.原型ID%Type, 
    作者_In   影像报告片段清单.作者%Type, 
    学科_In   影像报告片段清单.学科%Type, 
    Type_In   Varchar2 
	); 
  --38.根据原型获取关联的片段标签值 
  Procedure p_Get_Label_By_Aid( 
	Val           Out t_Refcur, 
	原型ID_In 影像报告原型片段.原型ID%Type 
	); 
  --39.获取所有词句分类 
  Procedure p_Get_All_Fragment_Class( 
    Val Out t_Refcur 
	); 
  --40.获取表名对应的最后编辑时间 
  Procedure p_Get_Data_Last_Edit_Time( 
	Val           Out t_Refcur, 
	Table_Name_In Varchar2 
	); 
  --41.添加文档事件 
  Procedure p_Add_Doc_Event( 
    ID_In       影像报告事件.ID%Type, 
    种类_In     影像报告事件.种类%Type, 
    原型ID_In   影像报告事件.原型ID%Type, 
    编号_In     影像报告事件.编号%Type, 
    名称_In     影像报告事件.名称%Type, 
    说明_In     影像报告事件.说明%Type, 
    元素IID_In  影像报告事件.元素IID%Type, 
    扩展标记_In 影像报告事件.扩展标记%Type); 
  --42.修改文档事件 
  Procedure p_Update_Doc_Event( 
    Id_In       影像报告事件.Id%Type, 
    种类_In     影像报告事件.种类%Type, 
    名称_In     影像报告事件.名称%Type, 
    说明_In     影像报告事件.说明%Type, 
    元素IID_In  影像报告事件.元素IID%Type, 
    扩展标记_In 影像报告事件.扩展标记%Type); 
  --43.删除文档事件 
  Procedure p_Delete_Doc_Event( 
    Id_In 影像报告事件.Id%Type 
	); 
  --44.删除所有未被使用的文档事件 
  Procedure p_Delete_Unused_Doc_Events( 
    Count_Out Out Number 
	); 
  --45.获取指定原型的文档事件 
  Procedure p_Get_Doc_Event_Of_Antetype( 
	Val           Out t_Refcur, 
	原型ID_In       影像报告事件.原型ID%Type, 
	Include_Base_In Number 
	); 
  --46.修改文档处理编号 
  Procedure p_Update_Doc_Process_Seqnum( 
    Id_In   影像报告动作.Id%Type, 
	序号_In 影像报告动作.序号%Type 
	); 
  --47.添加文档处理 
  Procedure p_Add_Doc_Process( 
    Id_In           影像报告动作.Id%Type, 
    原型ID_In       影像报告动作.原型ID%Type, 
    事件ID_In       影像报告动作.事件ID%Type, 
    动作类型_In     影像报告动作.动作类型%Type, 
    名称_In         影像报告动作.名称%Type, 
    说明_In         影像报告动作.说明%Type, 
    可否手工执行_In 影像报告动作.可否手工执行%Type, 
    序号_In         影像报告动作.序号%Type, 
    内容_In         影像报告动作.内容%Type 
	); 
  --48.修改文档处理 
  Procedure p_Update_Doc_Process( 
    Id_In           影像报告动作.Id%Type, 
    事件ID_In       影像报告动作.事件ID%Type, 
    动作类型_In     影像报告动作.动作类型%Type, 
    名称_In         影像报告动作.名称%Type, 
    说明_In         影像报告动作.说明%Type, 
    可否手工执行_In 影像报告动作.可否手工执行%Type, 
    内容_In         影像报告动作.内容%Type 
	); 
  --49.获取元素或者提纲的名称集合 
  Procedure p_Get_Antetype_Ele_Section( 
	Val           Out t_Refcur, 
	原型ID_In 影像报告原型清单.Id%Type, 
	Type_In   Varchar2 
	); 
  --50.删除文档处理 
  Procedure p_Del_Doc_Process( 
    Id_In        影像报告动作.ID%Type, 
	Del_Event_In Number 
	); 
 
  --51.查询元素值域类别的覆盖情况 
  Procedure p_Get_Ele_Same_Info( 
	Val           Out t_Refcur, 
	Id_In    影像报告值域清单.Id%Type, 
	Code_In  Varchar2, 
	Title_In Varchar2, 
	Flag_In  Varchar2 
	); 
  --52.获得所有的插件信息 
  Procedure p_Get_DocPluginList( 
    Val Out t_Refcur 
	); 
  --53.该ID的插件是否被原型使用过 
  Procedure p_IsExit_DocPluginByID( 
	Val           Out t_Refcur, 
	ID_In Varchar2 
	); 
  --54.新增报告插件信息 
  Procedure p_AddDocPlugin( 
    ID_In       影像报告插件.ID%Type, 
    编码_In     影像报告插件.编码%Type, 
    名称_In     影像报告插件.名称%Type, 
    说明_In     影像报告插件.说明%Type, 
    显示样式_In 影像报告插件.显示样式%Type, 
    种类_In     影像报告插件.种类%Type, 
    类名_In     影像报告插件.类名%Type, 
    库名_In     影像报告插件.库名%Type, 
    是否禁用_In 影像报告插件.是否禁用%Type 
	); 
  --55.修改报告插件信息 
  Procedure p_EditDocPlugin( 
    ID_In       影像报告插件.ID%Type, 
    编码_In     影像报告插件.编码%Type, 
    名称_In     影像报告插件.名称%Type, 
    说明_In     影像报告插件.说明%Type, 
    显示样式_In 影像报告插件.显示样式%Type, 
    种类_In     影像报告插件.种类%Type, 
    类名_In     影像报告插件.类名%Type, 
    库名_In     影像报告插件.库名%Type, 
    是否禁用_In 影像报告插件.是否禁用%Type 
	); 
  --56.删除报告插件信息 
  Procedure p_DelDocPlugin( 
    ID_In 影像报告插件.ID%Type 
	); 
  --57.改变插件的可用状态 
  Procedure p_IsEnableDocPlugin( 
    ID_In 影像报告插件.ID%Type 
	); 
  --58.通过ID获得对应的插件信息 
  Procedure p_GetDocPluginByID( 
	Val           Out t_Refcur, 
	ID_In 影像报告插件.ID%type 
	); 
  --59.判断编码和名称是否已存在 
  Procedure p_IsExitDocPlugin( 
	Val           Out t_Refcur, 
	ID_In   影像报告插件.ID%Type, 
    编码_In 影像报告插件.编码%Type, 
    名称_In 影像报告插件.名称%Type 
	); 
  --60.通过ID获得对应的专用插件信息 
  Procedure p_GetDocSpecPluginByID( 
	Val           Out t_Refcur, 
	ID_In 影像报告插件.ID%Type 
	); 
  --61.获得诊疗列表信息 
  Procedure p_GetDiagnosisList( 
	Val           Out t_Refcur, 
	类别_In Varchar2, 
    条件_In Varchar2 
	); 
  --62.获得诊疗类别列表 
  Procedure p_GetDiagnosisClass( 
    Val Out t_Refcur 
	); 
  --63.添加影像报告原型应用信息 
  Procedure p_AddMedicalAntetype( 
    诊疗项目ID_In 影像报告原型应用.诊疗项目ID%Type, 
	应用场合_In   影像报告原型应用.应用场合%Type, 
	报告原型ID_In 影像报告原型应用.报告原型ID%Type 
	); 
  --64.删除原型ID对应的病历单据应用信息 
  Procedure p_DelMedicalAntetype( 
    报告原型ID_In 影像报告原型应用.报告原型ID%Type 
	); 
  --65.通过原型ID获得对应的病历单据应用信息 
  Procedure p_GetMedicalByAID( 
	Val           Out t_Refcur, 
	报告原型ID_In 影像报告原型应用.报告原型ID%Type 
	); 
  --66.根据原型ID删除动作信息 
  Procedure p_DelDocProcessByAid( 
    报告原型ID_In 影像报告原型应用.报告原型ID%Type 
	); 
  --67.获取ID对应的原型的树形结构 
  Procedure p_GetAntetypeTreeByID( 
	Val           Out t_Refcur, 
	ID_In 影像报告原型清单.ID%Type 
	); 
  --68.原型是否存在对应的编码或名称 
  procedure p_IsExitAntetype( 
	Val           Out t_Refcur, 
	编码_In 影像报告原型清单.编码%Type, 
    名称_In 影像报告原型清单.名称%Type, 
    ID_In  影像报告原型清单.ID%Type 
	); 
 
  --69  获取影像存储设备 
  Procedure p_GetStorageDevice( 
		Val           Out t_Refcur); 
 
End b_PACS_RptAntetype;
/

