create Package Body b_PACS_RptAntetype Is 
  --Create By Hwei; 
  --2014/11/25 
 
  --1.获取文件原型类别 
  Procedure p_Get_Antetypelistkind( 
    Val Out t_Refcur 
	) As 
  Begin 
    Open Val For 
      Select 编码, a.名称, a.编码 || '-' || a.名称 As 标题 
        From 影像报告种类 A 
       Order By 编码; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Get_Antetypelistkind; 
 
  --2.根据文档类型获取文档信息 
  Procedure p_Get_Antetypelis_By_Kind( 
	Val           Out t_Refcur, 
	种类_In      影像报告原型清单.种类%Type, 
    Stop_Flag    Number, 
    Condition_In Varchar2 
	) As 
  Begin 
    Open Val For 
      Select ID, 编码, 名称, 标题, 分组, 是否禁用, 说明, Imageindex 
        From (Select Distinct 分组 As ID, 
                              (Select Min(b.编码) 
                                 From 影像报告原型清单 B 
                                Where b.分组 = a.分组) As 编码, 
                              a.分组 As 名称, 
                              a.分组 As 标题, 
                              null As 分组, 
                              0 As 是否禁用, 
                              null As 说明, 
                              0 As Imageindex 
                From 影像报告原型清单 A 
               Where a.种类 = 种类_In 
                 And ((a.是否禁用 <> 1 And Stop_Flag = 1) Or (Stop_Flag = 0)) 
                 And ((a.名称 Like '%' || Condition_In || '%' And 
                     Condition_In Is Not Null) Or Condition_In Is Null) 
                 And a.分组 Is Not Null 
              Union 
              Select RawtoHex(ID) ID, 
                     a.编码, 
                     名称 As 名称, 
                     编码 || '-' || 名称 As 标题, 
                     分组, 
                     a.是否禁用, 
                     a.说明, 
                     Decode(a.是否禁用, 1, 2, 1) Imageindex 
                From 影像报告原型清单 A 
               Where a. 
               种类 = 种类_In 
                 And ((a.是否禁用 <> 1 And Stop_Flag = 1) Or (Stop_Flag = 0)) 
                 And ((a.名称 Like '%' || Condition_In || '%' And 
                     Condition_In Is Not Null) Or Condition_In Is Null)) A 
       Order By a.编码; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Get_Antetypelis_By_Kind; 
 
  --3.添加一个文档原型 
  Procedure p_Add_Antetypelist( 
    ID_In           影像报告原型清单.ID%Type, 
    种类_In         影像报告原型清单.种类%Type, 
    编码_In         影像报告原型清单.编码%Type, 
    名称_In         影像报告原型清单.名称%Type, 
	设备号_In		影像设备目录.设备号%Type, 
    说明_In         影像报告原型清单.说明%Type, 
    可否重置页面_In 影像报告原型清单.可否重置页面%Type, 
    可否重置格式_In 影像报告原型清单.可否重置格式%Type, 
	可否书写多份_In 影像报告原型清单.可否书写多份%Type, 
    是否禁用_In     影像报告原型清单.是否禁用%Type, 
    创建人_In       影像报告原型清单.创建人%Type, 
    内容_In         影像报告原型清单.内容%Type, 
    控制选项_In     影像报告原型清单.控制选项%Type, 
	词句加载时机_In 影像报告原型清单.词句加载时机%Type, 
	插件加载时机_In 影像报告原型清单.插件加载时机%Type, 
    专用插件_In     影像报告原型清单.专用插件%Type, 
    Copy_ID_In      影像报告原型清单.ID%Type, 
    Only_Head_In    Varchar2, 
    分组_In         影像报告原型清单.分组%Type 
	) As 
    x_Str Xmltype; 
  Begin 
    Begin 
      If Copy_ID_In Is Null or Copy_ID_In = 0 Then 
        x_Str := 内容_In; 
      Else 
        Select Decode(Only_Head_In, 
                      1, 
                      Deletexml(a.内容, '/zlxml/document/node()'), 
                      a.内容) 
          Into x_Str 
          From 影像报告原型清单 A 
         Where a.id = Copy_ID_In; 
      End If; 
    Exception 
      When Others Then 
        x_Str := 内容_In; 
    End; 
 
    Insert Into 影像报告原型清单 
      (ID, 
       种类, 
       编码, 
       名称, 
	   设备号, 
       说明, 
       可否重置页面, 
       可否重置格式, 
	   可否书写多份, 
       是否禁用, 
       创建人, 
       创建时间, 
       内容, 
       控制选项, 
	   词句加载时机, 
	   插件加载时机, 
       专用插件, 
       分组) 
    Values 
      (ID_In, 
       种类_In, 
       编码_In, 
       名称_In, 
	   设备号_In, 
       说明_In, 
       可否重置页面_In, 
       可否重置格式_In, 
	   可否书写多份_In, 
       是否禁用_In, 
       创建人_In, 
       sysdate, 
       x_Str, 
       控制选项_In, 
	   词句加载时机_In, 
	   插件加载时机_In, 
       专用插件_In, 
       分组_In); 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Add_Antetypelist; 
 
  --4.修改一个文档原型 
  Procedure p_Edit_Antetypelist( 
    ID_In           影像报告原型清单.ID%Type, 
    种类_In         影像报告原型清单.种类%Type, 
    编码_In         影像报告原型清单.编码%Type, 
    名称_In         影像报告原型清单.名称%Type, 
	设备号_In		影像设备目录.设备号%Type, 
    说明_In         影像报告原型清单.说明%Type, 
    可否重置页面_In 影像报告原型清单.可否重置页面%Type, 
    可否重置格式_In 影像报告原型清单.可否重置格式%Type, 
	可否书写多份_In 影像报告原型清单.可否书写多份%Type, 
    是否禁用_In     影像报告原型清单.是否禁用%Type, 
    修改人_In       影像报告原型清单.修改人%Type, 
    内容_In         影像报告原型清单.内容%Type, 
    控制选项_In     影像报告原型清单.控制选项%Type, 
	词句加载时机_In 影像报告原型清单.词句加载时机%Type, 
	插件加载时机_In 影像报告原型清单.插件加载时机%Type, 
    专用插件_In     影像报告原型清单.专用插件%Type, 
    Copy_ID_In      影像报告原型清单.ID%Type, 
    Only_Head_In    Varchar2, 
    分组_In         影像报告原型清单.分组%Type 
	) As 
    x_Str     Xmltype; 
    n_Num     Number; 
    v_Err_Msg Varchar2(200); 
    Err_Item Exception; 
  Begin 
    Select Count(a.Id) 
      Into n_Num 
      From 影像报告原型清单 A 
     Where (a.编码 = 编码_In Or a.名称 = 名称_In) 
       And ID <> ID_In; 
 
    If n_Num > 0 Then 
      v_Err_Msg := '[ZLSOFT]存在相同的文档编码或者名称，请重新填写！[ZLSOFT]'; 
      Raise Err_Item; 
    End If; 
 
    If Copy_ID_In Is Null or Copy_ID_In = 0 Then 
      x_Str := 内容_In; 
    Else 
      Select Decode(Only_Head_In, 
                    1, 
                    Deletexml(a.内容, '/zlxml/document/node()'), 
                    a.内容) 
        Into x_Str 
        From 影像报告原型清单 A 
       Where a.id = Copy_ID_In; 
    End If; 
 
    Update 影像报告原型清单 
       Set 种类         = 种类_In, 
           编码         = 编码_In, 
           名称         = 名称_In, 
		   设备号		= 设备号_In, 
           说明         = 说明_In, 
           可否重置页面 = 可否重置页面_In, 
           可否重置格式 = 可否重置格式_In, 
		   可否书写多份 = 可否书写多份_In, 
           是否禁用     = NVL(是否禁用_In, 是否禁用), 
           修改人       = 修改人_In, 
           修改时间     = sysdate, 
           内容         = x_Str, 
           控制选项     = 控制选项_In, 
		   词句加载时机 =词句加载时机_In, 
		   插件加载时机 =插件加载时机_In, 
           专用插件     = 专用插件_In, 
           分组         = 分组_In 
     Where ID = ID_In; 
  Exception 
    When Err_Item Then 
      Raise_Application_Error(-20101, v_Err_Msg); 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Edit_Antetypelist; 
 
  --5.删除一个文件原型 
  Procedure p_Del_Antetypelist( 
    ID_In 影像报告原型清单.Id%Type 
	) As 
    n_Num     Number; 
    v_Err_Msg Varchar2(200); 
    Err_Item Exception; 
  Begin 
    Select Count(ID) Into n_Num From 影像报告记录 A Where a.原型id = ID_In; 
 
    If n_Num > 0 Then 
      v_Err_Msg := '[ZLSOFT]该原型已经被文档使用，不允许删除！[ZLSOFT]'; 
      Raise Err_Item; 
    End If; 
 
    Select Count(原型ID) 
      Into n_Num 
      From 影像报告原型片段 
     Where 影像报告原型片段.原型ID = ID_In; 
 
    If n_Num > 0 Then 
      v_Err_Msg := '[ZLSOFT]该文档下存在词句关联，不允许删除！[ZLSOFT]'; 
      Raise Err_Item; 
    End If; 
 
    Select Count(ID) 
      Into n_Num 
      From 影像报告范文清单 
     Where 影像报告范文清单.原型ID = ID_In; 
 
    If n_Num > 0 Then 
      v_Err_Msg := '[ZLSOFT]存在以此原型建立的范文信息，不允许删除！[ZLSOFT]'; 
      Raise Err_Item; 
    End If; 
 
    Delete From 影像报告原型清单 C Where c.Id = ID_In; 
  Exception 
    When Err_Item Then 
      Raise_Application_Error(-20101, v_Err_Msg); 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Del_Antetypelist; 
 
  --6.根据ID获取文件原型 
  Procedure p_Get_Antetypelist_By_Id( 
	Val           Out t_Refcur, 
	ID_In 影像报告原型清单.Id%Type 
	) As 
  Begin 
    Open Val For 
      Select rawtohex(a.ID) ID, 
             a.种类, 
             a.编码, 
             a.名称, 
			 a.设备号, 
             a.说明, 
             a.可否重置页面, 
             a.可否重置格式, 
			 a.可否书写多份, 
             Extractvalue(b.Column_Value, '/root/print_hf_mode') Printhfmode, 
             Extractvalue(b.Column_Value, '/root/print_follow_pages') Printfollowpages, 
             Nvl(Extractvalue(b.Column_Value, '/root/print_limit'), 0) Printlimit, 
             (Nvl(a.控制选项, XmlType('<NULL/>'))).GetClobVal() as 控制选项, 
			 a.词句加载时机, 
			 a.插件加载时机, 
             a.是否禁用, 
             (Nvl(a.专用插件, XmlType('<NULL/>'))).GetClobVal() as 专用插件, 
             a.创建人, 
             a.创建时间, 
             a.修改人, 
             a.修改时间, 
             a.分组 
        From 影像报告原型清单 A, 
             Table(Xmlsequence(Extract(a.控制选项, '/root'))) B 
       Where a.Id = ID_In; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Get_Antetypelist_By_Id; 
 
  --7.获取原型XML内容 
  Procedure p_Get_Antetypelist_Content( 
	Val           Out t_Refcur, 
	ID_In 影像报告原型清单.Id%Type 
	) As 
  Begin 
    Open Val For 
      Select (Nvl(a.内容, XmlType('<ZLXML/>'))).GetClobVal() As 内容 
        From 影像报告原型清单 A 
       Where a.Id = ID_In; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Get_Antetypelist_Content; 
 
  --8.停用或启用文件原型 
  Procedure p_Stop_Antetypelist( 
    ID_In 影像报告原型清单.Id%Type 
	) As 
  Begin 
    Update 影像报告原型清单 
       Set 是否禁用 = Decode(是否禁用, 1, 0, 0, 1) 
     Where ID = ID_In; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Stop_Antetypelist; 
 
  --9.新增文档种类信息 
  Procedure p_Add_Doc_Kind( 
    编码_In 影像报告种类.编码%Type, 
    名称_In 影像报告种类.名称%Type, 
    说明_In 影像报告种类.说明%Type 
	) As 
    n_Num     Number; 
    v_Err_Msg Varchar2(200); 
    Err_Item Exception; 
  Begin 
    Select Count(a.编码) 
      Into n_Num 
      From 影像报告种类 A 
     Where a.编码 = 编码_In 
        Or a.名称 = 名称_In; 
 
    If n_Num > 0 Then 
      v_Err_Msg := '[ZLSOFT]种类的编码或者名称不能相同！[ZLSOFT]'; 
      Raise Err_Item; 
    End If; 
 
    If 编码_In Is Null Or 编码_In Is Null Then 
      v_Err_Msg := '[ZLSOFT]种类的编码或者名称不能为空！[ZLSOFT]'; 
      Raise Err_Item; 
    End If; 
 
    Insert Into 影像报告种类 
      (编码, 名称, 说明) 
    Values 
      (编码_In, 名称_In, 说明_In); 
 
  Exception 
    When Err_Item Then 
      Raise_Application_Error(-20101, v_Err_Msg); 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Add_Doc_Kind; 
 
  --10.删除文档种类信息 
  Procedure p_Del_Doc_Kind As 
  Begin 
    Delete From 影像报告种类; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Del_Doc_Kind; 
 
  --11.获取预备提纲信息 
  Procedure p_Get_Pre_Outline( 
    Val Out t_Refcur 
	) As 
  Begin 
    Open Val For 
      Select RawtoHex(ID) ID, 编码, 名称, 说明, 最后编辑时间 
        From 影像报告预备提纲 A 
       Order By a.编码; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Get_Pre_Outline; 
 
  --12.添加预备提纲信息 
  Procedure p_Add_Pre_Outline( 
    ID_In   影像报告预备提纲.ID%Type, 
    编码_In 影像报告预备提纲.编码%Type, 
    名称_In 影像报告预备提纲.名称%Type, 
    说明_In 影像报告预备提纲.说明%Type 
	) As 
    n_Num     Number; 
    v_Err_Msg Varchar2(200); 
    Err_Item Exception; 
  Begin 
    Select Count(a.编码) 
      Into n_Num 
      From 影像报告预备提纲 A 
     Where a.编码 = 编码_In 
        Or a.名称 = 名称_In; 
 
    If n_Num > 0 Then 
      v_Err_Msg := '[ZLSOFT]种类的编码或者名称不能相同！[ZLSOFT]'; 
      Raise Err_Item; 
    End If; 
 
    If 编码_In Is Null Or 名称_In Is Null Then 
      v_Err_Msg := '[ZLSOFT]种类的编码或者名称不能为空！[ZLSOFT]'; 
      Raise Err_Item; 
    End If; 
 
    Insert Into 影像报告预备提纲 
      (ID, 编码, 名称, 说明, 最后编辑时间) 
    Values 
      (ID_In, 编码_In, 名称_In, 说明_In, sysdate); 
  Exception 
    When Err_Item Then 
      Raise_Application_Error(-20101, v_Err_Msg); 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Add_Pre_Outline; 
 
  --13.删除预备提纲信息 
  Procedure p_Del_Pre_Outline As 
  Begin 
    Delete From 影像报告预备提纲; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Del_Pre_Outline; 
 
  --14.获取导出的文档原型信息 
  Procedure p_Output_Antetypelist( 
    Val Out t_Refcur 
	) As 
  Begin 
    Open Val For 
      Select '类别' As 类别, 
             b.编码 As ID, 
             Null As 种类, 
             b.名称 As 种类名称, 
             b.编码 As 编码, 
             b.名称 As 名称, 
             b.说明 As 说明, 
             Null As 可否重置页面, 
             Null As 可否重置格式, 
             Null As 是否禁用, 
             Null As 创建人, 
             Null As 创建时间, 
             Null As 修改人, 
             Null As 修改时间, 
             Null As 内容 
        From 影像报告种类 B 
      Union All 
      Select '原型' 类别, 
             RawToHex(a.Id) ID, 
             a.种类, 
             b.名称 种类名称, 
             a.编码, 
             a.名称, 
             a.说明, 
             a.可否重置页面, 
             a.可否重置格式, 
             a.是否禁用, 
             a.创建人, 
             a.创建时间, 
             a.修改人, 
             a.修改时间, 
             Null As 内容 
        From 影像报告原型清单 A, 影像报告种类 B 
       Where a.种类 = b.编码; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Output_Antetypelist; 
 
  --15.添加原型片段 
  Procedure p_Add_Antetype_Fragments( 
    原型ID_In 影像报告原型片段.原型ID%Type, 
	片段ID_In 影像报告原型片段.片段ID%Type) As 
  Begin 
    Insert Into 影像报告原型片段 
      (原型ID, 片段ID) 
    Values 
      (原型ID_In, 片段ID_In); 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Add_Antetype_Fragments; 
 
  --16.删除原型片段 
  Procedure p_Del_Antetype_Fragments( 
    原型ID_In 影像报告原型片段.原型ID%Type 
	) As 
  Begin 
    Delete From 影像报告原型片段 Where 原型ID = 原型ID_In; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Del_Antetype_Fragments; 
 
  --17.获取原型片段 
  Procedure p_Get_Antetype_Fragments( 
	Val           Out t_Refcur, 
	原型ID_In 影像报告原型片段.原型ID%Type 
	) As 
  Begin 
    Open Val For 
      Select RawtoHex(片段ID) 片段ID 
        From 影像报告原型片段 A 
       Where a.原型ID = 原型ID_In; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Get_Antetype_Fragments; 
 
  --18.获取某个原型关联的某个片段分类 
  Procedure p_Get_Antetype_f_Byaidfid( 
	Val           Out t_Refcur, 
	原型ID_In 影像报告原型片段.原型ID%Type, 
	片段ID_In 影像报告原型片段.片段ID%Type 
	) As 
  Begin 
    Open Val For 
      Select RawtoHex(片段ID) 片段ID 
        From 影像报告原型片段 A 
       Where a.原型ID = 原型ID_In 
         And a.片段ID = 片段ID_In; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Get_Antetype_f_Byaidfid; 
 
  --19.插入文档原型XML内容 
  Procedure p_Edit_Antetypelist_Content( 
    ID_In     影像报告原型清单.Id%Type, 
	内容_In   影像报告原型清单.内容%Type, 
	修改人_In 影像报告原型清单.修改人%Type 
	) As 
  Begin 
    Update 影像报告原型清单 
       Set 内容 = 内容_In, 修改人 = 修改人_In, 修改时间 = Sysdate 
     Where ID = ID_In; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Edit_Antetypelist_Content; 
 
  --20.获取所有原型 
  Procedure p_Get_All_Antetype_Lists( 
    Val Out t_Refcur 
	) As 
  Begin 
    Open Val For 
      Select RawtoHex(ID) ID, 
             a.编码, 
             编码 || '-' || 名称 As 名称, 
             分组, 
             a.种类, 
             a.是否禁用, 
             a.说明, 
             Decode(a.是否禁用, 1, 2, 1) Imageindex, 
             (Nvl(a.内容, XmlType('<ZLXML/>'))).GetClobVal() As 内容 
        From 影像报告原型清单 A 
       Order By a.编码; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Get_All_Antetype_Lists; 
 
  --21.获取已经设置了关联的原型片段类别的信息 
  Procedure p_Get_Antetype_Fragments_Info( 
	Val           Out t_Refcur, 
	原型ID_In 影像报告原型片段.原型ID%Type 
	) As 
  Begin 
    Open Val For 
      Select RawtoHex(ID) ID, 
             a.编码, 
             a.名称, 
             a.编码 || '-' || a.名称 标题, 
             a.说明 
        From 影像报告片段清单 A 
       Where a.Id In (Select b.片段id 
                        From 影像报告原型片段 B 
                       Where b.原型id = 原型ID_In) 
       Order By a.编码; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Get_Antetype_Fragments_Info; 
 
  --22.获取选择的类别下面的短语名称 
  Procedure p_Get_Selected_Fragments( 
	Val           Out t_Refcur, 
	原型ID_In Varchar2 
	) As 
    v_Sql  Varchar2(4000); 
    v_Aids Varchar2(4000); 
    v_Msg  Varchar2(4000); 
    Err Exception; 
  Begin 
    For Myrow In (Select RawtoHex(a.片段id) ID 
                    From 影像报告原型片段 A 
                   Where a.原型id = 原型ID_In) Loop 
      If v_Aids Is Null Then 
        v_Aids := '''' || Myrow.Id || ''''; 
      Else 
        v_Aids := v_Aids || ',''' || Myrow.Id || ''''; 
      End If; 
    End Loop; 
 
    If v_Aids Is Null Then 
      If Substr(原型ID_In, 0, 1) <> '''' Then 
        v_Aids := '''' || 原型ID_In || ''''; 
      Else 
        v_Aids := 原型ID_In; 
      End If; 
    End If; 
 
    v_Sql := 'Select Distinct  RawtoHex(a.id) ID,  RawtoHex(a.上级ID) 上级ID , a.编码, a.编码 || ''-'' || a.名称 标题,Decode(a.节点类型, 0, 0, 1) 节点类型
      From 影像报告片段清单 A
      Start With a.Id In (' || v_Aids || ')
      Connect By Prior a.Id = a.上级ID
      Order By a.编码'; 
 
    Open Val For v_Sql; 
  Exception 
    When Err Then 
      Raise_Application_Error(-20101, v_Msg); 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Get_Selected_Fragments; 
 
  --23.获取能复制的原型名称 
  Procedure p_Get_Copy_Antetype( 
	Val           Out t_Refcur, 
	种类_In 影像报告原型清单.种类%Type 
	) As 
  Begin 
    Open Val For 
      Select RawtoHex(a.id) ID, a.编码 || '-' || a.名称 标题 
        From 影像报告原型清单 A 
       Where a.种类 = 种类_In 
       Order By a.编码; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Get_Copy_Antetype; 
 
  --24.获取原型的分组信息 
  Procedure p_Get_Antetype_Category( 
	Val           Out t_Refcur, 
	种类_In 影像报告原型清单.种类%Type 
	) As 
  Begin 
    Open Val For 
      Select Distinct a.分组 As 分组 
        From 影像报告原型清单 A 
       Where a.种类 = 种类_In 
         and a.分组 Is Not Null; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Get_Antetype_Category; 
 
  --25.根据原型同步范文提纲 
  Procedure p_Synchronous_Sample( 
    原型ID_In 影像报告原型清单.Id%Type 
	) As 
    x_Content Xmltype; 
    x_Result  Xmltype; 
    Cursor c_Antetype Is 
      Select Extractvalue(c.Column_Value, '/section/@iid') Iid, 
             Extractvalue(c.Column_Value, '/section/@title') Title, 
             c.Column_Value As Content 
        From 影像报告原型清单 A, 
             Table(Xmlsequence(Extract(a.内容, '/zlxml//section'))) C 
       Where a.Id = 原型ID_In; 
    n_i               Number; 
    n_j               Number; 
    n_Count           Number; 
    x_Subdocuments    Xmltype; 
    x_Docparameters   Xmltype; 
    x_Antetypecontent Xmltype; 
    v_Textstyleno     Varchar2(10); 
    v_Parastyleno     Varchar2(10); 
    x_Acontent        Xmltype; 
  Begin 
    For Mysample In (Select b.id, b.内容 
                       From 影像报告范文清单 B 
                      Where b.原型id = 原型ID_In) Loop 
      x_Content := Mysample.内容; 
      n_i       := 1; 
      If x_Content Is Null Then 
        Select a.内容 
          Into x_Result 
          From 影像报告原型清单 A 
         Where a.Id = 原型ID_In; 
      Else 
        Begin 
          Select Extractvalue(c.Column_Value, '/section/@textstyleno') Textstyleno, 
                 Extractvalue(c.Column_Value, '/section/@parastyleno') Parastyleno 
            Into v_Textstyleno, v_Parastyleno 
            From Table(Xmlsequence(Extract(x_Content, '/zlxml//section'))) C 
           Where Rownum = 1; 
        Exception 
          When Others Then 
            v_Textstyleno := '1'; 
            v_Parastyleno := '1'; 
        End; 
 
        For Myantetype In c_Antetype Loop 
          For I In 1 .. 1 Loop 
            If n_i <> 1 Or n_Count <> 0 Or n_Count Is Null Then 
              Select Count(*) 
                Into n_Count 
                From Table(Xmlsequence(Extract(x_Content, '/zlxml//section'))) C; 
            End If; 
            If n_Count < n_i Then 
              Select Updatexml(Myantetype.Content, 
                               '//section/@textstyleno', 
                               v_Textstyleno) 
                Into x_Acontent 
                From Dual; 
              Select Updatexml(x_Acontent, 
                               '//section/@parastyleno', 
                               v_Parastyleno) 
                Into x_Acontent 
                From Dual; 
              Select Appendchildxml(x_Content, 
                                    '/zlxml/document', 
                                    x_Acontent) 
                Into x_Content 
                From Dual; 
              Exit; 
            End If; 
            n_j := 1; 
            For Mysample In (Select Extractvalue(c.Column_Value, 
                                                 '/section/@iid') Iid, 
                                    Extractvalue(c.Column_Value, 
                                                 '/section/@title') Title 
                               From Table(Xmlsequence(Extract(x_Content, 
                                                              '/zlxml//section'))) C) Loop 
              If n_i = n_j Then 
                If Myantetype.Iid <> Mysample.Iid Then 
                  Select Updatexml(Myantetype.Content, 
                                   '//section/@textstyleno', 
                                   v_Textstyleno) 
                    Into x_Acontent 
                    From Dual; 
                  Select Updatexml(x_Acontent, 
                                   '//section/@parastyleno', 
                                   v_Parastyleno) 
                    Into x_Acontent 
                    From Dual; 
                  Select Deletexml(x_Content, 
                                   '//section[@iid="' || Myantetype.Iid || '"]') 
                    Into x_Content 
                    From Dual; 
                  Select Insertxmlbefore(x_Content, 
                                         '//section[@iid="' || Mysample.Iid || '"]', 
                                         x_Acontent) 
                    Into x_Content 
                    From Dual; 
                  n_j := n_j + 1; 
                  Exit; 
                Else 
                  n_j := n_j + 1; 
                  Exit; 
                End If; 
              End If; 
              n_j := n_j + 1; 
            End Loop; 
            n_i := n_i + 1; 
          End Loop; 
        End Loop; 
        x_Result := x_Content; 
        For Mysample2 In (Select Iid 
                            From (Select Extractvalue(c.Column_Value, 
                                                      '/section/@iid') Iid 
                                    From Table(Xmlsequence(Extract(x_Content, 
                                                                   '/zlxml//section'))) C) C 
                           Where c.Iid Not In 
                                 (Select Extractvalue(c.Column_Value, 
                                                      '/section/@iid') Iid 
                                    From 影像报告原型清单 A, 
                                         Table(Xmlsequence(Extract(a.内容, 
                                                                   '/zlxml//section'))) C 
                                   Where a.Id = 原型ID_In)) Loop 
          Select Deletexml(x_Result, 
                           '//section[@iid="' || Mysample2.Iid || '"]') 
            Into x_Result 
            From Dual; 
        End Loop; 
      End If; 
 
      Update 影像报告范文清单 X 
         Set x.内容 = x_Result 
       Where x.Id = Mysample.Id; 
    End Loop; 
 
    Select a.内容 
      Into x_Antetypecontent 
      From 影像报告原型清单 A 
     Where a.Id = 原型ID_In; 
    Select Extract(x_Antetypecontent, 'zlxml/subdocuments') 
      Into x_Subdocuments 
      From Dual; 
    Select Extract(x_Antetypecontent, 'zlxml/docparameters') 
      Into x_Docparameters 
      From Dual; 
    Update 影像报告范文清单 
       Set 内容 = Updatexml(内容, '/zlxml/subdocuments', x_Subdocuments) 
     Where 原型ID = 原型ID_In; 
    Update 影像报告范文清单 
       Set 内容 = Updatexml(内容, '/zlxml/docparameters', x_Docparameters) 
     Where 原型ID = 原型ID_In; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Synchronous_Sample; 
 
  --26.获取导出的原型列表 
  Procedure p_Get_Out_Antetypelist( 
    Val Out t_Refcur 
	) As 
  Begin 
    Open Val For 
      Select ID, 
             编码, 
             标题, 
             Parentid, 
             种类, 
             是否禁用, 
             说明, 
             Imageindex, 
             名称 
        From (Select a.编码 As ID, 
                     a.编码 As 编码, 
                     a.名称 As 标题, 
                     '' As Parentid, 
                     '-1' As 种类, 
                     0 As 是否禁用, 
                     a.说明 As 说明, 
                     4 As Imageindex, 
                     a.名称 名称 
                From 影像报告种类 A 
              Union 
              Select Distinct a.种类 || '-' || a.分组 As ID, 
                              (Select Min(编码) 
                                 From 影像报告原型清单 B 
                                Where b.分组 = a.分组) As 编码, 
                              Max(a.分组) As 名称, 
                              a.种类 As Parentid, 
                              '0' As 种类, 
                              0 As 是否禁用, 
                              '' As 说明, 
                              4 As Imageindex, 
                              a.分组 
                From 影像报告原型清单 A 
               Where a.分组 Is Not Null 
               Group By a.种类, a.分组 
              Union 
              Select RawTohex(ID), 
                     a.编码, 
                     编码 || '-' || 名称 As 标题, 
                     Decode(a.分组, Null, a.种类, a.种类 || '-' || a.分组) Parentid, 
                     a.种类 As 种类, 
                     a.是否禁用, 
                     a.说明, 
                     Decode(a.是否禁用, 1, 1, 0, 2), 
                     a.名称 
                From 影像报告原型清单 A) A 
       Order By a.编码; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Get_Out_Antetypelist; 
 
  --27.通过编码获取原型种类信息 
  Procedure p_Get_Antetype_Kind_By_Code( 
	Val           Out t_Refcur, 
	编码_In 影像报告种类.编码%Type 
	) As 
  Begin 
    Open Val For 
      Select a.编码, a.名称, a.说明 
        From 影像报告种类 A 
       Where a.编码 = 编码_In; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Get_Antetype_Kind_By_Code; 
  --28.获取事件信息，不包含固定事件 
  Procedure p_Get_Doc_Event( 
    Val Out t_Refcur 
	) As 
  Begin 
    Open Val For 
      Select RawtoHex(a.id) ID, 
             a.种类, 
             a.原型id, 
             a.编号, 
             a.名称, 
             a.说明, 
             a.元素iid, 
             a.扩展标记 
        From 影像报告事件 A 
       Where a.种类 <> 1; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Get_Doc_Event; 
 
  --29.获取关于原型导出的重复信息 
  Procedure p_Get_Antetypelist_Same_Info( 
	Val           Out t_Refcur, 
	Tablename_In Varchar2, 
	ID_In        影像报告原型清单.Id%Type, 
	编码_In      Varchar2, 
	名称_In      Varchar2 
	) As 
    n_Num    Number; 
    v_Result Varchar2(100); 
    v_Sql    Varchar2(4000); 
  Begin 
    If ID_In Is Not Null Then 
      v_Sql := 'select count(*) from ' || Tablename_In || ' where id=' || 
               ID_In; 
      Execute Immediate v_Sql 
        Into n_Num; 
      If n_Num > 0 Then 
        v_Result := 'ID重复'; 
      End If; 
    End If; 
    If 编码_In Is Not Null Then 
      v_Sql := 'select count(*) from ' || Tablename_In || ' where 编码=''' || 
               编码_In || ''''; 
      Execute Immediate v_Sql 
        Into n_Num; 
      If n_Num > 0 Then 
        If v_Result Is Not Null Then 
          v_Result := v_Result || ',编码重复'; 
        Else 
          v_Result := '编码重复'; 
        End If; 
      End If; 
    End If; 
    If 名称_In Is Not Null Then 
      v_Sql := 'select count(*) from ' || Tablename_In || ' where 名称=''' || 
               名称_In || ''''; 
      Execute Immediate v_Sql 
        Into n_Num; 
      If n_Num > 0 Then 
        If v_Result Is Not Null Then 
          v_Result := v_Result || ',名称重复'; 
        Else 
          v_Result := '名称重复'; 
        End If; 
      End If; 
    End If; 
    Open Val For 
      Select v_Result Result From Dual; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Get_Antetypelist_Same_Info; 
 
  --30.获取事件重复的信息 
  Procedure p_Event_Same_Info( 
	Val           Out t_Refcur, 
	ID_In      影像报告事件.Id%Type, 
    原型ID_In  影像报告事件.原型ID%Type, 
    元素IID_In 影像报告事件.元素IID%Type, 
    种类_In    影像报告事件.种类%Type, 
    名称_In    影像报告事件.名称%Type, 
    编号_In    影像报告事件.编号%Type 
	) As 
    v_Same_Antetype Varchar2(50); 
    n_Same_Id       Number; 
    n_Same_Title    Number; 
    n_Same_Seqnum   Number; 
    n_Maxnum        Number; 
  Begin 
    Select Count(*) 
      Into n_Same_Title 
      From 影像报告事件 A 
     Where a.原型ID = 原型ID_In 
       And a.种类 = 种类_In 
       And a.名称 = 名称_In; 
    Select Count(*) 
      Into n_Same_Seqnum 
      From 影像报告事件 A 
     Where a.原型ID = 原型ID_In 
       And a.种类 = 种类_In 
       And a.编号 = 编号_In; 
    Begin 
      Select a.Id 
        Into v_Same_Antetype 
        From 影像报告事件 A 
       Where a.原型ID = 原型ID_In 
         And a.元素IID = 元素IID_In; 
    Exception 
      When Others Then 
        v_Same_Antetype := ''; 
    End; 
 
    Select Count(*) Into n_Same_Id From 影像报告事件 A Where a.Id = ID_In; 
    Select Max(a.编号) Into n_Maxnum From 影像报告事件 A; 
 
    Open Val For 
      Select v_Same_Antetype As Sameaid, 
             n_Same_Id       As Sameid, 
             n_Same_Title    As Sametitle, 
             n_Same_Seqnum   As Sameseqnum, 
             n_Maxnum        As Maxnum 
        From Dual; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Event_Same_Info; 
 
  --31.获取原型校验的类别集合 
  Procedure p_Get_Process_Kind( 
    Val Out t_Refcur 
	) As 
  Begin 
    Open Val For 
      Select Distinct 动作类型 
        From (Select Extractvalue(c.Column_Value, '/step/kind') As 动作类型 
                From 影像报告动作 A, 
                     Table(Xmlsequence(Extract(a.内容, '/root/step'))) C) B 
       Where b.动作类型 Is Not Null; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Get_Process_Kind; 
 
 
  --33.获取指定原型的文档处理 
  Procedure p_Get_Doc_Process_Of_Antetype( 
	Val           Out t_Refcur, 
	原型ID_In 影像报告动作.原型id%Type 
	) As 
  Begin 
    Open Val For 
      Select RawtoHex(p.id) ID, 
             p.名称, 
             p.动作类型, 
             p.序号, 
             p.说明, 
             p.可否手工执行, 
             (Nvl(p.内容, XmlType('<NULL/>'))).GetClobVal() As 内容, --Nvl(p.内容,'<NULL/>') As 内容, 
             RawtoHex(p.事件ID) 事件ID, 
             0 Is_Event 
        From 影像报告动作 P 
       Where p.原型ID = 原型ID_In 
      Union All 
      Select RawtoHex(e.id) ID, 
             e.名称, 
             e.种类, 
             e.编号, 
             e.说明, 
             Null, 
             (XmlType('<Null/>')).GetClobVal() As 内容, --(Null,'<NULL/>') As 内容, 
             Null, 
             1 
        From 影像报告事件 E 
       Where e.Id In (Select RawtoHex(事件ID) 事件ID 
                        From 影像报告动作 
                       Where 原型ID = 原型ID_In) 
       Order By Is_Event, 动作类型, 序号; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Get_Doc_Process_Of_Antetype; 
 
  --34. 根据字典名称获取相应子项 
  Procedure p_Get_Dictitems_By_Title( 
	Val           Out t_Refcur, 
	名称_In 影像字典清单.名称%Type 
	) As 
  Begin 
    Open Val For 
      Select a.编号, a.名称, Rawtohex(a.字典id) As 字典ID 
        From 影像字典内容 A 
       Where a.字典id In (Select id From 影像字典清单 b Where b.名称 = 名称_In); 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Get_Dictitems_By_Title; 
 
  --35.获得所有的预备提纲 
  Procedure p_Get_All_Phr_Onlines( 
    Val Out t_Refcur 
	) As 
  Begin 
    Open Val For 
      Select Rawtohex(ID) ID, a.编码, a.名称 
        From 影像报告预备提纲 a 
       Order By a.编码; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Get_All_Phr_Onlines; 
 
  --36.获取所有词句信息 
  Procedure p_Get_All_Fragment( 
	Val           Out t_Refcur, 
	学科_In Varchar2 
	) As 
  Begin 
    If 学科_In <> '' Then 
      Open Val For 
        Select RawToHex(a.id) ID, 
               RawToHex(a.上级id) 上级id, 
               a.编码, 
               a.名称, 
               a.说明, 
               a.节点类型, 
               (Nvl(a.组成, XmlType('<NULL/>'))).GetClobVal() As 组成, 
               a.学科, 
               a.标签, 
               a.是否私有, 
               a.作者 
          From 影像报告片段清单 A 
         Where (a.学科 In 
               (Select /*+rule*/ 
                  Column_Value As Lable 
                   From Table(b_PACS_RptPublic.f_Str2list(学科_In, ',')) 
                 Intersect 
                 Select /*+rule*/ 
                  Column_Value As Lable 
                   From Table(b_PACS_RptPublic.f_Str2list(a.学科, ','))) And 
               a.节点类型 <> 0) 
            Or a.节点类型 = 0 
            Or a.学科 Is Null 
         Order By a.编码, a.上级id; 
    Else 
      Open Val For 
        Select RawToHex(a.id) ID, 
               RawToHex(a.上级id) 上级id, 
               a.编码, 
               a.名称, 
               a.说明, 
               a.节点类型, 
               (Nvl(a.组成, XmlType('<NULL/>'))).GetClobVal() As 组成, 
               a.学科, 
               a.标签, 
               a.是否私有, 
               a.作者 
          From 影像报告片段清单 A 
         Order By a.上级id, a.节点类型, a.编码, a.名称; 
    End If; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Get_All_Fragment; 
 
  --37. 获取词句信息 
  Procedure p_Get_Fragment_Filter( 
	Val           Out t_Refcur, 
	原型id_In 影像报告原型片段.原型ID%Type, 
    作者_In   影像报告片段清单.作者%Type, 
    学科_In   影像报告片段清单.学科%Type, 
    Type_In   Varchar2 
	) As 
  Begin 
    If Type_In = '1' Then 
      Open Val For 
        Select Rawtohex(b.Id) ID, 
               Rawtohex(b.上级id) 上级id, 
               b.编码, 
               b.名称, 
               b.说明, 
               b.节点类型, 
               (Nvl(b.组成, XmlType('<NULL/>'))).GetClobVal() As 组成, 
               b.学科, 
               b.标签, 
               b.是否私有, 
               b.作者, 
               b.最后编辑时间 
          From 影像报告原型片段 A, 影像报告片段清单 B 
         Where a.片段id = b.id 
           And a.原型id = 原型id_In; 
    Else 
      Open Val For 
        Select /*+ rule*/ 
         Rawtohex(b.Id) ID, 
         Rawtohex(b.上级id) 上级id, 
         b.编码, 
         b.名称, 
         b.说明, 
         b.节点类型, 
         (Nvl(b.组成, XmlType('<NULL/>'))).GetClobVal() As 组成, 
         b.学科, 
         b.标签, 
         b.是否私有, 
         b.作者, 
         b.最后编辑时间 
          From 影像报告片段清单 B 
         Where b.上级id = 原型id_In 
           And (b.是否私有 = 0 Or (b.是否私有 = 1 And b.作者 = 作者_In)) 
           And (b.学科 Is Null Or 
               (b.学科 Is Not Null And 
               b_PACS_RptPublic.f_If_Intersect(b.学科, 学科_In) > 0)); 
    End If; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Get_Fragment_Filter; 
 
  --38.根据原型获取关联的片段标签值 
  Procedure p_Get_Label_By_Aid( 
	Val           Out t_Refcur, 
	原型ID_In 影像报告原型片段.原型ID%Type 
	) As 
  Begin 
    Open Val For 
      Select Distinct b.标签 
        From 影像报告片段清单 B 
       Start With b.上级id In (Select a.片段id 
                               From 影像报告原型片段 A 
                              Where a.原型id = 原型ID_In) 
      Connect By Prior b.Id = b.上级id; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Get_Label_By_Aid; 
 
  --39.获取所有词句分类 
  Procedure p_Get_All_Fragment_Class( 
    Val Out t_Refcur 
	) As 
  Begin 
    Open Val For 
      Select Rawtohex(a.Id) ID, 
             Rawtohex(a.上级id) 上级id, 
             a.编码, 
             a.名称, 
             a.说明, 
             a.节点类型 
        From 影像报告片段清单 A 
       Where a.节点类型 = 0 
       Start With 上级id Is Null 
      Connect By Prior id = 上级id 
       Order By 编码; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Get_All_Fragment_Class; 
 
  --40.获取表名对应的最后编辑时间 
  Procedure p_Get_Data_Last_Edit_Time( 
	Val           Out t_Refcur, 
	Table_Name_In Varchar2 
	) As 
    v_sql Varchar2(4000); 
  Begin 
    v_sql := 'select max(最后编辑时间) maxvalue from ' || Table_Name_In; 
    Open val For v_sql; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Get_Data_Last_Edit_Time; 
 
  --41.添加文档事件 
  Procedure p_Add_Doc_Event( 
    ID_In       影像报告事件.ID%Type, 
    种类_In     影像报告事件.种类%Type, 
    原型ID_In   影像报告事件.原型ID%Type, 
    编号_In     影像报告事件.编号%Type, 
    名称_In     影像报告事件.名称%Type, 
    说明_In     影像报告事件.说明%Type, 
    元素IID_In  影像报告事件.元素IID%Type, 
    扩展标记_In 影像报告事件.扩展标记%Type 
	) As 
    n_Seq_Num  影像报告事件.编号%Type; 
    n_Is_Exist Number(1) := 0; 
    v_Err_Msg  Varchar2(100); 
    Err_Item Exception; 
  Begin 
    Select Count(*) 
      Into n_Is_Exist 
      From 影像报告事件 
     Where 原型ID = 原型ID_In 
       And 种类 = 种类_In 
       And 名称 = 名称_In; 
 
    If n_Is_Exist > 0 Then 
      v_Err_Msg := '[ZLSOFT]原型上已存在相同命名的事件[ZLSOFT]'; 
      Raise Err_Item; 
    End If; 
 
    If (编号_In Is Null Or 编号_In = 0) Then 
      Select Nvl(Max(编号), 0) + 1 Into n_Seq_Num From 影像报告事件; 
    Else 
      Select Count(*) 
        Into n_Is_Exist 
        From 影像报告事件 
       Where 原型ID = 原型ID_In 
         And 种类 = 种类_In 
         And 编号 = 编号_In; 
      If n_Is_Exist > 0 Then 
        v_Err_Msg := '[ZLSOFT]原型上已存在相同编号的事件[ZLSOFT]'; 
        Raise Err_Item; 
      End If; 
      n_Seq_Num := 编号_In; 
    End If; 
 
    Insert Into 影像报告事件 
      (ID, 种类, 原型ID, 编号, 名称, 说明, 元素IID, 扩展标记) 
    Values 
      (ID_In, 
       种类_In, 
       原型ID_In, 
       n_Seq_Num, 
       名称_In, 
       说明_In, 
       元素IID_In, 
       扩展标记_In); 
  Exception 
    When Err_Item Then 
      Raise_Application_Error(-20101, v_Err_Msg); 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Add_Doc_Event; 
 
  --42.修改文档事件 
  Procedure p_Update_Doc_Event( 
    Id_In       影像报告事件.Id%Type, 
    种类_In     影像报告事件.种类%Type, 
    名称_In     影像报告事件.名称%Type, 
    说明_In     影像报告事件.说明%Type, 
    元素IID_In  影像报告事件.元素IID%Type, 
    扩展标记_In 影像报告事件.扩展标记%Type 
	) As 
    r_Aid      影像报告事件.原型ID%Type; 
    n_Is_Exist Number(1) := 0; 
    v_Err_Msg  Varchar2(100); 
    Err_Item Exception; 
  Begin 
    Select 原型ID Into r_Aid From 影像报告事件 Where ID = Id_In; 
 
    Select Count(*) 
      Into n_Is_Exist 
      From 影像报告事件 
     Where 原型ID = r_Aid 
       And 种类 = 种类_In 
       And 名称 = 名称_In 
       And ID <> Id_In; 
 
    If n_Is_Exist > 0 Then 
      v_Err_Msg := '[ZLSOFT]原型上存在相同命名的事件[ZLSOFT]'; 
      Raise Err_Item; 
    End If; 
 
    Update 影像报告事件 
       Set 种类     = 种类_In, 
           名称     = 名称_In, 
           说明     = 说明_In, 
           元素IID  = 元素IID_In, 
           扩展标记 = 扩展标记_In 
     Where ID = Id_In; 
  Exception 
    When Err_Item Then 
      Raise_Application_Error(-20101, v_Err_Msg); 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Update_Doc_Event; 
 
  --43.删除文档事件 
  Procedure p_Delete_Doc_Event( 
    Id_In 影像报告事件.Id%Type 
	) As 
    n_Kind     影像报告事件.种类%Type; 
    n_Is_Exist Number(1) := 0; 
    v_Err_Msg  Varchar2(100); 
    Err_Item Exception; 
  Begin 
    Select 种类 Into n_Kind From 影像报告事件 Where ID = Id_In; 
 
    If n_Kind = 1 Then 
      v_Err_Msg := '[ZLSOFT]不允许删除固定事件[ZLSOFT]'; 
      Raise Err_Item; 
    End If; 
 
    Select Count(*) Into n_Is_Exist From 影像报告动作 Where 事件ID = Id_In; 
 
    If n_Is_Exist > 0 Then 
      v_Err_Msg := '[ZLSOFT]事件已经被使用,不能被删除！[ZLSOFT]'; 
      Raise Err_Item; 
    End If; 
 
    Delete From 影像报告事件 Where ID = Id_In; 
  Exception 
    When Err_Item Then 
      Raise_Application_Error(-20101, v_Err_Msg); 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Delete_Doc_Event; 
 
  --44.删除所有未被使用的文档事件 
  Procedure p_Delete_Unused_Doc_Events( 
    Count_Out Out Number 
	) As 
  Begin 
    Delete From 影像报告事件 
     Where 种类 <> 1 
       And ID Not In 
           (Select 事件ID From 影像报告动作 Where 事件ID Is Not Null); 
    Count_Out := Sql%RowCount; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Delete_Unused_Doc_Events; 
 
  --45.获取指定原型的文档事件 
  Procedure p_Get_Doc_Event_Of_Antetype( 
	Val           Out t_Refcur, 
	原型ID_In       影像报告事件.原型ID%Type, 
	Include_Base_In Number 
	) As 
  Begin 
    If Include_Base_In = 1 Then 
      Open Val For 
        Select Rawtohex(t.Id) ID, 
               t.种类, 
               t.名称, 
               t.说明, 
               t.元素iid, 
               t.扩展标记, 
               Nvl(p.Used_Count, 0) Used_Count 
          From 影像报告事件 T, 
               (Select Count(*) Used_Count, Max(事件ID) 事件ID 
                  From 影像报告动作 
                 Where 事件ID Is Not Null 
                 Group By 事件ID) P 
         Where (t.种类 = 1 Or t.原型id = 原型ID_In) 
           And t.Id = p.事件ID(+) 
         Order By t.编号; 
    Else 
      Open Val For 
        Select Rawtohex(t.Id) ID, 
               t.种类, 
               t.名称, 
               t.说明, 
               t.元素iid, 
               t.扩展标记, 
               Nvl(p.Used_Count, 0) Used_Count 
          From 影像报告事件 T, 
               (Select Count(*) Used_Count, Max(事件ID) 事件ID 
                  From 影像报告动作 
                 Where 事件ID Is Not Null 
                 Group By 事件ID) P 
         Where t.原型id = 原型ID_In 
           And t.种类 <> 1 
           And t.Id = p.事件ID(+) 
         Order By t.编号; 
    End If; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Get_Doc_Event_Of_Antetype; 
 
  --46.修改文档处理编号 
  Procedure p_Update_Doc_Process_Seqnum( 
    Id_In   影像报告动作.Id%Type, 
	序号_In 影像报告动作.序号%Type) As 
  Begin 
    Update 影像报告动作 Set 序号 = 序号_In Where ID = Id_In; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Update_Doc_Process_Seqnum; 
 
  --47.添加文档处理 
  Procedure p_Add_Doc_Process( 
    Id_In           影像报告动作.Id%Type, 
    原型ID_In       影像报告动作.原型ID%Type, 
    事件ID_In       影像报告动作.事件ID%Type, 
    动作类型_In     影像报告动作.动作类型%Type, 
    名称_In         影像报告动作.名称%Type, 
    说明_In         影像报告动作.说明%Type, 
    可否手工执行_In 影像报告动作.可否手工执行%Type, 
    序号_In         影像报告动作.序号%Type, 
    内容_In         影像报告动作.内容%Type 
	) As 
    n_Seq_Num  影像报告动作.序号%Type; 
    n_Is_Exist Number(1) := 0; 
    v_Err_Msg  Varchar2(100); 
    Err_Item Exception; 
  Begin 
    Select Count(*) 
      Into n_Is_Exist 
      From 影像报告动作 
     Where 原型ID = 原型ID_In 
       And 名称 = 名称_In; 
    If (序号_In Is Null Or 序号_In = 0) Then 
      If (事件ID_In Is Null) Then 
        Select Nvl(Max(序号), 0) + 1 
          Into n_Seq_Num 
          From 影像报告动作 
         Where 原型ID = 原型ID_In 
           And 事件ID Is Null; 
      Else 
        Select Nvl(Max(序号), 0) + 1 
          Into n_Seq_Num 
          From 影像报告动作 
         Where 原型ID = 原型ID_In 
           And 事件ID = 事件ID_In; 
      End If; 
    Else 
      n_Seq_Num := 序号_In; 
    End If; 
    If n_Is_Exist > 0 Then 
      v_Err_Msg := '[ZLSOFT]原型上存在相同命名的动作[ZLSOFT]'; 
      Raise Err_Item; 
    End If; 
    Insert Into 影像报告动作 
      (ID, 原型ID, 事件ID, 动作类型, 名称, 说明, 可否手工执行, 序号, 内容) 
    Values 
      (Id_In, 
       原型ID_In, 
       事件ID_In, 
       动作类型_In, 
       名称_In, 
       说明_In, 
       可否手工执行_In, 
       n_Seq_Num, 
       内容_In); 
  Exception 
    When Err_Item Then 
      Raise_Application_Error(-20101, v_Err_Msg); 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Add_Doc_Process; 
 
  --48.修改文档处理 
  Procedure p_Update_Doc_Process( 
    Id_In           影像报告动作.Id%Type, 
    事件ID_In       影像报告动作.事件ID%Type, 
    动作类型_In     影像报告动作.动作类型%Type, 
    名称_In         影像报告动作.名称%Type, 
    说明_In         影像报告动作.说明%Type, 
    可否手工执行_In 影像报告动作.可否手工执行%Type, 
    内容_In         影像报告动作.内容%Type 
	) As 
    r_Aid          影像报告事件.原型ID%Type; 
    r_Old_Event_Id 影像报告动作.事件ID%Type; 
    n_Seq_Num      影像报告事件.编号%Type; 
    n_Is_Exist     Number(1) := 0; 
    v_Err_Msg      Varchar2(100); 
    Err_Item Exception; 
  Begin 
    Select 原型ID Into r_Aid From 影像报告动作 Where ID = Id_In; 
    If (事件ID_In Is Not Null) Then 
      Select Count(*) 
        Into n_Is_Exist 
        From 影像报告事件 
       Where (原型ID Is Null Or 原型ID = r_Aid) 
         And ID = 事件ID_In; 
 
      If n_Is_Exist = 0 Then 
        v_Err_Msg := '[ZLSOFT]关联的事件不存在[ZLSOFT]'; 
        Raise Err_Item; 
      End If; 
 
    End If; 
 
    Select Count(*) 
      Into n_Is_Exist 
      From 影像报告动作 
     Where 原型ID = r_Aid 
       And 名称 = 名称_In 
       And ID <> Id_In; 
 
    If n_Is_Exist > 0 Then 
      v_Err_Msg := '[ZLSOFT]原型上存在相同命名的动作[ZLSOFT]'; 
      Raise Err_Item; 
    End If; 
 
    If (r_Old_Event_Id <> 事件ID_In Or 
       (事件ID_In Is Null And r_Old_Event_Id Is Not Null)) Then 
      If (事件ID_In Is Null) Then 
        Select Nvl(Max(序号), 0) + 1 
          Into n_Seq_Num 
          From 影像报告动作 
         Where 原型ID = r_Aid 
           And 事件ID Is Null; 
      Else 
        Select Nvl(Max(序号), 0) + 1 
          Into n_Seq_Num 
          From 影像报告动作 
         Where 原型ID = r_Aid 
           And 事件ID = 事件ID_In; 
      End If; 
    Else 
      n_Seq_Num := 0; 
    End If; 
 
    If n_Seq_Num > 0 Then 
      Update 影像报告动作 
         Set 事件id       = 事件ID_In, 
             动作类型     = 动作类型_In, 
             名称         = 名称_In, 
             说明         = 说明_In, 
             可否手工执行 = 可否手工执行_In, 
             内容         = 内容_In, 
             序号         = n_Seq_Num 
       Where ID = Id_In; 
    Else 
      Update 影像报告动作 
         Set 事件id       = 事件ID_In, 
             动作类型     = 动作类型_In, 
             名称         = 名称_In, 
             说明         = 说明_In, 
             可否手工执行 = 可否手工执行_In, 
             内容         = 内容_In 
       Where ID = Id_In; 
    End If; 
  Exception 
    When Err_Item Then 
      Raise_Application_Error(-20101, v_Err_Msg); 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Update_Doc_Process; 
 
  --49.获取元素或者提纲的名称集合 
  Procedure p_Get_Antetype_Ele_Section( 
	Val           Out t_Refcur, 
	原型ID_In 影像报告原型清单.Id%Type, 
	Type_In   Varchar2 
	) As 
    c_Content Clob; 
  Begin 
    /*Select To_Clob(a.内容)*/ 
    Select a.内容.getclobval() 
      Into c_Content 
      From 影像报告原型清单 A 
     Where a.Id = 原型ID_In; 
 
    If Type_In = '1' Then 
      Open Val For 
        Select Distinct Name 
          From (Select Extractvalue(c.Column_Value, '/*/@title') As Name 
                  From Table(Xmlsequence(Extract(Xmltype(c_Content), 
                                                 '/zlxml/document//element[@sid and @title]|/zlxml/document//e_list[@sid and @title]|/zlxml/document//e_enum[@sid and @title]|/zlxml/document//e_etree[@sid and @title]|/zlxml/document//e_utree[@sid and @title]'))) C) A 
         Where a.Name Is Not Null; 
    Else 
      Open Val For 
        Select Distinct Name 
          From (Select Extractvalue(c.Column_Value, '/section/@title') As Name 
                  From Table(Xmlsequence(Extract(Xmltype(c_Content), 
                                                 '//section'))) C) A 
         Where a.Name Is Not Null; 
    End If; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Get_Antetype_Ele_Section; 
 
  --50.删除文档处理 
  Procedure p_Del_Doc_Process(Id_In        影像报告动作.ID%Type, 
                              Del_Event_In Number) As 
    r_Event_Id   影像报告动作.事件ID%Type := Null; 
    n_Event_Kind 影像报告事件.种类%Type; 
    n_Is_Exist   Number(1) := 0; 
  Begin 
    If Del_Event_In = 1 Then 
      Select Max(e.Id), Max(e.种类) 
        Into r_Event_Id, n_Event_Kind 
        From 影像报告动作 P, 影像报告事件 E 
       Where p.Id = Id_In 
         And p.事件id = e.Id; 
    End If; 
 
    Delete From 影像报告动作 Where ID = Id_In; 
 
    If Del_Event_In = 1 Then 
      If (r_Event_Id Is Not Null And n_Event_Kind <> 1) Then 
        Select Count(*) 
          Into n_Is_Exist 
          From 影像报告动作 
         Where 事件id = r_Event_Id; 
        If n_Is_Exist = 0 Then 
          Delete From 影像报告事件 
           Where ID = r_Event_Id 
             And 种类 <> 1; 
        End If; 
      End If; 
    End If; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Del_Doc_Process; 
 
  --51.查询元素值域类别的覆盖情况 
  Procedure p_Get_Ele_Same_Info( 
	Val           Out t_Refcur, 
	Id_In    影像报告值域清单.Id%Type, 
	Code_In  Varchar2, 
	Title_In Varchar2, 
	Flag_In  Varchar2 
	) As 
    v_Result  Varchar2(50); 
    v_Id      Varchar2(50); 
    v_Code_Id Varchar2(50); 
    n_Num     Number; 
  Begin 
    If Flag_In = 1 Then 
      Select Count(ID) 
        Into n_Num 
        From 影像报告元素分类 A 
       Where a.Id = Id_In; 
 
      If n_Num > 0 Then 
        Select Rawtohex(a.Id) 
          Into v_Id 
          From 影像报告元素分类 A 
         Where a.Id = Id_In; 
        If v_Id Is Not Null Then 
          v_Result := 'ID重复'; 
        End If; 
      End If; 
 
      Select Count(ID) 
        Into n_Num 
        From 影像报告元素分类 A 
       Where a.编码 = Code_In; 
 
      If n_Num > 0 Then 
        Select Rawtohex(a.Id) 
          Into v_Code_Id 
          From 影像报告元素分类 A 
         Where a.编码 = Code_In; 
        If v_Code_Id Is Not Null Then 
          If v_Result Is Not Null Then 
            v_Result := v_Result || ',编码重复'; 
          Else 
            v_Result := '编码重复'; 
          End If; 
        End If; 
      End If; 
 
      Select Count(ID) 
        Into n_Num 
        From 影像报告元素分类 A 
       Where a.名称 = Title_In; 
      If n_Num > 0 Then 
        Select Rawtohex(a.Id) 
          Into v_Id 
          From 影像报告元素分类 A 
         Where a.名称 = Title_In; 
        If v_Id Is Not Null Then 
          If v_Result Is Not Null Then 
            v_Result := v_Result || ',名称重复'; 
          Else 
            v_Result := '名称重复'; 
          End If; 
        End If; 
      End If; 
 
    End If; 
 
    If Flag_In = 2 Then 
      Select Count(ID) 
        Into n_Num 
        From 影像报告元素清单 A 
       Where a.Id = Id_In; 
      If n_Num > 0 Then 
        Select Rawtohex(a.Id) 
          Into v_Id 
          From 影像报告元素清单 A 
         Where a.Id = Id_In; 
        If v_Id Is Not Null Then 
          v_Result := 'ID重复'; 
        End If; 
      End If; 
 
      Select Count(ID) 
        Into n_Num 
        From 影像报告元素清单 A 
       Where a.编码 = Code_In; 
      If n_Num > 0 Then 
        Select Rawtohex(a.Id) 
          Into v_Code_Id 
          From 影像报告元素清单 A 
         Where a.编码 = Code_In; 
        If v_Code_Id Is Not Null Then 
          If v_Result Is Not Null Then 
            v_Result := v_Result || ',编码重复'; 
          Else 
            v_Result := '编码重复'; 
          End If; 
        End If; 
      End If; 
 
      Select Count(ID) 
        Into n_Num 
        From 影像报告元素清单 A 
       Where a.名称 = Title_In; 
      If n_Num > 0 Then 
        Select Rawtohex(a.Id) 
          Into v_Id 
          From 影像报告元素清单 A 
         Where a.名称 = Title_In; 
        If v_Id Is Not Null Then 
          If v_Result Is Not Null Then 
            v_Result := v_Result || ',名称重复'; 
          Else 
            v_Result := '名称重复'; 
          End If; 
        End If; 
      End If; 
 
    End If; 
 
    If Flag_In = 3 Then 
      Select Count(ID) 
        Into n_Num 
        From 影像报告值域清单 A 
       Where a.Id = Id_In; 
      If n_Num > 0 Then 
        Select Rawtohex(a.Id) 
          Into v_Id 
          From 影像报告值域清单 A 
         Where a.Id = Id_In; 
        If v_Id Is Not Null Then 
          v_Result := 'ID重复'; 
        End If; 
      End If; 
 
      Select Count(ID) 
        Into n_Num 
        From 影像报告值域清单 A 
       Where a.编码 = Code_In; 
      If n_Num > 0 Then 
        Select Rawtohex(a.Id) 
          Into v_Code_Id 
          From 影像报告值域清单 A 
         Where a.编码 = Code_In; 
        If v_Code_Id Is Not Null Then 
          If v_Result Is Not Null Then 
            v_Result := v_Result || ',编码重复'; 
          Else 
            v_Result := '编码重复'; 
          End If; 
        End If; 
      End If; 
 
      Select Count(ID) 
        Into n_Num 
        From 影像报告值域清单 A 
       Where a.名称 = Title_In; 
      If n_Num > 0 Then 
        Select Rawtohex(a.Id) 
          Into v_Id 
          From 影像报告值域清单 A 
         Where a.名称 = Title_In; 
        If v_Id Is Not Null Then 
          If v_Result Is Not Null Then 
            v_Result := v_Result || ',名称重复'; 
          Else 
            v_Result := '名称重复'; 
          End If; 
        End If; 
      End If; 
 
    End If; 
 
    Open Val For 
      Select v_Result As Result, v_Id As ID, v_Code_Id As Codesameid 
        From Dual; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Get_Ele_Same_Info; 
 
  --52.获得所有的插件信息 
  Procedure p_Get_DocPluginList( 
    Val Out t_Refcur 
	) As 
  Begin 
    Open Val For 
      Select Rawtohex(Id) ID, 
             编码, 
             名称, 
             说明, 
             显示样式, 
             种类, 
             Decode(显示样式, '1', '嵌入式', '弹出式') 显示样式II, 
             Decode(种类, '1', '专用插件', '共享插件') 种类II, 
             类名, 
             库名, 
             是否禁用, 
             Decode(是否禁用, '1', '停用', '启用') IsEnable 
        From 影像报告插件; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_Get_DocPluginList; 
 
  --53.该ID的插件是否被原型使用过 
  Procedure p_IsExit_DocPluginByID( 
    Val           Out t_Refcur, 
	ID_In Varchar2 
	) As 
    CURSOR C_EVENT Is 
      Select t.专用插件.getclobval() 专用插件 From 影像报告原型清单 t; 
    anum Int := 0; 
    sult Varchar2(6666); 
  Begin 
    For temp In C_EVENT Loop 
      If instr(temp.专用插件, ID_In) > 0 Then 
        anum := anum + 1; 
      End If; 
    End Loop; 
    Open Val For 
      Select anum From dual; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_IsExit_DocPluginByID; 
 
  --54.新增报告插件信息 
  Procedure p_AddDocPlugin( 
    ID_In       影像报告插件.ID%Type, 
    编码_In     影像报告插件.编码%Type, 
    名称_In     影像报告插件.名称%Type, 
    说明_In     影像报告插件.说明%Type, 
    显示样式_In 影像报告插件.显示样式%Type, 
    种类_In     影像报告插件.种类%Type, 
    类名_In     影像报告插件.类名%Type, 
    库名_In     影像报告插件.库名%Type, 
    是否禁用_In 影像报告插件.是否禁用%Type 
	) As 
  Begin 
    Insert Into 影像报告插件 
      (ID, 编码, 名称, 说明, 显示样式, 种类, 类名, 库名, 是否禁用) 
    Values 
      (ID_In, 
       编码_In, 
       名称_In, 
       说明_In, 
       显示样式_In, 
       种类_In, 
       类名_In, 
       库名_In, 
       是否禁用_In); 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_AddDocPlugin; 
 
  --55.修改报告插件信息 
  Procedure p_EditDocPlugin( 
    ID_In       影像报告插件.ID%Type, 
    编码_In     影像报告插件.编码%Type, 
    名称_In     影像报告插件.名称%Type, 
    说明_In     影像报告插件.说明%Type, 
    显示样式_In 影像报告插件.显示样式%Type, 
    种类_In     影像报告插件.种类%Type, 
    类名_In     影像报告插件.类名%Type, 
    库名_In     影像报告插件.库名%Type, 
    是否禁用_In 影像报告插件.是否禁用%Type 
	) As 
  Begin 
    Update 影像报告插件 
       Set 编码     = 编码_In, 
           名称     = 名称_In, 
           说明     = 说明_In, 
           显示样式 = 显示样式_In, 
           种类     = 种类_In, 
           类名     = 类名_In, 
           库名     = 库名_In, 
           是否禁用 = 是否禁用_In 
     Where ID = ID_In; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_EditDocPlugin; 
 
  --56.删除报告插件信息 
  Procedure p_DelDocPlugin( 
    ID_In 影像报告插件.ID%Type 
	) As 
  Begin 
    Delete From 影像报告插件 Where id = ID_In; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_DelDocPlugin; 
 
  --57.改变插件的可用状态 
  Procedure p_IsEnableDocPlugin( 
    ID_In 影像报告插件.ID%Type 
	) As 
  Begin 
    Update 影像报告插件 a 
       Set 是否禁用 = Decode(a.是否禁用, 1, 0, 1) 
     Where id = ID_In; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_IsEnableDocPlugin; 
 
  --58.通过ID获得对应的插件信息 
  Procedure p_GetDocPluginByID( 
	Val           Out t_Refcur, 
	ID_In 影像报告插件.ID%type 
	) As 
  Begin 
    Open Val For 
      Select Rawtohex(Id) ID, 
             编码, 
             名称, 
             说明, 
             显示样式, 
             种类, 
             类名, 
             库名, 
             是否禁用 
        From 影像报告插件 
       Where id = ID_In; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_GetDocPluginByID; 
 
  --59.判断编码和名称是否已存在 
  Procedure p_IsExitDocPlugin( 
	Val           Out t_Refcur, 
	ID_In   影像报告插件.ID%Type, 
	编码_In 影像报告插件.编码%Type, 
	名称_In 影像报告插件.名称%Type 
	) As 
  Begin 
    Open Val For 
      Select Count(id) 
        From 影像报告插件 a 
       Where (a.编码 = 编码_In Or a.名称 = 名称_In) 
         and a.id <> ID_In; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_IsExitDocPlugin; 
 
  --60.通过ID获得对应的专用插件信息 
  Procedure p_GetDocSpecPluginByID( 
	Val           Out t_Refcur, 
	ID_In 影像报告插件.ID%Type 
	) As 
  Begin 
    Open Val For 
      Select Rawtohex(Id) ID, 
             编码, 
             名称, 
             说明, 
             显示样式, 
             种类, 
             类名, 
             库名, 
             是否禁用 
        From 影像报告插件 
       Where id = ID_In 
         And 种类 = 1; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_GetDocSpecPluginByID; 
 
  --61.获得诊疗列表信息 
  Procedure p_GetDiagnosisList( 
	Val           Out t_Refcur, 
	类别_In Varchar2, 
	条件_In Varchar2 
	) As 
  Begin 
    Open Val For 
      Select to_char(a.id) ID, 
             a.编码, 
             a.名称, 
             (Select b.名称 From 诊疗项目类别 b Where b.编码 = a.类别) 类别 
        From 诊疗项目目录 a 
       Where (a.id In (Select t.诊疗项目id From 影像检查项目 t) And a.类别 = 类别_In) 
         And (a.编码 Like 条件_In || '%' Or a.名称 Like 条件_In || '%'); 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_GetDiagnosisList; 
 
  --62.获得诊疗类别列表 
  Procedure p_GetDiagnosisClass( 
    Val Out t_Refcur 
	) As 
  Begin 
    Open Val For 
      Select t.编码, t.名称, t.简码 From 诊疗项目类别 t; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_GetDiagnosisClass; 
 
  --63.添加影像报告原型应用信息 
  Procedure p_AddMedicalAntetype( 
    诊疗项目ID_In 影像报告原型应用.诊疗项目ID%Type, 
    应用场合_In   影像报告原型应用.应用场合%Type, 
    报告原型ID_In 影像报告原型应用.报告原型ID%Type 
	) As 
  Begin 
    Insert Into 影像报告原型应用 
      (诊疗项目ID, 应用场合, 报告原型ID) 
    Values 
      (诊疗项目ID_In, 应用场合_In, 报告原型ID_In); 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_AddMedicalAntetype; 
 
  --64.删除原型ID对应的病历单据应用信息 
  Procedure p_DelMedicalAntetype( 
    报告原型ID_In 影像报告原型应用.报告原型ID%Type 
	) As 
  Begin 
    Delete From 影像报告原型应用 Where 报告原型ID = 报告原型ID_In; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_DelMedicalAntetype; 
 
  --65.通过原型ID获得对应的病历单据应用信息 
  Procedure p_GetMedicalByAID( 
	Val           Out t_Refcur, 
	报告原型ID_In 影像报告原型应用.报告原型ID%Type 
	) As 
  Begin 
    Open Val For 
      Select id, 
             x.编码, 
             x.名称, 
             x.类别, 
             Sum(x.门诊) 门诊, 
             Sum(x.住院) 住院, 
             Sum(x.外诊) 外诊, 
             Sum(x.体检) 体检 
        From (Select id, 
                     编码, 
                     名称, 
                     类别, 
                     Decode(应用场合, '1', 1, 0) as 门诊, 
                     Decode(应用场合, '2', 1, 0) as 住院, 
                     Decode(应用场合, '3', 1, 0) as 外诊, 
                     Decode(应用场合, '4', 1, 0) as 体检 
                From (Select to_Char(a.诊疗项目id) ID, 
                             (Select b.编码 
                                From 诊疗项目目录 b 
                               Where b.id = a.诊疗项目id) as 编码, 
                             (Select b.名称 
                                From 诊疗项目目录 b 
                               Where b.id = a.诊疗项目id) as 名称, 
                             (Select c.名称 
                                From 诊疗项目类别 c 
                               Where c.编码 = (Select b.类别 
                                               From 诊疗项目目录 b 
                                              Where b.id = a.诊疗项目id)) As 类别, 
                             a.应用场合 
                        From 影像报告原型应用 a 
                       Where a.报告原型id = 报告原型ID_In)) x 
       Group By x.id, x.编码, x.名称, x.类别; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_GetMedicalByAID; 
 
  --66.根据原型ID删除动作信息 
  Procedure p_DelDocProcessByAid( 
    报告原型ID_In 影像报告原型应用.报告原型ID%Type 
	) As 
  Begin 
    Delete From 影像报告动作 t Where t.原型id = 报告原型ID_In; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End; 
  --67.获取ID对应的原型的树形结构 
  Procedure p_GetAntetypeTreeByID( 
	Val           Out t_Refcur, 
	ID_In 影像报告原型清单.ID%Type 
	) As 
  Begin 
    Open Val For 
      Select ID, 编码, 名称, 标题, 分组, 是否禁用, 说明, Imageindex 
        From (Select Distinct 分组 As ID, 
                              (Select Min(b.编码) 
                                 From 影像报告原型清单 B 
                                Where b.分组 = a.分组) As 编码, 
                              a.分组 As 名称, 
                              a.分组 As 标题, 
                              null As 分组, 
                              0 As 是否禁用, 
                              null As 说明, 
                              0 As Imageindex 
                From 影像报告原型清单 A 
               Where a.id = ID_In 
              Union 
              Select RawtoHex(ID) ID, 
                     a.编码, 
                     a.名称 As 名称, 
                     编码 || '-' || 名称 As 标题, 
                     分组, 
                     a.是否禁用, 
                     a.说明, 
                     Decode(a.是否禁用, 1, 2, 1) Imageindex 
                From 影像报告原型清单 A 
               Where a.id = ID_In) A 
       Order By a.编码; 
  Exception 
    When Others Then 
      Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_GetAntetypeTreeByID; 
 
  --68.原型是否存在对应的编码或名称 
  procedure p_IsExitAntetype( 
	Val           Out t_Refcur, 
	编码_In 影像报告原型清单.编码%Type, 
	名称_In 影像报告原型清单.名称%Type, 
	ID_In  影像报告原型清单.ID%Type 
	) As 
  begin 
    Open Val For 
      Select Count(*) AS num 
        From 影像报告原型清单 t 
       where (t.编码 = 编码_In 
          or t.名称 = 名称_In) and t.id<>ID_In; 
  End p_IsExitAntetype; 
 
  --69. 获取影像存储设备 
  Procedure p_GetStorageDevice( 
	Val           Out t_Refcur 
	) Is 
  Begin 
	Open Val For 
		Select 设备号||' - '||设备名 As 存储设备, 设备号, IP地址, FTP目录, FTP用户名, FTP密码, 共享目录用户名, 共享目录密码, 共享目录 
		From 影像设备目录 Where 类型 = 1; 
	Exception 
	  When Others Then 
	  Zl_Errorcenter(Sqlcode, Sqlerrm); 
  End p_GetStorageDevice; 
End b_PACS_RptAntetype;
/

