create Package b_PACS_RptCombo Is 
  --Create By Hwei; 
  --2014/11/25 
  Type t_Refcur Is Ref Cursor; 
 
  --1.功  能：获得影像报告组句列表 
  Procedure p_GetComboList( 
    Val Out t_Refcur 
	); 
  --2.功  能：添加影像报告组句信息 
  Procedure p_AddComboInfo( 
    ID_In     In 影像报告组句清单.ID%Type, 
    编码_In   In 影像报告组句清单.编码%Type, 
    名称_In   In 影像报告组句清单.名称%Type, 
    说明_In   In 影像报告组句清单.说明%Type, 
    分组_In   In 影像报告组句清单.分组%Type, 
    多组_In   In 影像报告组句清单.多组%Type, 
    组成_In   In Varchar2, 
    编辑人_In In 影像报告组句清单.编辑人%Type 
	); 
  --3.功  能;修改影像报告组句信息 
  Procedure p_EditComboInfo( 
    ID_In     In 影像报告组句清单.ID%Type, 
    编码_In   In 影像报告组句清单.编码%Type, 
    名称_In   In 影像报告组句清单.名称%Type, 
    说明_In   In 影像报告组句清单.说明%Type, 
    分组_In   In 影像报告组句清单.分组%Type, 
    多组_In   In 影像报告组句清单.多组%Type, 
    组成_In   In Varchar2, 
    编辑人_In In 影像报告组句清单.编辑人%Type 
	); 
  --4.功  能：通过ID删除影像报告组句信息 
  Procedure p_DelComboInfo( 
    ID_In In 影像报告组句清单.ID%Type 
	); 
  --5.功  能：根据ID获得影像报告组句信息 
  Procedure p_GetComboInfoByID( 
	Val           Out t_Refcur, 
	ID_In In 影像报告组句清单.ID%Type 
	); 
  --6.功  能：获得影像报告组句的所有分组信息 
  Procedure p_GetComboAllGroup( 
    Val Out t_Refcur 
	); 
  --7.功  能：获得ID对应的影像报告组句的短语信息 
  Procedure p_GetComboContent( 
	Val           Out t_Refcur, 
	ID_In In 影像报告组句清单.ID%Type 
	); 
  --8.功  能：更新ID对应的影像报告组句的短语信息 
  Procedure p_EditComboContent( 
	ID_In   In 影像报告组句清单.ID%Type, 
	组成_In Varchar2 
	); 
  --9.功 能：获取编辑人对应的最后修改影像报告组句信息 
  Procedure p_GetComboInfoByEditor( 
	Val           Out t_Refcur, 
	编辑人_In In 影像报告组句清单.编辑人%Type 
	); 
  --10.功  能：新增片段到组合句 
  Procedure p_Append_Fragment_Tocombo( 
    Text_In In XmlType, 
    Id_In   In 影像报告组句清单.ID%Type 
	); 
 
  --11.功  能：修改片段到组合句 
  Procedure p_Update_Combo_Fragment( 
    Text_In In XmlType, 
    Id_In   In 影像报告组句清单.ID%Type, 
    Pid_In  In Varchar2 
	); 
  --12.功  能：根据分类ID查询词句 
  Procedure p_Get_Fragment_By_Typeid( 
	Val           Out t_Refcur, 
	Id_In In 影像报告组句清单.ID%Type 
	); 
  --13.功  能：获取下一个编码 
  Procedure p_Get_ComboNextCode( 
    Val Out t_Refcur 
	); 
end b_PACS_RptCombo;
/

