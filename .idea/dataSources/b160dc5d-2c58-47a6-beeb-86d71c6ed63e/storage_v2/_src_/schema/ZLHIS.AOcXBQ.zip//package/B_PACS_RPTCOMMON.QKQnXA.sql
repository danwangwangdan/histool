create Package b_PACS_RptCommon Is 
  Type t_Refcur Is Ref Cursor; 
 
  --获取预备提纲>>>>>>>>>>>>>>>>>>>>>>>>>>> 
  Procedure p_Get_Pre_Outline( 
    Val Out t_Refcur 
	); 
 
  --元素分类>>>>>>>>>>>>>>>>>>>>>>>>>>> 
  Procedure p_Get_All_Eleclass( 
    Val Out t_Refcur 
	); 
 
  --原型片段>>>>>>>>>>>>>>>>>>>>>>>>>>> 
  Procedure p_Get_Antetype_Fragments( 
    Val           Out t_Refcur, 
	Aid_In 影像报告原型片段.原型ID%Type 
	); 
 
  --原型列表>>>>>>>>>>>>>>>>>>>>>>>>>>> 
  Procedure p_Get_Antetypelist_By_Id( 
    Val           Out t_Refcur, 
	Id_In 影像报告原型清单.Id%Type 
	); 
 
  --原型内容>>>>>>>>>>>>>>>>>>>>>>>>>>> 
  Procedure p_Get_Antetypelist_Content( 
    Val           Out t_Refcur, 
	Id_In 影像报告原型清单.Id%Type 
	); 
 
  --范文清单>>>>>>>>>>>>>>>>>>>>>>>>>>> 
  Procedure p_Get_Samplelist_By_Aid( 
    Val           Out t_Refcur, 
	Antetypelist_Id_In Varchar2, 
	Condition_In       影像报告范文清单.名称%Type, 
	Author_In          影像报告范文清单.作者%Type, 
	Subjects_In        影像报告范文清单.学科%Type 
	); 
 
  --获取插件配置根据插件ID获取>>>>>>>>>>>>>>>>>>>>>>>>>>> 
  Procedure p_Get_Plugin_ConfigById( 
    Val           Out t_Refcur, 
	Id_In 影像报告插件.ID%Type 
	); 
 
  --获取插件配置根据原型清单获取>>>>>>>>>>>>>>>>>>>>>>>>>>> 
  Procedure p_Get_Plugin_ConfigByAId( 
    Val           Out t_Refcur, 
	Aid_In 影像报告原型清单.ID%Type 
	); 
 
  --获取元素>>>>>>>>>>>>>>>>>>>>>>>>>>> 
  Procedure p_Get_All_Element( 
    Val Out t_Refcur 
	); 
 
  --获取片段列表>>>>>>>>>>>>>>>>>>>>>>>>>>> 
  Procedure p_Get_All_Fragment_List( 
    Val Out t_Refcur 
	); 
 
  --获取值域列表>>>>>>>>>>>>>>>>>>>>>>>>>>> 
  Procedure p_Get_All_Range_List( 
    Val Out t_Refcur 
	); 
 
  --获取值域列表>>>>>>>>>>>>>>>>>>>>>>>>>>> 
  Procedure p_Get_All_Combo_List( 
    Val Out t_Refcur 
	); 
 
  --获取原型片段根据原型ID>>>>>>>>>>>>>>>>>>>>>>>>>>> 
  Procedure p_Get_FragmentDirectory_ByAid( 
    Val           Out t_Refcur, 
	Aid_In 影像报告原型片段.原型ID%Type 
	); 
 
  --根据原型id获取片段数据 
  Procedure p_Get_FragmentData_ByAid( 
    Val           Out t_Refcur, 
	Aid_In 影像报告原型片段.原型ID%Type 
	); 
 
  --获取数据表的最后更新时间>>>>>>>>>>>>>>>>>>>>>>>>>>> 
  procedure p_Get_Data_Last_Edit_Time( 
    Val           Out t_Refcur, 
	Table_Name_In Varchar2 
	); 
 
  --获取片段列表根据上级ID>>>>>>>>>>>>>>>>>>>>>>>>>>> 
  Procedure p_Get_Fragment_List_Bypid( 
    Val           Out t_Refcur, 
	Pid_In 影像报告片段清单.上级ID%Type 
	); 
 
  --获取片段列表根据节点类型>>>>>>>>>>>>>>>>>>>>>>>>>>> 
  Procedure p_Get_Fragment_List_Byleaf( 
    Val           Out t_Refcur, 
	Leaf_In 影像报告片段清单.节点类型%Type 
	); 
 
  --获取值域信息>>>>>>>>>>>>>>>>>>>>>>>>>>> 
  Procedure p_Get_Range_List_Byid( 
    Val           Out t_Refcur, 
	Id_In 影像报告值域清单.Id%Type 
	); 
 
  --根据元素ID获取值域ID>>>>>>>>>>>>>>>>>>>>>>>>>>> 
  Procedure p_Getelementrid_By_Eid( 
    Val           Out t_Refcur, 
	Eid_In 影像报告元素清单.Id%Type 
	); 
 
  --获取计量单位列表>>>>>>>>>>>>>>>>>>>>>>>>>>> 
  Procedure p_GetMasure_UnitList( 
    Val Out t_Refcur 
	); 
 
  --获取文档种类信息>>>>>>>>>>>>>>>>>>>>>>>>>>> 
  Procedure p_Get_Doc_Kind( 
    Val Out t_Refcur 
	); 
 
  --功能：获取所有学科信息>>>>>>>>>>>>>>>>>>>>>>>>>>> 
  Procedure p_Get_All_Subjects( 
    Val Out t_Refcur 
	); 
 
  --查看是否存在相应的编码或者名称(用于导入导出)>>>>>>>>>>>>>>>>>>>>>>>>>>> 
  Procedure p_If_Exits_Doc_Kinds( 
    Val           Out t_Refcur, 
	编码_In      Varchar2, 
	名称_In      Varchar2, 
	Tablename_In Varchar2 
	); 
 
  --是否存在相同的ID>>>>>>>>>>>>>>>>>>>>>>>>>>> 
  Procedure p_If_Exist_Id( 
    Val           Out t_Refcur, 
	Id_In        Number, 
	Tablename_In Varchar2 
	); 
 
  --通过名称获取ID信息>>>>>>>>>>>>>>>>>>>>>>>>>>> 
  Procedure p_Get_Id_By_Title( 
    Val           Out t_Refcur, 
	名称_In      Varchar2, 
	Tablename_In Varchar2, 
	Type_In      Varchar2 
	); 
 
  --通过简称片段清单 
  procedure p_Get_FragmentSampleName( 
    Val           Out t_Refcur, 
	简称_In Varchar2 
	); 
 
  --更新ID对应的片段内容 
  procedure p_Update_PhraseContent( 
    Id_In      影像报告片段清单.ID%type, 
	Name_In		影像报告片段清单.名称%Type, 
	Content_In Varchar2 
	); 
  --获取原型ID对应的第一层片段节点 
  procedure p_Get_FragmentData_LevelOne( 
    Val           Out t_Refcur, 
	AId_In 影像报告原型清单.ID%type 
	); 
 
  -- 获取片段的下层节点 
  procedure p_GetFragmentDataListByFID( 
    Val           Out t_Refcur, 
	FId_In 影像报告片段清单.ID%type 
	); 
end b_PACS_RptCommon;
/

