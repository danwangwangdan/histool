create Package b_PACS_RptElement Is 
  --Create By Hwei; 
  --2014/11/25 
  Type t_Refcur Is Ref Cursor; 
 
  Procedure p_GetElementClassList( 
    Val Out t_Refcur 
	); 
 
  --2.功  能：新增影像报告元素分类信息 
  Procedure p_AddElementClass( 
    ID_In   In 影像报告元素分类.ID%Type, 
	编码_In In 影像报告元素分类.编码%Type, 
	名称_In In 影像报告元素分类.名称%Type, 
	说明_In In 影像报告元素分类.说明%Type, 
	上级ID_In In 影像报告元素分类.上级ID%Type 
	); 
 
  --3.功  能：修改影像报告元素分类信息 
  Procedure p_EditElementClass( 
    ID_In   In 影像报告元素分类.ID%Type, 
	编码_In In 影像报告元素分类.编码%Type, 
	名称_In In 影像报告元素分类.名称%Type, 
	说明_In In 影像报告元素分类.说明%Type, 
	上级ID_In In 影像报告元素分类.上级ID%Type 
	); 
 
  --4.功  能：删除影像报告元素分类信息 
  Procedure p_DelelEmentClass( 
    ID_In In 影像报告元素分类.ID%Type 
	); 
 
  --5.功  能：获得分类对应的影像报告值域信息列表 
  Procedure p_GetRangeByClass( 
    Val           Out t_Refcur, 
	分类ID_In In 影像报告值域清单.分类ID%Type 
	); 
 
  --6.功  能：获得ID对应的影像报告值域信息 
  Procedure p_GetRangeByID( 
    Val           Out t_Refcur, 
	ID_In In 影像报告值域清单.ID%Type 
	); 
 
  --7.功  能：新增影像报告值域信息 
  Procedure p_AddRange( 
    ID_In          In 影像报告值域清单.ID%Type, 
	分类ID_In    In 影像报告值域清单.分类ID%Type, 
	编码_In       In 影像报告值域清单.编码%Type, 
	名称_In       In 影像报告值域清单.名称%Type, 
	说明_In       In 影像报告值域清单.说明%Type, 
	数据类型_In In 影像报告值域清单.数据类型%Type, 
	值域种类_In In 影像报告值域清单.值域种类%Type, 
	值域描述_In In Varchar2); 
 
  --8.功  能：修改影像报告值域信息 
  Procedure p_EditRange( 
    ID_In         In 影像报告值域清单.ID%Type, 
	分类ID_In   In 影像报告值域清单.分类ID%Type, 
	编码_In       In 影像报告值域清单.编码%Type, 
	名称_In       In 影像报告值域清单.名称%Type, 
	说明_In       In 影像报告值域清单.说明%Type, 
	数据类型_In In 影像报告值域清单.数据类型%Type, 
	值域种类_In In 影像报告值域清单.值域种类%Type, 
	值域描述_In In Varchar2 
	); 
 
  --9.功  能：删除影像报告值域信息 
  Procedure p_DelRange( 
    ID_In In 影像报告值域清单.ID%Type 
	); 
 
  --10.功  能：获得分类对应的影像报告元素列表 
  Procedure p_GetElementByClass( 
    Val           Out t_Refcur, 
    分类ID_In In 影像报告元素清单.分类ID%Type 
	); 
 
  --11.功  能：获得ID对应的影像报告元素信息 
  Procedure p_GetElementByID( 
    Val           Out t_Refcur, 
	ID_In In 影像报告元素清单.ID%Type 
	); 
 
  --12.功 能：新增影像报告元素信息 
  Procedure p_AddElement( 
    ID_In           In 影像报告元素清单.ID%Type, 
	分类ID_In     In 影像报告元素清单.分类ID%Type, 
	编码_In         In 影像报告元素清单.编码%Type, 
	名称_In         In 影像报告元素清单.名称%Type, 
	说明_In         In 影像报告元素清单.说明%Type, 
	前缀_In         In 影像报告元素清单.前缀%Type, 
	后缀_In         In 影像报告元素清单.后缀%Type, 
	数据类型_In   In 影像报告元素清单.数据类型%Type, 
	数值形态_In   In 影像报告元素清单.数值形态%Type, 
	最小长度_In   In 影像报告元素清单.最小长度%Type, 
	最大长度_In   In 影像报告元素清单.最大长度%Type, 
	最小小数位_In In 影像报告元素清单.最小小数位%Type, 
	最大小数位_In In 影像报告元素清单.最大小数位%Type, 
	计量单位_In   In 影像报告元素清单.计量单位%Type, 
	扩展描述_In   In Varchar2, 
	值域ID_In      In 影像报告元素清单.值域ID%Type, 
	值域种类_In   In 影像报告元素清单.值域种类%Type 
	); 
 
  --13.功 能：修改影像报告元素信息 
  Procedure p_EditElement( 
    ID_In         In 影像报告元素清单.ID%Type, 
	分类ID_In     In 影像报告元素清单.分类ID%Type, 
	编码_In       In 影像报告元素清单.编码%Type, 
	名称_In       In 影像报告元素清单.名称%Type, 
	前缀_In       In 影像报告元素清单.前缀%Type, 
    后缀_In       In 影像报告元素清单.后缀%Type, 
    说明_In       In 影像报告元素清单.说明%Type, 
    数据类型_In   In 影像报告元素清单.数据类型%Type, 
    数值形态_In   In 影像报告元素清单.数值形态%Type, 
    最小长度_In   In 影像报告元素清单.最小长度%Type, 
    最大长度_In   In 影像报告元素清单.最大长度%Type, 
    最小小数位_In In 影像报告元素清单.最小小数位%Type, 
    最大小数位_In In 影像报告元素清单.最大小数位%Type, 
    计量单位_In   In 影像报告元素清单.计量单位%Type, 
    扩展描述_In   In Varchar2, 
    值域ID_In     In 影像报告元素清单.值域ID%Type, 
    值域种类_In   In 影像报告元素清单.值域种类%Type 
	); 
 
  --14.功 能：删除影像报告元素信息 
  Procedure p_DelElement( 
    ID_In 影像报告元素清单.ID%Type 
	); 
 
  --15.功 能：通过ID获取影像报告分类信息 
  Procedure p_GetElementClassByID( 
    Val           Out t_Refcur, 
	ID_In In 影像报告元素分类.ID%Type 
	); 
  --16.功  能：获取元素的下一个编码 
  Procedure p_Get_ElementNextCode( 
    Val Out t_Refcur 
	); 
  --17.功  能：获取元素分类的下一个编码 
  Procedure p_Get_ElementClassNextCode( 
    Val Out t_Refcur 
	); 
  --18.功  能：获取对应的值域类型所在的元素类别 
  Procedure p_Get_ElementClassByKind( 
    Val           Out t_Refcur, 
	值域种类_In In 影像报告值域清单.值域种类%Type 
	); 
  --19.功  能：获取值域类型对应的值域信息 
  Procedure p_Get_RangeByKind( 
    Val           Out t_Refcur, 
	值域种类_In In 影像报告值域清单.值域种类%Type 
	); 
  --20.功  能：获取对应的值域类型和数据类型所在的元素类别 
  Procedure p_Get_ElementClassByKindType( 
    Val           Out t_Refcur, 
	值域种类_In In 影像报告值域清单.值域种类%Type, 
	数据类型_In In 影像报告值域清单.数据类型%Type 
	); 
  --21.功  能：获取值域类型和数据类型对应的值域信息 
  Procedure p_Get_RangeByKindAndType( 
    Val           Out t_Refcur, 
	值域种类_In In 影像报告值域清单.值域种类%Type, 
	数据类型_In In 影像报告值域清单.数据类型%Type 
	); 
  --22.功 能：获取最后修改影像报告元素分类信息 
  Procedure p_GetElementClassLastID( 
    Val Out t_Refcur 
	); 
  --23.功 能：获取编辑人对应的最后修改影像报告元素信息ID 
  Procedure p_GetElementLastID( 
    Val Out t_Refcur 
	); 
  --24.功 能：获取最后修改影像报告值域信息ID 
  Procedure p_GetRangeLastID( 
    Val Out t_Refcur 
	); 
  --25.功 能：添加计量单位信息 
  Procedure p_AddMasure_Unit( 
    编码_In 影像报告计量单位.编码%Type, 
    名称_In 影像报告计量单位.名称%Type, 
    说明_In 影像报告计量单位.说明%Type, 
    前缀_In 影像报告计量单位.前缀%Type 
	); 
  --26.功  能：修改计量单位 
  Procedure p_EditMasure_Unit( 
    原编码_In 影像报告计量单位.编码%Type, 
    编码_In   影像报告计量单位.编码%Type, 
    名称_In   影像报告计量单位.名称%Type, 
    说明_In   影像报告计量单位.说明%Type, 
    前缀_In   影像报告计量单位.前缀%Type 
	); 
  --27.功  能：删除计量单位 
  Procedure p_DelMasure_Unit( 
    编码_In 影像报告计量单位.编码%Type 
	); 
  --28.功  能：判断计量单位的编码是否已存在 
  Procedure p_If_Exist_Masure_Unit( 
    Val           Out t_Refcur, 
	编码_In 影像报告计量单位.编码%Type 
	); 
  --29.功  能： 判断元素编码是否已存在 
  Procedure p_If_Exist_ElementCode( 
    Val           Out t_Refcur, 
	ID_In   影像报告元素清单.ID%Type, 
	编码_In 影像报告元素清单.编码%Type 
	); 
  --30.功  能： 判断元素名称是否已存在 
  Procedure p_If_Exist_ElementName( 
    Val           Out t_Refcur, 
	ID_In   影像报告元素清单.ID%Type, 
	名称_In 影像报告元素清单.名称%Type 
	); 
  --31.功  能： 判断值域编码是否已存在 
  Procedure p_If_Exist_RangeCode( 
    Val           Out t_Refcur, 
	ID_In   影像报告值域清单.ID%Type, 
	编码_In 影像报告值域清单.编码%Type 
	); 
  --32.功  能： 判断值域标题是否已存在 
  Procedure p_If_Exist_RangeName( 
    Val           Out t_Refcur, 
	ID_In   影像报告值域清单.ID%Type, 
	名称_In 影像报告值域清单.名称%Type 
	); 
  --33.获得元素列表 
  Procedure p_GetElementList( 
    Val Out t_Refcur 
	); 
  --34.获得值域列表 
  Procedure p_GetRangeList( 
    Val Out t_Refcur 
	); 
  --35.判断元素分类的标题和编码是否存在 
  Procedure p_If_Exist_ElementClass( 
    Val           Out t_Refcur, 
	ID_In   影像报告元素分类.ID%Type, 
	编码_In 影像报告元素分类.编码%Type, 
	名称_In 影像报告元素分类.名称%Type 
	) ; 
    --36.判断该元素分类下面是否有值域或者元素 
  Procedure p_Is_CanDel_ElementClass( 
    Val           Out t_Refcur, 
	ID_In 影像报告元素分类.ID%Type 
	); 
End b_PACS_RptElement;
/

