create Package b_PACS_RptFragments Is 
  Type t_Refcur Is Ref Cursor; 
 
 
  --功能：获取所有预备提纲 
  Procedure p_Get_All_Phr_Onlines( 
    Val Out t_Refcur 
	); 
  --功能：获取所有短语分类 
  Procedure p_Get_All_Fragment_Class( 
    Val Out t_Refcur 
	); 
  --功能：获取当前用户学科所有短语包括父节点 
  Procedure p_Get_All_Fragment( 
    Val           Out t_Refcur, 
    Subjects_In 影像报告片段清单.学科%Type 
	) ; 
 
 
  --功能：根据分类ID查找短语 
  Procedure p_Get_Fragment_By_Typeid( 
    Val           Out t_Refcur, 
    Id_In 影像报告片段清单.ID%Type 
	) ; 
 
 
   Procedure p_Get_Label_By_Typeid( 
     Val           Out t_Refcur, 
	 Id_In 影像报告片段清单.ID%Type 
	 ) ; 
 
  --功能：新增短语分类 
  Procedure p_Add_Fragmenttype( 
    Id_In     影像报告片段清单.ID%Type, 
    Pid_In    影像报告片段清单.上级ID%Type, 
    Code_In   影像报告片段清单.编码%Type, 
    Title_In  影像报告片段清单.名称%Type, 
    Note_In   影像报告片段清单.说明%Type, 
    Leaf_In   影像报告片段清单.节点类型%Type, 
    Author_In 影像报告片段清单.作者%Type 
    ) ; 
 
  --功能：修改短语分类 
  Procedure p_Edit_Fragmenttype( 
    Id_In     影像报告片段清单.ID%Type, 
    Pid_In    影像报告片段清单.上级ID%Type, 
    Code_In   影像报告片段清单.编码%Type, 
    Title_In  影像报告片段清单.名称%Type, 
    Note_In   影像报告片段清单.说明%Type, 
    Leaf_In   影像报告片段清单.节点类型%Type, 
    Author_In 影像报告片段清单.作者%Type 
    ) ; 
 
  --功能：删除短语分类 
   Procedure p_Del_Fragmenttype( 
     Id_In 影像报告片段清单.ID%Type 
	 ); 
 
    --功能：添加短语 
  Procedure p_Add_Fragment( 
     Id_In      影像报告片段清单.ID%Type, 
    Pid_In      影像报告片段清单.上级ID%Type, 
    Code_In     影像报告片段清单.编码%Type, 
    Title_In    影像报告片段清单.名称%Type, 
    Note_In     影像报告片段清单.说明%Type, 
    Leaf_In     影像报告片段清单.节点类型%Type, 
    Content_In  影像报告片段清单.组成%Type, 
    Subjects_In 影像报告片段清单.学科%Type, 
    Label_In    影像报告片段清单.标签%Type, 
    Private_In  影像报告片段清单.是否私有%Type, 
    Author_In   影像报告片段清单.作者%Type 
    ) ; 
 
   --功能：修改短语 
  Procedure p_Edit_Fragment( 
    Id_In       影像报告片段清单.ID%Type, 
    Pid_In      影像报告片段清单.上级ID%Type, 
    Code_In     影像报告片段清单.编码%Type, 
    Title_In    影像报告片段清单.名称%Type, 
    Note_In     影像报告片段清单.说明%Type, 
    Leaf_In     影像报告片段清单.节点类型%Type, 
    Content_In  影像报告片段清单.组成%Type, 
    Subjects_In 影像报告片段清单.学科%Type, 
    Label_In    影像报告片段清单.标签%Type, 
    Private_In  影像报告片段清单.是否私有%Type, 
    Author_In   影像报告片段清单.作者%Type 
    ); 
   --功能：删除短语 
  Procedure p_Del_Fragment( 
    Id_In 影像报告片段清单.ID%Type 
	); 
 
  procedure p_Get_All_Fragment_List( 
    Val Out t_Refcur 
	); 
 
  --功能：导入短语 
  Procedure p_Import_Fragment( 
    Id_In       影像报告片段清单.ID%Type, 
    Pid_In      影像报告片段清单.上级ID%Type, 
    Code_In     影像报告片段清单.编码%Type, 
    Title_In    影像报告片段清单.名称%Type, 
    Note_In     影像报告片段清单.说明%Type, 
    Leaf_In     影像报告片段清单.节点类型%Type, 
    Content_In  影像报告片段清单.组成%Type, 
    Subjects_In 影像报告片段清单.学科%Type, 
    Label_In    影像报告片段清单.标签%Type, 
    Private_In  影像报告片段清单.是否私有%Type, 
    Author_In   影像报告片段清单.作者%Type 
    ) ; 
 
procedure p_Get_Data_Last_Edit_Time( 
  Val           Out t_Refcur, 
  Table_Name_In varchar2 
  ); 
 
   --功能：判断片段分类能否删除 
  Procedure p_IsCanDel_FragmentType( 
    Val           Out t_Refcur, 
	Id_In 影像报告片段清单.Id%Type 
	); 
 
  --功能：根据片段ID，设置当前片段的适应条件 
  Procedure p_Edit_FragmentConditionById 
  ( 
    ID_In      In 影像报告片段清单.ID%Type, 
    适应条件_In In 影像报告片段清单.适应条件%Type 
  ); 
 
  --功能：根据片段的父ID，设置整个目录或子目录片段的适应条件 
  Procedure p_Edit_FragmentConditionByPid 
  ( 
    上级ID_In      In 影像报告片段清单.ID%Type, 
    适应条件_In    In 影像报告片段清单.适应条件%Type 
  ); 
 
  --功能：获取当前检查的片段适应条件 
  Procedure p_Get_FraConditionByOrderId 
  ( 
    Val           Out t_Refcur, 
	医嘱ID_In    影像检查记录.医嘱ID%Type 
  ); 
 
  --功能：获取影像检查类别 
  Procedure p_Get_CheckLueKind 
  ( 
    Val           Out t_Refcur 
  ); 
 
  --功能：根据类别获取诊疗检查部位 
  Procedure p_Get_CheckPartList 
  ( 
    Val           Out t_Refcur, 
    Kind_In       Varchar2 
  ); 
 
  --功能：根据类别获取影像检查项目 
  Procedure p_Get_CheckRadListByKind 
  ( 
    Val           Out t_Refcur, 
    Kind_In       Varchar2 
  ); 
 
  --功能：根据诊疗编码获取影像检查项目 
  Procedure p_Get_CheckRadListByCode 
  ( 
    Val           Out t_Refcur, 
    Code_In       Varchar2 
  ); 
 
  --判断是否有相同的代码 
  Procedure p_Get_HasSameCode 
  ( 
  Val      Out t_Refcur, 
  ID_In      In 影像报告片段清单.ID%Type, 
  Code_In  影像报告片段清单.编码%Type 
  ); 
 
  --判断是否有相同的名称 
  Procedure p_Get_HasSameName 
  ( 
  Val      Out t_Refcur, 
  ID_In    In 影像报告片段清单.ID%Type, 
  PID_In    In 影像报告片段清单.上级ID%Type, 
  Name_In  In 影像报告片段清单.名称%Type, 
  Author_In In  影像报告片段清单.作者%Type 
  ); 
 
  End  b_PACS_RptFragments;
/

