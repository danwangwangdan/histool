create Package b_PACS_RptManage Is 
  Type t_Refcur Is Ref Cursor; 
 
  --1、锁定报告人 
  Procedure p_Edit_Doc_Lockinfo( 
    报告_Id_In 影像报告记录.Id%Type, 
	锁定人_In  影像报告记录.锁定人%Type 
	); 
 
  --2、评定报告质量 
  Procedure p_Edit_Doc_EvaluatRptQuality( 
    报告Id_In 影像报告记录.Id%Type, 
	质量等级_In 影像报告记录.报告质量%Type 
	); 
 
  --3、评定阴阳性 
  Procedure p_Edit_Doc_EvaluatResult( 
    报告Id_In 影像报告记录.Id%Type, 
	检查结果_In 影像报告记录.结果阳性%Type 
	); 
 
  --4、报告发放/回收 
  Procedure p_Edit_Doc_ReportRelease( 
    报告Id_In 影像报告记录.Id%Type, 
	当前操作人_In 影像报告记录.报告发放人%Type 
	); 
 
 --5、新增，修改报告 
  Procedure p_影像报告记录_新增( 
    原型ID_In     影像报告记录.原型ID%Type, 
    报告内容_In   影像报告记录.报告内容%Type, 
    记录人_In     影像报告记录.记录人%Type, 
    最后编辑人_In 影像报告记录.最后编辑人%Type, 
    Id_In         影像报告记录.Id%Type, 
    医嘱ID_In     影像报告记录.医嘱ID%Type 
	); 
 
  --6、获取书写的文档内容 
  Procedure p_Get_Doc_Content( 
    Val           Out t_Refcur, 
	DocID_In 影像报告记录.Id%Type 
	); 
 
  --7、设置报告打印作废信息 
  Procedure p_Checkrejectsignature(Signdate_In Date, 
                                   报告ID_In   影像报告操作记录.报告Id%Type, 
                                   作废人_In   影像报告操作记录.作废人%Type, 
                                   作废说明_In 影像报告操作记录.作废说明%Type, 
                                   Val         Out Sys_Refcursor); 
 
  --8、查询相应原型下的最大序号 
  Procedure p_Get_Samplelist_Maxseqnum( 
    Val           Out t_Refcur, 
	原型ID_In 影像报告范文清单.原型ID%Type 
	); 
 
  --9、删除文档范文 
  Procedure p_Del_影像报告范文清单( 
    Id_In 影像报告范文清单.Id%Type 
	); 
 
 --10、添加文档的操作日志 
 Procedure p_影像报告操作记录_Add(Id_In       影像报告操作记录.Id%Type, 
                               报告ID_In   影像报告操作记录.报告ID%Type, 
                               操作人_In   影像报告操作记录.操作人%Type, 
                               操作类型_In 影像报告操作记录.操作类型%Type); 
 
  --11、删除报告 
  Procedure p_影像报告记录_删除( 
    报告_Id_In 影像报告记录.Id%Type 
	); 
 
  --12、获取签名类型 
  Procedure p_Get_SysConfigSignature( 
    Val           Out t_Refcur, 
	科室ID_In		In 部门表.ID%Type 
	); 
 
--13、获取账户签名印章 
Procedure p_Get_PersonSignImg( 
  Val           Out t_Refcur, 
  ID_In		In 人员表.ID%Type 
  ); 
 
 
--14、获取签名的证书信息 
Procedure p_Get_SignCertInfo( 
  Val           Out t_Refcur, 
  证书ID_In		人员证书记录.ID%Type 
  ); 
 
--15、更新报告状态 
Procedure p_Update_ReportState( 
  报告Id_In  影像报告记录.ID%Type, 
  报告状态_In  影像报告记录.报告状态%Type, 
  审核人_In   影像报告记录.最后审核人%Type 
  ); 
 
--16、获取报告状态 
Procedure p_Get_ReportState( 
  Val           Out t_Refcur, 
  报告Id_In	影像报告记录.ID%Type 
  ); 
 
--17、报告驳回 
Procedure p_Reject_Report( 
  医嘱ID_In	影像报告驳回.医嘱ID%Type, 
  报告ID_In	影像报告驳回.检查报告ID%Type, 
  驳回理由_In 影像报告驳回.驳回理由%Type, 
  驳回时间_In 影像报告驳回.驳回时间%Type, 
  驳回人_In   影像报告驳回.驳回人%Type, 
  待处理人_In  影像报告记录.待处理人%Type, 
  报告状态_In 影像报告记录.报告状态%Type 
  ); 
 
--17.1、撤销报告驳回 
Procedure p_Reject_Cancel( 
  ID_In       影像报告驳回.ID%Type, 
  报告ID_In    影像报告驳回.检查报告ID%Type, 
  报告状态_In   影像报告记录.报告状态%Type 
  ); 
 
--18、获取报告驳回信息 
Procedure p_Get_RejectInfo( 
  Val           Out t_Refcur, 
  报告ID_In	影像报告驳回.检查报告ID%Type 
  ); 
 
--19、获取原型动作 
Procedure p_Get_Doc_Process( 
  Val           Out t_Refcur, 
  原型id_In 影像报告动作.原型id%Type 
  ); 
 
--20、通过学科筛选获得相应的范文信息 
  Procedure p_Get_Samplelist_By_Conditions( 
    Val           Out t_Refcur, 
    原型id_In       Varchar2, 
    学科_In  Varchar2, 
    Condition_In Varchar2, --过滤筛选 
    作者_In    Varchar2 
    ); 
 
  --21、通过部门ID获取部门名称 
  Procedure p_Get_部门名称_By_ID( 
    Val           Out t_Refcur, 
    ID_IN 部门表.ID%TYPE 
    ); 
 
  --22、提取所有预备提纲 
  Procedure p_Get_AllPreOutlines( 
    Val           Out t_Refcur 
    ); 
 
  --23、提取文档标题 
  Procedure p_Get_reportTitle_By_ID( 
    Val           Out t_Refcur, 
    ID_IN  影像报告记录.id%TYPE 
    ); 
 
  --24、提取报告锁定人 
  Procedure p_Get_报告锁定人_By_ID( 
    Val           Out t_Refcur, 
    ID_IN  影像报告记录.id%TYPE 
    ); 
 
  --25、通过医嘱ID获取报告列表 
  Procedure p_Get_影像报告记录_By_医嘱ID( 
    Val           Out t_Refcur, 
    医嘱ID_IN  影像报告记录.医嘱ID%TYPE 
    ); 
 
  --26、查询影像流程参数值 
  Procedure p_Get_影像流程参数值( 
    Val           Out t_Refcur, 
    科室ID_IN  影像流程参数.科室ID%TYPE 
    ); 
 
  --27、根据医嘱ID，查询对应的原型列表 
  Procedure p_Get_影像原型列表_By_医嘱ID( 
    Val           Out t_Refcur, 
    医嘱_IN  影像检查记录.医嘱ID%TYPE 
    ); 
 
  --28、根据报告ID查询打印记录 
  procedure p_Get_ReportPrintLog_By_报告ID 
  ( 
       val out sys_refcursor  , 
       报告_IN  影像报告操作记录.报告ID%TYPE 
  ); 
 
  --29、根据医嘱ID查询报告发放列表 
  Procedure p_Get_ReportReleaseList( 
    Val           Out t_Refcur, 
    医嘱_IN  影像报告记录.医嘱ID%TYPE 
    ); 
 
  --30、根据报告ID查询驳回记录数量 
  Procedure p_Get_RejectedCount( 
    Val           Out t_Refcur, 
    报告_IN  影像报告驳回.检查报告ID%TYPE 
    ); 
 
  --31、根据医嘱ID查询报告动作需要的一些ID们 
  Procedure p_Get_DocProcess_IDs( 
    Val           Out t_Refcur, 
    医嘱_IN  病人医嘱记录.ID%TYPE 
    ); 
 
  --32、根据医嘱ID和报告ID查询报告的一些参数 
  Procedure p_Get_DocInfo( 
    Val           Out t_Refcur, 
    医嘱ID_IN  影像检查记录.医嘱ID%TYPE, 
    报告ID_IN  影像报告记录.ID%TYPE 
    ); 
 
  --33、查询一个检查中相同原型ID的报告数量 
   Procedure p_Get_SameAntetypeDocCounts( 
       Val           Out t_Refcur, 
       医嘱ID_IN  影像报告记录.医嘱ID%TYPE, 
       原型ID_IN  影像报告记录.原型ID%TYPE 
  ); 
 
  --34、提取报告图存储信息 
  Procedure p_Get_DocImageSaveInof_By_ID( 
    Val           Out t_Refcur, 
	  ID_IN  影像报告记录.id%TYPE 
    ); 
 
  --35、修改原型使用次数 
  Procedure p_Update_Antetypeusecount(Id_In 影像报告原型清单.Id%Type); 
end b_PACS_RptManage;
/

