create Package b_PACS_RptParam Is 
  Type t_Refcur Is Ref Cursor; 
 
  --功能1：获得活动的参数列表 
  Procedure p_GetPrograms( 
    Val Out t_Refcur 
	); 
  --功能2：通过模块号获取影像参数信息 
  Procedure p_GetParamByQum( 
    Val           Out t_Refcur, 
	模块_In 影像参数说明.模块%Type 
	); 
  --功能3：通过参数ID号获取影像参数取值信息 
  Procedure p_GetParamValue( 
    Val           Out t_Refcur, 
	参数ID_In 影像参数取值.参数ID%Type 
	); 
  --功能4：获得部门信息 
  Procedure p_GetDepart( 
    Val Out t_Refcur 
	); 
  --功能5：获得人员信息 
  Procedure p_GetUsersInfo( 
    Val Out t_Refcur 
	); 
  --功能6：获得机器名信息 
  Procedure p_GetMachinesInfo( 
    Val Out t_Refcur 
	); 
  --功能7：获取所有的影像参数信息 
  Procedure p_GetAllParam( 
    Val Out t_Refcur 
	); 
  --功能8：获得所有部门的所有的参数取值信息 
  Procedure p_GetValueAllDepart( 
    Val Out t_Refcur, 
	参数ID_In 影像参数取值.参数ID%Type 
	); 
  --功能9：得ID对应部门的所有的参数取值信息 
  Procedure p_GetValueByDepart( 
    Val Out t_Refcur, 
	参数ID_In 影像参数取值.参数ID%Type, 
	部门ID_In 部门表.ID%Type 
	); 
  --功能9：获取所有的用户对应的参数值 
  Procedure p_GetValueAllUser( 
    Val Out t_Refcur, 
	参数ID_In 影像参数取值.参数ID%Type 
	); 
  --功能10：获取用户ID对应的参数信息 
  Procedure p_GetValueByUser( 
    Val Out t_Refcur, 
	参数ID_In 影像参数取值.参数ID%Type, 
	用户ID_In 人员表.ID%Type 
	); 
  --功能11：获取所有的工作站对应的参数值 
  Procedure p_GetValueAllMachine( 
    Val Out t_Refcur, 
	参数ID_In 影像参数取值.参数ID%Type 
	); 
  --功能12：获取工作站名称对应的参数信息 
  Procedure p_GetValueByMachine( 
    Val Out t_Refcur, 
	参数ID_In 影像参数取值.参数ID%Type, 
	机器名_In zlclients.工作站%Type 
	); 
  --功能13：添加参数信息 
  Procedure p_AddParamValue( 
    ID_In       影像参数取值.ID%Type, 
    参数ID_In   影像参数取值.参数ID%Type, 
    参数标识_In 影像参数取值.参数标识%Type, 
    参数值_In   影像参数取值.参数值%Type 
	); 
 
  --功能14：修改参数信息 
  Procedure p_EditParamValue( 
    ID_In       影像参数取值.ID%Type, 
    参数标识_In 影像参数取值.参数标识%Type, 
    参数值_In   影像参数取值.参数值%Type 
	); 
 
  --功能15:通过ID获得参数信息 
  Procedure p_GetParamByID( 
    Val Out t_Refcur, 
	ID_In 影像参数说明.ID%Type 
	); 
  --功能16：修改ID对应的参数级别 
  Procedure p_ChangeAdjustByID( 
    ID_In     影像参数说明.ID%Type, 
	Adjust_In 影像参数说明.参数级别%Type 
	); 
  --功能17：获得对应参数标识的参数取值信息 
  Procedure p_GetValueBySign( 
    Val Out t_Refcur, 
	参数ID_In 影像参数取值.参数ID%Type 
	); 
  --功能18：修改ID对应的参数信息的默认值 
  Procedure p_EditDaultValue( 
    ID_In     影像参数说明.ID%Type, 
	默认值_In 影像参数说明.默认值%Type); 
 
  --功能19：通过部门获得人员信息 
  Procedure p_GetUserByDID( 
    Val Out t_Refcur, 
	DID_In 部门人员.部门ID%Type 
	); 
  --功能21:通过ID获得参数取值 
  Procedure p_GetParamValueByCID( 
    Val Out t_Refcur, 
	CID_In 影像参数取值.参数ID%Type 
	); 
  --功能22:通过ID获得模块号的参数取值 
  Procedure p_GetValueLevel0( 
    Val Out t_Refcur, 
	参数ID_In   影像参数取值.参数ID%Type, 
	参数标识_In 影像参数取值.参数标识%Type 
	); 
end b_PACS_RptParam;
/

