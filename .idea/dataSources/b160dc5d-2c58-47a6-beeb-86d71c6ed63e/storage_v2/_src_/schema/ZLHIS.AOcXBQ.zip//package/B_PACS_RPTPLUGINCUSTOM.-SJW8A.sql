create Package b_PACS_RptPluginCustom Is 
  Type t_Refcur Is Ref Cursor; 
-- 功    能：该方法只用于演示... 
  Procedure Demo1; 
 
end b_PACS_RptPluginCustom ;
/

