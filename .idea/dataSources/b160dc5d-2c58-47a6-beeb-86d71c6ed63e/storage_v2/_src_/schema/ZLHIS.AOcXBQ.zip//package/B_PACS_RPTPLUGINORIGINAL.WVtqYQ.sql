create Package b_PACS_RptPluginOriginal Is 
  Type t_Refcur Is Ref Cursor; 
 
  -- 功    能：获取历史报告记录 
  Procedure p_GetReportHistory( 
    Val                   Out t_Refcur, 
    医嘱id_In             In 病人医嘱记录.ID%Type, 
    人员id_In             In 部门人员.人员id%Type, 
    当前科室id_In         In 部门人员.部门ID%Type, 
    查看其他科历史报告_In In number := 0 
  ); 
 
  --功    能：获取对应报告内容 
  Procedure p_GetReportContent( 
    Val           Out t_Refcur, 
    报告ID_In     In varchar2, 
    EditorType_In Number := 0 --0:PACS报告编辑器，1--电子病历编辑器，2--报告文档编辑器 
    ); 
 
  --功    能：根据医嘱ID获取检查信息 
  Procedure p_GetStudyInfoByAdviceId( 
    Val       Out t_Refcur, 
    医嘱id_In In 影像检查记录.医嘱id%Type 
  ); 
 
  --功    能：获取报告图像总数 
  Procedure p_GetReportImageCount( 
    Val Out t_Refcur, 
    查询条件_In In varchar2 
  ); 
 
  --功    能：获取报告图像数据 
  Procedure p_GetReportImageData( 
    Val         Out t_Refcur, 
    查询条件_In In varchar2, 
    开始位置_In In number, 
    结束位置_In In number 
  ); 
 
  --功    能：获取预览图像总数 
  Procedure p_GetStudyImageCount( 
    Val Out t_Refcur, 
    查询条件_In In varchar2, 
    是否临时_In In number:=0 
  ); 
 
  --功    能：获取预览图像数据 
  Procedure p_GetStudyImageData( 
    Val         Out t_Refcur, 
    查询方式_In In varchar2, 
    查询条件_In In varchar2, 
    开始位置_In In number, 
    结束位置_In In number, 
    是否临时_In In number 
  ); 
 
  --功能：获取临时图像序列 
  Procedure p_Get_TempImageSeries( 
    Val         Out t_Refcur, 
    时间范围_In In Number, 
    姓名_In In 影像临时记录.姓名%Type:=null 
  ); 
 
  --功能;获取图像备注 
  procedure P_Get_NormalNote( 
    Val         Out t_Refcur 
  ); 
 
  --功能：插入常用图像备注 
  Procedure p_Insert_Normalnote( 
    note_in in 影像字典内容.名称%Type, 
    code_In 影像字典内容.简码%Type 
  ); 
 
  --功能：修改常用图像备注 
  Procedure p_Edit_Normalnote( 
    note_in In 影像字典内容.名称%Type, 
    num_In  影像字典内容.编号%Type 
  ); 
 
  --功能：删除常用图像备注 
  Procedure p_Del_Normalnote( 
    num_In 影像字典内容.编号%Type 
  ); 
 
  --功能：获取备注的下一个编码 
  Procedure p_Get_NormalNum( 
    Val Out t_Refcur 
  ); 
  --功能：获取插件ID 
  Procedure p_Get_PlugID( 
    Val     Out t_Refcur, 
    类名_In In 影像报告插件.类名%Type 
  ); 
 
  --功能：插入编辑器字体参数 
  Procedure p_SetFontParam( 
    font_In nvarchar2, 
    user_In nvarchar2 
  ); 
 
  --功能：获取编辑器字体参数 
  Procedure p_GetFontParam( 
    Val Out t_Refcur, 
    user_In nvarchar2 
  ); 
 
  --功能：插入编辑器窗体参数 
  Procedure p_SetFormParam( 
    form_In nvarchar2, 
    user_In nvarchar2 
  ); 
 
  --功能：获取编辑器字体参数 
  Procedure p_GetFormParam( 
    Val Out t_Refcur, 
    user_In nvarchar2 
  ); 
 
  --功能：根据图像UID获取检查信息 
  Procedure p_GetStudyInfoByImageUID( 
    Val Out t_Refcur, 
    医嘱ID_In In 影像检查记录.医嘱ID%Type, 
    图像UID_In In 影像检查图象.图像UID%Type 
  ); 
 
  --功能：根据检查UID获取FTP信息 
  Procedure p_GetFtpinfoByStudyUID( 
    Val Out t_Refcur, 
    检查UID_In In 影像检查记录.检查UID%Type 
  ); 
 
  --功能：根据科室ID获取FTP信息 
  Procedure p_GetFtpinfoByDeptId( 
    Val Out t_Refcur, 
    科室ID_In In 影像流程参数.科室ID%Type 
  ); 
 
  --功能：根据医嘱ID获取FTP信息 
  Procedure p_GetFtpinfoByAdvicetId( 
    Val Out t_Refcur, 
    医嘱ID_In In 影像检查记录.医嘱ID%Type 
  ); 
 
  --功能：获取检查UID 
  Procedure p_GetStudyUID( 
    Val Out t_Refcur, 
    检查UID_In In 影像检查记录.检查UID%Type 
  ); 
 
  --功能：获取序列UID 
  Procedure p_GetSeriesUID( 
    Val Out t_Refcur, 
    序列UID_In In 影像检查序列.序列UID%Type 
  ); 
 
  --功能：根据设备号获取设备信息 
  Procedure p_GetDeviceInfo( 
    Val Out t_Refcur, 
    设备号_In In 影像设备目录.设备号%Type 
  ); 
 
  --获取医技站存储设备号 
  Procedure p_GetDeviceIdByAdviceId( 
    Val Out t_Refcur, 
    医嘱ID_In In 病人医嘱发送.医嘱ID%Type 
  ); 
End b_PACS_RptPluginOriginal;
/

