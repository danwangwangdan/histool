create Package b_PACS_RptPublic Is 
  Type t_Strlist Is Table Of Varchar2(4000); 
  --功能：将由逗号分隔的不带引号的字符序列转换为单列数据表 
  Function f_Str2list( 
    Str_In   In Varchar2, 
    Split_In In Varchar2 := ',' 
    ) Return t_Strlist 
    Pipelined; 
 
  --功能:跟据传入的表名称提取表中最大的Code并递增 
  Function f_Get_Nextcode( 
    Tablename_In Varchar2, 
    Len_In       Number := 0, 
    Mount_In     Number := 0, 
    Pre_In       Varchar2 := Null 
    ) Return Varchar2; 
 
  --功能：生成字符串拼音首码 
  Function f_Spellcode( 
    v_Instr  In Varchar2, 
    v_Outnum In Integer := 10 
    ) Return Varchar2; 
 
  --错误处理中心 
  Procedure zl_ErrorCenter( 
    Err_Num In Number, 
    Err_Msg In Varchar2 
    ); 
 
 --从传入的XML中提取编辑记录 
  Function f_Geteditlist( 
    Content_In In Xmltype 
	) Return t_Editlist; 
 
  Function Xml2clob( 
    Xml_In Xmltype 
	) Return Clob; 
 
  Function f_Getlastedit( 
    Content_In In Xmltype 
	) Return t_Editlist; 
 
  ----拆分匿名数据 
  --Function f_Disjoin_Anonym 
  --( 
    --Content_In    In Xmltype, 
    --x_Anonym_Data Out Xmltype 
  --) Return Xmltype; 
 
  ----合并匿名数据 
  --Function f_Incorporate_Anonym 
  --( 
    --Content_In    In Xmltype, 
    --x_Anonym_Data In Xmltype 
  --) Return Clob; 
 
  --设置XML的节点值,当节点为<ele></ele>此类闭合节点时，Updatexml函数无效 
  Procedure p_Set_Elementtext( 
    Texture In Out Xmltype, 
    Ename   In Varchar2, 
    Eaname  In Varchar2, 
    Eatext  In Varchar2, 
    Etext   In Varchar2 
    ); 
  --根据子文档ID提取子文档当前状态 
 Function f_Get_Docstatus( 
    Content_In In Xmltype 
    ) Return Varchar2; 
 
  Function f_If_Intersect( 
    Str1 Varchar2, 
    Str2 Varchar2 
    ) Return Number; 
 
End b_PACS_RptPublic;
/

