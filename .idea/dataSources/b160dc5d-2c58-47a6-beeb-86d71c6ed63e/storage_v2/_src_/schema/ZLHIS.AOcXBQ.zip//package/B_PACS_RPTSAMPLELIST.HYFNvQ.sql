create Package b_Pacs_RptSampleList Is 
  Type t_Refcur Is Ref Cursor; 
 
  -- Author  : SEEKING 
  -- Created : 2014/10/30 10:05:38 
  -- Purpose : 范文管理 
 
  --查找范文的原型类别 
 
  Procedure p_Get_Sample_List_Type( 
    Val Out t_Refcur, 
    Type_In Varchar2, 
    Kind_In varchar2 
	); 
 
  --新增文档原型 
  Procedure p_Add_Sample_List( 
    Id_In       影像报告范文清单.Id%Type, 
	Aid_In      影像报告范文清单.原型id%Type, 
	Seq_Num_In  影像报告范文清单.编号%Type, 
	Title_In    影像报告范文清单.名称%Type, 
	Note_In     影像报告范文清单.说明%Type, 
	Content_In  影像报告范文清单.内容%Type, 
	Subject_In  影像报告范文清单.学科%Type, 
	Label_In    影像报告范文清单.标签%Type, 
	Private_In  影像报告范文清单.是否私有%Type, 
	Author_In   影像报告范文清单.作者%Type, 
	Lasttime_In 影像报告范文清单.最后编辑时间%Type 
	); 
 
  --编辑范文信息 
  Procedure p_Edit_Sample_List( 
    Id_In       影像报告范文清单.Id%Type, 
    Aid_In      影像报告范文清单.原型id%Type, 
    Seq_Num_In  影像报告范文清单.编号%Type, 
    Title_In    影像报告范文清单.名称%Type, 
    Note_In     影像报告范文清单.说明%Type, 
    Content_In  影像报告范文清单.内容%Type, 
    Subject_In  影像报告范文清单.学科%Type, 
    Label_In    影像报告范文清单.标签%Type, 
    Private_In  影像报告范文清单.是否私有%Type, 
    Author_In   影像报告范文清单.作者%Type, 
    Lasttime_In 影像报告范文清单.最后编辑时间%Type 
	); 
  --删除文档范文 
  Procedure p_Del_Sample_List( 
    Id_In 影像报告范文清单.Id%Type 
	); 
 
  --通过原型ID获得相应的范文信息 
  Procedure p_Get_Samplelist_By_Aid( 
    Val Out t_Refcur, 
    Antetypelist_Id_In 影像报告范文清单.原型id%Type, 
    Author_In          影像报告范文清单.作者%Type, 
    Subjects_In        Varchar2 
	); 
 
  --通过种类id获取范文树 
  Procedure p_Get_Samplelist_By_Kind( 
    Val Out t_Refcur, 
    Kind_In      Varchar2, 
    Condition_In Varchar2, 
    Author_In    影像报告范文清单.作者%Type, 
    Subjects_In  Varchar2 
	); 
 
  --通过ID查找相应的范文信息 
  Procedure p_Get_Samplelist_By_Id( 
    Val Out t_Refcur, 
    Id_In 影像报告范文清单.Id%Type 
	); 
 
  --查询相应原型下的最大序号 
  Procedure p_Get_Samplelist_Maxseqnum( 
    Val Out t_Refcur, 
	Aid_In 影像报告范文清单.原型id%Type 
	); 
 
  --获取范文XML信息 
  Procedure p_Get_Samplexml( 
    Val Out t_Refcur, 
	Id_In 影像报告范文清单.Id%Type 
	); 
 
  --修改范文XML信息 
  Procedure p_Edit_Samplexml( 
    Id_In      影像报告范文清单.Id%Type, 
	Content_In 影像报告范文清单.内容%Type 
	); 
 
  --导出的范文列表 
  Procedure p_Output_Samplelist( 
    Val Out t_Refcur 
	); 
 
  --是否存在相应的原型类别 
  Procedure p_If_Exist_Antetypelist( 
    Val Out t_Refcur, 
	Title_In 影像报告原型清单.名称%Type 
	); 
 
  --同一个类别下是否存在相同名称的范文 
  Procedure p_If_Exist_Samplelist( 
    Val Out t_Refcur, 
    Type_In  影像报告原型清单.名称%Type, 
    Title_In 影像报告范文清单.名称%Type 
	); 
 
  --通过范文ID获得范文对应的树形结构 
  Procedure p_Get_SamplelistTree_By_Id( 
    Val Out t_Refcur, 
    Id_In 影像报告范文清单.Id%Type 
	); 
 
End b_Pacs_RptSampleList;
/

