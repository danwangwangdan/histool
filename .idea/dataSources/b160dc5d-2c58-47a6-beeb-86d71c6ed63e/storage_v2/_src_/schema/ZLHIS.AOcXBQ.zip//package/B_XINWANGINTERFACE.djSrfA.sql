create package b_XINWANGInterface is 
  Type t_Refcur Is Ref Cursor; 
-- 功    能：PACS状态改变信息 
  Procedure PacsStatusChange 
  ( 
    状态ID_In In Number, 
    医嘱ID_In In 影像检查记录.医嘱ID%Type, 
    影像类别_In In 影像检查记录.影像类别%Type, 
    检查号_In In 影像检查记录.检查号%Type, 
    处理时间  In date, 
    执行人 In  Varchar2, 
    胶片大小 In Varchar2 
  ); 
-- 功    能：取消图像关联 
  Procedure PacsUnmatchImage 
  ( 
    医嘱ID_In In 影像检查记录.医嘱ID%Type 
  ); 
-- 功    能：填写报告图的存储设备 
  Procedure PacsSetFTPDeviceNo 
  ( 
    医嘱ID_In In 影像检查记录.医嘱ID%Type , 
    设备号_In In 影像检查记录.位置一%Type 
  ); 
-- 功    能：更新图像数 
  Procedure UpdateImgCount 
  ( 
    医嘱ID_In 影像检查记录.医嘱ID%Type, 
    图像数_In NUMBER 
  ); 
 
end b_XINWANGInterface ;
/

