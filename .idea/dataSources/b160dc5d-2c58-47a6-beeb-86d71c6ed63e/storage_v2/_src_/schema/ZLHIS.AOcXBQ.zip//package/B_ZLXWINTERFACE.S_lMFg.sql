create Package b_Zlxwinterface Is 
  Type t_Refcur Is Ref Cursor; 
 
  --1、接收RIS状态改变 
  Procedure Receiverisstate(医嘱id_In   病人医嘱发送.医嘱id%Type, 
                            Risid_In    病人医嘱报告.Risid%Type, 
                            状态_In     Number, 
                            操作人员_In 病人医嘱发送.完成人%Type, 
                            执行时间_In 病人医嘱发送.完成时间%Type := Null, 
                            执行说明_In 病人医嘱发送.执行说明%Type := Null, 
                            单独执行_In Number := 0); 
 
  --2、费用确认 
  Procedure 影像费用执行(医嘱id_In     影像检查记录.医嘱id%Type, 
                   单独执行_In   Number := 0, 
                   操作员编号_In 人员表.编号%Type := Null, 
                   操作员姓名_In 人员表.姓名%Type := Null, 
                   执行部门id_In 门诊费用记录.执行部门id%Type := Null); 
 
  --3、取消费用确认 
  Procedure 影像费用执行_Cancel(医嘱id_In     影像检查记录.医嘱id%Type, 
                          单独执行_In   Number := 0, 
                          操作员编号_In 人员表.编号%Type := Null, 
                          操作员姓名_In 人员表.姓名%Type := Null, 
                          执行部门id_In 门诊费用记录.执行部门id%Type := Null); 
 
  --4、接收RIS的报告 
  Procedure Receivereport(医嘱id_In   病人医嘱发送.医嘱id%Type, 
                          Risid_In    病人医嘱报告.Risid%Type, 
                          报告所见_In 电子病历内容.内容文本%Type, 
                          报告意见_In 电子病历内容.内容文本%Type, 
                          报告建议_In 电子病历内容.内容文本%Type, 
                          报告医生_In 电子病历记录.创建人%Type); 
 
  --5、修改申请单信息 
  Procedure 影像病人信息_修改(医嘱id_In       病人医嘱记录.Id%Type, 
                      姓名_In         病人信息.姓名%Type, 
                      性别_In         病人信息.性别%Type, 
                      年龄_In         病人信息.年龄%Type, 
                      费别_In         病人信息.费别%Type, 
                      医疗付款方式_In 病人信息.医疗付款方式%Type, 
                      民族_In         病人信息.民族%Type, 
                      婚姻_In         病人信息.婚姻状况%Type, 
                      职业_In         病人信息.职业%Type, 
                      身份证号_In     病人信息.身份证号%Type, 
                      家庭地址_In     病人信息.家庭地址%Type, 
                      家庭电话_In     病人信息.家庭电话%Type, 
                      家庭地址邮编_In 病人信息.家庭地址邮编%Type, 
                      出生日期_In     病人信息.出生日期%Type := Null); 
 
  --6、取消申请单信息 
  Procedure 取消检查申请单(医嘱id_In     病人医嘱执行.医嘱id%Type, 
                    操作员编号_In 人员表.编号%Type := Null, 
                    操作员姓名_In 人员表.姓名%Type := Null, 
                    执行部门id_In 门诊费用记录.执行部门id%Type := 0, 
                    拒绝原因_In   病人医嘱发送.执行说明%Type := Null); 
 
  --7、插入医嘱操作失败记录 
  Procedure RIS医嘱失败记录_Insert(病人来源_In   In RIS医嘱失败记录.病人来源%Type, 
                             病人ID_In     In RIS医嘱失败记录.病人ID%Type, 
                             主页ID_In     In RIS医嘱失败记录.主页ID%Type, 
                             挂号单号_In   In RIS医嘱失败记录.挂号单号%Type, 
                             发送号_In     In RIS医嘱失败记录.发送号%Type, 
                             体检任务ID_In In RIS医嘱失败记录.体检任务ID%Type, 
                             体检报到号_In In RIS医嘱失败记录.体检报到号%Type, 
                             发送类型_In   In RIS医嘱失败记录.发送类型%Type); 
 
  --8、更新医嘱操作失败记录 
  Procedure RIS医嘱失败记录_重发(ID_In       In RIS医嘱失败记录.ID%Type, 
                         操作类型_In In Number); 
 
  --9、销账后新建住院记账单据 
  Procedure 病人医嘱_重建单据(医嘱ID_In In 病人医嘱发送.医嘱ID%Type, 
                      No_In     In 病人医嘱发送.No%Type, 
                      Action_In In number); 
 
  --10、打印RIS检查预约通知单 
  Procedure RIS检查预约_打印(医嘱ID_In In RIS检查预约.医嘱ID%Type); 
 
  --11、更新RIS分科室启用参数 
  Procedure RIS启用控制_Update(检查类型_In RIS启用控制.检查类型%Type, 
                           场合_In     RIS启用控制.场合%Type, 
                           部门ids_In  Varchar2, 
                           启用类型_In Number); 
 
  --12、删除RIS分科室启用参数 
  Procedure RIS启用控制_Delete; 
 
End b_Zlxwinterface;
/

