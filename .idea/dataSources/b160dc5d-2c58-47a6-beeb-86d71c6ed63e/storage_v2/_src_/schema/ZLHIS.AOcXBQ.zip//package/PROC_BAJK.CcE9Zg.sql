create Package       Proc_Bajk --病案接口
 As
	Type Mycursor Is Ref Cursor; --定义一个游标类型
/*function   yy101(jcxx01 in varchar2) return varchar2;--根据yygl101表的sjcxx01字段返回sjcxx02字段
  function   yy130(jbxx01 in varchar2) return varchar2;--根据yygl130表的sjbxx01字段返回sjbxx02字段
  function   yy140(ksxx01 in varchar2) return varchar2;--根据yygl140表的sksxx01字段返回sksxx02字段
  function   yy170(zgxx01 in varchar2) return varchar2;--根据yygl170表的szgxx01字段返回szgxx02字段
  function   yyi61(jsdh01 in varchar2,bnjflb in varchar2) return varchar2;--根据yygli61表的计算单号和计费类别返回该计费类别的费用
  function   yye41(ksbm in varchar2,yslb in varchar2,beginrq in date,endrq in date ) return number;--根据科室编号和医生职称以及时间段得到各种职称医生的门诊量
  function   yyk00(ksbm in varchar2,lb in varchar2,beginrq in date,endrq in date) return number;--根据科室编码和时间段查询科室各个状态下的病人数
  function   checkba return varchar2;--根据医院特征码判断该院是否启用病案接口
  function   checkpp return varchar2;--判断yygl_bajk表中是否还存在未匹配的his计费类别*/
End Proc_Bajk;
/

