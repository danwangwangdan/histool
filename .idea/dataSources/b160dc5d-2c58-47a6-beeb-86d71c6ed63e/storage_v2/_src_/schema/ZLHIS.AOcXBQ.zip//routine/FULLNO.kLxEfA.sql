create Function Fullno 
( 
  序号_In     In 号码控制表.项目序号%Type, 
  No_In       In 号码控制表.最大号码%Type, 
  科室id_In   In 部门表.Id%Type := Null, 
  Tag_In      In Varchar2 := Null, 
  号码个数_In In Integer := 1 
) Return Varchar2 
--    功能：根据特定规则和输入号码补全号码,规则如下： 
  --    一、项目序号： 
  --       1   病人ID         数字 
  --       2   住院号         数字 
  --       3   门诊号         数字 
  --       10  医嘱发送号     数字 
  --       x   其它单据号     字符 
  --    二、No： 
  --       输入序号码 
  --    三、年度位确定原则： 
  --       以1990为基数，随年度增长，按“0～9/A～Z”顺序作为年度编码 
  -- 
  --    说明：1、参数类型和意义按NextNo函数中定义，使其保持一致 
  --          2、输入No号长度大于号码组成规则中顺序号的长度则不处理，直接返回 
  -- 
  --    返回：补全后的号码 
 Is 
  v_No     号码控制表.最大号码%Type; 
  n_Mod    号码控制表.编号规则%Type; 
  v_Tmp    Varchar2(10); 
  v_Year   Varchar2(1); 
  v_Deptno Varchar2(20); 
 
  v_Error Varchar2(255); 
  Err_Custom Exception; 
 
  --按特定日期格式串构造字符编码 
  Function Getdateno 
  ( 
    No_In    In 号码控制表.最大号码%Type, 
    Type_In  In Varchar2, 
    Count_In In Integer 
  ) Return Varchar2 
  -- 
    -- Type_In  日期格式串 
    -- Count_In 输入编码格式位数 
   Is 
    v_Tmp Varchar2(10); 
  Begin 
    v_Tmp := To_Char(Sysdate, Type_In); 
    Return v_Tmp || LPad(No_In, Count_In, '0'); 
  End Getdateno; 
Begin 
  --数据检查 
  Begin 
    Select Nvl(编号规则, 0) Into n_Mod From 号码控制表 Where 项目序号 = 序号_In; 
  Exception 
    When Others Then 
      v_Error := '号码控制表中不存在序号为' || 序号_In || '的号码！'; 
      Raise Err_Custom; 
  End; 
 
  --1.病人ID 
  If 序号_In = 1 Then 
    v_No := No_In; 
 
    --2.住院号 
  Elsif 序号_In = 2 Then 
    If n_Mod = 0 Then 
      --0.顺序编号 
      v_No := No_In; 
    Elsif n_Mod = 1 Then 
      --1.年月+顺序号:YYMM0000 
      If Length(No_In) > 8 Then 
        v_No := No_In; 
      Elsif Length(No_In) > 6 Then 
        v_No := Substr(To_Char(Sysdate, 'YY'), 1, 8 - Length(No_In)) || No_In; 
      Elsif Length(No_In) > 4 Then 
        v_No := Getdateno(No_In, 'YY', 6); 
      Else 
        v_No := Getdateno(No_In, 'YYMM', 4); 
      End If; 
    Elsif n_Mod = 2 Then 
      --2.年+顺序号:YYYY00000 
      If Length(No_In) > 9 Then 
        v_No := No_In; 
      Elsif Length(No_In) > 5 Then 
        v_No := Substr(To_Char(Sysdate, 'YYYY'), 1, 9 - Length(No_In)) || No_In; 
      Else 
        v_No := Getdateno(No_In, 'YYYY', 5); 
      End If; 
    End If; 
 
    --3.门诊号 
  Elsif 序号_In = 3 Then 
    --处理规则用户自定义 
    v_No := Zl1_Clinicno_Full(No_In, n_Mod); 
 
    --10.医嘱发送号 
  Elsif 序号_In = 10 Then 
    v_No := No_In; 
 
    --汇总发药号 
  Elsif 序号_In = 20 Then 
    --年月日+5位顺序号:YYYYMMDD00000 
    If Length(No_In) > 13 Then 
      v_No := No_In; 
    Elsif Length(No_In) > 9 Then 
      v_No := Substr(To_Char(Sysdate, 'YYYY'), 1, 13 - Length(No_In)) || No_In; 
    Elsif Length(No_In) > 7 Then 
      v_No := Getdateno(No_In, 'YYYY', 9); 
    Elsif Length(No_In) > 5 Then 
      v_No := Getdateno(No_In, 'YYYYMM', 7); 
    Else 
      v_No := Getdateno(No_In, 'YYYYMMDD', 5); 
    End If; 
 
    --影像检查号 
  Elsif 序号_In = 123 Then 
    v_No := No_In; 
 
  Elsif 序号_In = 124 Then 
    v_No := No_In; 
 
    --检验条码 
  Elsif 序号_In = 125 Then 
    v_No := No_In; 
 
    --卫材条码序号 
  Elsif 序号_In = 126 Then 
    --12位顺序号:000000000000 
    If Length(No_In) > 12 Then 
      v_No := No_In; 
    Else 
      v_No := LPad(No_In, 12, '0'); 
    End If; 
 
    --药品卫材调价 
  Elsif 序号_In = 135 Then 
    --1.年月+顺序号:YYYYMM0000 
    If Length(No_In) > 10 Then 
      v_No := No_In; 
    Elsif Length(No_In) > 6 Then 
      v_No := Substr(To_Char(Sysdate, 'YYYY'), 1, 10 - Length(No_In)) || No_In; 
    Elsif Length(No_In) > 4 Then 
      v_No := Getdateno(No_In, 'YYYY', 6); 
    Else 
      v_No := Getdateno(No_In, 'YYYYMM', 4); 
    End If; 
 
    --瓶签号 
  Elsif 序号_In = 136 Then 
    --YYMMDD+5位顺序号:YYMMDD00000 
    If Length(No_In) > 11 Then 
      v_No := No_In; 
    Elsif Length(No_In) > 9 Then 
      v_No := Substr(To_Char(Sysdate, 'YY'), 1, 11 - Length(No_In)) || No_In; 
    Elsif Length(No_In) > 7 Then 
      v_No := Getdateno(No_In, 'YY', 9); 
    Elsif Length(No_In) > 5 Then 
      v_No := Getdateno(No_In, 'YYMM', 7); 
    Else 
      v_No := Getdateno(No_In, 'YYMMDD', 5); 
    End If; 
 
  Elsif 序号_In = 131 Then 
    --体检报到号 
    v_No := No_In; 
 
    --其它单据号 
  Else 
    --如果规则是按科室编号顺序产生，但又未设置科室编码，则采取按年顺序编号 
    If n_Mod = 2 And 序号_In <> 122 Then 
      Begin 
        Select 编号 Into v_Deptno From 科室号码表 Where 科室id = 科室id_In And 项目序号 = 序号_In; 
      Exception 
        When Others Then 
          Null; 
      End; 
      If v_Deptno Is Null Then 
        n_Mod := 0; 
      End If; 
    End If; 
    --获得年编码 
    Select Decode(Sign(Intyear - 10), -1, To_Char(Intyear, '9'), Chr(55 + Intyear)) 
    Into v_Year 
    From (Select To_Number(To_Char(Sysdate, 'yyyy'), '9999') - 1990 As Intyear From Dual); 
 
    If n_Mod = 0 Then 
      --0.按年顺序编号 
      --补全规则如下: 
      --1.如果传入的号码长度大于等于8位，则原样返回 
      --2.如果传入的号码长度小于8位，则 
      --2.1.如果号码第一位为非数字，则在字符和数字之间补0，使其达到8位长度，如：传入D1，则返回D0000001；传入D323，则返回D0000323 
      --2.2.其它，则从号码控制表中的最大号码中取前(8-传入号码长度)位补到传入号码前面，如：最大号码为Q7863409，传入256，则返回Q7863256 
      If Length(No_In) >= 8 Then 
        v_No := No_In; 
      Else 
        If Instr('0123456789', Substr(No_In, 1, 1)) = 0 Then 
          v_No := Substr(No_In, 1, 1) || LPad(Substr(No_In, 2), 7, '0'); 
        Else 
          Select Nvl(最大号码, '1') Into v_No From 号码控制表 Where 项目序号 = 序号_In; 
          v_No := Substr(v_No, 1, 8 - Length(No_In)) || No_In; 
        End If; 
      End If; 
    Elsif n_Mod = 1 Then 
      --1.按年+日顺序编号:YDDD0000 
      If Length(No_In) > 8 Then 
        v_No := No_In; 
      Elsif Length(No_In) > 4 Then 
        v_No := v_Year || LPad(No_In, 7, '0'); 
      Else 
        v_No := v_Year || LPad(Trunc(Sysdate - Trunc(Sysdate, 'YYYY') + 1, 0), 3, '0') || LPad(No_In, 4, '0'); 
      End If; 
    Elsif n_Mod = 2 Then 
      If 序号_In = 122 Then 
        --2.按科室编码+YYMMDD+3位顺序号:2201090728001 
        Select 编码 Into v_Deptno From 部门表 Where ID = 科室id_In; 
        If Length(No_In) > 9 Then 
          v_No := No_In; 
        Elsif Length(No_In) > 7 Then 
          v_No := v_Deptno || LPad(No_In, 9, '0'); 
        Elsif Length(No_In) > 5 Then 
          v_No := v_Deptno || Getdateno(No_In, 'YY', 7); 
        Elsif Length(No_In) > 3 Then 
          v_No := v_Deptno || Getdateno(No_In, 'YYMM', 5); 
        Else 
          v_No := v_Deptno || Getdateno(No_In, 'YYMMDD', 3); 
        End If; 
      Else 
        --2.按年+科室编号+月+顺序号:YKDD0000 
        Begin 
          Select 编号 Into v_Deptno From 科室号码表 Where 项目序号 = 序号_In And Nvl(科室id, 0) = Nvl(科室id_In, 0); 
        Exception 
          When Others Then 
            Null; 
        End; 
        If v_Deptno Is Null Then 
          v_Error := '科室未设置编号，无法补全号码！'; 
          Raise Err_Custom; 
        Else 
          If Length(No_In) > 7 Then 
            v_No := No_In; 
          Elsif Length(No_In) > 6 Then 
            v_No := v_Year || LPad(No_In, 7, '0'); 
          Elsif Length(No_In) > 4 Then 
            v_No := v_Year || v_Deptno || LPad(No_In, 6, '0'); 
          Else 
            v_Tmp := To_Char(Sysdate, 'MM'); 
            v_No  := v_Year || v_Deptno || v_Tmp || LPad(No_In, 4, '0'); 
          End If; 
        End If; 
      End If; 
    Elsif n_Mod = 3 Then 
      --按年月日+顺序号:YYMMDD000000 
      If Length(No_In) > 12 Then 
        v_No := No_In; 
      Elsif Length(No_In) > 10 Then 
        v_No := Substr(To_Char(Sysdate, 'YY'), 1, 12 - Length(No_In)) || No_In; 
      Elsif Length(No_In) > 8 Then 
        v_No := Getdateno(No_In, 'YY', 10); 
      Elsif Length(No_In) > 6 Then 
        v_No := Getdateno(No_In, 'YYMM', 8); 
      Else 
        v_No := Getdateno(No_In, 'YYMMDD', 6); 
      End If; 
    Elsif n_Mod = 5 Then 
      --1.年月(YYYYMM)+顺序号:YYYYMM000000 
      If Length(No_In) > 12 Then 
        v_No := No_In; 
      Elsif Length(No_In) > 8 Then 
        v_No := Substr(To_Char(Sysdate, 'YYYY'), 1, 12 - Length(No_In)) || No_In; 
      Elsif Length(No_In) > 6 Then 
        v_No := Getdateno(No_In, 'YYYY', 8); 
      Else 
        v_No := Getdateno(No_In, 'YYYYMM', 6); 
      End If; 
    Else 
      v_Error := '序号为' || 序号_In || '的号码,其规则值:' || n_Mod || ',当前系统不支持！'; 
      Raise Err_Custom; 
    End If; 
  End If; 
  Return v_No; 
Exception 
  When Err_Custom Then 
    Raise_Application_Error(-20101, '[ZLSOFT]' || v_Error || '[ZLSOFT]'); 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Fullno;
/

