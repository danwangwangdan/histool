create Function f_Check_Motheds 
( 
  类型_In In 诊疗检查部位.类型%Type := Null, 
  编码_In In 诊疗检查部位.编码%Type := Null 
) Return t_Dic_Rowset Is 
  ------------------------------------------------ 
  --说明：获得指定类型及部位的检查方法项目表 
  --返回：为减少固定类型的定义，本函数借用字典类型返回包含条件项目及其设置值和剩余可选值的类型；类型组成如下： 
  --      编码：使用检查方法的最小部位编码      名称：为条件项目名称      简码：该检查方法的使用频度 
  ------------------------------------------------ 
  a_Return t_Dic_Rowset := t_Dic_Rowset(); 
  a_Mothed t_Dic_Rowset := t_Dic_Rowset(); 
  v_Mothed Varchar2(40); 
  n_Exist  Number(1); 
 
Begin 
  If 类型_In Is Null Then 
    Select t_Dic_Record(编码, Substr(名称, 2), Null) Bulk Collect 
    Into a_Mothed 
    From (Select Min(编码) As 编码, Replace(Replace(Replace(',' || 方法, Chr(9), ','), ';', ','), ',,', ',') As 名称 
           From 诊疗检查部位 
           Group By 方法) 
    Order By 编码; 
  Elsif 编码_In Is Null Then 
    Select t_Dic_Record(编码, Substr(名称, 2), Null) Bulk Collect 
    Into a_Mothed 
    From (Select Min(编码) As 编码, Replace(Replace(Replace(',' || 方法, Chr(9), ','), ';', ','), ',,', ',') As 名称 
           From 诊疗检查部位 
           Where 类型 = 类型_In 
           Group By 方法) 
    Order By 编码; 
  Else 
    Select t_Dic_Record(编码, Substr(名称, 2), Null) Bulk Collect 
    Into a_Mothed 
    From (Select Min(编码) As 编码, Replace(Replace(Replace(',' || 方法, Chr(9), ','), ';', ','), ',,', ',') As 名称 
           From 诊疗检查部位 
           Where 编码 = 编码_In And 类型 = 类型_In 
           Group By 方法) 
    Order By 编码; 
  End If; 
  For n_Mcount In 1 .. a_Mothed.Count Loop 
    If a_Mothed(n_Mcount).名称 Is Not Null Then 
      a_Mothed(n_Mcount).名称 := a_Mothed(n_Mcount).名称 || ','; 
      Loop 
        v_Mothed := Substr(Substr(a_Mothed(n_Mcount).名称, 1, Instr(a_Mothed(n_Mcount).名称, ',') - 1), 2); 
        n_Exist  := 0; 
        For n_Rcount In 1 .. a_Return.Count Loop 
          If a_Return(n_Rcount).名称 = v_Mothed Then 
            a_Return(n_Rcount).简码 := To_Number(a_Return(n_Rcount).简码) + 1; 
            n_Exist := 1; 
            Exit; 
          End If; 
        End Loop; 
        If n_Exist = 0 Then 
          a_Return.Extend; 
          a_Return(a_Return.Count) := t_Dic_Record(Null, Null, Null); 
          a_Return(a_Return.Count).编码 := a_Mothed(n_Mcount).编码; 
          a_Return(a_Return.Count).名称 := v_Mothed; 
          a_Return(a_Return.Count).简码 := 1; 
        End If; 
        a_Mothed(n_Mcount).名称 := Substr(a_Mothed(n_Mcount).名称, Instr(a_Mothed(n_Mcount).名称, ',') + 1); 
        Exit When a_Mothed(n_Mcount) .名称 Is Null; 
      End Loop; 
    End If; 
  End Loop; 
  Return a_Return; 
End f_Check_Motheds;
/

