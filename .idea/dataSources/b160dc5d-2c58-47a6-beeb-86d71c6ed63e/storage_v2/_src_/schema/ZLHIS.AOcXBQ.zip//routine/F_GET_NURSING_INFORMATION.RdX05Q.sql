create Function f_Get_Nursing_Information
(
  变动记录id_In Number,
  Kind_In       Number
) Return Varchar2 As
  --提取指定的护理项目数据
  --参数：变动记录id_In 病人变动记录.ID   Kind_In护理数据的 项目序号
  v_Result Varchar2(20);
  n_病人id 病人变动记录.病人id%Type;
  n_主页id 病人变动记录.主页id%Type;
Begin
  Select z.病人id, z.主页id Into n_病人id, n_主页id From 病人变动记录 Z Where z.Id = 变动记录id_In;
  Select 记录内容
  Into v_Result
  From (Select 记录内容
         From (Select c.记录内容, Row_Number() Over(Partition By c.项目序号 Order By c.记录时间 Asc Nulls First) Rn
                From 病人护理文件 A, 病人护理数据 B, 病人护理明细 C
                Where a.病人id = n_病人id And a.主页id = n_主页id And Nvl(a.婴儿, 0) = 0 And a.Id = b.文件id And b.Id = c.记录id And
                      c.项目序号 = Kind_In)
         Where Rn = 1
         Union All
         Select 记录内容
         From (Select b.记录内容, Row_Number() Over(Partition By b.项目序号 Order By b.修改时间 Asc Nulls First) Rn
                From 病人护理记录 A, 病人护理内容 B
                Where a.病人id = n_病人id And a.主页id = n_主页id And Nvl(a.婴儿, 0) = 0 And a.Id = b.记录id And b.项目序号 = Kind_In)
         Where Rn = 1);
  Return v_Result;
End f_Get_Nursing_Information;
/

