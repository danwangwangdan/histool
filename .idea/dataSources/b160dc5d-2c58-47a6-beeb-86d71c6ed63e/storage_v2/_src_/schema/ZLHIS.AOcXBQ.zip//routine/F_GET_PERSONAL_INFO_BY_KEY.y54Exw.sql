create Function f_Get_Personal_Info_By_Key(Key_In In Varchar2) Return Xmltype Is
  Docxml Xmltype;
  v_Type Varchar2(20);
Begin
  Begin
    Select 人员性质
    Into v_Type
    From (Select b.人员性质
           From 人员证书记录 A, 人员性质说明 B
           Where a.Certsn = Key_In And a.人员id = b.人员id And (b.人员性质 = '医生' Or b.人员性质 = '护士')
           Order By 人员性质 Desc)
    Where Rownum = 1;
  Exception
    When Others Then
      Return Null;
  End;
  Select Xmltype('<root></root>') Into Docxml From Dual;
  If v_Type = '医生' Then
    Select Appendchildxml(Docxml, '/root',
                           Xmlconcat(Xmlelement("code", a.Id), Xmlelement("full_name", a.姓名),
                                      Xmlelement("sex", Xmlattributes(a.性别 As "display"),
                                                  Decode(a.性别, '男', '1', '女', '2', '未知', '0', '9')),
                                      Xmlelement("birthday", To_Char(a.出生日期, 'yyyy-mm-dd')),
                                      Xmlelement("idcard_num", a.身份证号),
                                      Xmlelement("sign_level",
                                                  Xmlattributes(Decode(a.聘任技术职务, 9, '实习医师', 3, '主治医师', 2, '副主任医师', 1, '主任医师',
                                                                        '经治医师') As "display"),
                                                  Decode(a.聘任技术职务, 9, 0, 3, 2, 2, 10, 1, 3, 1))))
    Into Docxml
    From 人员表 A, 人员证书记录 B
    Where b.Certsn = Key_In And b.人员id = a.Id And Nvl(a.撤档时间, To_Date('3000-01-01', 'yyyy-mm-dd')) > Sysdate And
          Rownum = 1
    Order By b.注册时间 Desc;
  Else
    Select Appendchildxml(Docxml, '/root',
                           Xmlconcat(Xmlelement("code", a.Id), Xmlelement("full_name", a.姓名),
                                      Xmlelement("sex", Xmlattributes(a.性别 As "display"),
                                                  Decode(a.性别, '男', '1', '女', '2', '未知', '0', '9')),
                                      Xmlelement("birthday", To_Char(a.出生日期, 'yyyy-mm-dd')),
                                      Xmlelement("idcard_num", a.身份证号),
                                      Xmlelement("sign_level",
                                                  Xmlattributes(Decode(a.聘任技术职务, 9, '实习护士', 5, '护士', 4, '护师', 3, '主管护师', 2,
                                                                        '副主任护师', 1, '主任护师', '护士') As "display"),
                                                  Decode(a.聘任技术职务, 9, 4, 5, 5, 4, 6, 3, 7, 2, 8, 1, 9))))
    Into Docxml
    From 人员表 A, 人员证书记录 B
    Where b.Certsn = Key_In And b.人员id = a.Id And Nvl(a.撤档时间, To_Date('3000-01-01', 'yyyy-mm-dd')) > Sysdate And
          Rownum = 1
    Order By b.注册时间 Desc;
  End If;
  Select Appendchildxml(Docxml, '/root', Xmlelement("esign_range", a.参数值))
  Into Docxml
  From zlParameters A
  Where a.参数名 = '电子签名使用场合' And a.参数号 = 26;
  Select Appendchildxml(Docxml, '/root',
                         Xmlelement("occasion_dept",
                                     Xmlagg(Xmlelement("esign", Xmlelement("occasion", e.场合), Xmlelement("deptId", e.部门id)))))
  Into Docxml
  From 电子签名启用部门 E;
  Select Appendchildxml(Docxml, '/root',
                         Xmlelement("departments",
                                     Xmlagg(Xmlelement("department", Xmlattributes(c.名称 As "display", d.缺省 As "current"),
                                                        c.Id))))
  Into Docxml
  From 人员证书记录 B, 部门表 C, 部门人员 D
  Where b.Certsn = Key_In And b.人员id = d.人员id And d.部门id = c.Id;
  For r_Record In (Select d.部门id, Xmlelement("subjects", Xmlagg(Xmlelement("subject", c.名称))) As 部门学科
                   From 临床部门 A, 人员证书记录 B, 部门人员 D, 临床性质 C
                   Where b.Certsn = Key_In And b.人员id = d.人员id And a.部门id = d.部门id And a.工作性质 = c.编码
                   Group By d.部门id
                   Order By d.部门id) Loop
    Select Appendchildxml(Docxml, '/root/departments/department[dept_value=' || r_Record.部门id || ']', r_Record.部门学科)
    Into Docxml
    From Dual;
  End Loop;
  Return Docxml;
Exception
  When Others Then
    Return Null;
End f_Get_Personal_Info_By_Key;
/

