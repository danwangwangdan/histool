create Function f_Segment_条件项(Id_In In 病历范文目录.Id%Type) Return t_Dic_Rowset Is 
  a_Term t_Dic_Rowset := t_Dic_Rowset(); 
  n_种类 病历文件列表.种类%Type; 
  Type t_Item_Record Is Record( 
    条件项 Varchar2(20), 
    条件值 Varchar2(2000)); 
  Type t_Item_Table Is Table Of t_Item_Record; 
  a_Set t_Item_Table := t_Item_Table(); 
 
  Procedure p_Add_Item(条件项_In In 病历范文条件.条件项%Type) Is 
  Begin 
    a_Term.Extend; 
    a_Term(a_Term.Count) := t_Dic_Record(Null, Null, Null); 
    a_Term(a_Term.Count).名称 := 条件项_In; 
    For n_Count In 1 .. a_Set.Count Loop 
      If a_Set(n_Count).条件项 = 条件项_In Then 
        a_Term(a_Term.Count).简码 := a_Set(n_Count).条件值; 
        Exit; 
      End If; 
    End Loop; 
  Exception 
    When Others Then 
      Null; 
  End p_Add_Item; 
 
Begin 
  Select c.种类 Into n_种类 From 病历文件列表 c, 病历范文目录 s Where c.Id = s.文件id And s.Id = Id_In; 
  For r_Temp In (Select 条件项, 条件值 From 病历范文条件 Where 范文id = Id_In) Loop 
    a_Set.Extend; 
    a_Set(a_Set.Count).条件项 := r_Temp.条件项; 
    a_Set(a_Set.Count).条件值 := r_Temp.条件值; 
  End Loop; 
 
  p_Add_Item('病人性别'); 
  p_Add_Item('婚姻状况'); 
  If n_种类 = 2 Or n_种类 = 4 Then 
    p_Add_Item('住院目的'); 
    p_Add_Item('病人病情'); 
    p_Add_Item('入院方式'); 
  End If; 
  If n_种类 = 7 Then 
    p_Add_Item('诊疗类别'); 
    If a_Term(a_Term.Count).名称 = '诊疗类别' And a_Term(a_Term.Count).简码 = '检查' Then 
      p_Add_Item('检查类型'); 
    End If; 
    If a_Term(a_Term.Count).名称 = '检查类型' And a_Term(a_Term.Count).简码 Is Not Null Then 
      p_Add_Item('检查部位'); 
      p_Add_Item('检查方法'); 
    End If; 
  End If; 
  Return a_Term; 
 
Exception 
  When Others Then 
    Return Null; 
End f_Segment_条件项;
/

