create Function f_Segment_Usable 
( 
  文件id_In In 电子病历记录.文件id%Type, 
  病人id_In In 电子病历记录.病人id%Type, 
  主页id_In In 电子病历记录.主页id%Type, 
  医嘱id_In In 病人医嘱记录.Id%Type := Null 
) Return t_Dic_Rowset Is 
  a_Id_Retu t_Dic_Rowset := t_Dic_Rowset(); 
 
  n_符合 Number(18); 
  Type t_Demo_Table Is Table Of 病历范文目录.Id%Type; 
  a_Demos t_Demo_Table := t_Demo_Table(); 
 
  Type t_Term_Record Is Record( 
    条件项 Varchar2(20), 
    条件值 Varchar2(2000)); 
  Type t_Term_Table Is Table Of t_Term_Record; 
  a_Terms t_Term_Table := t_Term_Table(); 
 
  r_Patient 病人信息%Rowtype := Null; 
  r_In_Page 病案主页%Rowtype := Null; 
  r_Advice  病人医嘱记录%Rowtype := Null; 
  v_Value   Varchar2(2000); 
 
Begin 
  Begin 
    Select * Into r_Patient From 病人信息 Where 病人id = 病人id_In; 
    Select * Into r_In_Page From 病案主页 Where 病人id = 病人id_In And 主页id = 主页id_In; 
  Exception 
    When Others Then 
      Null; 
  End; 
  Begin 
    Select * Into r_Advice From 病人医嘱记录 Where Id = 医嘱id_In And 病人id + 0 = 病人id_In; 
  Exception 
    When Others Then 
      Null; 
  End; 
 
  Select Id Bulk Collect Into a_Demos From 病历范文目录 Where 文件id = 文件id_In; 
  For n_Wcount In 1 .. a_Demos.Count Loop 
    n_符合  := 1; 
    a_Terms := t_Term_Table(); 
    For r_Temp In (Select 条件项, 条件值 From 病历范文条件 Where 范文id = a_Demos(n_Wcount) And 条件值 Is Not Null) Loop 
      a_Terms.Extend; 
      a_Terms(a_Terms.Count).条件项 := r_Temp.条件项; 
      a_Terms(a_Terms.Count).条件值 := Chr(9) || r_Temp.条件值 || Chr(9); 
    End Loop; 
    For n_Tcount In 1 .. a_Terms.Count Loop 
      If r_Patient.病人id Is Not Null Then 
        If a_Terms(n_Tcount).条件项 = '病人性别' Then 
          n_符合 := Instr(a_Terms(n_Tcount).条件值, Chr(9) || r_Patient.性别 || Chr(9)); 
        Elsif a_Terms(n_Tcount).条件项 = '婚姻状况' Then 
          n_符合 := Instr(a_Terms(n_Tcount).条件值, Chr(9) || r_Patient.婚姻状况 || Chr(9)); 
        End If; 
      End If; 
      If r_In_Page.主页id Is Not Null Then 
        If a_Terms(n_Tcount).条件项 = '住院目的' Then 
          n_符合 := Instr(a_Terms(n_Tcount).条件值, Chr(9) || r_In_Page.住院目的 || Chr(9)); 
        Elsif a_Terms(n_Tcount).条件项 = '病人病情' Then 
          n_符合 := Instr(a_Terms(n_Tcount).条件值, Chr(9) || r_In_Page.当前病况 || Chr(9)); 
        Elsif a_Terms(n_Tcount).条件项 = '入院方式' Then 
          n_符合 := Instr(a_Terms(n_Tcount).条件值, Chr(9) || r_In_Page.入院方式 || Chr(9)); 
        End If; 
      End If; 
      If r_Advice.Id Is Not Null Then 
        If a_Terms(n_Tcount).条件项 = '诊疗类别' Then 
          Select 名称 Into v_Value From 诊疗项目类别 Where 编码 = r_Advice.诊疗类别; 
          n_符合 := Instr(a_Terms(n_Tcount).条件值, Chr(9) || v_Value || Chr(9)); 
        Elsif a_Terms(n_Tcount).条件项 = '检查类型' Then 
          Select 操作类型 Into v_Value From 诊疗项目目录 i Where Id = r_Advice.诊疗项目id; 
          n_符合 := Instr(a_Terms(n_Tcount).条件值, Chr(9) || v_Value || Chr(9)); 
        Elsif a_Terms(n_Tcount).条件项 = '检查部位' Then 
          n_符合 := 0; 
          For r_Temp In (Select Distinct 标本部位 From 病人医嘱记录 Where Id = r_Advice.Id Or 相关id = r_Advice.Id) Loop 
            If Instr(a_Terms(n_Tcount).条件值, Chr(9) || r_Temp.标本部位 || Chr(9)) <> 0 Then 
              n_符合 := 1; 
              Exit; 
            End If; 
          End Loop; 
        Elsif a_Terms(n_Tcount).条件项 = '检查方法' Then 
          n_符合 := 0; 
          For r_Temp In (Select Distinct 检查方法 From 病人医嘱记录 Where Id = r_Advice.Id Or 相关id = r_Advice.Id) Loop 
            If Instr(a_Terms(n_Tcount).条件值, Chr(9) || r_Temp.检查方法 || Chr(9)) <> 0 Then 
              n_符合 := 1; 
              Exit; 
            End If; 
          End Loop; 
        End If; 
      End If; 
      If n_符合 = 0 Then 
        Exit; 
      End If; 
    End Loop; 
    If n_符合 <> 0 Then 
      a_Id_Retu.Extend; 
      a_Id_Retu(a_Id_Retu.Count) := t_Dic_Record(Null, Null, Null); 
      a_Id_Retu(a_Id_Retu.Count).编码 := a_Demos(n_Wcount); 
    End If; 
  End Loop; 
  Return a_Id_Retu; 
Exception 
  When Others Then 
    Return a_Id_Retu; 
End f_Segment_Usable;
/

