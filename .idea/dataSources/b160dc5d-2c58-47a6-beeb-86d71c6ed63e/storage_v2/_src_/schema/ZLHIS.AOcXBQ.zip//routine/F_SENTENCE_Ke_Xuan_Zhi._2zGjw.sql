create Function f_Sentence_可选值 
( 
  Id_In     In 病历词句示范.Id%Type, 
  条件项_In In 病历词句条件.条件项%Type 
) Return t_Dic_Rowset Is 
  a_Value  t_Dic_Rowset := t_Dic_Rowset(); 
  a_Mothed t_Dic_Rowset := t_Dic_Rowset(); 
  v_Mothed Varchar2(40); 
  n_Exist  Number(1); 
 
  v_Used  病历词句条件.条件值%Type := Null; 
  v_Check 病历词句条件.条件值%Type := Null; 
 
Begin 
  Begin 
    Select 条件值 Into v_Used From 病历词句条件 Where 词句id = Id_In And 条件项 = 条件项_In; 
  Exception 
    When Others Then 
      Null; 
  End; 
  v_Used := Chr(9) || v_Used || Chr(9); 
  If 条件项_In = '病人性别' Then 
    Select t_Dic_Record(Null, 名称, Null) Bulk Collect 
    Into a_Value 
    From (Select '男' As 名称 
           From Dual 
           Union All 
           Select '女' As 名称 From Dual) 
    Where Instr(v_Used, Chr(9) || 名称 || Chr(9)) = 0; 
  Elsif 条件项_In = '婚姻状况' Then 
    Select t_Dic_Record(Null, 名称, Null) Bulk Collect 
    Into a_Value 
    From 婚姻状况 
    Where Instr(v_Used, Chr(9) || 名称 || Chr(9)) = 0 
    Order By 编码; 
  Elsif 条件项_In = '住院目的' Then 
    Select t_Dic_Record(Null, 名称, Null) Bulk Collect 
    Into a_Value 
    From 住院目的 
    Where Instr(v_Used, Chr(9) || 名称 || Chr(9)) = 0 
    Order By 编码; 
  Elsif 条件项_In = '病人病情' Then 
    Select t_Dic_Record(Null, 名称, Null) Bulk Collect 
    Into a_Value 
    From 病情 
    Where Instr(v_Used, Chr(9) || 名称 || Chr(9)) = 0 
    Order By 编码; 
  Elsif 条件项_In = '入院方式' Then 
    Select t_Dic_Record(Null, 名称, Null) Bulk Collect 
    Into a_Value 
    From 入院方式 
    Where Instr(v_Used, Chr(9) || 名称 || Chr(9)) = 0 
    Order By 编码; 
  Elsif 条件项_In = '诊疗类别' Then 
    Select t_Dic_Record(Null, 名称, Null) Bulk Collect 
    Into a_Value 
    From (Select '检验' As 名称 
           From Dual 
           Union All 
           Select '检查' As 名称 
           From Dual 
           Union All 
           Select '治疗' As 名称 
           From Dual 
           Union All 
           Select '手术' As 名称 From Dual) 
    Where Instr(v_Used, Chr(9) || 名称 || Chr(9)) = 0; 
  Elsif 条件项_In = '检查类型' Then 
    Select t_Dic_Record(Null, 名称, Null) Bulk Collect 
    Into a_Value 
    From 诊疗检查类型 
    Where Instr(v_Used, Chr(9) || 名称 || Chr(9)) = 0 
    Order By 编码; 
  Elsif 条件项_In = '检查部位' Then 
    Begin 
      Select 条件值 Into v_Check From 病历词句条件 Where 词句id = Id_In And 条件项 = '检查类型'; 
    Exception 
      When Others Then 
        v_Check := '<未设置>'; 
    End; 
    Select t_Dic_Record(Null, 名称, Null) Bulk Collect 
    Into a_Value 
    From 诊疗检查部位 
    Where 类型 = v_Check And Instr(v_Used, Chr(9) || 名称 || Chr(9)) = 0 
    Order By 编码; 
  Elsif 条件项_In = '检查方法' Then 
    Begin 
      Select 条件值 Into v_Check From 病历词句条件 Where 词句id = Id_In And 条件项 = '检查类型'; 
    Exception 
      When Others Then 
        v_Check := '<未设置>'; 
    End; 
    Select t_Dic_Record(编码, Substr(名称, 2), Null) Bulk Collect 
    Into a_Mothed 
    From (Select Min(编码) As 编码, Replace(Replace(Replace(',' || 方法, Chr(9), ','), ';', ','), ',,', ',') As 名称 
           From 诊疗检查部位 
           Where 类型 = v_Check 
           Group By 方法) 
    Order By 编码; 
    For n_Mcount In 1 .. a_Mothed.Count Loop 
      If a_Mothed(n_Mcount).名称 Is Not Null Then 
        a_Mothed(n_Mcount).名称 := a_Mothed(n_Mcount).名称 || ','; 
        Loop 
          v_Mothed := Substr(Substr(a_Mothed(n_Mcount).名称, 1, Instr(a_Mothed(n_Mcount).名称, ',') - 1), 2); 
          n_Exist  := 0; 
          For n_Rcount In 1 .. a_Value.Count Loop 
            If a_Value(n_Rcount).名称 = v_Mothed Then 
              n_Exist := 1; 
              Exit; 
            End If; 
          End Loop; 
          If n_Exist = 0 Then 
            a_Value.Extend; 
            a_Value(a_Value.Count) := t_Dic_Record(Null, Null, Null); 
            a_Value(a_Value.Count).名称 := v_Mothed; 
          End If; 
          a_Mothed(n_Mcount).名称 := Substr(a_Mothed(n_Mcount).名称, Instr(a_Mothed(n_Mcount).名称, ',') + 1); 
          Exit When a_Mothed(n_Mcount) .名称 Is Null; 
        End Loop; 
      End If; 
    End Loop; 
  End If; 
  Return a_Value; 
Exception 
  When Others Then 
    Return Null; 
End f_Sentence_可选值;
/

