create Function f_Sentence_Matched 
( 
  词句id_In   病历词句示范.ID%Type, 
  来源_In     Number, 
  性别_In     病人信息.性别%Type, 
  婚姻状况_In 病人信息.婚姻状况%Type, 
  住院目的_In 病案主页.住院目的%Type, 
  病人病情_In 病案主页.当前病况%Type, 
  入院方式_In 病案主页.入院方式%Type, 
  诊疗类别_In 诊疗项目类别.名称%Type, 
  检查类型_In 诊疗检查类型.名称%Type := Null, 
  检查部位_In Varchar2 := Null, 
  检查方法_In Varchar2 := Null 
  --功能：根据当前病人和医嘱信息检查指定词句是否符合设定条件 
  --说明：之所以条件项以参数方式固定，是为了查询处理效率考虑 
  --参数： 
  --  来源_IN：1-门诊,2-住院 
  --  检查部位_IN：用","分隔的检查部位名称串 
  --  检查方法_IN：用","分隔的检查方法名称串 
) Return Number Is 
  n_符合 Number(18); 
 
  Type t_Term_Record Is Record( 
    条件项 Varchar2(20), 
    条件值 Varchar2(2000)); 
  Type t_Term_Table Is Table Of t_Term_Record; 
  a_Terms t_Term_Table := t_Term_Table(); 
Begin 
  --读取设置的条件 
  a_Terms := t_Term_Table(); 
  For r_Temp In (Select 条件项, 条件值 From 病历词句条件 Where 词句id = 词句id_In And 条件值 Is Not Null) Loop 
    a_Terms.Extend; 
    a_Terms(a_Terms.Count).条件项 := r_Temp.条件项; 
    a_Terms(a_Terms.Count).条件值 := Chr(9) || r_Temp.条件值 || Chr(9); 
  End Loop; 
 
  --逐条件进行检查 
  n_符合 := 1; 
  For n_Tcount In 1 .. a_Terms.Count Loop 
    If a_Terms(n_Tcount).条件项 = '病人性别' Then 
      n_符合 := Instr(a_Terms(n_Tcount).条件值, Chr(9) || 性别_In || Chr(9)); 
    Elsif a_Terms(n_Tcount).条件项 = '婚姻状况' Then 
      n_符合 := Instr(a_Terms(n_Tcount).条件值, Chr(9) || 婚姻状况_In || Chr(9)); 
    Elsif a_Terms(n_Tcount).条件项 = '住院目的' Then 
      If 来源_In = 2 Then 
        n_符合 := Instr(a_Terms(n_Tcount).条件值, Chr(9) || 住院目的_In || Chr(9)); 
      End If; 
    Elsif a_Terms(n_Tcount).条件项 = '病人病情' Then 
      If 来源_In = 2 Then 
        n_符合 := Instr(a_Terms(n_Tcount).条件值, Chr(9) || 病人病情_In || Chr(9)); 
      End If; 
    Elsif a_Terms(n_Tcount).条件项 = '入院方式' Then 
      If 来源_In = 2 Then 
        n_符合 := Instr(a_Terms(n_Tcount).条件值, Chr(9) || 入院方式_In || Chr(9)); 
      End If; 
    Elsif a_Terms(n_Tcount).条件项 = '诊疗类别' Then 
      n_符合 := Instr(a_Terms(n_Tcount).条件值, Chr(9) || 诊疗类别_In || Chr(9)); 
    Elsif a_Terms(n_Tcount).条件项 = '检查类型' Then 
      If 诊疗类别_In = '检查' Then 
        n_符合 := Instr(a_Terms(n_Tcount).条件值, Chr(9) || 检查类型_In || Chr(9)); 
      End If; 
    Elsif a_Terms(n_Tcount).条件项 = '检查部位' Then 
      If 诊疗类别_In = '检查' Then 
        n_符合 := 0; 
        For r_Temp In (Select Distinct Column_Value As 标本部位 From Table(Cast(f_Str2list(检查部位_In) As zlTools.t_Strlist))) Loop 
          If Instr(a_Terms(n_Tcount).条件值, Chr(9) || r_Temp.标本部位 || Chr(9)) <> 0 Then 
            n_符合 := 1; 
            Exit; 
          End If; 
        End Loop; 
      End If; 
    Elsif a_Terms(n_Tcount).条件项 = '检查方法' Then 
      If 诊疗类别_In = '检查' Then 
        n_符合 := 0; 
        For r_Temp In (Select Distinct Column_Value As 检查方法 From Table(Cast(f_Str2list(检查方法_In) As zlTools.t_Strlist))) Loop 
          If Instr(a_Terms(n_Tcount).条件值, Chr(9) || r_Temp.检查方法 || Chr(9)) <> 0 Then 
            n_符合 := 1; 
            Exit; 
          End If; 
        End Loop; 
      End If; 
    End If; 
 
    If n_符合 = 0 Then 
      Exit; 
    End If; 
  End Loop; 
 
  If n_符合 > 0 Then 
    n_符合 := 1; 
  End If; 
  Return n_符合; 
Exception 
  When Others Then 
    Return 0; 
End f_Sentence_Matched;
/

