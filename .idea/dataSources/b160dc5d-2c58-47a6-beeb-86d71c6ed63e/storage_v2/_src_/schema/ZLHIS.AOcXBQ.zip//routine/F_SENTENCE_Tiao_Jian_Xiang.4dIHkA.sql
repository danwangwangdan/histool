create Function f_Sentence_条件项(Id_In In 病历词句示范.ID%Type) Return t_Dic_Rowset Is 
  ------------------------------------------------ 
  --说明：根据当前词句对应分类可应用的病历种类，确定允许设置的条件项目以及项目的设置值列表、可选值列表 
  --返回：为减少固定类型的定义，本函数借用字典类型返回包含条件项目及其设置值和剩余可选值的类型；类型组成如下： 
  --      编码：始终为Null      名称：为条件项目名称 
  --      简码：按"设置值1||chr(9)||设置值2||chr(9)||设置值3..."组织的字符串 
  ------------------------------------------------ 
  a_Term t_Dic_Rowset := t_Dic_Rowset(); 
  v_范围 病历词句分类.范围%Type; 
  Type t_Item_Record Is Record( 
    条件项 Varchar2(20), 
    条件值 Varchar2(2000)); 
  Type t_Item_Table Is Table Of t_Item_Record; 
  a_Set t_Item_Table := t_Item_Table(); 
 
  --添加一个元素到数组中 
  Procedure p_Add_Item(条件项_In In 病历词句条件.条件项%Type) Is 
  Begin 
    a_Term.Extend; 
    a_Term(a_Term.Count) := t_Dic_Record(Null, Null, Null); 
    a_Term(a_Term.Count).名称 := 条件项_In; 
    For n_Count In 1 .. a_Set.Count Loop 
      If a_Set(n_Count).条件项 = 条件项_In Then 
        a_Term(a_Term.Count).简码 := a_Set(n_Count).条件值; 
        Exit; 
      End If; 
    End Loop; 
  Exception 
    When Others Then 
      Null; 
  End p_Add_Item; 
 
  ------------------------------------------------ 
  --函数主体 
Begin 
  Select C.范围 Into v_范围 From 病历词句分类 C, 病历词句示范 S Where C.ID = S.分类id And S.ID = Id_In; 
  v_范围 := Substr(v_范围 || '00000000', 1, 8); 
  For r_Temp In (Select 条件项, 条件值 From 病历词句条件 Where 词句id = Id_In) Loop 
    a_Set.Extend; 
    a_Set(a_Set.Count).条件项 := r_Temp.条件项; 
    a_Set(a_Set.Count).条件值 := r_Temp.条件值; 
  End Loop; 
 
  p_Add_Item('病人性别'); 
  p_Add_Item('婚姻状况'); 
  If To_Number(Substr(v_范围, 2)) > 0 Then 
    p_Add_Item('住院目的'); 
    p_Add_Item('病人病情'); 
    p_Add_Item('入院方式'); 
  End If; 
  If Substr(v_范围, 7, 1) = '1' Or Substr(v_范围, 8, 1) = '1' Then 
    p_Add_Item('诊疗类别'); 
    If a_Term(a_Term.Count).名称 = '诊疗类别' And a_Term(a_Term.Count).简码 = '检查' Then 
      p_Add_Item('检查类型'); 
    End If; 
    If a_Term(a_Term.Count).名称 = '检查类型' And a_Term(a_Term.Count).简码 Is Not Null Then 
      p_Add_Item('检查部位'); 
      p_Add_Item('检查方法'); 
    End If; 
  End If; 
  Return a_Term; 
 
Exception 
  When Others Then 
    Return Null; 
End f_Sentence_条件项;
/

