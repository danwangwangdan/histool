create Function Gettext 
( 
	文本_In Varchar2, 
	个数_In Number, 
	行数_In Number := 1 
) Return Varchar2 As 
	n_Loop      Number(18); 
	n_Asc       Number(18); 
	n_Asc2      Number(18); 
	n_Lens      Number(18); 
	n_Rows      Number(18); 
	n_Start     Number(18); 
	n_Wordcount Number(18); 
	n_Charcount Number(18); 
	v_Tmp       Varchar2(4000); 
Begin 
	n_Rows      := 0; 
	n_Loop      := 1; 
	n_Start     := 1; 
	n_Charcount := 0; 
	n_Wordcount := 0; 
 
	n_Lens := Length(文本_In); 
 
	While n_Loop <= n_Lens Loop 
 
		n_Asc2 := 0; 
		v_Tmp  := Substr(文本_In, n_Loop, 1); 
		n_Asc  := Ascii(v_Tmp); 
		If n_Asc = 13 Then 
			n_Asc2 := Ascii(Substr(文本_In, n_Loop + 1, 1)); 
 
		End If; 
 
		If n_Asc = 10 Then 
			n_Asc2 := Ascii(Substr(文本_In, n_Loop + 1, 1)); 
 
		End If; 
 
		If n_Asc2=13 Or n_Asc2=10 Then 
			n_Loop := n_Loop + 1; 
		End If; 
 
		If (n_Asc = 13 And n_Asc2 = 10) Or (n_Asc2 = 13 And n_Asc = 10) Or n_Asc = 10 Then 
			n_Rows := n_Rows + 1; 
			If n_Rows = 行数_In Then 
 
				v_Tmp := Substr(文本_In, n_Start, n_Wordcount); 
 
				Select Replace(v_Tmp, Chr(13), '') Into v_Tmp From Dual; 
				Select Replace(v_Tmp, Chr(10), '') Into v_Tmp From Dual; 
 
				Return(v_Tmp); 
			Else 
				If (n_Asc = 13 And n_Asc2 = 10) Or (n_Asc2 = 13 And n_Asc = 10) Then 
					n_Start := n_Start + n_Wordcount + 2; 
				Else 
					n_Start := n_Start + n_Wordcount + 1; 
				End If; 
 
				n_Charcount := 0; 
				n_Wordcount := 0; 
			End If; 
 
		Elsif Nvl(Length(v_Tmp), 0) <> Nvl(Lengthb(v_Tmp), 0) Then 
			--双字节字符,比如汉字 
			If n_Charcount + 2 <= 个数_In Then 
				n_Charcount := n_Charcount + 2; 
				n_Wordcount := n_Wordcount + 1; 
			Else 
				n_Rows := n_Rows + 1; 
				If n_Rows = 行数_In Then 
 
					v_Tmp := Substr(文本_In, n_Start, n_Wordcount); 
 
					Select Replace(v_Tmp, Chr(13), '') Into v_Tmp From Dual; 
					Select Replace(v_Tmp, Chr(10), '') Into v_Tmp From Dual; 
 
					Return(v_Tmp); 
 
				Else 
					n_Start     := n_Start + n_Wordcount; 
					n_Charcount := 2; 
					n_Wordcount := 1; 
				End If; 
			End If; 
 
		Elsif Nvl(Length(v_Tmp), 0) = Nvl(Lengthb(v_Tmp), 0) Then 
			--单字节字符，如A 
			If n_Charcount + 1 <= 个数_In Then 
				n_Charcount := n_Charcount + 1; 
				n_Wordcount := n_Wordcount + 1; 
			Else 
				n_Rows := n_Rows + 1; 
				If n_Rows = 行数_In Then 
 
					v_Tmp := Substr(文本_In, n_Start, n_Wordcount); 
 
					Select Replace(v_Tmp, Chr(13), '') Into v_Tmp From Dual; 
					Select Replace(v_Tmp, Chr(10), '') Into v_Tmp From Dual; 
 
					Return(v_Tmp); 
				Else 
					n_Start     := n_Start + n_Wordcount; 
					n_Charcount := 1; 
					n_Wordcount := 1; 
				End If; 
			End If; 
		End If; 
 
		n_Loop := n_Loop + 1; 
	End Loop; 
 
	If n_Wordcount > 0 And n_Rows = (行数_In - 1) Then 
		v_Tmp := Substr(文本_In, n_Start, n_Wordcount); 
 
		Select Replace(v_Tmp, Chr(13), '') Into v_Tmp From Dual; 
		Select Replace(v_Tmp, Chr(10), '') Into v_Tmp From Dual; 
 
		Return(v_Tmp); 
	Else 
		Return(''); 
	End If; 
End;
/

