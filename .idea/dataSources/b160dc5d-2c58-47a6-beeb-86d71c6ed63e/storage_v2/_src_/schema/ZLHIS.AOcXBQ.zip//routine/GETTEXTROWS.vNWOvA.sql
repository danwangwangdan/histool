create Function GetTextRows 
( 
	文本_In Varchar2, 
	个数_In Number 
) Return Number As 
	v_Rows    Number(18); 
	v_Len     Number(18); 
	v_Pos     Number(18); 
	v_Tmp     Varchar2(4000); 
	v_Tmpline Varchar2(4000); 
Begin 
 
	v_Rows := 0; 
 
	v_Tmp := 文本_In; 
	v_Pos := Instrb(v_Tmp, Chr(10)); 
	While v_Pos > 0 Loop 
		v_Tmpline := Substrb(v_Tmp, 1, v_Pos - 1); 
 
		v_Len := Nvl(Lengthb(v_Tmpline),0); 
 
		v_Rows := v_Rows + Nvl(Ceil(v_Len / 个数_In),0); 
 
		v_Tmp := Substrb(v_Tmp, v_Pos + 1); 
		v_Pos := Instrb(v_Tmp, Chr(10)); 
 
	End Loop; 
	v_Len  := Nvl(Lengthb(v_Tmp),0); 
	v_Rows := v_Rows + Nvl(Ceil(v_Len / 个数_In),0); 
 
	If v_Rows < 1 Then 
		v_Rows := 1; 
	End If; 
	If Mod(lengthb(文本_In),个数_In)=0 Then 
		v_Rows:=v_Rows+1; 
	End If; 
 
	Return(v_Rows); 
End;
/

