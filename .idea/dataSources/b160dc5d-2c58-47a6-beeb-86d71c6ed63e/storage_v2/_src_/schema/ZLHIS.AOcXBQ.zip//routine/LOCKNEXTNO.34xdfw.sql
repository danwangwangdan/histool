create Function Locknextno 
( 
  病人id_In In Number, 
  门诊号_In In Number:=0 
) Return Varchar2 Is 
 
  Pragma Autonomous_Transaction; 
 
  n_病人id 病人信息.病人id%Type; 
  n_门诊号 病人信息.门诊号%Type; 
  n_病人Num Number; 
  n_门诊Num Number; 
  n_Mod Number; 
Begin 
 
  n_病人id := Nextno(1); 
 
  If 门诊号_In > 0 Then 
    n_门诊号 := Nextno(3); 
  End If; 
 
  If 病人id_In>0 Then 
    n_病人Num := 病人id_In-1; 
  Else 
    n_病人Num := 病人id_In; 
  End If; 
 
  If n_门诊号>0 Then 
    n_门诊Num := 门诊号_In-1; 
  Else 
    n_门诊Num := 门诊号_In; 
  End If; 
 
   Select Nvl(编号规则, 0) Into n_Mod From 号码控制表 Where 项目序号 = 1; 
 
  --从序列取值，用于不要求病人ID必须连续的用户减少并发争用 
  If n_Mod=0 Then 
     Insert Into 病人信息 (病人id, 门诊号, 停用时间) Values (n_病人id + n_病人Num, n_门诊号 + n_门诊Num,Sysdate); 
  Else 
     Insert Into 病人信息 (病人id, 门诊号, 停用时间) Values (-n_病人id , n_门诊号 + n_门诊Num,Sysdate); 
  End if; 
 
  Commit; 
 
  Return To_Char(n_病人id) || ',' || To_Char(n_门诊号); 
Exception 
  When No_Data_Found Then 
    Return Null; 
End Locknextno;
/

