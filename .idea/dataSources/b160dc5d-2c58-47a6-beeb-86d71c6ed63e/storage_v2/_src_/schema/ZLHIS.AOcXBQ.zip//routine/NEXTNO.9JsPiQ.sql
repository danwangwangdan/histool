create Function Nextno 
( 
  序号_In     In 号码控制表.项目序号%Type, 
  科室id_In   In 部门表.Id%Type := Null, 
  v_Tag       In Varchar2 := Null, 
  号码个数_In In Integer := 1 
) Return Varchar2 
--    功能：根据特定规则产生新的号码,规则如下： 
  --    一、项目序号： 
  --       1   病人ID         数字 
  --       2   住院号         数字 
  --       3   门诊号         数字 
  --       10  医嘱发送号     数字,顺序递增编号 
  --       x   其它单据号     字符,根据编号规则顺序递增编号,不自动补缺 
  --    二、年度位确定原则： 
  --       以1990为基数，随年度增长，按“0～9/A～Z”顺序作为年度编码 
  -- 
  --    说明：最大号码-10存入号码控制表,用于并发情况下补缺号(取了号,但未使用) 
  --          For Update在并发情况下锁定行,不用Wait选项以避免向调用者返回空 
  --          v_Tag 可用其它未指明的参数,目前 有影像检查类别(编码) 
  --    返回：最大号码 
 Is 
  Pragma Autonomous_Transaction; 
  v_No     号码控制表.最大号码%Type; 
  v_Maxno  号码控制表.最大号码%Type; 
  n_Maxno  Number; 
  n_Amt    Number; 
  n_Mod    号码控制表.编号规则%Type; 
  v_Deptno Varchar2(20); 
  v_Year   Varchar2(1); 
  v_Tmp    Varchar2(10); 
 
  v_试管编码   Number; 
  v_生成条码   Varchar2(20); 
  v_编码       Varchar2(10); 
  v_医嘱       Varchar2(18); 
  v_Error      Varchar2(255); 
  n_Checkmaxno Number; 
 
  Err_Custom Exception; 
Begin 
 
  --1.病人ID 
  If 序号_In = 1 Then 
    Select Nvl(编号规则, 0) Into n_Mod From 号码控制表 Where 项目序号 = 序号_In; 
 
    --从序列取值，用于不要求病人ID必须连续的用户减少并发争用 
    If n_Mod = 1 Then 
      Select 病人信息_Id.Nextval Into v_No From Dual; 
    Else 
      Select Nvl(最大号码, '0') Into v_Maxno From 号码控制表 Where 项目序号 = 序号_In For Update; 
 
      Select Nvl(Max(病人id), 0) + 1 Into n_Maxno From 病人信息 Where 病人id >= To_Number(v_Maxno); 
 
      Update 号码控制表 Set 最大号码 = Decode(Sign(n_Maxno - 10), 1, n_Maxno - 10, 1) Where 项目序号 = 序号_In; 
      v_No := To_Char(n_Maxno); 
    End If; 
    --2.住院号 
  Elsif 序号_In = 2 Then 
    Select Nvl(最大号码, '0'), Nvl(编号规则, 0) 
    Into v_Maxno, n_Mod 
    From 号码控制表 
    Where 项目序号 = 序号_In 
    For Update; 
 
    If n_Mod = 0 Then 
      --0.顺序编号 
      Select Nvl(Max(住院号), 0) + 1 Into n_Maxno From 病人信息 Where 住院号 >= To_Number(v_Maxno); 
 
      Update 号码控制表 Set 最大号码 = Decode(Sign(n_Maxno - 10), 1, n_Maxno - 10, 1) Where 项目序号 = 序号_In; 
    Elsif n_Mod = 1 Then 
      --1.年月(YYMM)+顺序号(0000) 
      v_Tmp := To_Char(Sysdate, 'YYMM'); 
 
      Select Nvl(Max(住院号), To_Number(v_Tmp || '0000')) + 1 
      Into n_Maxno 
      From 病人信息 
      Where 住院号 Like To_Number(v_Tmp) || '%' And 住院号 >= To_Number(v_Maxno); 
      Update 号码控制表 
      Set 最大号码 = Decode(Sign(n_Maxno - 10 - To_Number(v_Tmp || '0000')), 1, n_Maxno - 10, To_Number(v_Tmp || '0001')) 
      Where 项目序号 = 序号_In; 
 
    Elsif n_Mod = 2 Then 
      --2.年(YYYY)+顺序号(00000) 
      v_Tmp := To_Char(Sysdate, 'YYYY'); 
 
      Select Nvl(Max(住院号), To_Number(v_Tmp || '00000')) + 1 
      Into n_Maxno 
      From 病人信息 
      Where 住院号 Like To_Number(v_Tmp) || '%' And 住院号 >= To_Number(v_Maxno); 
      Update 号码控制表 
      Set 最大号码 = Decode(Sign(n_Maxno - 10 - To_Number(v_Tmp || '00000')), 1, n_Maxno - 10, To_Number(v_Tmp || '00001')) 
      Where 项目序号 = 序号_In; 
 
    End If; 
    v_No := To_Char(n_Maxno); 
 
    --3.门诊号 
  Elsif 序号_In = 3 Then 
    Select Nvl(最大号码, '0'), Nvl(编号规则, 0) 
    Into v_Maxno, n_Mod 
    From 号码控制表 
    Where 项目序号 = 序号_In 
    For Update; 
 
    If n_Mod = 0 Then 
      --0.顺序编号 
 
      Select Nvl(Max(门诊号), 0) + 1 Into n_Maxno From 病人信息 Where 门诊号 >= To_Number(v_Maxno); 
 
      Update 号码控制表 Set 最大号码 = Decode(Sign(n_Maxno - 10), 1, n_Maxno - 10, 1) Where 项目序号 = 序号_In; 
    Elsif n_Mod = 1 Then 
      --1.日期编号YYMMDD 
      v_Tmp := To_Char(Sysdate, 'YYMMDD'); 
 
      Select Nvl(Max(门诊号), To_Number(v_Tmp || '0000')) + 1 
      Into n_Maxno 
      From 病人信息 
      Where 门诊号 Like To_Number(v_Tmp) || '%' And 门诊号 >= To_Number(v_Maxno); 
      Update 号码控制表 
      Set 最大号码 = Decode(Sign(n_Maxno - 10 - To_Number(v_Tmp || '0000')), 1, n_Maxno - 10, To_Number(v_Tmp || '0001')) 
      Where 项目序号 = 序号_In; 
 
    End If; 
    v_No := To_Char(n_Maxno); 
 
    --10.医嘱发送号 
  Elsif 序号_In = 10 Then 
    Select Nvl(最大号码, '0') Into v_Maxno From 号码控制表 Where 项目序号 = 序号_In For Update; 
    v_Maxno := To_Char(To_Number(v_Maxno) + 1); 
    Update 号码控制表 Set 最大号码 = v_Maxno Where 项目序号 = 序号_In; 
    v_No := v_Maxno; 
 
    --汇总发药号 
  Elsif 序号_In = 20 Then 
    --YYYYMMDD+5位顺序号(00000) 
    Select To_Char(Sysdate, 'yyyymmdd') Into v_Tmp From Dual; 
    Select Nvl(最大号码, '0') Into v_Maxno From 号码控制表 Where 项目序号 = 序号_In For Update; 
 
    If v_Maxno = '0' Then 
      v_Maxno := v_Tmp || '00001'; 
    Else 
      If Substr(v_Maxno, 1, 8) = v_Tmp Then 
        If To_Number(Substr(v_Maxno, 9, 5)) = 99999 Then 
          v_Maxno := v_Tmp || '00001'; 
        Else 
          v_Maxno := v_Tmp || Trim(To_Char(To_Number(Substr(v_Maxno, 9, 5)) + 1, '00000')); 
        End If; 
      Else 
        v_Maxno := v_Tmp || '00001'; 
      End If; 
    End If; 
    Update 号码控制表 Set 最大号码 = v_Maxno Where 项目序号 = 序号_In; 
 
    v_No := v_Maxno; 
 
  Elsif 序号_In = 123 Then 
 
    Select Nvl(Max(参数值), 0) Into n_Mod From 影像流程参数 Where 科室id = 科室id_In And 参数名 = '检查号生成方式'; 
    Select Nvl(Max(参数值), 1) 
    Into n_Checkmaxno 
    From 影像流程参数 
    Where 科室id = 科室id_In And 参数名 = '提取实际最大号码'; 
 
    If n_Mod = 1 Then 
      --影像检查号按科室递增 
      --从号码表提取最大号码 
      Select Count(*) Into n_Maxno From 科室号码表 Where 项目序号 = 序号_In And 科室id = 科室id_In; 
      If Nvl(n_Maxno, 0) = 0 Then 
          --没有记录，则自动增加科室号码表 
          Insert Into 科室号码表 (项目序号, 科室id, 编号, 最大号码) Values (序号_In, 科室id_In, 'A', '1'); 
          Commit; 
      End If; 
 
      Select Nvl(最大号码, 0) Into n_Maxno From 科室号码表 Where 项目序号 = 序号_In And 科室id = 科室id_In for update; 
 
      --提取实际最大号码,如果有实际最大号码，这个号码会比号码表中的大10 
      If n_Checkmaxno = 1 Then 
        Select Nvl(Max(检查号), 0) + 1 Into n_Amt From 影像检查记录 Where 执行科室id = 科室id_In And 检查号 >= n_Maxno; 
 
        If n_Amt > n_Maxno Then 
          n_Maxno := n_Amt; 
        End If; 
      Else 
        -- 如果不提取实际最大号码，加上10 
        n_Maxno := n_Maxno + 10 + 1; 
      End If; 
 
      -- 回填最大号码 
      Update 科室号码表 
        Set 最大号码 = Decode(Sign(n_Maxno - 10), 1, n_Maxno - 10, 1) 
        Where 项目序号 = 序号_In And 科室id = 科室id_In; 
    Else 
      --影像检查号按类别递增 
      Select Nvl(最大号码, 0) Into n_Maxno From 影像检查类别 Where 编码 = v_Tag for update ; 
      --提取实际最大号码，如果有实际最大号码，这个号码会比号码表中的大10 
      If n_Checkmaxno = 1 Then 
        Select Nvl(Max(检查号), 0) + 1 Into n_Amt From 影像检查记录 Where 影像类别 = v_Tag And 检查号 >= n_Maxno; 
 
        If n_Amt > n_Maxno Then 
          n_Maxno := n_Amt; 
        End If; 
      Else 
        -- 如果不提取实际最大号码，加上10 
        n_Maxno := n_Maxno + 10 + 1; 
      End If; 
 
      -- 回填最大号码 
      Update 影像检查类别 Set 最大号码 = Decode(Sign(n_Maxno - 10), 1, n_Maxno - 10, 1) Where 编码 = v_Tag; 
    End If; 
    v_No := To_Char(n_Maxno); 
 
  Elsif 序号_In = 124 Then 
    ---------------------------------------------------------------------------------------------------------------------------- 
    --体检健康号 
 
    Begin 
      Select Nvl(编号规则, 0) Into n_Mod From 号码控制表 Where 项目序号 = 序号_In; 
    Exception 
      When Others Then 
        v_Error := '号码控制表中不存在序号为' || 序号_In || '的号码'; 
        Raise Err_Custom; 
    End; 
 
    If n_Mod = 0 Then 
      --顺序编号 
      Select Nvl(Zl_To_Number(最大号码), 0) + 号码个数_In 
      Into v_Maxno 
      From 号码控制表 
      Where 项目序号 = 序号_In 
      For Update; 
      Update 号码控制表 Set 最大号码 = v_Maxno Where 项目序号 = 序号_In; 
    Else 
      --前缀+顺序号 
      Update 号码编号表 Set 最大号码 = 最大号码 Where 项目序号 = 序号_In And 号码前缀 = v_Tag; 
      If Sql%RowCount = 0 Then 
        Insert Into 号码编号表 
          (项目序号, 号码前缀, 日期, 最大号码) 
          Select 序号_In, v_Tag, Sysdate, '' From Dual; 
      End If; 
 
      Select Nvl(Zl_To_Number(最大号码), 0) + 号码个数_In 
      Into n_Maxno 
      From 号码编号表 A 
      Where a.项目序号 = 序号_In And a.号码前缀 = v_Tag; 
 
      If Substr(n_Maxno, 1, Length(v_Tag)) <> v_Tag Then 
        --进位了 
        Select Nvl(Zl_To_Number(Substr(最大号码, Length(v_Tag) + 1)), 0) + 号码个数_In 
        Into n_Maxno 
        From 号码编号表 A 
        Where a.项目序号 = 序号_In And a.号码前缀 = v_Tag; 
        Select v_Tag || n_Maxno Into v_Maxno From Dual; 
      Else 
        If n_Maxno = 号码个数_In Then 
          v_Maxno := v_Tag || To_Char(号码个数_In); 
        Else 
          v_Maxno := n_Maxno; 
        End If; 
      End If; 
 
      Update 号码编号表 Set 最大号码 = v_Maxno Where 项目序号 = 序号_In And 号码前缀 = v_Tag; 
    End If; 
    v_No := v_Maxno; 
 
  Elsif 序号_In = 125 Then 
    --这里是为了减少号码控制表的锁定时间 
    If n_Mod = 0 Then 
      Begin 
        Select 试管编码 
        Into v_试管编码 
        From 病人医嘱记录 A, 诊疗项目目录 B 
        Where a.诊疗项目id = b.Id And a.Id = 科室id_In And 试管编码 Is Not Null; 
      Exception 
        When Others Then 
          v_Error := '没有找到检验项目对应的管码！'; 
          Raise Err_Custom; 
      End; 
    Else 
      Begin 
        Select 试管编码, c.编码 
        Into v_试管编码, v_编码 
        From 病人医嘱记录 A, 诊疗项目目录 B, 诊疗检验类型 C 
        Where a.诊疗项目id = b.Id And a.Id = 科室id_In And b.操作类型 = c.名称 And 试管编码 Is Not Null; 
 
      Exception 
        When Others Then 
          v_Error := '没有找到检验项目对应的管码和编码！'; 
          Raise Err_Custom; 
      End; 
    End If; 
 
    Select Nvl(最大号码, '0'), Nvl(编号规则, 0) 
    Into v_Maxno, n_Mod 
    From 号码控制表 
    Where 项目序号 = 序号_In 
    For Update; 
 
    If n_Mod = 0 Then 
      --按医嘱生成 
 
      v_医嘱 := 科室id_In; 
      If Length(v_医嘱) > 12 Then 
        v_医嘱 := Substr(v_医嘱, Length(v_医嘱) - 11); 
      Else 
        v_医嘱 := LPad(v_医嘱, 12, '0'); 
      End If; 
      if Length(ltrim(v_医嘱,'0'))>8 then 
         Select v_试管编码 || LPad(Substr(v_医嘱, Length(v_医嘱) - (13 - Length(v_试管编码) - 2)), (13 - Length(v_试管编码)), '0') 
          Into v_生成条码 
         From Dual; 
      else 
         Select v_试管编码 || LPad(Substr(v_医嘱, Length(v_医嘱) - (12 - Length(v_试管编码) - 2)), (12 - Length(v_试管编码)), '0') 
         Into v_生成条码 
         From Dual; 
      end if; 
      v_No := v_生成条码; 
    Else 
      --按"小组编号（1位）+管码(2位)+日期(6位)+顺序号(3)位"生成条码 
      Begin 
        Select 最大号码 
        Into v_Maxno 
        From 号码编号表 
        Where 项目序号 = 序号_In And 号码前缀 = v_编码 || v_试管编码 And Trunc(日期) = Trunc(Sysdate) 
        For Update; 
        v_Maxno := v_Maxno + 1; 
        If Length(v_Maxno) <= 3 Then 
          v_Maxno := LPad(v_Maxno, 3, '0'); 
        End If; 
        v_No := v_编码 || v_试管编码 || To_Char(Trunc(Sysdate), 'yymmdd') || v_Maxno; 
        Update 号码编号表 
        Set 日期 = Trunc(Sysdate), 最大号码 = v_Maxno 
        Where 号码前缀 = v_编码 || v_试管编码 And Trunc(日期) = Trunc(Sysdate); 
      Exception 
        When Others Then 
          Update 号码编号表 Set 日期 = Trunc(Sysdate), 最大号码 = 1 Where 号码前缀 = v_编码 || v_试管编码; 
          If Sql%RowCount = 0 Then 
            Insert Into 号码编号表 
              (项目序号, 号码前缀, 日期, 最大号码) 
            Values 
              (序号_In, v_编码 || v_试管编码, Trunc(Sysdate), 1); 
          End If; 
          v_No := v_编码 || v_试管编码 || To_Char(Trunc(Sysdate), 'yymmdd') || '001'; 
      End; 
    End If; 
    --卫材条码序号 
  Elsif 序号_In = 126 Then 
    --12位顺序号 
    Select Nvl(最大号码, '0') Into v_Maxno From 号码控制表 Where 项目序号 = 序号_In For Update; 
 
    If v_Maxno = '0' Then 
      v_Maxno := '000000000001'; 
    Else 
      v_Maxno := Trim(To_Char(To_Number(v_Maxno) + 1, '000000000000')); 
    End If; 
    Update 号码控制表 Set 最大号码 = v_Maxno Where 项目序号 = 序号_In; 
 
    v_No := v_Maxno; 
  Elsif 序号_In = 135 Then 
    --药品卫材调价 
    Begin 
      Select Nvl(编号规则, 0) Into n_Mod From 号码控制表 Where 项目序号 = 序号_In; 
    Exception 
      When Others Then 
        v_Error := '号码控制表中不存在序号为' || 序号_In || '的号码'; 
        Raise Err_Custom; 
    End; 
    --1.年月(YYYYMM)+顺序号(0000) 
    v_Tmp := To_Char(Sysdate, 'YYYYMM'); 
    Select Nvl(最大号码, '0') Into v_Maxno From 号码控制表 Where 项目序号 = 序号_In For Update; 
 
    If v_Maxno = '0' Then 
      v_Maxno := v_Tmp || '0001'; 
    Else 
      If Substr(v_Maxno, 1, 6) = v_Tmp Then 
        v_Maxno := v_Tmp || Trim(To_Char(To_Number(Substr(v_Maxno, 7, 4)) + 1, '0000')); 
      Else 
        v_Maxno := v_Tmp || '0001'; 
      End If; 
    End If; 
    Update 号码控制表 Set 最大号码 = v_Maxno Where 项目序号 = 序号_In; 
    v_No := v_Maxno; 
  Elsif 序号_In = 136 Then 
      --YYMMDD+5位顺序号(00000) 
      Select To_Char(sysdate, 'yymmdd') Into v_Tmp From Dual; 
      Select Nvl(最大号码, '0') Into v_Maxno From 号码控制表 Where 项目序号 = 序号_In For Update; 
 
      If v_Maxno = '0' Then 
        v_Maxno := v_Tmp || '00001'; 
      Else 
        If Substr(v_Maxno, 1, 6) = v_Tmp Then 
          If To_Number(Substr(v_Maxno, 7, 5)) = 99999 Then 
            v_Maxno := v_Tmp || '00001'; 
          Else 
            v_Maxno := v_Tmp || Trim(To_Char(To_Number(Substr(v_Maxno, 7, 5)) + 1, '00000')); 
          End If; 
        Else 
          v_Maxno := v_Tmp || '00001'; 
        End If; 
      End If; 
      Update 号码控制表 Set 最大号码 = v_Maxno Where 项目序号 = 序号_In; 
      v_No := v_Maxno; 
  Elsif 序号_In = 131 Then 
    --体检报到号 
    Select Nvl(最大号码, '0') Into v_Maxno From 号码控制表 Where 项目序号 = 序号_In For Update; 
    v_Maxno := To_Char(To_Number(v_Maxno) + 1); 
    Update 号码控制表 Set 最大号码 = v_Maxno Where 项目序号 = 序号_In; 
    v_No := v_Maxno; 
    --其它单据号 
  Else 
    Begin 
      Select Nvl(编号规则, 0) Into n_Mod From 号码控制表 Where 项目序号 = 序号_In; 
    Exception 
      When Others Then 
        v_Error := '号码控制表中不存在序号为' || 序号_In || '的号码'; 
        Raise Err_Custom; 
    End; 
 
    --如果规则是按科室编号顺序产生，但又未设置科室编码，则采取按年顺序编号 
    If n_Mod = 2 And 序号_In <> 122 Then 
      Begin 
        Select 编号 Into v_Deptno From 科室号码表 Where 科室id = 科室id_In And 项目序号 = 序号_In; 
      Exception 
        When Others Then 
          Null; 
      End; 
      If v_Deptno Is Null Then 
        n_Mod := 0; 
      End If; 
    End If; 
 
    Select Decode(Sign(Intyear - 10), -1, To_Char(Intyear, '9'), Chr(55 + Intyear)) 
    Into v_Year 
    From (Select To_Number(To_Char(Sysdate, 'yyyy'), '9999') - 1990 As Intyear From Dual); 
 
    If n_Mod = 0 Then 
      --0.按年顺序编号 
      Select Nvl(最大号码, '0') Into v_No From 号码控制表 Where 项目序号 = 序号_In For Update; 
 
      --第2位增长方式:0-9,A-Z 
      Select Bit1 || Decode(Sign(Ascii(Bit2) - Ascii('9')), -1, LPad(To_Number(Bit28) + 1, 7, '0'), 
                             Decode(Bit38, '999999', Decode(Bit2, '9', 'A', Chr(Ascii(Bit2) + 1)) || '000000', 
                                     Bit2 || LPad(To_Number(Bit38) + 1, 6, '0'))) 
      Into v_No 
      From (Select Substr(Maxno, 1, 1) As Bit1, Substr(Maxno, 2, 1) As Bit2, Substr(Maxno, 2) As Bit28, 
                    Substr(Maxno, 3) As Bit38 
             From (Select Decode(v_No, '0', v_Year || '0000000', 
                                   Decode(Sign(Ascii(Substr(v_No, 1, 1)) - Ascii(v_Year)), -1, v_Year || '0000000', v_No)) As Maxno 
                    From Dual)); 
 
      Update 号码控制表 Set 最大号码 = v_No Where 项目序号 = 序号_In; 
 
    Elsif n_Mod = 1 Then 
      --1.按年+日顺序编号:YDDD0000 
      Select Nvl(最大号码, '0') Into v_No From 号码控制表 Where 项目序号 = 序号_In For Update; 
      Select v_Year || LPad(Trunc(Sysdate - Trunc(Sysdate, 'YYYY') + 1, 0), 3, '0') || '0000' Into v_Maxno From Dual; 
      If v_No < v_Maxno Then 
        v_No := v_Maxno; 
      End If; 
      v_No := Substr(v_No, 1, 4) || LPad(To_Number(Substr(v_No, 5, 4)) + 1, 4, '0'); 
      Update 号码控制表 Set 最大号码 = v_No Where 项目序号 = 序号_In; 
 
    Elsif n_Mod = 2 Then 
      If 序号_In = 122 Then 
        --2.按科室编码+YYMMDD+3位顺序号:2201090728001 
        Select Count(*) Into n_Maxno From 科室号码表 Where 项目序号 = 序号_In And 科室id = 科室id_In; 
        If Nvl(n_Maxno, 0) = 0 Then 
          Insert Into 科室号码表 (项目序号, 科室id, 最大号码, 编号) Values (序号_In, 科室id_In, Null, Null); 
          Commit; 
        End If; 
 
        Select 编码 Into v_Deptno From 部门表 Where ID = 科室id_In; 
        Select Nvl(最大号码, '-') Into v_No From 科室号码表 Where 项目序号 = 序号_In And 科室id = 科室id_In For Update; 
        v_Tmp := To_Char(Sysdate, 'YYMMDD'); 
 
        If Substr(v_No, 1, Length(v_Deptno || v_Tmp)) = v_Deptno || v_Tmp Then 
          v_No := v_Deptno || v_Tmp || LPad(To_Number(Substr(v_No, Length(v_Deptno || v_Tmp) + 1)) + 1, 3, '0'); 
        Else 
          v_No := v_Deptno || v_Tmp || LPad('1', 3, '0'); 
        End If; 
        Update 科室号码表 Set 最大号码 = v_No Where 项目序号 = 序号_In And 科室id = 科室id_In; 
 
      Else 
        --2.按年+科室编号+月+顺序号:YKDD0000 
        Begin 
          --符号-的asscii为45,用于和year比较(0的ascii为48) 
          Select 编号, Nvl(最大号码, '-') 
          Into v_Deptno, v_No 
          From 科室号码表 
          Where 项目序号 = 序号_In And Nvl(科室id, 0) = Nvl(科室id_In, 0) 
          For Update; 
        Exception 
          When Others Then 
            Null; 
        End; 
        If v_Deptno Is Null Then 
          v_Error := '科室未设置编号，无法产生号码！'; 
          Raise Err_Custom; 
        Else 
          v_Tmp := To_Char(Sysdate, 'MM'); 
          Select Substr(Maxno, 1, 4) || LPad(To_Number(Substr(Maxno, 5, 4)) + 1, 4, '0') 
          Into v_No 
          From (Select Decode(Sign(Ascii(Substr(v_No, 1, 1)) - Ascii(v_Year)), -1, v_Year || v_Deptno || v_Tmp || '0000', 
                                Decode(Sign(To_Number(Substr(v_No, 3, 2)) - To_Number(v_Tmp)), -1, 
                                        v_Year || v_Deptno || v_Tmp || '0000', v_No)) As Maxno 
                 From Dual); 
          Update 科室号码表 Set 最大号码 = v_No Where 项目序号 = 序号_In And Nvl(科室id, 0) = Nvl(科室id_In, 0); 
 
        End If; 
      End If; 
    Elsif n_Mod = 3 Then 
 
      --按年月日+000001生成 
      Select Substr(To_Char(Sysdate, 'yyyymmdd'), 3, 6) Into v_Tmp From Dual; 
      Select Nvl(最大号码, '0') Into v_Maxno From 号码控制表 Where 项目序号 = 序号_In For Update; 
 
      If v_Maxno = '0' Then 
        v_Maxno := v_Tmp || '000001'; 
      Else 
        If Substr(v_Maxno, 1, 6) = v_Tmp Then 
          v_Maxno := v_Tmp || Trim(To_Char(To_Number(Substr(v_Maxno, 7, 6)) + 1, '000000')); 
        Else 
          v_Maxno := v_Tmp || '000001'; 
        End If; 
      End If; 
      Update 号码控制表 Set 最大号码 = v_Maxno Where 项目序号 = 序号_In; 
      v_No := v_Maxno; 
 
    Elsif n_Mod = 5 Then 
      --1.年月(YYYYMM)+顺序号(000000) 
      v_Tmp := To_Char(Sysdate, 'YYYYMM'); 
      Select Nvl(最大号码, '0') Into v_Maxno From 号码控制表 Where 项目序号 = 序号_In For Update; 
 
      If v_Maxno = '0' Then 
        v_Maxno := v_Tmp || '000001'; 
      Else 
        If Substr(v_Maxno, 1, 6) = v_Tmp Then 
          v_Maxno := v_Tmp || Trim(To_Char(To_Number(Substr(v_Maxno, 7, 6)) + 1, '000000')); 
        Else 
          v_Maxno := v_Tmp || '000001'; 
        End If; 
      End If; 
      Update 号码控制表 Set 最大号码 = v_Maxno Where 项目序号 = 序号_In; 
      v_No := v_Maxno; 
    Else 
      v_Error := '序号为' || 序号_In || '的号码,其规则值:' || n_Mod || ',当前系统不支持！'; 
      Raise Err_Custom; 
    End If; 
  End If; 
 
  Commit; 
  Return v_No; 
Exception 
  When Err_Custom Then 
    Rollback; 
    Raise_Application_Error(-20101, '[ZLSOFT]' || v_Error || '[ZLSOFT]'); 
  When Others Then 
    Rollback; 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Nextno;
/

