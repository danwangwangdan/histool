create Function Nextreservationnum 
( 
  记录id_In     In 临床出诊序号控制.记录id%Type, 
  序号_In       In 临床出诊序号控制.序号%Type, 
  操作员姓名_In In 临床出诊序号控制.操作员姓名%Type 
) Return Varchar2 
--获取最大预约顺序号，只针对预约普通分时段 
 Is 
  Pragma Autonomous_Transaction; 
  v_机器名   临床出诊序号控制.工作站名称%Type; 
  v_工作站ip 临床出诊序号控制.工作站ip%Type; 
  n_数量     临床出诊序号控制.数量%Type; 
  n_已约数   临床出诊序号控制.数量%Type; 
  n_Maxno    Number; 
 
  v_Error Varchar2(255); 
  Err_Custom Exception; 
Begin 
  Select Terminal Into v_机器名 From V$session Where Audsid = Userenv('sessionid'); 
  Select Sys_Context('USERENV', 'IP_ADDRESS') Into v_工作站ip From Dual; 
  Begin 
    Select a.数量, b.已约数 
    Into n_数量, n_已约数 
    From 临床出诊序号控制 A, 
         (Select 记录id, 序号, Count(1) As 已约数 
           From 临床出诊序号控制 
           Where 记录id = 记录id_In And 序号 = 序号_In And 挂号状态 <> 0 And 挂号状态 <> 4 And 预约顺序号 Is Not Null 
           Group By 记录id, 序号) B 
    Where a.记录id = b.记录id(+) And a.序号 = b.序号(+) And a.记录id = 记录id_In And a.序号 = 序号_In And a.预约顺序号 Is Null; 
  Exception 
    When Others Then 
      v_Error := '没找到对应的出诊安排记录'; 
      Raise Err_Custom; 
  End; 
 
  If Nvl(n_已约数, 0) < Nvl(n_数量, 0) Then 
    Select Nvl(Max(预约顺序号), 0) Into n_Maxno From 临床出诊序号控制 Where 记录id = 记录id_In And 序号 = 序号_In; 
    --If n_挂号序号=0 then 
    n_Maxno := n_Maxno + 1; 
    Insert Into 临床出诊序号控制 
      (记录id, 序号, 预约顺序号, 开始时间, 终止时间, 数量, 是否预约, 挂号状态, 锁号时间, 类型, 名称, 操作员姓名, 工作站ip, 工作站名称, 备注) 
      Select 记录id, 序号, n_Maxno, 开始时间, 终止时间, 1, 是否预约, 5, Sysdate, 类型, 名称, 操作员姓名_In, v_工作站ip, v_机器名, '自助机锁号' 
      From 临床出诊序号控制 
      Where 记录id = 记录id_In And 序号 = 序号_In And 预约顺序号 Is Null; 
  Else 
    v_Error := '当前时段预约已超过最大限约数'; 
    Raise Err_Custom; 
  End If; 
  Commit; 
  Return n_Maxno; 
Exception 
  When Err_Custom Then 
    Rollback; 
    Raise_Application_Error(-20101, '[ZLSOFT]' || v_Error || '[ZLSOFT]'); 
  When Others Then 
    Rollback; 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Nextreservationnum;
/

