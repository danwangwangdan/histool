create Function Zl1_Clinicno_Full 
( 
  No_In  In 号码控制表.最大号码%Type, 
  Mod_In In 号码控制表.编号规则%Type 
) Return Varchar2 
--    功能：门诊号处理规则，用户自己定义 
  --    参数： 
  --        No_In：输入门诊号 
  --        Mod_In：系统参数设置的门诊号编号规则 
  --    返回：按规则处理后的门诊号 
 Is 
  v_No 号码控制表.最大号码%Type; 
Begin 
  --门诊号默认按如下规则处理 
  If Mod_In = 0 Then 
    --0.顺序编号 
    v_No := No_In; 
  Elsif Mod_In = 1 Then 
    --1.年月日 + 顺序号:YYMMDD0000 
    If Length(No_In) > 10 Then 
      v_No := No_In; 
    Elsif Length(No_In) > 8 Then 
      v_No := Substr(To_Char(Sysdate, 'YY'), 1, 10 - Length(No_In)) || No_In; 
    Elsif Length(No_In) > 6 Then 
      v_No := To_Char(Sysdate, 'YY') || LPad(No_In, 8, '0'); 
    Elsif Length(No_In) > 4 Then 
      v_No := To_Char(Sysdate, 'YYMM') || LPad(No_In, 6, '0'); 
    Else 
      v_No := To_Char(Sysdate, 'YYMMDD') || LPad(No_In, 4, '0'); 
    End If; 
  End If; 
  Return v_No; 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zl1_Clinicno_Full;
/

