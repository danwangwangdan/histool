create Function Zl1_Ex_Isdoctorsamelevel 
( 
  甲医生id_In   In 人员表.Id%Type, 
  甲医生姓名_In In 人员表.姓名%Type, 
  乙医生id_In   In 人员表.Id%Type, 
  乙医生姓名_In In 人员表.姓名%Type 
) Return Number 
--功能说明：比较两个医生的职务大小。 
  --适用说明：挂号安排替诊时调用，检查替诊医生的职务是否大于等于原医生职务。 
  --入参说明： 
  --     甲医生ID：人员ID,院外医生传入NULL 
  --     甲医生姓名：人员姓名 
  --     乙医生ID：人员ID,院外医生传入NULL 
  --     乙医生姓名：人员姓名 
  --函数返回： 
  --     -1 - 甲医生的职务大于乙医生的职务 
  --     0 - 甲医生的职务等于乙医生的职务 
  --     1 - 甲医生的职务小于乙医生的职务 
  --说明：根据“专业技术职务”来判断,编码小的表示职务越大,没有设置专业技术职务的医生表示职务最低 
 Is 
  n_a Number; 
  n_b Number; 
Begin 
  If Nvl(甲医生id_In, 0) = 0 Then 
    --院外医生 
    n_a := -1; 
  Else 
    Begin 
      Select To_Number(Nvl(b.编码, -1)) 
      Into n_a 
      From 人员表 A, 专业技术职务 B 
      Where a.专业技术职务 = b.名称(+) And a.Id = 甲医生id_In; 
    Exception 
      When Others Then 
        n_a := -1; 
    End; 
  End If; 
  If Nvl(乙医生id_In, 0) = 0 Then 
    --院外医生 
    n_b := -1; 
  Else 
    Begin 
      Select To_Number(Nvl(b.编码, -1)) 
      Into n_b 
      From 人员表 A, 专业技术职务 B 
      Where a.专业技术职务 = b.名称(+) And a.Id = 乙医生id_In; 
    Exception 
      When Others Then 
        n_b := -1; 
    End; 
  End If; 
 
  If n_a = -1 And n_b = -1 Then 
    Return 0; 
  Elsif n_a = -1 Then 
    Return 1; 
  Elsif n_b = -1 Then 
    Return - 1; 
  Else 
    If n_a = n_b Then 
      Return 0; 
    Elsif n_a > n_b Then 
      Return 1; 
    Else 
      Return - 1; 
    End If; 
  End If; 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zl1_Ex_Isdoctorsamelevel;
/

