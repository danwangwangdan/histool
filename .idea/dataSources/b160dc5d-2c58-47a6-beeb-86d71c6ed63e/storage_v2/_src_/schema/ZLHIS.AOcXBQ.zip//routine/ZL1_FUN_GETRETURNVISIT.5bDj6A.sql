create Function Zl1_Fun_Getreturnvisit 
( 
  病人id_In 病人信息.病人id%Type, 
  科室id_In 部门表.Id%Type 
) Return Number As 
  -------------------------------------------------------------------------------------------------- 
  --功能:挂号时判断病人是否复诊 
  --默认规则:当前挂号科室的临床性质或临床性质取两位的编码且在30天内存在挂号记录的,为复诊 
  --入参: 
  --  病人ID_In   : 挂号病人ID 
  --  科室ID_In   : 挂号科室ID 
  --返回:是否复诊,1-复诊,0-初诊 
  -------------------------------------------------------------------------------------------------- 
  v_挂号性质 临床部门.工作性质%Type; 
  n_Exists   Number(3); 
  v_部门ids  Varchar2(4000); 
  v_Err_Msg  Varchar2(200); 
  Err_Item Exception; 
Begin 
  Begin 
    Select 工作性质 Into v_挂号性质 From 临床部门 Where 部门id = 科室id_In And Rownum < 2; 
  Exception 
    When Others Then 
      Return 0; 
  End; 
  v_挂号性质 := Substr(v_挂号性质, 1, 2) || '%'; 
  For r_部门 In (Select Distinct 部门id From 临床部门 Where 工作性质 Like v_挂号性质) Loop 
    v_部门ids := v_部门ids || ',' || r_部门.部门id; 
  End Loop; 
  If v_部门ids Is Not Null Then 
    v_部门ids := Substr(v_部门ids, 2); 
  End If; 
  n_Exists := 0; 
  Select Max(1) 
  Into n_Exists 
  From 病人挂号记录 
  Where 登记时间 > Sysdate - 30 And 病人id = 病人id_In And 记录状态 = 1 And 记录性质 = 1 And 
        执行部门id In (Select Column_Value From Table(f_Str2list(v_部门ids))); 
  Return Nvl(n_Exists, 0); 
Exception 
  When Err_Item Then 
    v_Err_Msg := '[ZLSOFT]' || v_Err_Msg || '[ZLSOFT]'; 
    Raise_Application_Error(-20101, v_Err_Msg); 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End;
/

