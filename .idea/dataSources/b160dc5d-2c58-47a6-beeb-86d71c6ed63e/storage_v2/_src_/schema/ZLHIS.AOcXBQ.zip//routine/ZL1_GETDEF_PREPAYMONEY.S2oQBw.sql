create Function Zl1_Getdef_Prepaymoney 
( 
  病人id_In 病人信息.病人id%Type, 
  主页id_In 病案主页.主页id%Type 
  --功能：获取默认的预交款缴款额 
  --     本函数主要供病人费用查询时调用缴预交时调用,主要是读取缺省的预交金额 
  --     用户可以根据实际产生的规则,来生成这个缺省值 
  --参数： 
  --    病人ID_In：病人ID 
  --    主页ID_In:主页ID 
) Return Number Is 
  Err_Custom Exception; 
  n_预交余额 病人余额.预交余额%Type; 
  n_费用余额 病人余额.费用余额%Type; 
  n_预结费用 病人余额.预交余额%Type; 
  n_本次预交 病人余额.预交余额%Type; 
Begin 
  --目前按规则:（总费用-预交款总额-报销金额 >0） 
  Select Nvl(Sum(预交余额), 0), Nvl(Sum(费用余额), 0), Nvl(Sum(预结费用), 0) 
  Into n_预交余额, n_费用余额, n_预结费用 
  From (Select Nvl(预交余额, 0) 预交余额, Nvl(费用余额, 0) 费用余额, 0 As 预结费用 
         From 病人余额 
         Where 性质 = 1 And 病人id = 病人id_In AND nvl(类型,2)=2 
         Union All 
         Select 0 As 预交余额, 0 As 费用余额, Sum(B.金额) As 预结费用 
         From 病人信息 A, 保险模拟结算 B 
         Where A.病人id = B.病人id And A.主页ID = B.主页id And A.病人id = 病人id_In); 
  n_本次预交 := n_预交余额 - n_费用余额 + n_预结费用; 
  If n_本次预交 > 0 Then 
    n_本次预交 := 0; 
  End If; 
  n_本次预交 := Abs(n_本次预交); 
  Return n_本次预交; 
 
End Zl1_Getdef_Prepaymoney;
/

