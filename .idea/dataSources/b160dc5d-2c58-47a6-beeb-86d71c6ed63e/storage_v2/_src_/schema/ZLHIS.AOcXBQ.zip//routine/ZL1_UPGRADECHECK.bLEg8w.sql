create Function zl1_UpgradeCheck( 
	v_CurVer In Varchar2, 
	v_NewVer In Varchar2 
) Return Varchar2 Is 
	v_Error   Varchar2(2000); 
	v_Message Varchar2(500); 
Begin 
	v_Error:=Null; 
 
	--检查表空间是否满足需要 
	v_Message:=Null; 
	Select 
		Decode(Count(*),8,Null,'●请先创建 zl9BaseItem、zl9Patient、zl9Expense、zl9MedLst、zl9DueRec、zl9CisRec、zl9EPRLob、zl9EPRDat 表空间') 
	Into v_Message 
	From User_TableSpaces 
	Where Upper(TableSpace_Name) In ('ZL9BASEITEM', 'ZL9PATIENT', 'ZL9EXPENSE', 'ZL9MEDLST', 'ZL9DUEREC', 'ZL9CISREC', 'ZL9EPRLOB','ZL9EPRDAT') 
		And Status = 'ONLINE'; 
	If v_Message is Not Null Then 
		v_Error:=v_Error||Chr(10)||v_Message; 
	End If; 
	 
	If v_NewVer>='10.14.0' Then 
		v_Message:=Null; 
		Select 
			Decode(Count(*),2,Null,'●升级到ZLHIS 10.14.0及以上版本，请先创建 ZL9EPRLob、ZL9EPRDat 表空间，初始尺寸至少50M') 
		Into v_Message 
		From User_TableSpaces 
		Where Upper(TableSpace_Name) In ('ZL9EPRLOB', 'ZL9EPRDAT') And Status = 'ONLINE'; 
		If v_Message is Not Null Then 
			v_Error:=v_Error||Chr(10)||v_Message; 
		End If; 
	End IF; 
 
	If v_NewVer>='10.16.0' Then 
		v_Message:=Null; 
		Select 
			Decode(Count(*),2,Null,'●升级到ZLHIS 10.16.0及以上版本，请先创建 ZL9IndexHIS、ZL9IndexCIS 表空间，初始尺寸至少100M') 
		Into v_Message 
		From User_TableSpaces 
		Where Upper(TableSpace_Name) In ('ZL9INDEXHIS', 'ZL9INDEXCIS') And Status = 'ONLINE'; 
		If v_Message is Not Null Then 
			v_Error:=v_Error||Chr(10)||v_Message; 
		End If; 
	End IF; 
 
--	If v_NewVer>='10.18.0' Then 
--		v_Message:=Null; 
--		Select 
--			Decode(Count(*),1,Null,'●升级到ZLHIS 10.18.0及以上版本，请先创建 zl9PeisData 表空间，初始尺寸至少50M') 
--		Into v_Message 
--		From User_TableSpaces 
--		Where Upper(TableSpace_Name) In ('ZL9PEISDATA') And Status = 'ONLINE'; 
--		If v_Message is Not Null Then 
--			v_Error:=v_Error||Chr(10)||v_Message; 
--		End If; 
--	End IF; 
 
	If v_NewVer>='10.21.0' Then 
		v_Message:=Null; 
		Select 
			Decode(Count(*),1,Null,'●升级到ZLHIS 10.21.0及以上版本，请先创建 zl9CISAudit 表空间，初始尺寸至少50M') 
		Into v_Message 
		From User_TableSpaces 
		Where Upper(TableSpace_Name) In ('ZL9CISAUDIT') And Status = 'ONLINE'; 
		If v_Message is Not Null Then 
			v_Error:=v_Error||Chr(10)||v_Message; 
		End If; 
	End IF; 
 
	--整理返回信息 
	If v_Error Is Not Null Then 
		v_Error:= Substr(v_Error, 2); 
	End If; 
	Return v_Error; 
Exception 
	When Others Then 
		v_Error:=v_Error||Chr(10)||'应用系统升级检查失败。'; 
		If v_Error Is Not Null Then 
			v_Error:=Substr(v_Error, 2); 
		End If; 
		Return v_Error; 
End;
/

