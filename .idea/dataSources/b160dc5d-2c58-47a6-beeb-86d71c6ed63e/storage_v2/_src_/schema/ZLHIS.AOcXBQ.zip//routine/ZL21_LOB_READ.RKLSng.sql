create Function Zl21_Lob_Read 
( 
  Tab_In In Number, 
  Key_In In Varchar2, 
  Pos_In In Number 
  --参数说明： 
  --Tab_In：包含LOB的数据表 
  --        1-体质类型调养;2-体检体辨结论;3-体检申报记录;4-体检任务人员;5-体检任务结果 
  --Key_In：数据记录的关键字 
  --Pos_In：从0开始不断读取，直到返回为空 
  --Moved_In: 0正常记录,1读取转储后备表记录 
) Return Varchar2 Is 
  a_Key    t_Strlist := t_Strlist(); 
  l_Blob   Blob; 
  v_Buffer Varchar2(32767); 
  n_Amount Number := 2000; 
  n_Offset Number := 1; 
 
  Function Getsplitstring 
  ( 
    Str_In      In Varchar2, 
    p_Separator Varchar2 
  ) Return t_Strlist As 
 
    v_Str   Long Default Str_In || p_Separator; 
    v_Index Number; 
    v_List  t_Strlist := t_Strlist(); 
 
  Begin 
    Loop 
      v_Index := Instr(v_Str, p_Separator); 
      Exit When(Nvl(v_Index, 0) = 0); 
      v_List.Extend; 
      v_List(v_List.Count) := Trim(Substr(v_Str, 1, v_Index - 1)); 
      v_Str := Substr(v_Str, v_Index + 1); 
    End Loop; 
    Return v_List; 
  End; 
 
Begin 
  If Tab_In = 1 Then 
    a_Key := Getsplitstring(Key_In, ''''); 
    Select 图形内容 
    Into l_Blob 
    From 体质类型调养 
    Where 体质类型id = To_Number(a_Key(1)) And 调养类型 = a_Key(2) And 记录序号 = To_Number(a_Key(3)) And 图形内容 Is Not Null; 
  Elsif Tab_In = 2 Then 
    a_Key := Getsplitstring(Key_In, ''''); 
    Select 图形内容 
    Into l_Blob 
    From 体检体辨结论 
    Where ID = To_Number(a_Key(1)) And 体质类型id = To_Number(a_Key(2)) And 调养类型 = a_Key(3) And 记录序号 = To_Number(a_Key(4)) And 
          图形内容 Is Not Null; 
  Elsif Tab_In = 3 Then 
    a_Key := Getsplitstring(Key_In, ''''); 
    Select 生产工艺 Into l_Blob From 体检申报记录 Where ID = To_Number(a_Key(1)) And 生产工艺 Is Not Null; 
  Elsif Tab_In = 4 Then 
    a_Key := Getsplitstring(Key_In, ''''); 
    Select 照片 
    Into l_Blob 
    From 体检任务人员 
    Where 任务id = To_Number(a_Key(1)) And 病人id = To_Number(a_Key(2)) And 照片 Is Not Null; 
   Elsif Tab_In = 5 Then 
    a_Key := Getsplitstring(Key_In, ','); 
    Select 图形 
    Into l_Blob 
    From 体检任务结果 
    Where 任务id = To_Number(a_Key(1)) And 病人id = To_Number(a_Key(2)) And 清单id = To_Number(a_Key(3)) And 体检指标id = To_Number(a_Key(4)) And 图形 Is Not Null; 
  End If; 
 
  n_Offset := n_Offset + Pos_In * n_Amount; 
  Dbms_Lob.Read(l_Blob, n_Amount, n_Offset, v_Buffer); 
  Return v_Buffer; 
Exception 
  When No_Data_Found Then 
    Return Null; 
End Zl21_Lob_Read;
/

