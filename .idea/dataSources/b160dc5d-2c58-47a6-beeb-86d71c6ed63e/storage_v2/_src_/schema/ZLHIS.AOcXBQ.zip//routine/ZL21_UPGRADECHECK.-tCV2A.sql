create Function Zl21_UpgradeCheck( 
	v_CurVer In Varchar2, 
	v_NewVer In Varchar2 
) Return Varchar2 Is 
	v_Error   Varchar2(2000); 
	v_Message Varchar2(500); 
Begin 
	--检查表空间是否满足需要 
	Select 
		Decode(Count(*),1,Null,'请先创建 zl9PeisData 表空间') 
	Into v_Message 
	From User_TableSpaces 
	Where TableSpace_Name In ('ZL9PEISDATA') 
		And Status = 'ONLINE'; 
	If v_Message IS Not Null Then 
		v_Error:=v_Error||Chr(10)||v_Message; 
	End If; 
	 
	--整理返回信息 
	If v_Error Is Not Null Then 
		v_Error:= Substr(v_Error, 2); 
	End If; 
	Return v_Error; 
Exception 
	When Others Then 
		v_Error:=v_Error||Chr(10)||'应用系统升级检查失败。'; 
		If v_Error Is Not Null Then 
			v_Error:=Substr(v_Error, 2); 
		End If; 
		Return v_Error; 
End;
/

