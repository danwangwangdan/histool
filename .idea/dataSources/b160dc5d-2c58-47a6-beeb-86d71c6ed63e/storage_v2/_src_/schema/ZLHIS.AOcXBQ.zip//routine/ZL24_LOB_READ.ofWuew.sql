create Function zl24_Lob_Read 
( 
  Key_In   In Varchar2, 
  Pos_In   In Number 
) Return Varchar2 Is 
  l_Blob   Blob; 
  v_Buffer Varchar2(32767); 
  n_Amount Number := 2000; 
  n_Offset Number := 1; 
Begin 
 
  Begin 
	Select 图形 Into l_Blob From 手麻常用图形 Where 序号 = To_Number(Key_In); 
  Exception 
	When Others Then l_Blob:=Null; 
  End; 
  If l_Blob Is Not Null Then 
	n_Offset := n_Offset + Pos_In * n_Amount; 
	Dbms_Lob.Read(l_Blob, n_Amount, n_Offset, v_Buffer); 
  End If; 
 
  Return v_Buffer; 
Exception 
  When No_Data_Found Then 
    Return Null; 
End zl24_Lob_Read;
/

