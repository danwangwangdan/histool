create Function Zl24_Replace_Element_Value 
( 
  元素名_In   In 诊治所见项目.中文名%Type, 
  病人id_In   In 电子病历记录.病人id%Type, 
  就诊id_In   In 电子病历记录.主页id%Type, 
  病人来源_In In 电子病历记录.病人来源%Type, 
  医嘱id_In   In 病人医嘱记录.ID%Type := Null 
) Return Varchar2 Is 
  v_Return  Varchar2(4000) := Null; 
 
  Cursor c_Pati Is 
    Select 姓名, 性别, 年龄, 职业, 民族, 国籍, 婚姻状况, 出生日期, 出生地点, 身份证号, 身份, 学历, 家庭地址, 家庭电话, 工作单位, 单位电话, 门诊号, 住院次数, 联系人姓名, 
           联系人关系, 联系人地址, 联系人电话 
    From 病人信息 
    Where 病人id = 病人id_In; 
  r_Patient c_Pati%RowType; 
 
  Cursor c_Reg Is 
    Select 摘要, 登记时间, 急诊, 执行部门id 
    From 病人挂号记录 
    Where 病人id + 0 = 病人id_In And ID = 就诊id_In And 记录性质=1 And 记录状态=1; 
  r_Regist c_Reg%RowType; 
 
  Cursor c_Inpage Is 
    Select 年龄, 住院号, 入院日期, 出院日期, 住院目的, 入院科室id, 入院病区id, 出院病床, 当前病区id, 当前病况, 住院医师, 责任护士, 二级院转入, 入院方式, 护理等级id, 
           出院方式, 入院病床, 联系人姓名, 联系人关系, 联系人地址, 联系人电话, 出院科室id 
    From 病案主页 
    Where 病人id = 病人id_In And 主页id = 就诊id_In; 
  r_Inpage c_Inpage%RowType; 
 
  Cursor c_Order Is 
    Select ID,婴儿, 紧急标志, 开嘱科室id, 开嘱医生, 开嘱时间, 执行科室id, 开始执行时间, 医生嘱托, 诊疗类别, 诊疗项目id, 标本部位, 检查方法 
    From 病人医嘱记录 
    Where 病人id + 0 = 病人id_In And ID = 医嘱id_In; 
  r_Order c_Order%RowType; 
 
  v_Subtype 诊疗项目目录.操作类型%Type := Null; 
 
  Type t_Str_Table Is Table Of Varchar2(2000); 
  a_Return t_Str_Table := t_Str_Table(); 
 
  n_主页id 病案主页.主页id%Type; 
  n_Times  Number; 
 
  --获取指定表的行类型 
  Procedure p_Get_Rowtype(Table_In In Varchar2) Is 
  Begin 
    If Table_In = '病人信息' Then 
      Open c_Pati; 
      Fetch c_Pati 
        Into r_Patient; 
    Elsif Table_In = '病人挂号记录' Then 
      Open c_Reg; 
      Fetch c_Reg 
        Into r_Regist; 
    Elsif Table_In = '病案主页' Then 
      Open c_Inpage; 
      Fetch c_Inpage 
        Into r_Inpage; 
    Elsif Table_In = '病人医嘱记录' Then 
      Open c_Order; 
      Fetch c_Order 
        Into r_Order; 
    End If; 
  Exception 
    When Others Then 
      Null; 
  End p_Get_Rowtype; 
	 
Begin 
  --p_Get_Rowtype('病人信息'); 
  --p_Get_Rowtype('病人挂号记录'); 
  --p_Get_Rowtype('病案主页'); 
  p_Get_Rowtype('病人医嘱记录'); 
  If 元素名_In = '拟施手术时间' Then 
	v_Return:=To_Char(r_Order.开始执行时间, 'yyyy-mm-dd'); 
  ElsIf 元素名_In = '拟施麻醉方式' Then	 
    Select Max(医嘱内容) Into v_Return From 病人医嘱记录 Where 相关id=r_Order.ID And 诊疗类别='G' And RowNum<2; 
  ElsIf 元素名_In = '手术开始时间' Then 
    Select To_Char(Max(开始时间), 'yyyy-mm-dd hh24:mi') Into v_Return From 病人手麻主页 Where 申请id = r_Order.ID; 
  Elsif 元素名_In = '手术结束时间' Then 
    Select To_Char(Max(结束时间), 'yyyy-mm-dd hh24:mi') Into v_Return From 病人手麻主页 Where 申请id = r_Order.ID; 
  Elsif 元素名_In = '手术规模' Then 
    Select 手术规模 Into v_Return From 病人手麻主页 Where 申请id = r_Order.ID And Rownum < 2; 
  Elsif 元素名_In = '手术执行间' Then 
    Select 手术间号 Into v_Return From 病人手麻主页 Where 申请id = r_Order.ID And Rownum < 2; 
  Elsif 元素名_In = '麻醉开始时间' Then 
    Select To_Char(Max(麻醉开始), 'yyyy-mm-dd hh24:mi') Into v_Return From 病人手麻主页 Where 申请id = r_Order.ID; 
  Elsif 元素名_In = '麻醉结束时间' Then 
    Select To_Char(Max(麻醉结束), 'yyyy-mm-dd hh24:mi') Into v_Return From 病人手麻主页 Where 申请id = r_Order.ID; 
  Elsif 元素名_In = '手术麻醉方式' Then 
    Select c.名称 Into v_Return From 病人手麻主页 a,病人手麻麻醉 b,诊疗项目目录 c Where a.申请id = r_Order.ID And a.ID=b.手麻主页id And b.诊疗项目id=c.ID And Rownum < 2; 
  Elsif 元素名_In = '手术麻醉质量' Then 
    Select 麻醉质量 Into v_Return From 病人手麻主页 Where 申请id = r_Order.ID And Rownum < 2; 
  Elsif 元素名_In = '输氧开始时间' Then 
    Select To_Char(Max(输氧开始), 'yyyy-mm-dd hh24:mi') Into v_Return From 病人手麻主页 Where 申请id = r_Order.ID; 
  Elsif 元素名_In = '输氧结束时间' Then 
    Select To_Char(Max(输氧结束), 'yyyy-mm-dd hh24:mi') Into v_Return From 病人手麻主页 Where 申请id = r_Order.ID; 
  Elsif 元素名_In = '主刀医生' Then 
    If 医嘱id_In Is Null Then 
      Begin 
        Select B.姓名 
        Into v_Return 
        From 上机人员表 A, 人员表 B, 人员性质说明 C 
        Where Upper(A.用户名) = User And A.人员id = B.ID And B.ID = C.人员id And C.人员性质 = '医生'; 
      Exception 
        When Others Then 
          v_Return := ''; 
      End; 
    Else 
 
	Select A.姓名 Bulk Collect 
	Into a_Return 
	From 病人手麻人员 A, 病人手麻主页 B 
	Where B.申请id = r_Order.ID And A.手麻主页id = B.ID And a.期间=2 And A.岗位  In ('主刀医生'); 
	For n_Count In 1 .. a_Return.Count Loop 
		v_Return := v_Return || ' ' || a_Return(n_Count); 
	End Loop; 
	v_Return := Trim(v_Return); 
    End If; 
 
  Elsif 元素名_In = '助手医生' Then 
    Select A.姓名 Bulk Collect 
    Into a_Return 
    From 病人手麻人员 A, 病人手麻主页 B 
    Where B.申请id = r_Order.ID And A.手麻主页id = B.ID And a.期间=2 And A.岗位  In ('助手医生','一助医生','二助医生'); 
    For n_Count In 1 .. a_Return.Count Loop 
      v_Return := v_Return || ' ' || a_Return(n_Count); 
    End Loop; 
    v_Return := Trim(v_Return); 
  Elsif 元素名_In = '麻醉医生' Then 
    Select A.姓名 Bulk Collect 
    Into a_Return 
    From 病人手麻人员 A, 病人手麻主页 B 
    Where B.申请id = r_Order.ID And A.手麻主页id = B.ID And a.期间=2 And A.岗位 In ('麻醉医生','主麻医生'); 
    For n_Count In 1 .. a_Return.Count Loop 
      v_Return := v_Return || ' ' || a_Return(n_Count); 
    End Loop; 
    v_Return := Trim(v_Return); 
  Elsif 元素名_In = '洗手护士' Then 
    Select A.姓名 Bulk Collect 
    Into a_Return 
    From 病人手麻人员 A, 病人手麻主页 B 
    Where B.申请id = r_Order.ID And A.手麻主页id = B.ID And a.期间=2 And A.岗位 = '洗手护士'; 
    For n_Count In 1 .. a_Return.Count Loop 
      v_Return := v_Return || ' ' || a_Return(n_Count); 
    End Loop; 
    v_Return := Trim(v_Return); 
  Elsif 元素名_In = '巡回护士' Then 
    Select A.姓名 Bulk Collect 
    Into a_Return 
    From 病人手麻人员 A, 病人手麻主页 B 
    Where B.申请id = r_Order.ID And A.手麻主页id = B.ID And a.期间=2 And A.岗位 = '巡回护士'; 
    For n_Count In 1 .. a_Return.Count Loop 
      v_Return := v_Return || ' ' || a_Return(n_Count); 
    End Loop; 
    v_Return := Trim(v_Return); 
  Elsif 元素名_In = '其他手术人员' Then 
    Select A.姓名 Bulk Collect 
    Into a_Return 
    From 病人手麻人员 A, 病人手麻主页 B 
    Where B.申请id = r_Order.ID And A.手麻主页id = B.ID And a.期间=2 And A.岗位 Not In ('主刀医生', '助手医生','一助医生','二助医生', '麻醉医生','主麻医生', '洗手护士', '巡回护士'); 
    For n_Count In 1 .. a_Return.Count Loop 
      v_Return := v_Return || ' ' || a_Return(n_Count); 
    End Loop; 
    v_Return := Trim(v_Return); 
  Elsif 元素名_In = '拟行主手术' Then 
    Select A.手术名称 Bulk Collect 
    Into a_Return 
    From 病人手麻手术 A, 病人手麻主页 B 
    Where B.申请id = r_Order.ID And A.手麻主页id = B.ID And A.记录性质 = 1 And Nvl(A.主手术, 0) = 1; 
    For n_Count In 1 .. a_Return.Count Loop 
      v_Return := v_Return || ' ' || a_Return(n_Count); 
    End Loop; 
    v_Return := Trim(v_Return); 
  Elsif 元素名_In = '拟行附手术' Then 
    Select A.手术名称 Bulk Collect 
    Into a_Return 
    From 病人手麻手术 A, 病人手麻主页 B 
    Where B.申请id = r_Order.ID And A.手麻主页id = B.ID And A.记录性质 = 1 And Nvl(A.主手术, 0) = 0; 
    For n_Count In 1 .. a_Return.Count Loop 
      v_Return := v_Return || ' ' || a_Return(n_Count); 
    End Loop; 
    v_Return := Trim(v_Return); 
  Elsif 元素名_In = '已行主手术' Then 
    Select A.手术名称 Bulk Collect 
    Into a_Return 
    From 病人手麻手术 A, 病人手麻主页 B 
    Where B.申请id = r_Order.ID And A.手麻主页id = B.ID And A.记录性质 = 2 And Nvl(A.主手术, 0) = 1; 
    For n_Count In 1 .. a_Return.Count Loop 
      v_Return := v_Return || ' ' || a_Return(n_Count); 
    End Loop; 
    v_Return := Trim(v_Return); 
  Elsif 元素名_In = '已行附手术' Then 
    Select A.手术名称 Bulk Collect 
    Into a_Return 
    From 病人手麻手术 A, 病人手麻主页 B 
    Where B.申请id = r_Order.ID And A.手麻主页id = B.ID And A.记录性质 = 2 And Nvl(A.主手术, 0) = 0; 
    For n_Count In 1 .. a_Return.Count Loop 
      v_Return := v_Return || ' ' || a_Return(n_Count); 
    End Loop; 
    v_Return := Trim(v_Return); 
  Elsif 元素名_In = '术前主诊断' Then 
    Select A.诊断描述 Bulk Collect 
    Into a_Return 
    From 病人诊断记录 A 
    Where A.医嘱id = r_Order.ID And A.诊断类型 = 8 And Nvl(A.诊断次序, 0) = 1; 
    For n_Count In 1 .. a_Return.Count Loop 
      v_Return := v_Return || ' ' || a_Return(n_Count); 
    End Loop; 
    v_Return := Trim(v_Return); 
  Elsif 元素名_In = '术前次诊断' Then 
    Select 诊断描述 Bulk Collect 
    Into a_Return 
    From (Select A.诊断描述 
           From 病人诊断记录 A 
           Where A.医嘱id = r_Order.ID And A.诊断类型 = 8 And Nvl(A.诊断次序, 0) > 1 
           Order By A.诊断次序); 
    For n_Count In 1 .. a_Return.Count Loop 
      v_Return := v_Return || ' ' || a_Return(n_Count); 
    End Loop; 
    v_Return := Trim(v_Return); 
  Elsif 元素名_In = '术后主诊断' Then 
    Select A.诊断描述 Bulk Collect 
    Into a_Return 
    From 病人诊断记录 A 
    Where A.医嘱id = r_Order.ID And A.诊断类型 = 9 And Nvl(A.诊断次序, 0) = 1; 
    For n_Count In 1 .. a_Return.Count Loop 
      v_Return := v_Return || ' ' || a_Return(n_Count); 
    End Loop; 
    v_Return := Trim(v_Return); 
  Elsif 元素名_In = '术后次诊断' Then 
    Select 诊断描述 Bulk Collect 
    Into a_Return 
    From (Select A.诊断描述 
           From 病人诊断记录 A 
           Where A.医嘱id = r_Order.ID And A.诊断类型 = 9 And Nvl(A.诊断次序, 0) > 1 
           Order By A.诊断次序); 
    For n_Count In 1 .. a_Return.Count Loop 
      v_Return := v_Return || ' ' || a_Return(n_Count); 
    End Loop; 
    v_Return := Trim(v_Return); 
  End If; 
 
  Return Trim(v_Return); 
 
Exception 
  When Others Then 
    Return Null; 
End Zl24_Replace_Element_Value;
/

