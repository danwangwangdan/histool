create Function Zl3_Get护理天数 
( 
  病人id_In   病案主页.病人id%Type, 
  主页id_In   病案主页.主页id%Type, 
  项目名称_In Varchar2 
) Return Varchar2 Is 
  N_护理id 病人变动记录.护理等级id%Type; 
  N_天数   Number(18); 
  V_Sql    Varchar2(200); 
  V_名称   Varchar2(200); 
  V_名称1  Varchar2(200); 
  V_Return Varchar2(500); 
Begin 
  For Rs In (Select Column_Value 项目 From Table(Cast(F_Str2list(项目名称_In) As Zltools.T_Strlist))) Loop 
    N_天数 := 0; 
    If Not Rs.项目 Is Null Then 
      --需要将I或一或规换成统一的查找 
      If Rs.项目 = '一级护理' Then 
        V_名称  := Replace(Rs.项目, '一', 'I'); 
        V_名称1 := Replace(Rs.项目, '一', 'Ⅰ'); 
      Elsif Rs.项目 = '二级护理' Then 
        V_名称  := Replace(Rs.项目, '二', 'II'); 
        V_名称1 := Replace(Rs.项目, '二', 'Ⅱ'); 
      Elsif Rs.项目 = '三级护理' Then 
        V_名称  := Replace(Rs.项目, '三', 'III'); 
        V_名称1 := Replace(Rs.项目, '三', 'Ⅲ'); 
      Elsif Rs.项目 = 'CCU' Then 
        V_名称  := 'ccu'; 
        V_名称1 := 'Ccu'; 
      Elsif Rs.项目 = 'Icu' Then 
        V_名称  := 'Icu '; 
        V_名称1 := 'Icu'; 
      End If; 
      Begin 
        V_Sql := ' Select ID From 收费项目目录 Where(名称 = :1 Or 名称 = :2 Or 名称 = :3) And Rownum = 1 '; --动态SQL 
        Execute Immediate V_Sql 
          Into N_护理id 
          Using Rs.项目, V_名称, V_名称1; 
      Exception 
        When Others Then 
          N_护理id := 0; 
      End; 
 
      If N_护理id <= 0 Then 
        N_天数 := 0; 
      Else 
        Select Sum(终止时间 - 开始时间) 
        Into N_天数 
        From (Select Distinct 护理等级id, Trunc(开始时间) As 开始时间, Trunc(Decode(终止原因, 1, 1, 0) + 终止时间) As 终止时间 
               From 病人变动记录 
               Where 病人id = 病人id_In And 主页id = 主页id_In And 护理等级id = N_护理id); 
      End If; 
    End If; 
    V_Return := V_Return || '|' || N_天数; 
  End Loop; 
  If V_Return Is Not Null Then 
    V_Return := Substr(V_Return, 2); 
  End If; 
  Return V_Return; 
Exception 
  When Others Then 
    Return Null; 
End Zl3_Get护理天数;
/

