create Function zl3_GetSysParameter 
( 
  参数_In zlParameters.参数名%Type, 
  模块_In zlParameters.模块%Type := Null, 
  系统_In zlParameters.系统%Type := 3 
  --功能：获取当前系统中指定参数的参数值 
  ----本函数主要供其他过程调用，因zlParameters是公共表，程序中使用公共部件的公共函数 
  ----调用时注意,如果参数值为空或没有该参数,则返回空 
  --参数： 
  ----参数_In：必须传入非Null值，以字符形式传入的参数号或参数名,注意参数名不能为数字。 
  ----系统_IN：非标准版系统需要传入系统号，注意是示扩展的系统号，如1，而不是100。无系统传入Null 
) Return Varchar2 As 
  v_系统		zlParameters.系统%Type; 
	v_私有		zlParameters.私有%Type; 
	v_本机		zlParameters.本机%Type; 
 
	v_参数ID	zlUserParas.参数ID%Type; 
	v_机器名	zlUserParas.机器名%Type; 
	v_参数值	zlParameters.参数值%Type; 
Begin 
  --确定系统,可能没有系统(如私有全局) 
	If 系统_In Is Not Null Then 
		Select 编号 Into v_系统 From zlSystems 
		Where Trunc(编号 / 100) = 系统_In And 所有者 = (Select UserName From All_Users Where User_Id = Userenv('SchemaID')); 
	End If; 
	 
	--读取参数信息 
	Begin 
		If Zl_To_Number(参数_In) <> 0 Then 
			Select ID,Nvl(参数值, 缺省值),私有,本机,SYS_CONTEXT('USERENV','TERMINAL') 
				Into v_参数ID,v_参数值,v_私有,v_本机,v_机器名 
			From zlParameters 
			Where 参数号 = Zl_To_Number(参数_In) And Nvl(模块, 0) = Nvl(模块_In, 0) And Nvl(系统,0) = Nvl(v_系统,0); 
		Else 
			Select ID,Nvl(参数值, 缺省值),私有,本机,SYS_CONTEXT('USERENV','TERMINAL') 
				Into v_参数ID,v_参数值,v_私有,v_本机,v_机器名 
			From zlParameters 
			Where 参数名 = 参数_In And Nvl(模块, 0) = Nvl(模块_In, 0) And Nvl(系统,0) = Nvl(v_系统,0); 
		End If; 
	Exception 
		When Others Then Return Null; 
	End; 
	 
	--读取参数值 
	If Nvl(v_私有,0)=1 Or Nvl(v_本机,0)=1 Then 
		Begin 
			Select Nvl(参数值,v_参数值) Into v_参数值 From zlUserParas 
			Where 参数ID=v_参数ID And (用户名=User Or Nvl(v_私有,0)=0) And (机器名=v_机器名 Or Nvl(v_本机,0)=0); 
		Exception 
			When Others Then Return v_参数值; 
		End; 
	End IF; 
	 
	Return v_参数值; 
End zl3_GetSysParameter;
/

