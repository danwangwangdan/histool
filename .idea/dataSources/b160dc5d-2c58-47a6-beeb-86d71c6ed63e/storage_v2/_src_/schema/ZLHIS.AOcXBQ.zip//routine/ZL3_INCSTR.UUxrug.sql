create Function Zl3_Incstr(v_String Varchar2) Return Varchar2 Is 
  I          Number(18); 
  v_Tmp      Varchar2(400); 
  v_Input    Varchar2(4000); 
  n_Up       Number(3); 
  n_Add      Number(3); 
  n_Isnumber Number(2); 
  n_Number   Number(20); 
Begin 
  --功能：对一个字符串自动加1。 
  --说明：每一位进位时,如果是数字,则按十进制处理,否则按26进制处理 
  --参数：v_String=要加1的字符串 
  v_Input := v_String; 
  I       := Length(v_Input); 
  n_Up    := 0; 
  While I > 0 Loop 
    If I = Length(v_Input) Then 
      n_Add := 1; 
    Else 
      n_Add := 0; 
    End If; 
    Begin 
      Select To_Number(Substr(v_Input, I, 1)) Into n_Number From Dual; 
      n_Isnumber := 1; 
    Exception 
      When Others Then 
        n_Isnumber := 0; 
    End; 
    If n_Isnumber = 1 Then 
      If To_Number(Substr(v_Input, I, 1)) + n_Add + n_Up < 10 Then 
        v_Tmp := Substr(v_Input, 1, I - 1) || ltrim(rtrim(to_char(To_Number(Substr(v_Input, I, 1)) + n_Add + n_Up))) || Substr(v_Input, I + 1); 
        Return v_Tmp; 
        n_Up := 0; 
      Else 
        v_Input := Substr(v_Input, 1, I - 1) || '0' || Substr(v_Input, I + 1); 
        n_Up    := 1; 
      End If; 
    Else 
      If Ascii(Substr(v_Input, I, 1)) + n_Add + n_Up <= Ascii('Z') Then 
        v_Input := Substr(v_Input, 1, I - 1) || Chr(Ascii(Substr(v_Input, I, 1)) + n_Add + n_Up) || 
                   Substr(v_Input, I + 1); 
        n_Up    := 0; 
        Return v_Input; 
      Else 
        v_Input := Substr(v_Input, 1, I - 1) || '0' || Substr(v_Input, I + 1); 
        n_Up    := 1; 
      End If; 
    End If; 
    If n_Up = 0 Then 
      Return v_Input; 
    End If; 
    I := I - 1; 
  End Loop; 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
    Return v_Input; 
End;
/

