create Function Zl3_Isnumber(v_String Varchar2) Return Number Is 
  n_Number Number(2); 
  n_Up     Number(18); 
  n_Count  Number(20); 
Begin 
  --功能：判断一个字符串是否是数字。 
  --参数：v_String=要判断的字符串 
  If v_String Is Null Then 
    Return 0; 
  End If; 
  n_Count := Length(v_String); 
  For n_Up In 1 .. n_Count Loop 
    Begin 
      --如果数字，就直接加数(如果含有字符，利用异常判断出是否为全数字 
      n_Number := To_Number(Substr(v_String, n_Up, 1)); 
    Exception 
      When Others Then 
        Return 0; 
    End; 
  End Loop; 
  Return 1; 
Exception 
  When Others Then 
    Return 0; 
End Zl3_Isnumber;
/

