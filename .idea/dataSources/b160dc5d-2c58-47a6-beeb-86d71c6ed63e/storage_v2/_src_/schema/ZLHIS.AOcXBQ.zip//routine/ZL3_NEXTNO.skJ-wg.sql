create Function Zl3_Nextno 
( 
  序号_In In 号码控制表.项目序号%Type, 
  判断_In In Number := Null, 
  编码_In In 部门表.编码%Type := Null 
) Return Varchar2 
--    功能：根据特定规则产生新的号码,规则如下： 
  --    一、项目序号： 
  --       1   病人ID         数字 
  --       2   住院号         数字 
  --       4   病案号         数字 
  --    二、年度位确定原则： 
  --       以1990为基数，随年度增长，按“0～9/A～Z”顺序作为年度编码 
  -- 
  --    说明：最大号码-10存入号码控制表,用于并发情况下补缺号(取了号,但未使用) 
  --          For Update在并发情况下锁定行,不用Wait选项以避免向调用者返回空 
  --    返回：最大号码 
 Is 
  Pragma Autonomous_Transaction; 
  v_No        号码控制表.最大号码%Type; 
  v_Maxno     号码控制表.最大号码%Type; 
  n_Maxno     Number; 
  v_Preno     号码控制表.最大号码%Type; 
  n_Mod       号码控制表.编号规则%Type; 
  v_Tmp       Varchar2(10); 
  v_Site_No   Varchar2(1); 
  v_Code      Varchar2(20); 
  n_Codelenth Number; 
 
  v_Error Varchar2(255); 
  Err_Custom Exception; 
Begin 
  v_Site_No := f_Get_Node_No; 
 
  --1.病人ID 
  If 序号_In = 1 Then 
    Select Nvl(编号规则, 0) Into n_Mod From 号码控制表 Where 项目序号 = 序号_In; 
 
    --从序列取值，用于不要求病人ID必须连续的用户减少并发争用 
    If n_Mod = 1 Then 
      Select 病人信息_Id.Nextval Into v_No From Dual; 
    Else 
      Select Nvl(最大号码, '0') Into v_Maxno From 号码控制表 Where 项目序号 = 序号_In For Update; 
      If v_Site_No Is Null Then 
        Select Nvl(Max(病人id), 0) + 1 Into n_Maxno From 病人信息 Where 病人id >= To_Number(v_Maxno); 
      Else 
        Select Trunc(Nvl(Max(病人id), 0) / 10) + 1 
        Into n_Maxno 
        From 病人信息 
        Where 病人id >= To_Number(v_Maxno) * 10 And Mod(病人id, 10) = To_Number(v_Site_No); 
      End If; 
      Update 号码控制表 Set 最大号码 = Decode(Sign(n_Maxno - 10), 1, n_Maxno - 10, 1) Where 项目序号 = 序号_In; 
      v_No := To_Char(n_Maxno) || v_Site_No; 
    End If; 
    --2.住院号 
  Elsif 序号_In = 2 Then 
    Select Nvl(最大号码, '0'), Nvl(编号规则, 0) 
    Into v_Maxno, n_Mod 
    From 号码控制表 
    Where 项目序号 = 序号_In 
    For Update; 
 
    If n_Mod = 0 Then 
      --0.顺序编号 
      If v_Site_No Is Null Then 
        Select Nvl(Max(住院号), 0) + 1 Into n_Maxno From 病案主页 Where 住院号 >= To_Number(v_Maxno); 
      Else 
        Select Trunc(Nvl(Max(住院号), 0) / 10) + 1 
        Into n_Maxno 
        From 病案主页 
        Where 住院号 >= To_Number(v_Maxno) * 10 And Mod(住院号, 10) = To_Number(v_Site_No); 
      End If; 
 
      Update 号码控制表 Set 最大号码 = Decode(Sign(n_Maxno - 10), 1, n_Maxno - 10, 1) Where 项目序号 = 序号_In; 
    Elsif n_Mod = 1 Then 
      --1.年月(YYMM)+顺序号(0000) 
      v_Tmp := To_Char(Sysdate, 'YYMM'); 
      If v_Site_No Is Null Then 
        Select Nvl(Max(住院号), To_Number(v_Tmp || '0000')) + 1 
        Into n_Maxno 
        From 病案主页 
        Where 住院号 Like To_Number(v_Tmp) || '%' And 住院号 >= To_Number(v_Maxno); 
      Else 
        Select Trunc(Nvl(Max(住院号), To_Number(v_Tmp || '0000')) / 10) + 1 
        Into n_Maxno 
        From 病案主页 
        Where 住院号 Like To_Number(v_Tmp) || '%' And 住院号 >= To_Number(v_Maxno) * 10 And 
              Mod(住院号, 10) = To_Number(v_Site_No); 
      End If; 
 
      Update 号码控制表 
      Set 最大号码 = Decode(Sign(n_Maxno - 10 - To_Number(v_Tmp || '0000')), 1, n_Maxno - 10, To_Number(v_Tmp || '0001')) 
      Where 项目序号 = 序号_In; 
    Elsif n_Mod = 2 Then 
      --2.年(YYYY)+顺序号(00000) 
      v_Tmp := To_Char(Sysdate, 'YYYY'); 
      If v_Site_No Is Null Then 
        Select Nvl(Max(住院号), To_Number(v_Tmp || '00000')) + 1 
        Into n_Maxno 
        From 病案主页 
        Where 住院号 Like To_Number(v_Tmp) || '%' And 住院号 >= To_Number(v_Maxno); 
      Else 
        Select Trunc(Nvl(Max(住院号), To_Number(v_Tmp || '00000')) / 10) + 1 
        Into n_Maxno 
        From 病案主页 
        Where 住院号 Like To_Number(v_Tmp) || '%' And 住院号 >= To_Number(v_Maxno) * 10 And 
              Mod(住院号, 10) = To_Number(v_Site_No); 
      End If; 
 
      Update 号码控制表 
      Set 最大号码 = Decode(Sign(n_Maxno - 10 - To_Number(v_Tmp || '00000')), 1, n_Maxno - 10, To_Number(v_Tmp || '00001')) 
      Where 项目序号 = 序号_In; 
    End If; 
    v_No := To_Char(n_Maxno) || v_Site_No; 
 
    --4.病案号 
  Elsif 序号_In = 4 Then 
    Select Nvl(最大号码, '0'), Nvl(编号规则, 0) 
    Into v_Maxno, n_Mod 
    From 号码控制表 
    Where 项目序号 = 序号_In 
    For Update; 
 
    If 判断_In = 1 And n_Mod <> 0 Then 
      v_No := ' '; 
      Return v_No; 
    End If; 
 
    If n_Mod = 0 Then 
      --0.顺序编号 
      If v_Site_No Is Null Then 
        --Select Nvl(Max(病案号), '') Into v_Maxno From 住院病案记录 Where 病案号 >= v_Maxno; 
        If Zl3_Isnumber(Nvl(v_Maxno, '0')) = 0 Then 
          --是字符,需处理字符加1 
          v_Maxno := Zl3_Incstr(v_Maxno); 
        Else 
          v_Maxno := To_Char(To_Number(Nvl(v_Maxno, '0') + 1)); 
          v_Maxno := Ltrim(Rtrim(v_Maxno)); 
        End If; 
        If 判断_In = 1 Then 
          Update 号码控制表 Set 最大号码 = v_Maxno Where 项目序号 = 序号_In; 
        End If; 
      Else 
        --第1位为:站点号,后面为顺序号+1 
        --Select Nvl(Max(病案号), '') 
        --Into v_Maxno 
        --From 住院病案记录 
        --Where 病案号 >= v_Maxno And 病案号 Like v_Site_No || '%'; 
 
        v_Maxno := Substr(Nvl(v_Maxno, '0'), 2); 
 
        If Zl3_Isnumber(Nvl(v_Maxno, '0')) = 0 Then 
          --是字符,需处理字符加1 
          v_Maxno := Zl3_Incstr(v_Maxno); 
        Else 
          v_Maxno := To_Char(To_Number(Nvl(v_Maxno, '0') + 1)); 
          v_Maxno := Ltrim(Rtrim(v_Maxno)); 
        End If; 
        v_Maxno := v_Site_No || v_Maxno; 
        If 判断_In = 1 Then 
          Update 号码控制表 Set 最大号码 = v_Maxno Where 项目序号 = 序号_In; 
        End If; 
      End If; 
      v_No := v_Maxno; 
    Elsif n_Mod = 1 Then 
      --1.年月(YYMM)+顺序号(00000) 
      v_Tmp := To_Char(Sysdate, 'YYMM'); 
      If v_Site_No Is Null Then 
        Select Nvl(Max(病案号), To_Number(v_Tmp || '00000')) 
        Into v_Maxno 
        From 住院病案记录 
        Where 病案号 Like v_Tmp || '%' And 病案号 >= v_Maxno; 
        v_Maxno := Substr(v_Maxno, 5); 
        If Zl3_Isnumber(Nvl(v_Maxno, '0')) = 0 Then 
          --是字符,需处理字符加1 
          v_Preno := v_Tmp || v_Maxno; 
          v_Maxno := v_Tmp || Zl3_Incstr(v_Maxno); 
        Else 
          v_Preno := v_Tmp || Lpad(To_Number(Nvl(v_Maxno, '0')), 5, '0'); 
          v_Maxno := v_Tmp || Lpad(To_Number(Nvl(v_Maxno, '0') + 1), 5, '0'); 
        End If; 
      Else 
        --年月(YYMM)+站点号+顺序号(0000) 
        Select Nvl(Max(病案号), To_Number(v_Tmp || '00000')) 
        Into v_Maxno 
        From 住院病案记录 
        Where 病案号 Like v_Tmp || v_Site_No || '%' And 病案号 >= v_Maxno; 
 
        v_Maxno := Substr(v_Maxno, 6); 
        If Zl3_Isnumber(Nvl(v_Maxno, '0')) = 0 Then 
          --是字符,需处理字符加1 
          v_Preno := v_Tmp || v_Site_No || v_Maxno; 
          v_Maxno := v_Tmp || v_Site_No || Zl3_Incstr(v_Maxno); 
        Else 
          v_Preno := v_Tmp || v_Site_No || Lpad(To_Number(Nvl(v_Maxno, '0')), 4, '0'); 
          v_Maxno := v_Tmp || v_Site_No || Lpad(To_Number(Nvl(v_Maxno, '0') + 1), 4, '0'); 
        End If; 
      End If; 
      --防止取号后弃用，所以用当前的号码来更新 
      Update 号码控制表 Set 最大号码 = v_Preno Where 项目序号 = 序号_In; 
      v_No := v_Maxno; 
    Elsif n_Mod = 2 Then 
      --2.年(YYYY)+顺序号(00000) 
      v_Tmp := To_Char(Sysdate, 'YYYY'); 
 
      If v_Site_No Is Null Then 
        Select Nvl(Max(病案号), To_Number(v_Tmp || '00000')) 
        Into v_Maxno 
        From 住院病案记录 
        Where 病案号 Like v_Tmp || '%' And 病案号 >= v_Maxno; 
        v_Maxno := Substr(v_Maxno, 5); 
        If Zl3_Isnumber(Nvl(v_Maxno, '0')) = 0 Then 
          --是字符,需处理字符加1 
          v_Preno := v_Tmp || v_Maxno; 
          v_Maxno := v_Tmp || Zl3_Incstr(v_Maxno); 
        Else 
          v_Preno := v_Tmp || Lpad(To_Number(Nvl(v_Maxno, '0')), 5, '0'); 
          v_Maxno := v_Tmp || Lpad(To_Number(Nvl(v_Maxno, '0') + 1), 5, '0'); 
        End If; 
 
      Else 
        --年月(YYYY)+站点号+顺序号(0000) 
        Select Nvl(Max(病案号), To_Number(v_Tmp || '00000')) 
        Into v_Maxno 
        From 住院病案记录 
        Where 病案号 Like v_Tmp || v_Site_No || '%' And 病案号 >= v_Maxno; 
        v_Maxno := Substr(v_Maxno, 6); 
 
        If Zl3_Isnumber(Nvl(v_Maxno, '0')) = 0 Then 
          --是字符,需处理字符加1 
          v_Preno := v_Tmp || v_Site_No || v_Maxno; 
          v_Maxno := v_Tmp || v_Site_No || Zl3_Incstr(v_Maxno); 
        Else 
          v_Preno := v_Tmp || v_Site_No || Lpad(To_Number(Nvl(v_Maxno, '0')), 4, '0'); 
          v_Maxno := v_Tmp || v_Site_No || Lpad(To_Number(Nvl(v_Maxno, '0') + 1), 4, '0'); 
 
        End If; 
      End If; 
      --防止取号后弃用，所以用当前的号码来更新 
      Update 号码控制表 Set 最大号码 = v_Preno Where 项目序号 = 序号_In; 
      v_No := v_Maxno; 
    Elsif n_Mod = 3 Then 
      --3.年(YYYY)+科室编码+顺序号(00000) 
      v_Tmp := To_Char(Sysdate, 'YYYY'); 
      If 编码_In Is Null Then 
        v_Code := ''; 
      Else 
        v_Code := 编码_In; 
      End If; 
 
      --获取年+科室编码的固定长度 
      n_Codelenth := Length(v_Tmp || v_Code) + 1; 
 
      If v_Site_No Is Null Then 
        Select Nvl(Max(病案号), To_Number(v_Tmp || v_Code || '00000')) 
        Into v_Maxno 
        From 住院病案记录 
        Where 病案号 Like v_Tmp || v_Code || '%' And 病案号 >= v_Maxno; 
 
        v_Maxno := Substr(v_Maxno, n_Codelenth); 
        If Zl3_Isnumber(Nvl(v_Maxno, '0')) = 0 Then 
          --是字符,需处理字符加1 
          v_Preno := v_Tmp || v_Code || v_Maxno; 
          v_Maxno := v_Tmp || v_Code || Zl3_Incstr(v_Maxno); 
 
        Else 
          v_Preno := v_Tmp || v_Code || Lpad(To_Number(Nvl(v_Maxno, '0')), 5, '0'); 
          v_Maxno := v_Tmp || v_Code || Lpad(To_Number(Nvl(v_Maxno, '0') + 1), 5, '0'); 
        End If; 
 
      Else 
        --年月(YYYY)+站点号+顺序号(0000) 
        Select Nvl(Max(病案号), To_Number(v_Tmp || v_Code || '00000')) 
        Into v_Maxno 
        From 住院病案记录 
        Where 病案号 Like v_Tmp || v_Code || v_Site_No || '%' And 病案号 >= v_Maxno; 
        v_Maxno := Substr(v_Maxno, n_Codelenth + 1); 
 
        If Zl3_Isnumber(Nvl(v_Maxno, '0')) = 0 Then 
          --是字符,需处理字符加1 
          v_Preno := v_Tmp || v_Code || v_Site_No || v_Maxno; 
          v_Maxno := v_Tmp || v_Code || v_Site_No || Zl3_Incstr(v_Maxno); 
 
        Else 
          v_Preno := v_Tmp || v_Code || v_Site_No || Lpad(To_Number(Nvl(v_Maxno, '0')), 4, '0'); 
          v_Maxno := v_Tmp || v_Code || v_Site_No || Lpad(To_Number(Nvl(v_Maxno, '0') + 1), 4, '0'); 
 
        End If; 
      End If; 
      --防止取号后弃用，所以用当前的号码来更新 
      Update 号码控制表 Set 最大号码 = v_Preno Where 项目序号 = 序号_In; 
      v_No := v_Maxno; 
    End If; 
    --档案号 
  Elsif 序号_In = 5 Then 
    Select Nvl(最大号码, '0'), Nvl(编号规则, 0) 
    Into v_Maxno, n_Mod 
    From 号码控制表 
    Where 项目序号 = 序号_In 
    For Update; 
 
    If n_Mod = 0 Then 
      --0.顺序编号 
      If v_Site_No Is Null Then 
        Select Substr(Nvl(Max(Lpad(档案号, 20, 0)), ''), 
                       20 - Nvl(Max(Length(档案号)), 20) + 1, 
                       Nvl(Max(Length(档案号)), 20)) 
        Into v_Maxno 
        From 住院病案记录 
        Where Lpad(档案号, 20, 0) >= Lpad(v_Maxno, 20, 0) And 档案号 > '0'; 
 
        If Zl3_Isnumber(Nvl(v_Maxno, '0')) = 0 Then 
          --是字符,需处理字符加1 
          v_Maxno := Zl3_Incstr(v_Maxno); 
        Else 
          v_Maxno := To_Char(To_Number(Nvl(v_Maxno, '0') + 1)); 
          v_Maxno := Ltrim(Rtrim(v_Maxno)); 
        End If; 
      Else 
        --第1位为:站点号,后面为顺序号+1 
        Select Substr(Nvl(Max(Lpad(档案号, 20, 0)), ''), 
                       20 - Nvl(Max(Length(档案号)), 20) + 1, 
                       Nvl(Max(Length(档案号)), 20)) 
        Into v_Maxno 
        From 住院病案记录 
        Where Lpad(档案号, 20, 0) >= Lpad(v_Maxno, 20, 0) And 档案号 > '0' And 档案号 Like v_Site_No || '%'; 
 
        v_Maxno := Substr(Nvl(v_Maxno, '0'), 2); 
 
        If Zl3_Isnumber(Nvl(v_Maxno, '0')) = 0 Then 
          --是字符,需处理字符加1 
          v_Maxno := Zl3_Incstr(v_Maxno); 
        Else 
          v_Maxno := To_Char(To_Number(Nvl(v_Maxno, '0') + 1)); 
          v_Maxno := Ltrim(Rtrim(v_Maxno)); 
        End If; 
        v_Maxno := v_Site_No || v_Maxno; 
      End If; 
      If Zl3_Isnumber(Nvl(v_Maxno, '0')) = 1 Then 
        Update 号码控制表 Set 最大号码 = Decode(Sign(v_Maxno - 10), 1, v_Maxno - 10, 1) Where 项目序号 = 序号_In; 
      End If; 
      v_No := v_Maxno; 
    Elsif n_Mod = 1 Then 
      --1.年月(YYMM)+顺序号(00000) 
      v_Tmp := To_Char(Sysdate, 'YYMM'); 
      If v_Site_No Is Null Then 
        Select Substr(Nvl(Max(Lpad(档案号, 20, 0)), To_Number(v_Tmp || '00000')), 
                       20 - Nvl(Max(Length(档案号)), 20) + 1, 
                       Nvl(Max(Length(档案号)), 20)) 
        Into v_Maxno 
        From 住院病案记录 
        Where 档案号 Like v_Tmp || '%' And Lpad(档案号, 20, 0) >= Lpad(v_Maxno, 20, 0) And 档案号 > '0'; 
        v_Maxno := Substr(v_Maxno, 5); 
        If Zl3_Isnumber(Nvl(v_Maxno, '0')) = 0 Then 
          --是字符,需处理字符加1 
          v_Maxno := v_Tmp || Zl3_Incstr(v_Maxno); 
        Else 
          v_Maxno := v_Tmp || Lpad(To_Number(Nvl(v_Maxno, '0') + 1), 5, '0'); 
        End If; 
      Else 
        --年月(YYMM)+站点号+顺序号(0000) 
        Select Substr(Nvl(Max(Lpad(档案号, 20, 0)), To_Number(v_Tmp || '00000')), 
                       20 - Nvl(Max(Length(档案号)), 20) + 1, 
                       Nvl(Max(Length(档案号)), 20)) 
        Into v_Maxno 
        From 住院病案记录 
        Where 档案号 Like v_Tmp || v_Site_No || '%' And Lpad(档案号, 20, 0) >= Lpad(v_Maxno, 20, 0) And 档案号 > '0'; 
 
        v_Maxno := Substr(v_Maxno, 6); 
        If Zl3_Isnumber(Nvl(v_Maxno, '0')) = 0 Then 
          --是字符,需处理字符加1 
          v_Maxno := v_Tmp || v_Site_No || Zl3_Incstr(v_Maxno); 
        Else 
          v_Maxno := v_Tmp || v_Site_No || Lpad(To_Number(Nvl(v_Maxno, '0') + 1), 4, '0'); 
        End If; 
      End If; 
      If Zl3_Isnumber(Nvl(v_Maxno, '0')) = 1 Then 
        Update 号码控制表 
        Set 最大号码 = Decode(Sign(v_Maxno - 10 - To_Number(v_Tmp || '00000')), 1, v_Maxno - 10, To_Number(v_Tmp || '00001')) 
        Where 项目序号 = 序号_In; 
      End If; 
      v_No := v_Maxno; 
    Elsif n_Mod = 2 Then 
      --2.年(YYYY)+顺序号(00000) 
      v_Tmp := To_Char(Sysdate, 'YYYY'); 
 
      If v_Site_No Is Null Then 
        Select Substr(Nvl(Max(Lpad(档案号, 20, 0)), To_Number(v_Tmp || '00000')), 
                       20 - Nvl(Max(Length(档案号)), 20) + 1, 
                       Nvl(Max(Length(档案号)), 20)) 
        Into v_Maxno 
        From 住院病案记录 
        Where 档案号 Like v_Tmp || '%' And Lpad(档案号, 20, 0) >= Lpad(v_Maxno, 20, 0) And 档案号 > '0'; 
        v_Maxno := Substr(v_Maxno, 5); 
        If Zl3_Isnumber(Nvl(v_Maxno, '0')) = 0 Then 
          --是字符,需处理字符加1 
          v_Maxno := v_Tmp || Zl3_Incstr(v_Maxno); 
        Else 
          v_Maxno := v_Tmp || Lpad(To_Number(Nvl(v_Maxno, '0') + 1), 5, '0'); 
        End If; 
      Else 
        --年月(YYYY)+站点号+顺序号(0000) 
        Select Substr(Nvl(Max(Lpad(档案号, 20, 0)), To_Number(v_Tmp || '00000')), 
                       20 - Nvl(Max(Length(档案号)), 20) + 1, 
                       Nvl(Max(Length(档案号)), 20)) 
        Into v_Maxno 
        From 住院病案记录 
        Where 档案号 Like v_Tmp || v_Site_No || '%' And Lpad(档案号, 20, 0) >= Lpad(v_Maxno, 20, 0) And 档案号 > '0'; 
        v_Maxno := Substr(v_Maxno, 6); 
 
        If Zl3_Isnumber(Nvl(v_Maxno, '0')) = 0 Then 
          --是字符,需处理字符加1 
          v_Maxno := v_Tmp || v_Site_No || Zl3_Incstr(v_Maxno); 
        Else 
          v_Maxno := v_Tmp || v_Site_No || Lpad(To_Number(Nvl(v_Maxno, '0') + 1), 4, '0'); 
        End If; 
      End If; 
      If Zl3_Isnumber(Nvl(v_Maxno, '0')) = 1 Then 
        Update 号码控制表 
        Set 最大号码 = Decode(Sign(v_Maxno - 10 - To_Number(v_Tmp || '00000')), 1, v_Maxno - 10, To_Number(v_Tmp || '00001')) 
        Where 项目序号 = 序号_In; 
      End If; 
      v_No := v_Maxno; 
    Elsif n_Mod = 3 Then 
      --3.年(YYYY)+科室编码+顺序号(00000) 
      v_Tmp := To_Char(Sysdate, 'YYYY'); 
      If 编码_In Is Null Then 
        v_Code := ''; 
      Else 
        v_Code := 编码_In; 
      End If; 
 
      --获取年+科室编码的固定长度 
      n_Codelenth := Length(v_Tmp || v_Code) + 1; 
 
      If v_Site_No Is Null Then 
        Select Substr(Nvl(Max(Lpad(档案号, 20, 0)), To_Number(v_Tmp || v_Code || '00000')), 
                       20 - Nvl(Max(Length(档案号)), 20) + 1, 
                       Nvl(Max(Length(档案号)), 20)) 
        Into v_Maxno 
        From 住院病案记录 
        Where 档案号 Like v_Tmp || v_Code || '%' And Lpad(档案号, 20, 0) >= Lpad(v_Maxno, 20, 0) And 档案号 > '0'; 
 
        v_Maxno := Substr(v_Maxno, n_Codelenth); 
        If Zl3_Isnumber(Nvl(v_Maxno, '0')) = 0 Then 
          --是字符,需处理字符加1 
          v_Maxno := v_Tmp || v_Code || Zl3_Incstr(v_Maxno); 
        Else 
          v_Maxno := v_Tmp || v_Code || Lpad(To_Number(Nvl(v_Maxno, '0') + 1), 5, '0'); 
        End If; 
 
      Else 
        --年月(YYYY)+站点号+顺序号(0000) 
        Select Substr(Nvl(Max(Lpad(档案号, 20, 0)), To_Number(v_Tmp || v_Code || '00000')), 
                       20 - Nvl(Max(Length(档案号)), 20) + 1, 
                       Nvl(Max(Length(档案号)), 20)) 
        Into v_Maxno 
        From 住院病案记录 
        Where 档案号 Like v_Tmp || v_Code || v_Site_No || '%' And Lpad(档案号, 20, 0) >= Lpad(v_Maxno, 20, 0) And 档案号 > '0'; 
        v_Maxno := Substr(v_Maxno, n_Codelenth + 1); 
 
        If Zl3_Isnumber(Nvl(v_Maxno, '0')) = 0 Then 
          --是字符,需处理字符加1 
          v_Maxno := v_Tmp || v_Code || v_Site_No || Zl3_Incstr(v_Maxno); 
        Else 
          v_Maxno := v_Tmp || v_Code || v_Site_No || Lpad(To_Number(Nvl(v_Maxno, '0') + 1), 4, '0'); 
        End If; 
      End If; 
      If Zl3_Isnumber(Nvl(v_Maxno, '0')) = 1 Then 
        Update 号码控制表 
        Set 最大号码 = Decode(Sign(v_Maxno - 10 - To_Number(v_Tmp || v_Code || '00000')), 
                           1, 
                           v_Maxno - 10, 
                           To_Number(v_Tmp || v_Code || '00001')) 
        Where 项目序号 = 序号_In; 
      End If; 
      v_No := v_Maxno; 
    End If; 
  Else 
    v_Error := '序号为' || 序号_In || '的号码,其规则值:' || n_Mod || ',当前系统不支持！'; 
    Raise Err_Custom; 
  End If; 
 
  Commit; 
  Return v_No; 
Exception 
  When Err_Custom Then 
    Rollback; 
    Raise_Application_Error(-20101, '[ZLSOFT]' || v_Error || '[ZLSOFT]'); 
  When Others Then 
    Rollback; 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
End Zl3_Nextno;
/

