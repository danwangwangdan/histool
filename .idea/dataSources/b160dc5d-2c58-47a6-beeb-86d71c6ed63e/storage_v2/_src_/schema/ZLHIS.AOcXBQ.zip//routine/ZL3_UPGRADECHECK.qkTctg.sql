create FUNCTION zl3_UpgradeCheck( 
	v_CurVer IN VARCHAR2, 
	v_NewVer IN VARCHAR2 
	) RETURN VARCHAR2 
    IS v_Error VARCHAR2(2000); 
    v_Message VARCHAR2(100); 
BEGIN 
    v_Error:=''; 
    --检查表空间是否满足需要 
    v_Message:=''; 
    select decode(count(*),3,'','请先创建 ZL9MEDBASE、ZL9MEDREC和ZL9MEDDAY 表空间') into v_Message 
    from user_tablespaces 
    where TABLESPACE_NAME = 'ZL9MEDREC' OR TABLESPACE_NAME = 'ZL9MEDBASE' OR TABLESPACE_NAME = 'ZL9MEDDAY' 
        and STATUS='ONLINE'; 
    if length(v_Message)<>0 then 
        v_Error:=v_Error||chr(10)||v_Message; 
    end if; 
 
    --整理返回信息 
    if length(v_Error)<>0 then 
        v_Error:=substr(v_Error,2); 
    end if; 
	return v_Error; 
EXCEPTION 
    WHEN OTHERS THEN 
    v_Error:=v_Error||chr(10)||'无法有效完成升级检查'; 
    if length(v_Error)<>0 then 
        v_Error:=substr(v_Error,2); 
    end if; 
    return v_Error; 
END;
/

