create Function Zl4_Nextno 
( 
  序号_In   In 号码控制表.项目序号%Type, 
  科室id_In In 部门表.ID%Type := Null 
) Return Varchar2 
--    功能：根据特定规则产生新的号码,规则如下： 
  --    一、项目序号： 
  --       1   病人ID         数字 
  --       2   住院号         数字 
  --       3   门诊号         数字 
  --       10  医嘱发送号     数字,顺序递增编号 
  --       x   其它单据号     字符,根据编号规则顺序递增编号,不自动补缺 
  --    二、年度位确定原则： 
  --       以1990为基数，随年度增长，按“0～9/A～Z”顺序作为年度编码 
  -- 
  --    说明：最大号码-10存入号码控制表,用于并发情况下补缺号(取了号,但未使用) 
  --          For Update在并发情况下锁定行,不用Wait选项以避免向调用者返回空 
  --    返回：最大号码 
 Is 
  Pragma Autonomous_Transaction; 
  v_No      号码控制表.最大号码%Type; 
  v_Maxno   号码控制表.最大号码%Type; 
  n_Mod     号码控制表.编号规则%Type; 
  v_Deptno  科室号码表.编号%Type; 
  v_Year    Varchar2(1); 
  v_Tmp     Varchar2(10); 
  v_Site_No Varchar2(1); 
 
  v_Err_Msg Varchar2(255); 
  Err_Item Exception; 
Begin 
  v_Site_No := f_Get_Node_No; 
 
  Begin 
    Select Nvl(编号规则, 0) Into n_Mod From 号码控制表 Where 项目序号 = 序号_In; 
  Exception 
    When Others Then 
      v_Err_Msg := '号码控制表中不存在序号为' || 序号_In || '的号码'; 
      Raise Err_Item; 
  End; 
 
  Select Decode(Sign(Intyear - 10), -1, To_Char(Intyear, '9'), Chr(55 + Intyear)) 
  Into v_Year 
  From (Select To_Number(To_Char(Sysdate, 'yyyy'), '9999') - 1990 As Intyear From Dual); 
 
  If n_Mod = 0 Then 
    --0.按年顺序编号 
    Select Nvl(最大号码, '0') Into v_No From 号码控制表 Where 项目序号 = 序号_In For Update; 
    Select Substr(Maxno, 1, 1) || LPad(To_Number(Substr(Maxno, 2)) + 1, 7, '0') 
    Into v_No 
    From (Select Decode(v_No, '0', v_Year || '0000000', 
                          Decode(Sign(Ascii(Substr(v_No, 1, 1)) - Ascii(v_Year)), -1, v_Year || '0000000', v_No)) As Maxno 
           From Dual); 
    Update 号码控制表 Set 最大号码 = v_No Where 项目序号 = 序号_In; 
 
    If v_Site_No Is Not Null Then 
      v_No := Substr(v_No, 1, 1) || Substr(v_No, 3, Length(v_No) - 2) || v_Site_No; 
    End If; 
 
  Elsif n_Mod = 1 Then 
    --1.按年+日顺序编号:YDDD0000 
    Select Nvl(最大号码, '0') Into v_No From 号码控制表 Where 项目序号 = 序号_In For Update; 
    Select v_Year || LPad(Trunc(Sysdate - Trunc(Sysdate, 'YYYY') + 1, 0), 3, '0') || '0000' Into v_Maxno From Dual; 
    If v_No < v_Maxno Then 
      v_No := v_Maxno; 
    End If; 
    v_No := Substr(v_No, 1, 4) || LPad(To_Number(Substr(v_No, 5, 4)) + 1, 4, '0'); 
    Update 号码控制表 Set 最大号码 = v_No Where 项目序号 = 序号_In; 
 
    If v_Site_No Is Not Null Then 
      v_No := Substr(v_No, 1, 4) || Substr(v_No, 6, Length(v_No) - 5) || v_Site_No; 
    End If; 
 
  Elsif n_Mod = 2 Then 
    --2.按年+科室编号+月+顺序号:YKDD0000 
    Begin 
      --符号-的asscii为45,用于和year比较(0的ascii为48) 
      Select 编号, Nvl(最大号码, '-') 
      Into v_Deptno, v_No 
      From 科室号码表 
      Where 项目序号 = 序号_In And Nvl(科室id, 0) = Nvl(科室id_In, 0) 
      For Update; 
    Exception 
      When Others Then 
        Null; 
    End; 
    If v_Deptno Is Null Then 
      v_Err_Msg := '科室未设置编号，无法产生号码！'; 
      Raise Err_Item; 
    Else 
      v_Tmp := To_Char(Sysdate, 'MM'); 
      Select Substr(Maxno, 1, 4) || LPad(To_Number(Substr(Maxno, 5, 4)) + 1, 4, '0') 
      Into v_No 
      From (Select Decode(Sign(Ascii(Substr(v_No, 1, 1)) - Ascii(v_Year)), -1, v_Year || v_Deptno || v_Tmp || '0000', 
                            Decode(Sign(To_Number(Substr(v_No, 3, 2)) - To_Number(v_Tmp)), -1, 
                                    v_Year || v_Deptno || v_Tmp || '0000', v_No)) As Maxno 
             From Dual); 
      Update 科室号码表 Set 最大号码 = v_No Where 项目序号 = 序号_In And Nvl(科室id, 0) = Nvl(科室id_In, 0); 
 
      If v_Site_No Is Not Null Then 
        v_No := Substr(v_No, 1, 4) || Substr(v_No, 6, Length(v_No) - 5) || v_Site_No; 
      End If; 
    End If; 
  Elsif n_Mod = 4 Then 
    --4-按执行科室分期间编号(年(期间表中的年)+执行科室编号+月份(期间表中的月)+顺序号) 
    v_Tmp := Null; 
    Begin 
      Select 期间 Into v_Tmp From 期间表 Where Trunc(Sysdate) Between 开始日期 And 终止日期; 
    Exception 
      When Others Then 
        v_Tmp := Null; 
    End; 
    If v_Tmp Is Null Then 
      v_Err_Msg := '在期间管理中未设置当前日期的期间，请检查『期间划分管理』'; 
      Raise Err_Item; 
    End If; 
    Select Decode(Sign(Intyear - 10), -1, To_Char(Intyear, '9'), Chr(55 + Intyear)) 
    Into v_Year 
    From (Select To_Number(Substr(v_Tmp, 1, 4), '9999') - 1990 As Intyear From Dual); 
    Begin 
      --符号-的asscii为45,用于和year比较(0的ascii为48) 
      Select 编号, Nvl(最大号码, '-') 
      Into v_Deptno, v_No 
      From 科室号码表 
      Where 项目序号 = 序号_In And Nvl(科室id, 0) = Nvl(科室id_In, 0) 
      For Update; 
    Exception 
      When Others Then 
        Null; 
    End; 
    If v_Deptno Is Null Then 
      v_Err_Msg := '科室未设置编号，无法产生号码！'; 
      Raise Err_Item; 
    Else 
      v_Tmp := Substr(v_Tmp, 5, 2); 
      Select Substr(Maxno, 1, 4) || LPad(To_Number(Substr(Maxno, 5, 4)) + 1, 4, '0') 
      Into v_No 
      From (Select Decode(Sign(Ascii(Substr(v_No, 1, 1)) - Ascii(v_Year)), -1, v_Year || v_Deptno || v_Tmp || '0000', 
                            Decode(Sign(To_Number(Substr(v_No, 3, 2)) - To_Number(v_Tmp)), -1, 
                                    v_Year || v_Deptno || v_Tmp || '0000', v_No)) As Maxno 
             From Dual); 
      Update 科室号码表 Set 最大号码 = v_No Where 项目序号 = 序号_In And Nvl(科室id, 0) = Nvl(科室id_In, 0); 
 
      If v_Site_No Is Not Null Then 
        v_No := Substr(v_No, 1, 4) || Substr(v_No, 6, Length(v_No) - 5) || v_Site_No; 
      End If; 
    End If; 
  Else 
    v_Err_Msg := '序号为' || 序号_In || '的号码,其规则值:' || n_Mod || ',当前系统不支持！'; 
    Raise Err_Item; 
  End If; 
 
  Commit; 
  Return v_No; 
Exception 
  When Err_Item Then 
    Rollback; 
    Raise_Application_Error(-20101, '[ZLSOFT]' || v_Err_Msg || '[ZLSOFT]'); 
  When Others Then 
    Rollback; 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zl4_Nextno;
/

