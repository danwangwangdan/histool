create FUNCTION  ZL6_NEXTNO(序号_in IN 	号码控制表.项目序号%type) 
    ------------------------------------------------------------------------------------ 
    --功能：根据特定规则产生新的入库单号码,规则如下： 
    --       年度位确定原则: 
    --       以1990为基数，随年度增长，按“0～9/A～Z”顺序作为年度编码 
    --返回： 
    -------------------------------------------------------------------------------------- 
	RETURN VARCHAR2 
IS 
	intYear  number(4); 
	strYear  varchar2(8); 
	vntNo	 号码控制表.最大号码%type; 
BEGIN 
	BEGIN 
		SELECT 最大号码 INTO vntNo FROM 号码控制表  WHERE 项目序号=序号_IN; 
	EXCEPTION 
		WHEN OTHERS THEN 
			vntNo:=null; 
	END ; 
	 
        intYear:= to_number(to_char(sysdate,'yyyy'),'9999') - 1990; 
 
	IF intyear<10 then 
		stryear:=to_char(intyear,'9999'); 
	ELSE 
		stryear:=chr(55+intyear); 
	END IF ; 
 
        IF vntno IS NULL THEN 
	    vntNo := strYear || '0000000'; 
	ELSE 
		If substr(vntNo, 1,1) < strYear Then 
		    vntNo:= strYear || '0000000'; 
		End If; 
	END IF ; 
 
        vntNo := substr(vntNo, 1,1) || lpad(to_number(substr(vntno,2))+1,7,'0'); 
	UPDATE 号码控制表 SET 最大号码= vntNo 
	WHERE 项目序号=序号_IN; 
	RETURN vntNo; 
 
EXCEPTION 
	WHEN OTHERS  THEN 
	zl_ErrorCenter (SQLCODE, SQLERRM); 
	RETURN vntNo; 
End ZL6_NEXTNO;
/

