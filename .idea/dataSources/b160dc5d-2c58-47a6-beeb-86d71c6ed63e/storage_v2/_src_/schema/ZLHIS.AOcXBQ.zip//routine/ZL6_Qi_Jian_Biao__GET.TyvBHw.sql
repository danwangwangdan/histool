create Function Zl6_期间表_Get(日期_In In 期间表.开始日期%Type) 
------------------------------------------------------------------------------------ 
  --功能：根据指定的日期,获取期间数据 
  --     日期_in-指定获取期的日期 
  --返回：期间 
  -------------------------------------------------------------------------------------- 
 Return Varchar2 Is 
  Err_Item Exception; 
  v_Err_Msg Varchar2(100); 
  v_期间    期间表.期间%Type; 
 
Begin 
  If 日期_In Is Null Then 
    v_期间 := Null; 
    Return v_期间; 
  Else 
    Begin 
      Select 期间 Into v_期间 From 期间表 Where Trunc(日期_In) Between 开始日期 And 终止日期; 
    Exception 
      When Others Then 
        v_期间 := Null; 
    End; 
    If v_期间 Is Null Then 
      v_Err_Msg := '[ZLSOFT]日期为' || To_Char(日期_In, 'yyyy-mm-dd') || '未进行期间划分,请检查【期间划分】![ZLSOFT]'; 
      Raise Err_Item; 
    End If; 
    Return v_期间; 
  End If; 
Exception 
  When Err_Item Then 
    Raise_Application_Error(-20001, v_Err_Msg); 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
    Return v_期间; 
End Zl6_期间表_Get;
/

