create FUNCTION zl6_UpgradeCheck( 
	v_CurVer IN VARCHAR2, 
	v_NewVer IN VARCHAR2 
	) RETURN VARCHAR2 
    IS v_Error VARCHAR2(2000); 
    v_Message VARCHAR2(100); 
BEGIN 
    v_Error:=''; 
    --检查表空间是否满足需要 
    v_Message:=''; 
    select decode(count(*),3,'','1、表空间不正确，你需要先创建它们(参见zlSetup.ini)；') into v_Message 
    from user_tablespaces 
    where upper(TABLESPACE_NAME) in('ZL9DEVBASE','ZL9DEVREC','ZL9DEVUSE') 
        and STATUS='ONLINE'; 
    if length(v_Message)<>0 then 
        v_Error:=v_Error||chr(10)||v_Message; 
    end if; 
 
    --整理返回信息 
    if length(v_Error)<>0 then 
        v_Error:=substr(v_Error,2); 
    end if; 
    return v_Error; 
EXCEPTION 
    WHEN OTHERS THEN 
    v_Error:=v_Error||chr(10)||'无法有效完成升级检查'; 
    if length(v_Error)<>0 then 
        v_Error:=substr(v_Error,2); 
    end if; 
    return v_Error; 
END;
/

