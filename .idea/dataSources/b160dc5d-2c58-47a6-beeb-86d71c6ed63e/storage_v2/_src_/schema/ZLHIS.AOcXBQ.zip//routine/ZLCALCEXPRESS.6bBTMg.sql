create Function Zlcalcexpress 
( 
  检验标本id_In In 检验普通结果.检验标本id%Type, 
  计算公式_In   In 检验项目.计算公式%Type 
) Return Varchar2 As 
  V_Yesno    Number(1); 
  V_Leftpos  Number(18); 
  V_Rightpos Number(18); 
  V_Tmpid    Number(18); 
 
  V_检验结果 检验普通结果.检验结果%Type; 
  V_计算公式 检验项目.计算公式%Type; 
 
  V_Cursorid Integer; 
  V_Return   Integer; 
 
  V_Result Varchar2(250); 
  V_Sql    Varchar2(4000); 
 
Begin 
 
  If 计算公式_In Is Null Then 
    Return Null; 
  End If; 
 
  V_计算公式 := 计算公式_In; 
 
  V_Leftpos  := Instr(V_计算公式, '['); 
  V_Rightpos := Instr(V_计算公式, ']'); 
 
  While V_Leftpos > 0 Loop 
    V_Tmpid := To_Number(Substr(V_计算公式, V_Leftpos + 1, V_Rightpos - V_Leftpos - 1)); 
 
    --确定是否为计算项目 
    V_Yesno := 0; 
    Begin 
      Select 1 Into V_Yesno From 检验项目 Where 计算公式 Is Not Null And 诊治项目id = V_Tmpid; 
    Exception 
      When Others Then 
        V_Yesno := 0; 
    End; 
 
    V_检验结果 := Null; 
    If V_Yesno = 1 Then 
      Begin 
        Select Zlcalcexpress(检验标本id_In, 计算公式) Into V_检验结果 From 检验项目 Where 诊治项目id = V_Tmpid; 
      Exception 
        When Others Then 
          V_检验结果 := Null; 
      End; 
    Else 
      Begin 
        Select A.检验结果 
        Into V_检验结果 
        From 检验普通结果 A, 检验标本记录 B 
        Where A.检验标本id = 检验标本id_In And A.检验标本id = B.Id And 检验项目id = V_Tmpid And A.记录类型 = B.报告结果; 
      Exception 
        When Others Then 
          V_检验结果 := Null; 
      End; 
    End If; 
 
    If V_检验结果 Is Null Then 
      Return Null; 
    End If; 
 
    V_计算公式 := Substr(V_计算公式, 1, V_Leftpos - 1) || V_检验结果 || Substr(V_计算公式, V_Rightpos + 1, Length(V_计算公式) - V_Rightpos); 
 
    V_Leftpos  := Instr(V_计算公式, '['); 
    V_Rightpos := Instr(V_计算公式, ']'); 
  End Loop; 
 
  V_Result := Null; 
  Begin 
    --    SELECT v_计算公式 INTO v_检验结果 FROM DUAL; 
    V_Sql := 'SELECT ' || V_计算公式 || ' AS 检验结果 FROM DUAL'; 
    Execute Immediate V_Sql 
      Into V_Result; 
  Exception 
    When Others Then 
      Null; 
  End; 
  Return Trim(V_Result); 
End Zlcalcexpress;
/

