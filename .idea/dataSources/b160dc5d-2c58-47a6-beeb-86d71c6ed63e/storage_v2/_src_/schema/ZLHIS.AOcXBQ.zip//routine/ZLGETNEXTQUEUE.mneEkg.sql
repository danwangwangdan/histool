create Function Zlgetnextqueue 
( 
  执行部门id_In Number, 
  业务id_In     Number := Null, 
  扩展_In       Varchar2 := Null 
  --功能：获取指定的排队序号 
  --     本函数主要供其他过程调用,读取相关的排队序号 
  --     用户可以根据实际产生的规则,来生成排队序号 
  --参数： 
  --    执行部门ID_In: 传入的是挂号的执行部门。 
  --    业务ID_In：传入的是挂号ID 
  --    扩展_IN：传入的是号别和号序,之间用|分隔;左边为号码,右边为号序 
 
) Return VARCHAR2  Is 
  Pragma Autonomous_Transaction; 
  v_Maxno 排队号码表.最大号码%Type; 
  Err_Custom Exception; 
Begin 
 
  --目前排队可以有三种情况: 
  --1. 全院级的:按整个医院来生成排队号码 
  --2. 科室级的:按执行科室来生成排队号码,目前缺省是按此种方式进行处理 
  --3.医生级或诊室级的:按执行科室+医生或诊室的级别来产生排队号码 
  If 业务id_In Is Null Then 
    --暂无用 
    Null; 
  End If; 
  --缺省产生执行科室级: 
  Begin 
    Select Nvl(最大号码, '0') 
    Into v_Maxno 
    From 排队号码表 
    Where 队列日期 = Trunc(Sysdate) And 排队名称 = 执行部门id_In; 
  Exception 
    When Others Then 
      Insert Into 排队号码表 (队列日期, 排队名称, 最大号码) Values (Trunc(Sysdate), 执行部门id_In, '0'); 
  End; 
  Delete 排队号码表 Where 队列日期 < Trunc(Sysdate); 
  Commit; 
 
  Select Nvl(最大号码, '0') 
  Into v_Maxno 
  From 排队号码表 
  Where 队列日期 = Trunc(Sysdate) And 排队名称 = 执行部门id_In 
  For Update; 
 
  If v_Maxno = '0' Then 
    v_Maxno := '1'; 
  Else 
    v_Maxno := Zl_To_Number(v_Maxno) + 1; 
  End If; 
  Update 排队号码表 Set 最大号码 = v_Maxno Where 队列日期 = Trunc(Sysdate) And 排队名称 = 执行部门id_In; 
  Commit; 
  Return v_Maxno; 
End Zlgetnextqueue;
/

