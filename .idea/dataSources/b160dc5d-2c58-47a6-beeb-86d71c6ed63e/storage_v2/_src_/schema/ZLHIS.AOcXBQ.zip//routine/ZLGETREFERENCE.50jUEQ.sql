create Function Zlgetreference 
( 
  项目id_In     In Number, 
  标本类型_In   In Varchar2, 
  性别_In       In Number, 
  出生日期_In   In Date, 
  仪器id_In     In Number := Null, 
  年龄_In       In Varchar2 := Null, 
  申请科室id_In In Number := Null 
) Return Varchar2 As 
  V_Return Varchar2(5000); 
Begin 
  Select Zl_Get_Reference(0, 项目id_In, 标本类型_In, 性别_In, 出生日期_In, 仪器id_In, 年龄_In, 申请科室id_In) 
  Into V_Return 
  From Dual; 
  Return V_Return; 
End Zlgetreference;
/

