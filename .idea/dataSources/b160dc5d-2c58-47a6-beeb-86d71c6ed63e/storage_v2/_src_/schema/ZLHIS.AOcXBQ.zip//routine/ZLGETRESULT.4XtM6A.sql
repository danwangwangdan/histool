create FUNCTION zlGetResult( 
	病人id_IN			IN 病人医嘱记录.病人id%Type, 
	主页id_IN			IN 病人医嘱记录.主页id%Type, 
	检验项目ID_IN			IN NUMBER, 
	检验时间_IN			IN DATE, 
	倒数次数_IN			IN NUMBER) 
	RETURN VARCHAR2 
AS 
	CURSOR v_Result IS 
		SELECT 检验结果 FROM ( 
		SELECT 检验结果,ROWNUM AS 序号 FROM ( 
		SELECT B.检验时间,A.检验结果 FROM 检验普通结果 A,检验标本记录 B,病人医嘱记录 C 
		WHERE A.检验项目ID=检验项目ID_IN 
			AND B.检验时间<检验时间_IN 
			AND B.医嘱id=C.ID 
			AND A.检验标本ID = B.ID 
			AND A.记录类型=B.报告结果 
			AND C.病人id=病人id_IN 
			AND NVL(C.主页id,0)=NVL(主页id_IN,0) 
		ORDER BY B.检验时间 DESC)) WHERE 序号=倒数次数_IN; 
Begin 
 
	FOR v_Cur IN v_Result 
	LOOP 
		RETURN v_Cur.检验结果; 
	End LOOP; 
 
	RETURN ''; 
End zlGetResult;
/

