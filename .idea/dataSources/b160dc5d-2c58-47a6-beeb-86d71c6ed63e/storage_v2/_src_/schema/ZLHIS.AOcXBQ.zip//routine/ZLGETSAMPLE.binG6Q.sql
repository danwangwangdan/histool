create FUNCTION zlGetSample( 
	项目ID_IN			IN NUMBER, 
	是否组合诊疗			IN NUMBER:=0, 
	排除项目ID_IN			IN NUMBER:=-1) 
	RETURN VARCHAR2 
AS 
	v_Return		VARCHAR2(5000); 
	v_NewReturn		VARCHAR2(5000); 
	v_Tmp			VARCHAR2(5000); 
	v_Pos			NUMBER(18); 
	v_Name			VARCHAR2(1000); 
	v_FLAG			NUMBER(1); 
 
	CURSOR v_Combo IS 
		SELECT 报告项目id FROM 检验报告项目 WHERE 诊疗项目ID=项目ID_IN; 
 
	CURSOR v_Sample(v_Key 检验项目参考.项目ID%type) IS 
		SELECT A.标本类型,B.诊疗项目id FROM 检验项目参考 A,检验报告项目 B,诊疗项目目录 C 
		WHERE A.项目id=B.报告项目id 
			AND B.诊疗项目id=C.ID 
			AND C.组合项目<>1 
			AND A.项目ID=v_Key 
		GROUP BY A.标本类型,B.诊疗项目id; 
Begin 
	v_Return:=''; 
 
	IF 是否组合诊疗=0 THEN 
		FOR r_Sample IN v_Sample(项目ID_IN) LOOP 
			v_Return:=v_Return||','||r_Sample.标本类型; 
		End LOOP; 
	ELSE 
		FOR r_Combo IN v_Combo LOOP 
			v_Tmp:=''; 
			v_FLAG:=0; 
			FOR r_Sample IN v_Sample(r_Combo.报告项目id) LOOP 
				v_Tmp:=v_Tmp||','||r_Sample.标本类型; 
				IF r_Sample.诊疗项目id=排除项目ID_IN THEN 
					v_FLAG:=1; 
				End IF; 
			End LOOP; 
			IF v_FLAG=0 THEN 
				IF v_Return IS NULL THEN 
					--第一个检验项目的标本类型,直接作为公共标本类型 
					v_Return:=v_Tmp; 
				ELSE 
					--非第一个检验项目的标本类型要与以前的公共标本类型比较 
					--方法是依次从v_Return中取出标本类型,检查是否被包含在v_Tmp中,若是包含在其中,则还是公共标本,否则不再是公共标本 
					v_Return:=v_Return||','; 
					v_Pos:=instr(v_Return,','); 
					v_NewReturn:=''; 
					WHILE v_Pos>0 LOOP 
						v_Name:=substr(v_Return,1,v_Pos-1); 
						IF v_Name IS NOT NULL THEN 
							IF INSTR(','||v_Tmp||',',','||v_Name||',')>0 THEN 
								v_NewReturn:=v_NewReturn||','||v_Name; 
							End IF; 
						End IF; 
						v_Return:=substr(v_Return,v_Pos+1,length(v_Return)-v_Pos); 
						v_Pos:=instr(v_Return,','); 
					End LOOP; 
					v_Return:=v_NewReturn; 
				End IF; 
 
				IF v_Return IS NULL THEN 
					RETURN ''; 
				End IF; 
			End IF; 
		End LOOP; 
	End IF; 
 
	IF SUBSTR(v_Return,1,1)=',' THEN 
		RETURN SUBSTR(v_Return,2,LENGTH(v_Return)-1); 
	ELSE 
		RETURN v_Return; 
	End IF; 
End;
/

