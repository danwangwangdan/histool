create Function ZLgetSequenceNum 
( 
  业务id_In     Number := Null, 
  业务类型id_In Number:=Null, 
  操作类型_In   Number:= Null 
  --功能：获取指定的排队序号 
  --     本函数主要供其他过程调用,读取相关的排队序号 
  --     用户可以根据实际产生的规则,来生成排队序号 
  --参数： 
  --    业务ID_In：传入的是挂号ID 
  --    业务类型ID_IN: 传入排队业务类型 
  --    操作类型_In：0-正常排队;1-调整;2-回诊 
 
) Return VARCHAR2  Is 
  Pragma Autonomous_Transaction; 
  v_Maxno 排队号码表.最大号码%Type; 
  执行部门id_In Number; 
  Err_Custom Exception; 
Begin 
  Return Null; 
End ZLgetSequenceNum;
/

