create Function Zlpub_Pacs_获取报告列表Ex 
( 
  医嘱ID_In In 病人医嘱记录.id%Type 
) Return Varchar2 Is 
  Pragma Autonomous_Transaction; 
 
  TYPE C_REPORT_LIST IS REF CURSOR; 
  C_REPORT_ITEM C_REPORT_LIST; 
 
  v_Return Varchar2(4000); 
  v_Sql    Varchar2(4000); 
  v_Temp   Varchar2(2000); 
  n_Count  Number; 
 
  n_ITEM_Id       Varchar2(64); 
  n_ITEM_YZID     Number(18); 
  v_ITEM_YZNR     Varchar2(1024); 
  v_ITEM_MC       Varchar2(60); 
  n_ITEM_BGLX     Number(18); 
  v_ITEM_BGR      Varchar2(64); 
  v_ITEM_BGSJ     Varchar2(64); 
 
Begin 
 
    Select Count(*) Into n_Count From user_tables Where table_name =Upper('zlTempReportListEx'); 
 
    if n_Count > 0 then 
      v_sql := 'Truncate Table zlTempReportListEx'; 
      Execute Immediate v_sql; 
      Commit; 
    Else 
      v_sql := 'Create Global Temporary Table zlTempReportListEx(
               ID Varchar2(64),
               YZID Number(18),
               YZNR Varchar2(1024),
               MC Varchar2(60),
               BGLX Number(1),
               BGR Varchar2(64),
               BGSJ Date
              ) On Commit Preserve Rows'; 
 
      Execute Immediate v_sql; 
    End if; 
 
    v_Sql := 'Insert Into zlTempReportListEx(Id, YZID, YZNR, MC, BGLX, BGR, BGSJ)
                           Select b.病历id || '''' As ID, a.Id As YZID, a.医嘱内容 As YXNR, c.病历名称 as MC, 0 As BGLX, c.保存人 As BGR, c.完成时间 As BGSJ
                           From 病人医嘱记录 A, 病人医嘱报告 B, 电子病历记录 C, 影像检查记录 D, 病人医嘱发送 E
                           Where a.Id = b.医嘱id And b.病历id = c.Id And A.Id=E.医嘱ID And a.诊疗类别 = ''D'' And 相关id Is Null And B.RISID Is Null And
                           c.完成时间 Is Not Null And a.Id = d.医嘱id(+) And a.医嘱期效 = 1 And a.医嘱状态 In (3, 5, 6, 7, 8) And E.执行状态 = 1 And
                           a.ID = :1'; 
    Begin 
        Execute Immediate v_Sql Using 医嘱ID_In; 
    Exception 
      When Others Then 
        Begin 
          v_Sql := 'Insert Into zlTempReportListEx(Id, YZID, YZNR, MC, BGLX, BGR, BGSJ)
                                 Select b.病历id || '''' As ID, a.Id As YZID, a.医嘱内容 As YZNR, c.病历名称 As MC, 0 As BGLX, c.保存人 As BGR, c.完成时间 As BGSJ
                                 From 病人医嘱记录 A, 病人医嘱报告 B, 电子病历记录 C, 影像检查记录 D, 病人医嘱发送 E
                                 Where a.Id = b.医嘱id And b.病历id = c.Id And A.Id=E.医嘱ID And a.诊疗类别 = ''D'' And 相关id Is Null And
                                 c.完成时间 Is Not Null And a.Id = d.医嘱id(+) And a.医嘱期效 = 1 And a.医嘱状态 In (3, 5, 6, 7, 8) And E.执行状态 = 1 And
                                 a.id = :1'; 
          Execute Immediate v_Sql Using 医嘱ID_In; 
        Exception 
          When Others Then Null; 
        end; 
    End; 
 
 
    v_Sql := 'Insert Into zlTempReportListEx(Id, YZID, YZNR, MC, BGLX, BGR, BGSJ)
                          Select b.检查报告id || '''' As ID, a.Id As YZID, a.医嘱内容 As YZNR, c.文档标题 As MC, 1 as BGLX, c.最后编辑人 As BGR, c.最后审核时间 As BGSJ
                          From 病人医嘱记录 A, 病人医嘱报告 B, 影像报告记录 C, 影像检查记录 D, 病人医嘱发送 E
                          where a.Id = b.医嘱id And b.检查报告id = c.Id And A.Id=E.医嘱ID And a.诊疗类别 = ''D'' And 相关id Is Null And
                          c.最后审核时间 Is Not Null And a.Id = d.医嘱id(+) And a.医嘱期效 = 1 And a.医嘱状态 In (3, 5, 6, 7, 8) And E.执行状态 = 1 And
                          a.id = :1'; 
    Begin 
        Execute Immediate v_Sql Using 医嘱ID_In; 
    Exception 
      When Others Then Null; 
    End; 
 
 
    v_Sql := 'Insert Into zlTempReportListEx(Id, YZID, YZNR, MC, BGLX, BGR, BGSJ)
                          Select b.RISID || '''' As ID, a.Id As YZID, a.医嘱内容 As YZNR, c.病历名称 As MC, 2 as BGLX, c.保存人 As BGR, c.完成时间 As BGSJ
                          From 病人医嘱记录 A, 病人医嘱报告 B, 电子病历记录 C, 影像检查记录 D, 病人医嘱发送 E
                          Where a.Id = b.医嘱id And b.病历ID = c.Id And A.Id=E.医嘱ID And a.诊疗类别 = ''D'' And 相关id Is Null And B.RISID Is Not Null And
                          c.完成时间 Is Not Null And a.Id = d.医嘱id(+) And a.医嘱期效 = 1 And a.医嘱状态 In (3, 5, 6, 7, 8) And E.执行状态 = 1 And
                          a.id = :1'; 
    Begin 
        Execute Immediate v_Sql Using 医嘱ID_In; 
    Exception 
      When Others Then Null; 
    End; 
 
    Commit; 
 
    v_Sql := 'Select Id, YZID, YZNR, MC, BGLX, BGR, To_Char(BGSJ,''yyyy-mm-dd hh24:mi:ss'') As BGSJ  From zlTempReportListEx Order by BGSJ'; 
 
    Open C_REPORT_ITEM For v_Sql; 
    Loop 
      Fetch C_REPORT_ITEM INTO n_ITEM_ID, n_ITEM_YZID, v_ITEM_YZNR, v_ITEM_MC, n_ITEM_BGLX, v_ITEM_BGR, v_ITEM_BGSJ; 
      Exit When C_REPORT_ITEM%NotFound; 
 
      v_Temp := '<FILE>' || 
                      '<ID>' || n_ITEM_ID || '</ID>' || 
                      '<YZID>' || n_ITEM_YZID || '</YZID>' || 
                      '<YZNR>' || v_ITEM_YZNR || '</YZNR>' || 
                      '<MC>' || v_ITEM_MC || '</MC>' || 
                      '<BGLX>' || n_ITEM_BGLX || '</BGLX>' || 
                      '<BGR>' || v_ITEM_BGR || '</BGR>' || 
                      '<BGSJ>' || v_ITEM_BGSJ || '</BGSJ>' || 
             '</FILE>'; 
 
      v_Return := v_Return || v_Temp; 
    End Loop; 
    Close C_REPORT_ITEM; 
 
    If v_Return <> ' ' Then 
      v_Return := '<FILELIST>' || v_Return || '</FILELIST>'; 
    End If; 
 
    Return v_Return; 
 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zlpub_Pacs_获取报告列表Ex;
/

