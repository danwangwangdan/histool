create Function Zlpub_Pacs_获取报告提纲 
( 
  报告id_In In Varchar2, 
  报告来源_In In Number 
) Return Varchar2 Is 
  v_报告提纲 Varchar2(2000); 
  n_病历ID Number(18); 
 
  v_Sql Varchar2(100); 
Begin 
  If 报告来源_In = 1 Then 
    v_Sql := 'Select Zlpub_Pacs_获取文档提纲(:1)  From Dual'; 
    Begin 
        Execute Immediate v_Sql Into v_报告提纲 Using 报告id_In ; 
    Exception 
      When Others Then v_报告提纲 := ''; 
    End; 
  Else 
    n_病历ID := To_Number(报告id_In); 
 
    If 报告来源_In = 2 Then 
      v_Sql := 'Select 病历ID From 病人医嘱报告 Where RISID=:1'; 
      Execute Immediate v_Sql Into n_病历ID Using 报告id_In ; 
    End If; 
 
    v_Sql := 'Select Zlpub_Pacs_获取病历提纲(:1)  From Dual'; 
    Begin 
        Execute Immediate v_Sql Into v_报告提纲 Using n_病历ID ; 
    Exception 
      When Others Then v_报告提纲 := ''; 
    End; 
  End If; 
 
  Return v_报告提纲; 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zlpub_Pacs_获取报告提纲;
/

