create Function Zlpub_Pacs_获取报告文本 
( 
  Ids_In In Varchar2, 
  From_In Number 
) Return Xmltype Is 
--Ids_In规则是以 '|' 分隔的ID串，开始/结尾无 '|' 
  --根所给定的病历文件ID串生成内容XML并返回XMLType 
  Docxml XmlType; 
  v_Sql Varchar2(1000); 
Begin 
 
  If From_In = 1 Then 
    v_Sql := 'Select Zlpub_Pacs_获取文档文本(:1) From Dual'; 
    Execute Immediate v_Sql Into Docxml Using Ids_In; 
  Else 
    v_Sql := 'Select Zlpub_Pacs_获取病历文本(:1, :2) From Dual'; 
    Execute Immediate v_Sql Into Docxml Using Ids_In, From_In; 
  End If; 
 
  Return Docxml; 
Exception 
  When Others Then 
    Return Null; 
End Zlpub_Pacs_获取报告文本;
/

