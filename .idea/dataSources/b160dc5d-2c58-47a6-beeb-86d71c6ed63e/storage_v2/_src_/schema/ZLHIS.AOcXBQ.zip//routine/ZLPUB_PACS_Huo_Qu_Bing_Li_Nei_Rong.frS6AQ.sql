create Function Zlpub_Pacs_获取病历内容 
( 
  报告ID_In   In Number, 
  报告来源_In In Number, 
  报告提纲_In In Varchar2 
) Return Varchar2 Is 
  Type t_Str_Table Is Table Of Varchar2(4000); 
  a_Return t_Str_Table := t_Str_Table(); 
 
  v_Return        Varchar2(4000); 
  v_Temp          Varchar2(4000); 
  n_Count         Number(2); 
  n_病历ID        Number(18); 
 
  v_Sql           Varchar2(1000); 
Begin 
  n_病历ID := 报告id_In; 
  v_Return       := ''; 
 
  If 报告来源_In = 2 Then 
     v_Sql := 'Select 病历ID From 病人医嘱报告 Where RISID=:1'; 
     Execute Immediate v_Sql Into n_病历ID Using 报告id_In; 
  End If; 
 
  Begin 
    Select Decode(是否换行, 1, 内容文本 || Chr(10) || Chr(13), 内容文本) Bulk Collect 
    Into a_Return 
    From 电子病历内容 
    Where 终止版 = 0  And 对象类型 In(2,4) And 文件id = n_病历ID 
    Start With  父id = (Select ID From 电子病历内容 Where 文件id = n_病历ID And 内容文本 = 报告提纲_In And 对象类型 = 1) 
    Connect By Prior ID=父ID 
    Order By 对象序号; 
 
    For n_Count In 1 .. a_Return.Count Loop 
      If v_Return Is Null Then 
        If n_Count = 1 Then 
          v_Temp := a_Return(n_Count); 
          If Instr(v_Temp,报告提纲_In) <> 1 Then 
            v_Return := v_Temp; 
          End If; 
        Else 
          v_Return := a_Return(n_Count); 
        End If; 
 
      Else 
        v_Return := v_Return || a_Return(n_Count); 
      End If; 
    End Loop; 
 
  Exception 
    When Others Then 
      v_Return := Null; 
  End; 
 
  Begin 
    If v_Return Is Null Then 
      Select Decode(是否换行, 1, 内容文本 || Chr(10) || Chr(13), 内容文本) Bulk Collect 
      Into a_Return 
      From 电子病历内容 
      Where 终止版 = 0  And 对象类型 In(2,4) And 文件id = n_病历ID 
      Start With  父id = (Select ID From 电子病历内容 Where 文件id = n_病历ID And 内容文本 = 报告提纲_In And 对象类型 = 3) 
      Connect By Prior ID=父ID 
      Order By 对象序号; 
 
      For n_Count In 1 .. a_Return.Count Loop 
        If v_Return Is Null Then 
          v_Return := a_Return(n_Count); 
        Else 
          v_Return := v_Return || a_Return(n_Count); 
        End If; 
      End Loop; 
 
    End If; 
  Exception 
    When Others Then 
      v_Return := Null; 
  End; 
 
  If v_Return Is Null Then 
    Select Decode(是否换行, 1, 内容文本 || Chr(10) || Chr(13), 内容文本) Bulk Collect 
    Into a_Return 
    From 电子病历内容 
    Where 终止版 = 0  And Substr(对象属性,1,1) = '0' And 文件id = n_病历ID 
    Start With  父id = (Select ID From 电子病历内容 Where 文件id = n_病历ID And 内容文本 = 报告提纲_In And 对象类型 = 1) 
    Connect By Prior ID=父ID 
    Order By 对象序号; 
 
    For n_Count In 1 .. a_Return.Count Loop 
        If v_Return Is Null Then 
          If n_Count = 1 Then 
            v_Temp := a_Return(n_Count); 
            If Instr(v_Temp,报告提纲_In) <> 1 Then 
              v_Return := v_Temp; 
            End If; 
          Else 
            v_Return := a_Return(n_Count); 
          End If; 
 
        Else 
          v_Return := v_Return || a_Return(n_Count); 
        End If; 
    End Loop; 
  End If; 
 
  Return v_Return; 
End Zlpub_Pacs_获取病历内容;
/

