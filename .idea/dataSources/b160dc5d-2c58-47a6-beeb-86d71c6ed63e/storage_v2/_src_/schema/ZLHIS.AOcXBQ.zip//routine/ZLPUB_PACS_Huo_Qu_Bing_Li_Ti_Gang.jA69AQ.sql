create Function Zlpub_Pacs_获取病历提纲 
( 
  报告id_In In 病人医嘱报告.病历id%Type 
) Return Varchar2 Is 
  v_报告提纲 Varchar2(1000); 
 
  Cursor c_报告提纲 Is 
    Select Distinct a.内容文本 
    From 电子病历内容 A, 电子病历内容 B, 病人医嘱报告 C 
    Where a.对象类型 = 3 And a.Id = b.父id And b.对象类型 = 2 And b.终止版 = 0 And a.文件id = c.病历id And c.病历id = 报告id_In; 
Begin 
  For Row_Cols In c_报告提纲 Loop 
    v_报告提纲 := '<split>' || Row_Cols.内容文本 || v_报告提纲; 
  End Loop; 
 
  Return(Substr(v_报告提纲, 8)); 
 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zlpub_Pacs_获取病历提纲;
/

