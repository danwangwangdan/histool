create Function Zlpub_Pacs_获取病历文本 
( 
  Ids_In   In Varchar2, 
  From_In Number 
)Return XmlType Is 
  Docxml XmlType; 
 
  File_Id Varchar2(32); 
  n_Adviceid Number(18); 
 
  v_Sql        Varchar2(1000); 
 
  --标记变量 
  v_Mark     Varchar2(500); 
  v_Marks    Varchar2(2500); 
  Makxml     Xmltype; 
  Maksxml    Xmltype; 
  v_Ftppath  Varchar2(200); 
 
  v_Newline Varchar2(2); 
Begin 
  Select Xmltype('<?xml version="1.0" encoding="' || Value || '"?><ZlEPR></ZlEPR>') 
  Into Docxml 
  From Nls_Database_Parameters 
  Where Parameter = 'NLS_CHARACTERSET'; 
 
  For J In 1 .. 1000 Loop 
    File_Id := 0; 
    Select Zl_Eprsplit(Ids_In, '|', J) Into File_Id From Dual; 
 
    If File_Id Is Null Then 
      Exit; 
    End If; 
 
    If From_In = 2 Then 
       --RIS报告 
       v_Sql := 'Select 病历Id From 病人医嘱报告 Where RISID = :1'; 
       Execute Immediate v_Sql Into File_Id Using File_Id; 
    End If; 
 
    --开始某个病历文件读取 
    Begin 
      Select Appendchildxml(Docxml, '/ZlEPR', 
                             Xmlelement("Document", 
                                         Xmlattributes(b.姓名 As "姓名", a.病人id As "病人ID", a.主页id As "主页ID", a.病历名称 As "文件名", 
                                                        a.Id As "文件ID"))) 
      Into Docxml 
      From 电子病历记录 A, 病人信息 B 
      Where a.Id = File_Id And a.编辑方式 = 0 And a.病人id = b.病人id; 
 
      Select 医嘱id Into n_Adviceid From 病人医嘱报告 Where 病历id = File_Id; 
    Exception 
      --给定的病历文件ID无效 
      When Others Then Return Null; 
    End; 
 
    Select Insertchildxml(Docxml, '/ZlEPR/Document[@文件ID="' || File_Id || '"]', 'Compend', 
                           Xmlelement("Compend", Xmlattributes('0' As "ID", '内容' As "Name"))) 
    Into Docxml 
    From Dual; 
 
    Select Appendchildxml(Docxml, '/ZlEPR/Document[@文件ID=' || File_Id || ']/Compend[@ID=0]', 
                           Xmlelement("Text", Xmlattributes(Nvl(Null, 0) As "NewLine"), '内容文本')) 
    Into Docxml 
    From Dual; 
 
    For Rs In (Select ID, 父id, 对象序号, 对象类型, 对象属性, 内容行次, 内容文本, 是否换行, 要素名称 
               From (Select ID, 父id, 对象序号, 对象类型, 对象属性, 内容行次, 内容文本, 是否换行, 要素名称 
                      From 电子病历内容 
                      Where 文件id = File_Id And 对象序号 > 0 And 对象序号 <> ID And 终止版 = 0) 
               Start With 父id Is Null 
               Connect By Prior ID = 父id 
               Order Siblings By 对象序号, 内容行次) Loop 
      If Rs.对象类型 = 1 Then 
        --提纲 
        If Rs.父id Is Null Then 
          Select Appendchildxml(Docxml, '/ZlEPR/Document[@文件ID=' || File_Id || ']', 
                                 Xmlelement("Compend", Xmlattributes(Rs.内容文本 As "Name", Rs.Id As "ID"))) 
          Into Docxml 
          From Dual; 
        Else 
          Select Appendchildxml(Docxml, 
                                 '/ZlEPR/Document[@文件ID=' || File_Id || ']/descendant::Compend[@ID=' || Rs.父id || ']', 
                                 Xmlelement("Compend", Xmlattributes(Rs.内容文本 As "Name", Rs.Id As "ID"))) 
          Into Docxml 
          From Dual; 
        End If; 
      Elsif Rs.对象类型 = 2 Then 
        --文本 
        If Rs.父id Is Null Then 
          Select Appendchildxml(Docxml, '/ZlEPR/Document[@文件ID=' || File_Id || ']/Compend[@ID=0]', 
                                 Xmlelement("Text", Xmlattributes(Nvl(Rs.是否换行, 0) As "NewLine"), Rs.内容文本)) 
          Into Docxml 
          From Dual; 
        Else 
          Select Appendchildxml(Docxml, 
                                 '/ZlEPR/Document[@文件ID=' || File_Id || ']/descendant::Compend[@ID=' || Rs.父id || ']', 
                                 Xmlelement("Text", Xmlattributes(Nvl(Rs.是否换行, 0) As "NewLine"), Rs.内容文本)) 
          Into Docxml 
          From Dual; 
        End If; 
      Elsif Rs.对象类型 = 3 Then 
        --表格 
        If Rs.父id Is Null Then 
          Select Appendchildxml(Docxml, '/ZlEPR/Document[@文件ID=' || File_Id || ']/Compend[@ID=0]', 
                                 Xmlelement("Table", 
                                             Xmlattributes(Zl_Eprsplit(Rs.对象属性, ';', 1) As "Rows", 
                                                            Zl_Eprsplit(Rs.对象属性, ';', 2) As "Cols", 
                                                            Zl_Eprsplit(Rs.对象属性, ';', 3) As "Width", 
                                                            Zl_Eprsplit(Rs.对象属性, ';', 4) As "Height", 
                                                            Zl_Eprsplit(Rs.对象属性, ';', 5) As "ColWidthString", 
                                                            Nvl(Rs.是否换行, 0) As "NewLine", Rs.Id As "ID"), Rs.内容文本)) 
          Into Docxml 
          From Dual; 
        Else 
          Select Appendchildxml(Docxml, 
                                 '/ZlEPR/Document[@文件ID=' || File_Id || ']/descendant::Compend[@ID=' || Rs.父id || ']', 
                                 Xmlelement("Table", 
                                             Xmlattributes(Zl_Eprsplit(Rs.对象属性, ';', 1) As "Rows", 
                                                            Zl_Eprsplit(Rs.对象属性, ';', 2) As "Cols", 
                                                            Zl_Eprsplit(Rs.对象属性, ';', 3) As "Width", 
                                                            Zl_Eprsplit(Rs.对象属性, ';', 4) As "Height", 
                                                            Zl_Eprsplit(Rs.对象属性, ';', 5) As "ColWidthString", 
                                                            Nvl(Rs.是否换行, 0) As "NewLine", Rs.Id As "ID"), Rs.内容文本)) 
          Into Docxml 
          From Dual; 
        End If; 
 
        ---对表格的单元格进行填充 
        For Rs_Cell In (Select ID, 父id, 对象序号, 对象类型, 对象属性, 内容行次, 内容文本, 是否换行, 要素名称 
                        From 电子病历内容 
                        Where 文件id = File_Id And 父id = Rs.Id And 终止版 = 0 
                        Order By 内容行次, ID) Loop 
          If Rs_Cell.对象类型 = 2 Or Rs_Cell.对象类型 = 4 Then 
            If Zl_Eprsplit(Rs_Cell.对象属性, '|', 26) Is Null Then 
              --兼容历史病历 
              Select Appendchildxml(Docxml, 
                                     '/ZlEPR/Document[@文件ID=' || File_Id || ']/descendant::Table[@ID=' || Rs.Id || ']', 
                                     Xmlelement("Cell", 
                                                 Xmlattributes(Zl_Eprsplit(Rs_Cell.对象属性, '|', 2) As "Row", 
                                                                Zl_Eprsplit(Rs_Cell.对象属性, '|', 3) As "Col", 
                                                                Zl_Eprsplit(Rs_Cell.对象属性, '|', 2) || '_' || 
                                                                 Zl_Eprsplit(Rs_Cell.对象属性, '|', 3) As "Row_Col", 
                                                                Decode(Rs_Cell.对象类型, 2, 0, 4, 1) As "Type", 
                                                                Zl_Eprsplit(Rs_Cell.对象属性, '|', 5) As "Width", 
                                                                Zl_Eprsplit(Rs_Cell.对象属性, '|', 6) As "Height", 
                                                                Zl_Eprsplit(Rs_Cell.对象属性, '|', 4) As "MergeNo", 
                                                                Nvl(Rs.是否换行, 0) As "NewLine", Rs_Cell.Id As "ID"), 
                                                 Rs_Cell.内容文本)) 
              Into Docxml 
              From Dual; 
            Else 
              Select Appendchildxml(Docxml, 
                                     '/ZlEPR/Document[@文件ID=' || File_Id || ']/descendant::Table[@ID=' || Rs.Id || ']', 
                                     Xmlelement("Cell", 
                                                 Xmlattributes(Zl_Eprsplit(Rs_Cell.对象属性, '|', 3) As "Row", 
                                                                Zl_Eprsplit(Rs_Cell.对象属性, '|', 4) As "Col", 
                                                                Zl_Eprsplit(Rs_Cell.对象属性, '|', 3) || '_' || 
                                                                 Zl_Eprsplit(Rs_Cell.对象属性, '|', 4) As "Row_Col", 
                                                                Decode(Rs_Cell.对象类型, 2, 0, 4, 1) As "Type", 
                                                                Zl_Eprsplit(Rs_Cell.对象属性, '', 6) As "Width", 
                                                                Zl_Eprsplit(Rs_Cell.对象属性, '|', 7) As "Height", 
                                                                Zl_Eprsplit(Rs_Cell.对象属性, '|', 5) As "MergeNo", 
                                                                Nvl(Rs.是否换行, 0) As "NewLine", Rs_Cell.Id As "ID"), 
                                                 Rs_Cell.内容文本)) 
              Into Docxml 
              From Dual; 
            End If; 
          Elsif Rs_Cell.对象类型 = 5 And Zl_Eprsplit(Rs_Cell.对象属性, ';', 1) = 2 Then 
            --单元格图由Webservice直接读取BLOB之后直接写文件以提高速度 
            Select Appendchildxml(Docxml, 
                                   '/ZlEPR/Document[@文件ID=' || File_Id || ']/descendant::Table[@ID=' || Rs.Id || ']', 
                                   Xmlelement("Picture", 
                                               Xmlattributes(Zl_Eprsplit(Rs_Cell.对象属性, ';', 2) As "Row", 
                                                              Zl_Eprsplit(Rs_Cell.对象属性, ';', 3) As "Col", 
                                                              Zl_Eprsplit(Rs_Cell.对象属性, ';', 8) As "OrigWidth", 
                                                              Zl_Eprsplit(Rs_Cell.对象属性, ';', 9) As "OrigHeight", 
                                                              Zl_Eprsplit(Rs_Cell.对象属性, ';', 6) As "ShowWidth", 
                                                              Zl_Eprsplit(Rs_Cell.对象属性, ';', 7) As "ShowHeight", 
                                                              Nvl(Zl_Eprsplit(Rs_Cell.对象属性, ';', 12), ' ') As "PicName", 
                                                              Nvl(Zl_Eprsplit(Rs_Cell.对象属性, ';', 13), '0') As "AdviceID", 
                                                              Rs_Cell.Id As "ID"), Rs_Cell.Id)) 
            Into Docxml 
            From Dual; 
 
            If Nvl(n_Adviceid, 0) = 0 Then 
              n_Adviceid := Nvl(Zl_Eprsplit(Rs_Cell.对象属性, ';', 13), '0'); 
            End If; 
          Elsif Rs_Cell.对象类型 = 5 And Zl_Eprsplit(Rs_Cell.对象属性, ';', 1) <> 2 Then 
            --单元格图由Webservice直接读取BLOB之后直接写文件以提高速度 
            Select Appendchildxml(Docxml, 
                                   '/ZlEPR/Document[@文件ID=' || File_Id || ']/descendant::Table[@ID=' || Rs.Id || 
                                    ']/Cell[@Row_Col="' || Zl_Eprsplit(Rs_Cell.对象属性, ';', 2) || '_' || 
                                    Zl_Eprsplit(Rs_Cell.对象属性, ';', 3) || '"]', 
                                   Xmlelement("Picture", 
                                               Xmlattributes(Zl_Eprsplit(Rs_Cell.对象属性, ';', 2) As "Row", 
                                                              Zl_Eprsplit(Rs_Cell.对象属性, ';', 3) As "Col", 
                                                              Zl_Eprsplit(Rs_Cell.对象属性, ';', 8) As "OrigWidth", 
                                                              Zl_Eprsplit(Rs_Cell.对象属性, ';', 9) As "OrigHeight", 
                                                              Zl_Eprsplit(Rs_Cell.对象属性, ';', 6) As "ShowWidth", 
                                                              Zl_Eprsplit(Rs_Cell.对象属性, ';', 7) As "ShowHeight", 
                                                              Nvl(Zl_Eprsplit(Rs_Cell.对象属性, ';', 12), ' ') As "PicName", 
                                                              Nvl(Zl_Eprsplit(Rs_Cell.对象属性, ';', 13), '0') As "AdviceID", 
                                                              Rs_Cell.Id As "ID"), Rs_Cell.Id)) 
            Into Docxml 
            From Dual; 
            --制作标记子节点集 
            v_Mark  := ''; 
            Makxml  := Null; 
            Maksxml := Null; 
            For Rs_Mark In (Select ID, 父id, 内容文本, 内容行次 
                            From 电子病历内容 
                            Where 父id = Rs_Cell.Id 
                            Order By 内容行次) Loop 
              v_Marks := v_Mark || Rs_Mark.内容文本; 
              v_Marks := Replace(v_Marks, '||', '^'); 
              For I In 1 .. 100 Loop 
                v_Mark := Zl_Eprsplit(v_Marks, '^', I); 
                If Zl_Eprsplit(v_Mark, '|', 15) Is Null Then 
                  --最后一个标记信息不全，存在下一行中 
                  Exit; 
                Else 
                  Select Xmlelement("Mark", 
                                     Xmlforest(Zl_Eprsplit(v_Mark, '|', 2) As "类型", 
                                                Zl_Eprsplit(v_Mark, '|', 3) As "内容", Zl_Eprsplit(v_Mark, '|', 4) As "点集", 
                                                Zl_Eprsplit(v_Mark, '|', 5) As "X1", Zl_Eprsplit(v_Mark, '|', 6) As "Y1", 
                                                Zl_Eprsplit(v_Mark, '|', 7) As "X2", Zl_Eprsplit(v_Mark, '|', 8) As "Y2", 
                                                Zl_Eprsplit(v_Mark, '|', 9) As "填充色", 
                                                Zl_Eprsplit(v_Mark, '|', 10) As "填充方式", 
                                                Zl_Eprsplit(v_Mark, '|', 11) As "线条色", 
                                                Zl_Eprsplit(v_Mark, '|', 12) As "字体色", 
                                                Zl_Eprsplit(v_Mark, '|', 13) As "线型", 
                                                Zl_Eprsplit(v_Mark, '|', 14) As "线宽", 
                                                Zl_Eprsplit(v_Mark, '|', 15) As "字体")) 
                  Into Makxml 
                  From Dual; 
                  Select Xmlconcat(Maksxml, Makxml) Into Maksxml From Dual; 
                End If; 
              End Loop; 
            End Loop; 
            --向Picture插入标记子节点 
            Select Appendchildxml(Docxml, 
                                   '/ZlEPR/Document[@文件ID=' || File_Id || ']/descendant::Picture[@ID=' || Rs_Cell.Id || ']', 
                                   Maksxml) 
            Into Docxml 
            From Dual; 
          End If; 
        End Loop; 
      Elsif Rs.对象类型 = 4 Then 
        --要素 
        If Rs.父id Is Null Then 
          Select Appendchildxml(Docxml, '/ZlEPR/Document[@文件ID=' || File_Id || ']/Compend[@ID=0]', 
                                 Xmlelement("Element", Xmlattributes(Rs.要素名称 As "Name", Nvl(Rs.是否换行, 0) As "NewLine"), 
                                             Rs.内容文本)) 
          Into Docxml 
          From Dual; 
        Else 
          Select Appendchildxml(Docxml, 
                                 '/ZlEPR/Document[@文件ID=' || File_Id || ']/descendant::Compend[@ID=' || Rs.父id || ']', 
                                 Xmlelement("Element", Xmlattributes(Rs.要素名称 As "Name", Nvl(Rs.是否换行, 0) As "NewLine"), 
                                             Rs.内容文本)) 
          Into Docxml 
          From Dual; 
        End If; 
      Elsif Rs.对象类型 = 5 And Nvl(Rs.内容行次, 0) = 0 Then 
        --图片由Webservice直接读取BLOB之后直接写文件以提高速度 
 
        If Rs.父id Is Null Then 
          Select Appendchildxml(Docxml, '/ZlEPR/Document[@文件ID=' || File_Id || ']/Compend[@ID=0]', 
                                 Xmlelement("Picture", 
                                             Xmlattributes(Zl_Eprsplit(Rs.对象属性, ';', 8) As "OrigWidth", 
                                                            Zl_Eprsplit(Rs.对象属性, ';', 9) As "OrigHeight", 
                                                            Zl_Eprsplit(Rs.对象属性, ';', 6) As "ShowWidth", 
                                                            Zl_Eprsplit(Rs.对象属性, ';', 7) As "ShowHeight", 
                                                            Nvl(Zl_Eprsplit(Rs.对象属性, ';', 12), ' ') As "PicName", 
                                                            Nvl(Zl_Eprsplit(Rs.对象属性, ';', 13), '0') As "AdviceID", 
                                                            Nvl(Rs.是否换行, 0) As "NewLine", Rs.Id As "ID"), Rs.Id)) 
          Into Docxml 
          From Dual; 
        Else 
          Select Appendchildxml(Docxml, 
                                 '/ZlEPR/Document[@文件ID=' || File_Id || ']/descendant::Compend[@ID=' || Rs.父id || ']', 
                                 Xmlelement("Picture", 
                                             Xmlattributes(Zl_Eprsplit(Rs.对象属性, ';', 8) As "OrigWidth", 
                                                            Zl_Eprsplit(Rs.对象属性, ';', 9) As "OrigHeight", 
                                                            Zl_Eprsplit(Rs.对象属性, ';', 6) As "ShowWidth", 
                                                            Zl_Eprsplit(Rs.对象属性, ';', 7) As "ShowHeight", 
                                                            Nvl(Zl_Eprsplit(Rs.对象属性, ';', 12), ' ') As "PicName", 
                                                            Nvl(Zl_Eprsplit(Rs.对象属性, ';', 13), '0') As "AdviceID", 
                                                            Nvl(Rs.是否换行, 0) As "NewLine", Rs.Id As "ID"), Rs.Id)) 
          Into Docxml 
          From Dual; 
        End If; 
        --制作标记子节点集 
        v_Mark  := ''; 
        Makxml  := Null; 
        Maksxml := Null; 
        For Rs_Mark In (Select ID, 父id, 内容文本, 内容行次 From 电子病历内容 Where 父id = Rs.Id Order By 内容行次) Loop 
          v_Marks := v_Mark || Rs_Mark.内容文本; 
          v_Marks := Replace(v_Marks, '||', '^'); 
          For I In 1 .. 100 Loop 
            v_Mark := Zl_Eprsplit(v_Marks, '^', I); 
            If Zl_Eprsplit(v_Mark, '|', 15) Is Null Then 
              --最后一个标记信息不全，存在下一行中 
              Exit; 
            Else 
              Select Xmlelement("Mark", 
                                 Xmlforest(Zl_Eprsplit(v_Mark, '|', 2) As "类型", Zl_Eprsplit(v_Mark, '|', 3) As "内容", 
                                            Zl_Eprsplit(v_Mark, '|', 4) As "点集", Zl_Eprsplit(v_Mark, '|', 5) As "X1", 
                                            Zl_Eprsplit(v_Mark, '|', 6) As "Y1", Zl_Eprsplit(v_Mark, '|', 7) As "X2", 
                                            Zl_Eprsplit(v_Mark, '|', 8) As "Y2", Zl_Eprsplit(v_Mark, '|', 9) As "填充色", 
                                            Zl_Eprsplit(v_Mark, '|', 10) As "填充方式", 
                                            Zl_Eprsplit(v_Mark, '|', 11) As "线条色", Zl_Eprsplit(v_Mark, '|', 12) As "字体色", 
                                            Zl_Eprsplit(v_Mark, '|', 13) As "线型", Zl_Eprsplit(v_Mark, '|', 14) As "线宽", 
                                            Zl_Eprsplit(v_Mark, '|', 15) As "字体")) 
              Into Makxml 
              From Dual; 
              Select Xmlconcat(Maksxml, Makxml) Into Maksxml From Dual; 
            End If; 
          End Loop; 
        End Loop; 
        --向Picture插入标记子节点 
        Select Appendchildxml(Docxml, 
                               '/ZlEPR/Document[@文件ID=' || File_Id || ']/descendant::Picture[@ID=' || Rs.Id || ']', 
                               Maksxml) 
        Into Docxml 
        From Dual; 
      Elsif Rs.对象类型 = 7 Then 
        --诊断 
        If Rs.父id Is Null Then 
          Select Appendchildxml(Docxml, '/ZlEPR/Document[@文件ID=' || File_Id || ']/Compend[@ID=0]', 
                                 Xmlelement("Diagnosise", Xmlattributes(Nvl(Rs.是否换行, 0) As "NewLine"), Rs.内容文本)) 
          Into Docxml 
          From Dual; 
        Else 
          Select Appendchildxml(Docxml, 
                                 '/ZlEPR/Document[@文件ID=' || File_Id || ']/descendant::Compend[@ID=' || Rs.父id || ']', 
                                 Xmlelement("Diagnosise", Xmlattributes(Nvl(Rs.是否换行, 0) As "NewLine"), Rs.内容文本)) 
          Into Docxml 
          From Dual; 
        End If; 
      Elsif Rs.对象类型 = 8 Then 
        --签名 
        If Rs.父id Is Null Then 
          Select Appendchildxml(Docxml, '/ZlEPR/Document[@文件ID=' || File_Id || ']/Compend[@ID=0]', 
                                 Xmlelement("Sign", Xmlattributes(Nvl(Rs.是否换行, 0) As "NewLine"), 
                                             Zl_Eprsplit(Rs.内容文本, ';', 1))) 
          Into Docxml 
          From Dual; 
        Else 
          Select Appendchildxml(Docxml, 
                                 '/ZlEPR/Document[@文件ID=' || File_Id || ']/descendant::Compend[@ID=' || Rs.父id || ']', 
                                 Xmlelement("Sign", Xmlattributes(Nvl(Rs.是否换行, 0) As "NewLine"), 
                                             Zl_Eprsplit(Rs.内容文本, ';', 1))) 
          Into Docxml 
          From Dual; 
        End If; 
      End If; 
    End Loop; 
 
    For Aa In (Select A1.Ftp目录 || '/' || To_Char(l.接收日期, 'yyyymmdd') || '/' || l.检查uid As v_Ftppath 
               From 影像检查记录 L, 影像设备目录 A1 
               Where l.位置一 = A1.设备号(+) And l.医嘱id = n_Adviceid) Loop 
 
      Select Appendchildxml(Docxml, '/ZlEPR/Document[@文件ID="' || File_Id || '"]/Compend[@ID=0]', 
                             Xmlelement("FtpPath", Xmlattributes(v_Newline As "NewLine"), Aa.v_Ftppath)) 
      Into Docxml 
      From Dual; 
    End Loop; 
 
  End Loop; 
 
  Return Docxml; 
End Zlpub_Pacs_获取病历文本;
/

