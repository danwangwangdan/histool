create Function Zlpub_Pacs_获取提纲内容 
( 
  报告id_In   In Varchar2, 
  报告来源_In In Number, 
  报告提纲_In In Varchar2 
) Return Varchar2 Is 
 
  v_Result        Varchar2(4000); 
  v_Singleresult  Varchar2(4000); 
  v_Sql           Varchar2(1000); 
 
Begin 
  v_Result       := ''; 
  v_Singleresult := ''; 
 
  If 报告来源_In = 1 Then 
    v_Sql := 'Select Zlpub_Pacs_获取文档内容(:1, :2) From Dual'; 
    Execute Immediate v_Sql Into v_Singleresult Using 报告id_In,报告提纲_In; 
  Else 
    v_Sql := 'Select Zlpub_Pacs_获取病历内容(:1, :2, :3) From Dual'; 
    Execute Immediate v_Sql Into v_Singleresult Using 报告id_In,报告来源_In, 报告提纲_In; 
  End If; 
 
  If v_Result Is Null And Not v_Singleresult Is Null Then 
    v_Result := v_Singleresult; 
  Elsif Not v_Singleresult Is Null Then 
    v_Result := v_Result || ';' || v_Singleresult; 
  End If; 
 
  Return v_Result; 
 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zlpub_Pacs_获取提纲内容;
/

