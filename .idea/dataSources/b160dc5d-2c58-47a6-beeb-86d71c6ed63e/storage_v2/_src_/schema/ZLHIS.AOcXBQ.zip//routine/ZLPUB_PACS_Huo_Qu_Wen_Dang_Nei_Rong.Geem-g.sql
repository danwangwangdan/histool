create Function Zlpub_Pacs_获取文档内容 
( 
  报告ID_In In 影像报告记录.ID%Type, 
  报告提纲_In In 影像报告记录.诊断意见%Type 
) Return Varchar2 Is 
  x_Content        xmltype; 
  Xcdom            Xmldom.Domdocument; 
  Section_List     Xmldom.Domnodelist; 
  Section_Node     Xmldom.Domnode; 
  Node_List        Xmldom.Domnodelist; 
  n_Len            Number; 
  Element_Node     Xmldom.Domnode; 
  p_Node           Xmldom.Domnode; 
  Enum_Node        Xmldom.Domnode; 
  e_Node           Xmldom.Domnodelist; 
  c_Node           Xmldom.Domnode; 
  Enumeration_List Xmldom.Domnodelist; 
  Enumeration_Node Xmldom.Domnode; 
  Item_List        Xmldom.Domnodelist; 
  Item_Node        Xmldom.Domnode; 
  Item_Node1       Xmldom.Domnode; 
  v_Name           Varchar2(100); 
  v_Result         Varchar2(4000); 
  n_i              Number; 
  n_Num            Number; 
  n_j              Number; 
  n_Enum           Number; 
  v_Val            Varchar2(20); 
  v_Content        Varchar2(4000); 
  v_Eleid          Varchar2(50); 
  v_Multisel       Varchar2(10); 
Begin 
    v_Result := ''; 
 
    Select 报告内容 Into x_Content From 影像报告记录 Where id = 报告ID_In; 
 
    Select Deletexml(x_Content, '//image') Into x_Content From Dual; 
 
    Xcdom := Xmldom.Newdomdocument(x_Content); 
 
    For Myrow In (Select Column_Value Name From Table(f_Str2list(报告提纲_In))) Loop 
      n_i := -1; 
      --循环提纲名称 
      Section_List := Xmldom.Getelementsbytagname(Xcdom, 'section'); 
      n_Len        := Xmldom.Getlength(Section_List); 
 
      For I In 0 .. n_Len - 1 Loop 
        If Xmldom.Getattribute(Xmldom.Makeelement(Xmldom.Item(Section_List, I)), 'title') = Myrow.Name Then 
          n_i := I; 
          Exit; 
        End If; 
      End Loop; 
 
      If n_i >= 0 Then 
        Section_Node := Xmldom.Item(Section_List, n_i); 
        Node_List    := Xmldom.Getelementsbytagname(Xmldom.Makeelement(Section_Node), '*'); 
        n_Len        := Xmldom.Getlength(Node_List); 
 
        For I In 0 .. n_Len - 1 Loop 
          Element_Node := Xmldom.Item(Node_List, I); 
          v_Name       := Xmldom.Getnodename(Element_Node); 
 
          If v_Name = 'element' Then 
            If Xmldom.Getattribute(Xmldom.Makeelement(Element_Node), 'unit') Is Not Null Then 
              v_Content := Xmldom.Getnodevalue(Xmldom.Getfirstchild(Element_Node)); 
 
              If Instr(v_Content, 'textstyleno') > 0 Then 
                v_Content := ''; 
              End If; 
              --如果有单位 
              v_Result := v_Result || v_Content || Xmldom.Getattribute(Xmldom.Makeelement(Element_Node), 'unit'); 
            Else 
              p_Node := Xmldom.Getparentnode(Element_Node); 
              If Xmldom.Getnodename(p_Node) <> 'enumvalues' Then 
                v_Result := v_Result || Xmldom.Getnodevalue(Xmldom.Getfirstchild(Element_Node)); 
              End If; 
            End If; 
          Elsif v_Name = 'utext' Then 
            v_Result := v_Result || LTrim(LTrim(Xmldom.Getnodevalue(Xmldom.Getfirstchild(Element_Node)), ':'), '：'); 
          Elsif v_Name = 'e_list' Or v_Name = 'e_enum' Or v_Name = 'e_etree' Or v_Name = 'e_utree' Then 
            Enumeration_List := Xmldom.Getelementsbytagname(Xmldom.Makeelement(Element_Node), 'enumeration'); 
            n_Num            := Xmldom.Getlength(Enumeration_List); 
 
            If v_Name = 'e_enum' And n_Num > 0 Then 
              For J In 0 .. n_Num - 1 Loop 
                Enumeration_Node := Xmldom.Item(Enumeration_List, J); 
                Item_List        := Xmldom.Getelementsbytagname(Xmldom.Makeelement(Element_Node), 'item'); 
                n_j              := Xmldom.Getlength(Item_List); 
 
                For K In 0 .. n_j - 1 Loop 
                  Item_Node := Xmldom.Item(Item_List, K); 
                  If Xmldom.Getattribute(Xmldom.Makeelement(Item_Node), 'checked') = '1' Then 
                    v_Val := Xmldom.Getattribute(Xmldom.Makeelement(Item_Node), 'val'); 
 
                    For Z In 0 .. n_j - 1 Loop 
                      Item_Node1 := Xmldom.Item(Item_List, Z); 
                      If Xmldom.Getattribute(Xmldom.Makeelement(Item_Node1), 'val') = v_Val And 
                         Xmldom.Getattribute(Xmldom.Makeelement(Item_Node1), 'issymbol') = '0' Then 
                        v_Result := v_Result || Xmldom.Getnodevalue(Xmldom.Getfirstchild(Item_Node1)); 
                        Exit; 
                      End If; 
                    End Loop; 
                  End If; 
                End Loop; 
              End Loop; 
            Else 
              --这里处理枚举有无的情况 
              v_Eleid := Xmldom.Getattribute(Xmldom.Makeelement(Element_Node), 'sid'); --获取元素ID 
 
              Select Extractvalue(b.值域描述, '/root/multisel') 
              Into v_Multisel 
              From 影像报告元素清单 A, 影像报告值域清单 B 
              Where a.值域id = b.id And a.id = Hextoraw(v_Eleid); 
 
              If v_Multisel = 2 And v_Name = 'e_enum' Then 
                --为是否类型的枚举 
                v_Result := v_Result || Xmldom.Getnodevalue(Xmldom.getLastChild(Element_Node)); 
              Else 
                Enum_Node := Xmldom.Item(Xmldom.Getelementsbytagname(Xmldom.Makeelement(Element_Node), 'enumvalues'), 0); 
                e_Node := Xmldom.Getelementsbytagname(Xmldom.Makeelement(Enum_Node), 'element'); 
                n_Enum := Xmldom.Getlength(e_Node); 
 
                For K In 0 .. n_Enum - 1 Loop 
                  c_Node   := Xmldom.Item(e_Node, K); 
                  v_Result := v_Result || Xmldom.Getattribute(Xmldom.Makeelement(c_Node), 'showtext'); 
 
                  If K <> n_Enum - 1 Then 
                    v_Result := v_Result || '、'; 
                  End If; 
                End Loop; 
              End If; 
            End If; 
          End If; 
        End Loop; 
      End If; 
    End Loop; 
 
    Xmldom.Freedocument(Xcdom); 
 
    Return translate(v_Result,chr(13)||chr(10),','); 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zlpub_Pacs_获取文档内容;
/

