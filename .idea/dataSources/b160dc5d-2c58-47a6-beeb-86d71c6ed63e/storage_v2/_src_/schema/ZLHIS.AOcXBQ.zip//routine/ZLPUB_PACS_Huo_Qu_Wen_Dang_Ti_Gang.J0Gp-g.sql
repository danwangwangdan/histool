create Function Zlpub_Pacs_获取文档提纲 
( 
  报告id_In In 病人医嘱报告.检查报告ID%Type 
) Return Varchar2 Is 
  v_报告提纲 Varchar2(1000); 
  v_提纲内容 Varchar2(100); 
 
  x_Content xmltype; 
  n_NodeNum number(2); 
  Xcdom            Xmldom.Domdocument; 
  Section_List     Xmldom.Domnodelist; 
Begin 
    v_报告提纲 := ''; 
 
    Select b.报告内容 Into x_Content From 病人医嘱报告 a, 影像报告记录 b Where a.检查报告id=b.id And  a.检查报告id = 报告id_In; 
 
    Xcdom         := Xmldom.Newdomdocument(x_Content); 
    Section_List  := Xmldom.Getelementsbytagname(Xcdom, 'section'); 
    n_NodeNum     := Xmldom.Getlength(Section_List); 
 
    For i in 0..n_NodeNum-1 Loop 
      v_提纲内容 := Xmldom.Getattribute(Xmldom.Makeelement(Xmldom.Item(Section_List, i)), 'title'); 
 
      If Nvl(v_提纲内容,' ') != ' ' Then 
        v_报告提纲 := v_报告提纲 || '<split>' || v_提纲内容; 
      End If; 
    End Loop; 
 
    Return(Substr(v_报告提纲, 8)); 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zlpub_Pacs_获取文档提纲;
/

