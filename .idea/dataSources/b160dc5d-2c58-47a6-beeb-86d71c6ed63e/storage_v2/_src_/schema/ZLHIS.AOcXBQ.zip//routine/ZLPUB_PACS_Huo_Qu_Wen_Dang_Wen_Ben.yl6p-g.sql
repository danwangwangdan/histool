create Function Zlpub_Pacs_获取文档文本 
( 
  Ids_In   In Varchar2 
)Return XmlType Is 
  Docxml XmlType; 
 
  File_Id Varchar2(32); 
  n_Adviceid Number(18); 
 
  x_Content    Xmltype; 
  Section_Node Xmldom.Domnode; 
  Element_Node Xmldom.Domnode; 
  Xcdom        Xmldom.Domdocument; 
  Node_List    Xmldom.Domnodelist; 
  Section_List Xmldom.Domnodelist; 
 
  n_Count Number(1); 
  --标记变量 
 
  n_Len     Number(3); 
  n_Width   Number(4); 
  n_Height  Number(4); 
  v_Id      Varchar2(100); 
  v_Title   Varchar2(100); 
  v_Newline Varchar2(2); 
  v_Text    Varchar2(4000); 
  v_Name    Varchar2(100); 
  v_Type    Varchar2(20); 
Begin 
  Select Xmltype('<?xml version="1.0" encoding="' || Value || '"?><ZlEPR></ZlEPR>') 
  Into Docxml 
  From Nls_Database_Parameters 
  Where Parameter = 'NLS_CHARACTERSET'; 
 
  For J In 1 .. 1000 Loop 
    File_Id := 0; 
    Select Zl_Eprsplit(Ids_In, '|', J) Into File_Id From Dual; 
 
    If File_Id Is Null Then 
      Exit; 
    End If; 
 
    --开始某个文件读取 
    Begin 
      Select a.医嘱id, 
             Appendchildxml(Docxml, '/ZlEPR', 
                             Xmlelement("Document", 
                                         Xmlattributes(b.姓名 As "姓名", b.病人id As "病人ID", b.主页id As "主页ID", a.文档标题 As "文件名", 
                                                        Rawtohex(a.Id) As "文件ID"))) 
      Into n_Adviceid, Docxml 
      From 影像报告记录 A, 病人医嘱记录 B 
      Where a.Id = Hextoraw(File_Id) And a.医嘱id = b.Id; 
    Exception 
      --给定的文件ID无效 
      When Others Then 
        Return Null; 
    End; 
 
    Select Insertchildxml(Docxml, '/ZlEPR/Document[@文件ID="' || File_Id || '"]', 'Compend', 
                           Xmlelement("Compend", Xmlattributes('0' As "ID", '内容' As "Name"))) 
    Into Docxml 
    From Dual; 
 
    --开始读取内容 
    Select b.报告内容 Into x_Content From 影像报告记录 B Where b.Id || '' = File_Id; 
 
    Xcdom := Xmldom.Newdomdocument(x_Content); 
 
    Section_List := Xmldom.Getelementsbytagname(Xcdom, 'zlxml'); 
    Section_Node := Xmldom.Item(Section_List, 0); 
    Node_List    := Xmldom.Getelementsbytagname(Xmldom.Makeelement(Section_Node), '*'); 
    n_Len        := Xmldom.Getlength(Node_List); 
 
    For I In 0 .. n_Len - 1 Loop 
      Element_Node := Xmldom.Item(Node_List, I); 
 
      v_Name    := Xmldom.Getnodename(Element_Node); 
      v_Newline := Xmldom.Getattribute(Xmldom.Makeelement(Element_Node), 'br'); 
 
      If v_Newline Is Null Then 
        v_Newline := '1'; 
      End If; 
 
      If v_Name = 'section' Then 
        --提纲 
        v_Title := Xmldom.Getattribute(Xmldom.Makeelement(Element_Node), 'title'); 
        v_Id    := Xmldom.Getattribute(Xmldom.Makeelement(Element_Node), 'sid'); 
 
        Select Appendchildxml(Docxml, '/ZlEPR/Document[@文件ID="' || File_Id || '"]', 
                               Xmlelement("Compend", Xmlattributes(v_Title As "Name", v_Id As "ID"))) 
        Into Docxml 
        From Dual; 
      Elsif v_Name = 'utext' Then 
        --文本 
        v_Text := LTrim(LTrim(Xmldom.Getnodevalue(Xmldom.Getfirstchild(Element_Node)), ':'), '：'); 
 
        If Nvl(v_Id, ' ') = ' ' Then 
          Select Appendchildxml(Docxml, '/ZlEPR/Document[@文件ID="' || File_Id || '"]/Compend[@ID=0]', 
                                 Xmlelement("Text", Xmlattributes(v_Newline As "NewLine"), v_Text)) 
          Into Docxml 
          From Dual; 
        Else 
          Select Appendchildxml(Docxml, 
                                 '/ZlEPR/Document[@文件ID="' || File_Id || '"]/descendant::Compend[@ID="' || v_Id || '"]', 
                                 Xmlelement("Text", Xmlattributes(v_Newline As "NewLine"), v_Text)) 
          Into Docxml 
          From Dual; 
        End If; 
      Elsif v_Name = 'element' Then 
        --要素 
        v_Title := Xmldom.Getattribute(Xmldom.Makeelement(Element_Node), 'title'); 
        v_Text  := Xmldom.Getattribute(Xmldom.Makeelement(Element_Node), 'value') || 
                   Xmldom.Getattribute(Xmldom.Makeelement(Element_Node), 'unit'); 
 
        If Nvl(v_Id, ' ') = ' ' Then 
          Select Appendchildxml(Docxml, '/ZlEPR/Document[@文件ID="' || File_Id || '"]/Compend[@ID=0]', 
                                 Xmlelement("Element", Xmlattributes(v_Title As "Name", v_Newline As "NewLine"), 
                                             v_Text)) 
          Into Docxml 
          From Dual; 
        Else 
          Select Appendchildxml(Docxml, 
                                 '/ZlEPR/Document[@文件ID="' || File_Id || '"]/descendant::Compend[@ID="' || v_Id || '"]', 
                                 Xmlelement("Element", Xmlattributes(v_Title As "Name", v_Newline As "NewLine"), 
                                             v_Text)) 
          Into Docxml 
          From Dual; 
        End If; 
      Elsif v_Name = 'image' Then 
        --图片 
        n_Width  := Xmldom.Getattribute(Xmldom.Makeelement(Element_Node), 'width'); 
        n_Height := Xmldom.Getattribute(Xmldom.Makeelement(Element_Node), 'height'); 
        v_Name   := Xmldom.Getattribute(Xmldom.Makeelement(Element_Node), 'key'); 
        v_Type   := Xmldom.Getattribute(Xmldom.Makeelement(Element_Node), 'class'); 
 
        If Nvl(v_Name, ' ') <> ' ' Then 
          If Nvl(v_Id, ' ') = ' ' Then 
            Select Appendchildxml(Docxml, '/ZlEPR/Document[@文件ID="' || File_Id || '"]/Compend[@ID=0]', 
                                   Xmlelement("Picture", 
                                               Xmlattributes(n_Width As "OrigWidth", n_Height As "OrigHeight", 
                                                              n_Width As "ShowWidth", n_Height As "ShowHeight", 
                                                              v_Name As "PicName", n_Adviceid As "AdviceID", 
                                                              v_Type As "Type"))) 
            Into Docxml 
            From Dual; 
          Else 
            Select Appendchildxml(Docxml, 
                                   '/ZlEPR/Document[@文件ID="' || File_Id || '"]/descendant::Compend[@ID="' || v_Id || '"]', 
                                   Xmlelement("Picture", 
                                               Xmlattributes(n_Width As "OrigWidth", n_Height As "OrigHeight", 
                                                              n_Width As "ShowWidth", n_Height As "ShowHeight", 
                                                              v_Name As "PicName", n_Adviceid As "AdviceID", 
                                                              v_Type As "Type"))) 
            Into Docxml 
            From Dual; 
          End If; 
        End If; 
 
      Elsif v_Name = 'signature' Then 
        --签名 
        v_Text := Xmldom.Getattribute(Xmldom.Makeelement(Element_Node), 'displayinfo'); 
 
        If Nvl(v_Id, ' ') = ' ' Then 
          Select Appendchildxml(Docxml, '/ZlEPR/Document[@文件ID="' || File_Id || '"]/Compend[@ID=0]', 
                                 Xmlelement("Sign", Xmlattributes(v_Newline As "NewLine"), Zl_Eprsplit(v_Text, ';', 1))) 
          Into Docxml 
          From Dual; 
        Else 
          Select Appendchildxml(Docxml, 
                                 '/ZlEPR/Document[@文件ID="' || File_Id || '"]/descendant::Compend[@ID="' || v_Id || '"]', 
                                 Xmlelement("Sign", Xmlattributes(v_Newline As "NewLine"), Zl_Eprsplit(v_Text, ';', 1))) 
          Into Docxml 
          From Dual; 
        End If; 
      End If; 
    End Loop; 
 
    For Aa In (Select '/' || a.Ftp目录 || '/ReportImages/' || To_Char(b.创建时间, 'YYYYMMDD') || '/' || b.Id || '/' As v_Ftppath 
               From 影像设备目录 A, 影像报告记录 B 
               Where a.设备号 = b.设备号 And b.Id = File_Id) Loop 
 
      Select Appendchildxml(Docxml, '/ZlEPR/Document[@文件ID="' || File_Id || '"]/Compend[@ID=0]', 
                             Xmlelement("FtpPath", Xmlattributes(v_Newline As "NewLine"), Aa.v_Ftppath)) 
      Into Docxml 
      From Dual; 
    End Loop; 
  End Loop; 
 
  Return Docxml; 
End Zlpub_Pacs_获取文档文本;
/

