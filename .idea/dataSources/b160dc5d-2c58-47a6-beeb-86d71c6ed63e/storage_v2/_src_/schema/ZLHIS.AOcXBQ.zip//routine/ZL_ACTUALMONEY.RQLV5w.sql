create Function Zl_Actualmoney 
( 
  费别_In       Varchar2, 
  收费细目id_In 费别明细.收费细目id%Type, 
  收入项目id_In 费别明细.收入项目id%Type, 
  应收金额_In   门诊费用记录.应收金额%Type, 
  数量_In       门诊费用记录.数次%Type := 0, 
  药房id_In     药品库存.库房id%Type := 0 
) Return Varchar2 As 
  --功能:根据应收金额按费别进行打折计算 
  --参数: 
  --     费别_In:病人当前费别，如果是动态费别，值为'费别1,费别2,...' 
  --     应收金额_In:应传入加班加价计算之前的真实应收金额 
  --     数量_In:售价数量，药品才需传入 
  --     药房id_in:药品才需传入 
  --返回:费别:实收金额 
 
  n_实收金额 门诊费用记录.实收金额%Type; 
  v_费别     门诊费用记录.费别%Type; 
 
  n_Money   门诊费用记录.实收金额%Type; 
  n_Rate    Number; 
  n_Cost    Number; 
  n_Price   Number; 
  n_Outmode Number; 
  n_数量    Number; 
  n_总数量  Number; 
 
  n_Cnt0 Number; 
  n_Cnt1 Number; 
 
  Cursor c_Med Is 
    Select B.类别, A.指导差价率, Nvl(C.现价, 0) As 售价, Nvl(A.药房分批, 0) As 分批, Nvl(B.是否变价, 0) As 变价 
    From 药品规格 A, 收费项目目录 B, 收费价目 C 
    Where A.药品id = B.ID And B.ID = C.收费细目id And A.药品id = 收费细目id_In And Sysdate Between C.执行日期 And 
          Nvl(C.终止日期, To_Date('3000-01-01', 'YYYY-MM-DD')); 
  r_Med c_Med%Rowtype; 
 
Begin 
  n_实收金额 := 应收金额_In; 
  If Instr(费别_In, ',') = 0 Then 
    v_费别 := 费别_In; 
  Else 
    v_费别 := Substr(费别_In, 1, Instr(费别_In, ',') - 1); 
  End If; 
  If Nvl(数量_In, 0) <> 0 Then 
    n_Outmode := Nvl(Zl_Getsysparameter(150), 0); 
  End If; 
 
  For Rs In (Select 费别, 实收比率, 实收金额, 计算方法 
             From (Select A.费别, Nvl(A.实收比率, 0) As 实收比率, 应收金额_In * Nvl(A.实收比率, 0) / 100 As 实收金额, 
                           Nvl(A.计算方法, 0) As 计算方法, B.属性, B.编码 
                    From 费别明细 A, 费别 B 
                    Where A.费别 = B.名称 And A.收费细目id = 收费细目id_In And 
                          Instr(',' || 费别_In || ',', ',' || B.名称 || ',') > 0 And Abs(应收金额_In) Between A.应收段首值 And 
                          A.应收段尾值 
                    Union All 
                    Select A.费别, Nvl(A.实收比率, 0) As 实收比率, 应收金额_In * Nvl(A.实收比率, 0) / 100 As 实收金额, 
                           Nvl(A.计算方法, 0) As 计算方法, B.属性, B.编码 
                    From 费别明细 A, 费别 B 
                    Where A.费别 = B.名称 And A.收入项目id = 收入项目id_In And 
                          Instr(',' || 费别_In || ',', ',' || B.名称 || ',') > 0 And Abs(应收金额_In) Between A.应收段首值 And 
                          A.应收段尾值 And Not Exists 
                     (Select 1 From 费别明细 C Where C.费别 = A.费别 And C.收费细目id  = 收费细目id_In)) 
             Order By 计算方法, 实收比率, 属性, 编码) Loop 
 
    If Rs.计算方法 = 0 And Nvl(n_Cnt0, 0) = 0 Then 
      n_Cnt0     := 1; --一种计算方法只取最优惠的一行记录 
      n_实收金额 := Rs.实收金额; 
      v_费别     := Rs.费别; 
    Elsif Rs.计算方法 = 1 And 数量_In <> 0 And Nvl(n_Cnt1, 0) = 0 Then 
      n_Cnt1 := 1; --一种计算方法只取最优惠的一行记录 
      --药品按成本价加收方式 
      Open c_Med; 
      Fetch c_Med 
        Into r_Med; 
      If c_Med%Rowcount > 0 Then 
        n_Rate := Rs.实收比率 / 100; 
 
        If Nvl(药房id_In, 0) = 0 Then 
          --没有确定药房时(或分离模式),分批或不分批药品都按指导差价率算 
          n_Money := 应收金额_In * (1 - Nvl(r_Med.指导差价率, 0) / 100) * (1 + n_Rate); 
          If n_Money < n_实收金额 Then 
            n_实收金额 := n_Money; 
            v_费别     := Rs.费别; 
          End If; 
 
        Elsif r_Med.分批 = 0 Then 
          Select 应收金额_In * 
                  (1 - Nvl(Decode(Sign(Nvl(A.实际金额, 0)), 1, A.实际差价 / A.实际金额, B.指导差价率 / 100), 0)) As 成本金额 
          Into n_Cost 
          From 药品库存 A, 药品规格 B 
          Where A.药品id(+) = B.药品id And A.库房id(+) = 药房id_In And A.性质(+) = 1 And B.药品id = 收费细目id_In; 
          If n_Cost <> 0 Then 
            n_Money := n_Cost * (1 + n_Rate); 
            If n_Money < n_实收金额 Then 
              n_实收金额 := n_Money; 
              v_费别     := Rs.费别; 
            End If; 
          End If; 
 
        Elsif r_Med.分批 = 1 Then 
          n_总数量 := 数量_In; 
          n_Money  := 0; 
          For r_Stock In (Select Nvl(批次, 0) As 批次, Nvl(可用数量, 0) As 库存, 
                                 Nvl(零售价,Nvl(Decode(Nvl(实际数量, 0), 0, 0, 实际金额 / 实际数量), 0)) As 时价, 
                                 Nvl(实际差价, 0) As 实际差价, Nvl(实际金额, 0) As 实际金额 
                          From 药品库存 
                          Where 库房id = 药房id_In And 药品id = 收费细目id_In And Nvl(可用数量, 0) > 0 And 性质 = 1 And 
                                (Nvl(批次, 0) = 0 Or 效期 Is Null Or 效期 > Trunc(Sysdate)) 
                          Order By Decode(n_Outmode, 1, 效期, To_Date('2008-08-08', 'yyyy-mm-dd')), Nvl(批次, 0)) Loop 
            If n_总数量 = 0 Then 
              Exit; 
            End If; 
            If n_总数量 <= r_Stock.库存 Then 
              n_数量 := n_总数量; 
            Else 
              n_数量 := r_Stock.库存; 
            End If; 
 
            If r_Med.变价 = 1 Then 
              n_Price := r_Stock.时价; 
            Else 
              n_Price := r_Med.售价; 
            End If; 
 
            If r_Stock.实际金额 <> 0 Then 
              -- 本批次成本价:按库存差价率算 
              n_Cost := n_Price * (1 - r_Stock.实际差价 / r_Stock.实际金额); 
            Else 
              --无库存金额按指导差价率算,无库存的批次在SQL中已排开 
              n_Cost := n_Price * (1 - Nvl(r_Med.指导差价率, 0) / 100); 
            End If; 
 
            If n_Cost <> 0 Then 
              n_Money  := n_Money + n_Cost * (1 + n_Rate) * n_数量; 
              n_总数量 := n_总数量 - n_数量; 
            End If; 
          End Loop; 
          If n_总数量 = 0 Then 
            If n_Money < n_实收金额 Then 
              n_实收金额 := n_Money; 
              v_费别     := Rs.费别; 
            End If; 
          End If; 
        End If; 
        Close c_Med; 
      End If; 
    End If; 
  End Loop; 
 
  Return v_费别 || ':' || n_实收金额; 
Exception 
  When Others Then 
    Return v_费别 || ':' || n_实收金额; 
End Zl_Actualmoney;
/

