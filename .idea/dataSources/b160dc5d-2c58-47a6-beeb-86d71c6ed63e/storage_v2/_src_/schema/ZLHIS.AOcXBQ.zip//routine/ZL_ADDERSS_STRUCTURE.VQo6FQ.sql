create Function Zl_Adderss_Structure(v_Addressinfo Varchar2) Return Varchar2 Is 
  --返回结构：省,省编码,是否虚拟,是否不显示,是否只有虚拟级|市,市编码,是否虚拟,是否不显示,是否只有虚拟级 
  --          |区县,区县编码,是否虚拟,是否不显示,是否只有虚拟级|乡镇,乡镇编码,是否虚拟,是否不显示,是否只有虚拟级 
  --          |街道,街道编码,是否虚拟,是否不显示,是否只有虚拟级 
  v_省       Varchar2(100); 
  v_Code省   Varchar2(15); 
  v_Info省   Varchar2(150); 
  v_市       Varchar2(100); 
  v_Code市   Varchar2(15); 
  v_Info市   Varchar2(150); 
  v_区县     Varchar2(100); 
  v_Code区县 Varchar2(15); 
  v_Info区县 Varchar2(150); 
  v_乡镇     Varchar2(100); 
  v_Code乡镇 Varchar2(15); 
  v_Info乡镇 Varchar2(150); 
  v_街道     Varchar2(500); 
  v_Code街道 Varchar2(15); 
  v_Info街道 Varchar2(550); 
  v_Tmp      Varchar2(100); 
  v_Adrstmp  Varchar2(500); 
  n_Pos      Number(5); 
  n_虚拟     Number(1); 
  n_不显示   Number(1); 
  n_Count    Number(3); 
  v_Return   Varchar2(700); 
Begin 
  --传入结构化的地址，不用进行地址标准化分割解析 
  v_Adrstmp := v_Addressinfo; 
  If v_Addressinfo Like '%,%,%,%,%' Then 
    n_Pos     := Instr(v_Adrstmp, ','); 
    v_省      := Substr(v_Adrstmp, 1, n_Pos - 1); 
    v_Adrstmp := Substr(v_Adrstmp, n_Pos + 1); 
    n_Pos     := Instr(v_Adrstmp, ','); 
    v_市      := Substr(v_Adrstmp, 1, n_Pos - 1); 
    v_Adrstmp := Substr(v_Adrstmp, n_Pos + 1); 
    n_Pos     := Instr(v_Adrstmp, ','); 
    v_区县    := Substr(v_Adrstmp, 1, n_Pos - 1); 
    v_Adrstmp := Substr(v_Adrstmp, n_Pos + 1); 
    n_Pos     := Instr(v_Adrstmp, ','); 
    v_乡镇    := Substr(v_Adrstmp, 1, n_Pos - 1); 
    v_街道    := Substr(v_Adrstmp, n_Pos + 1); 
    Select Max(编码) Into v_Code省 From 区域 Where 名称 = v_省 And Nvl(级数, 0) = 0; 
    --省级地址都没有，就不做处理 
    If v_Code省 Is Not Null Then 
      Select Max(编码), Max(是否虚拟), Max(是否不显示) 
      Into v_Code市, n_虚拟, n_不显示 
      From 区域 
      Where 名称 = v_市 And Nvl(级数, 0) = 1 And 上级编码 = v_Code省; 
      If v_Code市 Is Not Null Then 
        v_Info市 := v_市 || ',' || v_Code市 || ',' || n_虚拟 || ',' || n_不显示; 
        Select Max(编码), Max(是否虚拟), Max(是否不显示) 
        Into v_Code区县, n_虚拟, n_不显示 
        From 区域 
        Where 名称 = v_区县 And Nvl(级数, 0) = 2 And 上级编码 = v_Code市; 
        --可能是虚拟地址 
      Else 
        Select Max(编码), Max(上级编码) 
        Into v_Code区县, v_Code市 
        From 区域 
        Where 名称 = v_区县 And Nvl(级数, 0) = 2 And 上级编码 In (Select 编码 From 区域 Where 上级编码 = v_Code省); 
        If v_Code市 Is Not Null Then 
          Select Max(名称), Max(编码), Max(是否虚拟), Max(是否不显示) 
          Into v_市, v_Code市, n_虚拟, n_不显示 
          From 区域 
          Where 编码 = v_Code市; 
        End If; 
        v_Info市 := v_市 || ',' || v_Code市 || ',' || n_虚拟 || ',' || n_不显示; 
        Select Max(编码), Max(是否虚拟), Max(是否不显示) 
        Into v_Code区县, n_虚拟, n_不显示 
        From 区域 
        Where 编码 = v_Code区县; 
      End If; 
      v_Info区县 := v_区县 || ',' || v_Code区县 || ',' || n_虚拟 || ',' || n_不显示; 
      If v_Code区县 Is Not Null Then 
        --可能乡镇在详细地址中，关联参数乡镇地址结构化录入 
        If v_乡镇 Is Null And Not v_街道 Is Null Then 
          --先截取乡镇级的两个字做关键字，来匹配 
          v_Tmp := Substr(v_街道, 1, 2); 
          Select Max(名称) 
          Into v_乡镇 
          From 区域 
          Where 名称 Like v_Tmp || '%' And Nvl(级数, 0) = 3 And 上级编码 = v_Code区县; 
          --存在多行匹配，则继续增加长度，暂时从2个字增加到3个字匹配 
          If n_Count > 1 Then 
            v_Tmp := Substr(v_街道, 1, 3); 
            Select Max(名称) 
            Into v_乡镇 
            From 区域 
            Where 名称 Like v_Tmp || '%' And Nvl(级数, 0) = 3 And 上级编码 = v_Code区县; 
          End If; 
          If Not v_乡镇 Is Null Then 
            v_街道 := Substr(v_街道, Length(v_乡镇) + 1); 
          End If; 
        End If; 
        Select Max(编码), Max(是否虚拟), Max(是否不显示) 
        Into v_Code乡镇, n_虚拟, n_不显示 
        From 区域 
        Where 名称 = v_乡镇 And Nvl(级数, 0) = 3 And 上级编码 = v_Code区县; 
        --可能是虚拟地址 
        If v_Code乡镇 Is Null Then 
          Select Max(编码), Max(上级编码) 
          Into v_Code街道, v_Code乡镇 
          From 区域 
          Where 名称 = v_街道 And Nvl(级数, 0) = 4 And 上级编码 In (Select 编码 From 区域 Where 上级编码 = v_Code区县); 
          If v_Code乡镇 Is Not Null Then 
            Select Max(名称), Max(编码), Max(是否虚拟), Max(是否不显示) 
            Into v_乡镇, v_Code乡镇, n_虚拟, n_不显示 
            From 区域 
            Where 编码 = v_Code乡镇; 
          End If; 
        End If; 
        v_Info乡镇 := v_乡镇 || ',' || v_Code乡镇 || ',' || n_虚拟 || ',' || n_不显示; 
        If v_Code乡镇 Is Not Null Then 
          Select Max(编码), Max(是否虚拟), Max(是否不显示) 
          Into v_Code街道, n_虚拟, n_不显示 
          From 区域 
          Where 名称 = v_街道 And Nvl(级数, 0) = 4 And 上级编码 = v_Code乡镇; 
          v_Info街道 := v_街道 || ',' || v_Code街道 || ',' || n_虚拟 || ',' || n_不显示; 
        End If; 
      End If; 
    End If; 
    --非标准地址，是完整地址，需要分割省，市，县, 
  Else 
    v_Adrstmp := v_Addressinfo; 
    v_Tmp     := Substr(v_Adrstmp, 1, 2); 
    Select Max(名称), Max(编码) Into v_省, v_Code省 From 区域 Where 名称 Like v_Tmp || '%' And Nvl(级数, 0) = 0; 
    --有省级地址，说明可以结构化 
    If v_Code省 Is Not Null Then 
      --省级地址是标准的 
      If Substr(v_Adrstmp, 1, Length(v_省)) = v_省 Then 
        v_Adrstmp := Substr(v_Adrstmp, Length(v_省) + 1); 
        --省级地址不标准,可能新疆省略自治区等,此时，市级地址可能是标准化的。 
      Else 
        --先判断二级地址是否存在虚拟地址与不显示的地址 
        If v_Tmp = '内蒙' Then 
          v_Tmp := '内蒙古'; 
        Elsif v_Tmp = '黑龙' Then 
          v_Tmp := '黑龙江'; 
        End If; 
        v_Adrstmp := Substr(v_Adrstmp, Length(v_Tmp) + 1); 
      End If; 
      --先截取市级的两个字做关键字，来匹配 
      v_Tmp := Substr(v_Adrstmp, 1, 2); 
      Select Max(名称), Max(编码), Max(是否虚拟), Max(是否不显示), Count(1) 
      Into v_市, v_Code市, n_虚拟, n_不显示, n_Count 
      From 区域 
      Where 名称 Like v_Tmp || '%' And Nvl(级数, 0) = 1 And 上级编码 = v_Code省; 
      --存在多行匹配，则继续增加长度，暂时从2个字增加到3个字匹配 
      If n_Count > 1 Then 
        v_Tmp := Substr(v_Adrstmp, 1, 3); 
        Select Max(名称), Max(编码), Max(是否虚拟), Max(是否不显示) 
        Into v_市, v_Code市, n_虚拟, n_不显示 
        From 区域 
        Where 名称 Like v_Tmp || '%' And Nvl(级数, 0) = 1 And 上级编码 = v_Code省; 
      End If; 
      --判断是否存在虚拟地址或不显示的地址导致的,如果存在，则根据第三级地址来确定虚拟地址 
      --可能是没有第二级，因此需要第三级判断 
      If v_Code市 Is Null Then 
        Select Max(名称), Max(编码), Max(是否虚拟), Max(是否不显示), Count(1), Max(上级编码) 
        Into v_区县, v_Code区县, n_虚拟, n_不显示, n_Count, v_Code市 
        From 区域 
        Where 名称 Like v_Tmp || '%' And Nvl(级数, 0) = 2 And 上级编码 In (Select 编码 From 区域 Where 上级编码 = v_Code省); 
        --存在多行匹配，则继续增加长度，暂时从2个字增加到3个字匹配 
        If n_Count > 1 Then 
          v_Tmp := Substr(v_Adrstmp, 1, 3); 
          Select Max(名称), Max(编码), Max(是否虚拟), Max(是否不显示), Max(上级编码) 
          Into v_区县, v_Code区县, n_虚拟, n_不显示, v_Code市 
          From 区域 
          Where 名称 Like v_Tmp || '%' And Nvl(级数, 0) = 2 And 上级编码 In (Select 编码 From 区域 Where 上级编码 = v_Code省); 
        End If; 
        If v_Code市 Is Not Null Then 
          v_Info区县 := v_区县 || ',' || v_Code区县 || ',' || n_虚拟 || ',' || n_不显示; 
          v_Adrstmp  := Substr(v_Adrstmp, Length(v_区县) + 1); 
          Select Max(名称), Max(编码), Max(是否虚拟), Max(是否不显示) 
          Into v_市, v_Code市, n_虚拟, n_不显示 
          From 区域 
          Where 编码 = v_Code市; 
          v_Info市 := v_市 || ',' || v_Code市 || ',' || n_虚拟 || ',' || n_不显示; 
        End If; 
      Else 
        v_Info市  := v_市 || ',' || v_Code市 || ',' || n_虚拟 || ',' || n_不显示; 
        v_Adrstmp := Substr(v_Adrstmp, Length(v_市) + 1); 
      End If; 
      --没有区县，则解析区县 
      If Not v_Code市 Is Null And v_Code区县 Is Null Then 
        --先截取县级的两个字做关键字，来匹配 
        v_Tmp := Substr(v_Adrstmp, 1, 2); 
        Select Max(名称), Max(编码), Max(是否虚拟), Max(是否不显示), Count(1) 
        Into v_区县, v_Code区县, n_虚拟, n_不显示, n_Count 
        From 区域 
        Where 名称 Like v_Tmp || '%' And Nvl(级数, 0) = 2 And 上级编码 = v_Code市; 
        --存在多行匹配，则继续增加长度，暂时从2个字增加到3个字匹配 
        If n_Count > 1 Then 
          v_Tmp := Substr(v_Adrstmp, 1, 3); 
          Select Max(名称), Max(编码), Max(是否虚拟), Max(是否不显示) 
          Into v_区县, v_Code区县, n_虚拟, n_不显示 
          From 区域 
          Where 名称 Like v_Tmp || '%' And Nvl(级数, 0) = 2 And 上级编码 = v_Code市; 
        End If; 
        If v_Code区县 Is Null Then 
          Select Max(是否虚拟), Max(是否不显示) Into n_虚拟, n_不显示 From 区域 Where 上级编码 = v_Code市; 
          If Nvl(n_虚拟, 0) = 1 Or Nvl(n_不显示, 0) = 1 Then 
            Select Max(名称), Max(编码), Max(是否虚拟), Max(是否不显示), Count(1), Max(上级编码) 
            Into v_乡镇, v_Code乡镇, n_虚拟, n_不显示, n_Count, v_Code区县 
            From 区域 
            Where 名称 Like v_Tmp || '%' And Nvl(级数, 0) = 3 And 上级编码 In (Select 编码 From 区域 Where 上级编码 = v_Code市); 
            --存在多行匹配，则继续增加长度，暂时从2个字增加到3个字匹配 
            If n_Count > 1 Then 
              v_Tmp := Substr(v_Adrstmp, 1, 3); 
              Select Max(名称), Max(编码), Max(是否虚拟), Max(是否不显示), Max(上级编码) 
              Into v_乡镇, v_Code乡镇, n_虚拟, n_不显示, v_Code区县 
              From 区域 
              Where 名称 Like v_Tmp || '%' And Nvl(级数, 0) = 3 And 上级编码 In (Select 编码 From 区域 Where 上级编码 = v_Code市); 
            End If; 
 
            If v_Code乡镇 Is Not Null Then 
              v_Info乡镇 := v_乡镇 || ',' || v_Code乡镇 || ',' || n_虚拟 || ',' || n_不显示; 
              v_Adrstmp  := Substr(v_Adrstmp, Length(v_乡镇) + 1); 
              Select Max(名称), Max(编码), Max(是否虚拟), Max(是否不显示) 
              Into v_区县, v_Code区县, n_虚拟, n_不显示 
              From 区域 
              Where 编码 = v_Code区县; 
              v_Info区县 := v_区县 || ',' || v_Code区县 || ',' || n_虚拟 || ',' || n_不显示; 
            End If; 
          End If; 
        Else 
          v_Info区县 := v_区县 || ',' || v_Code区县 || ',' || n_虚拟 || ',' || n_不显示; 
          v_Adrstmp  := Substr(v_Adrstmp, Length(v_区县) + 1); 
        End If; 
      End If; 
      If v_Code区县 Is Not Null And v_Code乡镇 Is Null Then 
        --先截取乡镇级的两个字做关键字，来匹配 
        v_Tmp := Substr(v_Adrstmp, 1, 2); 
        Select Max(名称), Max(编码), Max(是否虚拟), Max(是否不显示), Count(1) 
        Into v_乡镇, v_Code乡镇, n_虚拟, n_不显示, n_Count 
        From 区域 
        Where 名称 Like v_Tmp || '%' And Nvl(级数, 0) = 3 And 上级编码 = v_Code区县; 
        --存在多行匹配，则继续增加长度，暂时从2个字增加到3个字匹配 
        If n_Count > 1 Then 
          v_Tmp := Substr(v_Adrstmp, 1, 3); 
          Select Max(名称), Max(编码), Max(是否虚拟), Max(是否不显示), Count(1) 
          Into v_乡镇, v_Code乡镇, n_虚拟, n_不显示, n_Count 
          From 区域 
          Where 名称 Like v_Tmp || '%' And Nvl(级数, 0) = 3 And 上级编码 = v_Code区县; 
        End If; 
        If v_Code乡镇 Is Null Then 
          Select Max(是否虚拟), Max(是否不显示) Into n_虚拟, n_不显示 From 区域 Where 上级编码 = v_Code区县; 
          If Nvl(n_虚拟, 0) = 1 Or Nvl(n_不显示, 0) = 1 Then 
            Select Max(名称), Max(编码), Max(是否虚拟), Max(是否不显示), Count(1), Max(上级编码) 
            Into v_街道, v_Code街道, n_虚拟, n_不显示, n_Count, v_Code乡镇 
            From 区域 
            Where 名称 = v_Adrstmp And 上级编码 In (Select 编码 From 区域 Where 上级编码 = v_Code区县); 
          End If; 
          If v_Code乡镇 Is Not Null Then 
            v_Info街道 := v_街道 || ',' || v_Code街道 || ',' || n_虚拟 || ',' || n_不显示; 
            Select Max(名称), Max(编码), Max(是否虚拟), Max(是否不显示) 
            Into v_乡镇, v_Code乡镇, n_虚拟, n_不显示 
            From 区域 
            Where 编码 = v_Code乡镇; 
            v_Info乡镇 := v_乡镇 || ',' || v_Code乡镇 || ',' || n_虚拟 || ',' || n_不显示; 
          End If; 
        Else 
          v_Info乡镇 := v_乡镇 || ',' || v_Code乡镇 || ',' || n_虚拟 || ',' || n_不显示; 
          v_Adrstmp  := Substr(v_Adrstmp, Length(v_乡镇) + 1); 
        End If; 
        If v_Code乡镇 Is Not Null And v_Code街道 Is Null Then 
          Select Max(名称), Max(编码), Max(是否虚拟), Max(是否不显示) 
          Into v_街道, v_Code街道, n_虚拟, n_不显示 
          From 区域 
          Where 名称 = v_Adrstmp And Nvl(级数, 0) = 4 And 上级编码 = v_Code乡镇; 
          If v_Code街道 Is Not Null Then 
            v_Info街道 := v_街道 || ',' || v_Code街道 || ',' || n_虚拟 || ',' || n_不显示; 
          End If; 
        End If; 
      End If; 
    End If; 
    If v_街道 Is Null Then 
      v_街道 := v_Adrstmp; 
    End If; 
  End If; 
  v_Info省 := v_省 || ',' || v_Code省 || ',,,'; 
  If v_Info市 Is Null Then 
    v_Info市 := v_市 || ',,,'; 
  End If; 
  --只有省没有市，判断市是否只有虚拟级 
  If Not v_Code省 Is Null And v_市 Is Null Then 
    Select Count(1) 
    Into n_Count 
    From 区域 
    Where 上级编码 = v_Code省 And Nvl(是否虚拟, 0) = 0 And Nvl(是否不显示, 0) = 0 And Rownum < 2; 
    If n_Count = 0 Then 
      Select Count(1) Into n_Count From 区域 Where 上级编码 = v_Code省 And Rownum < 2; 
      If n_Count = 0 Then 
        v_Info市 := v_Info市 || ','; 
      Else 
        v_Info市 := v_Info市 || ',1'; 
      End If; 
    Else 
      v_Info市 := v_Info市 || ','; 
    End If; 
  Else 
    v_Info市 := v_Info市 || ','; 
  End If; 
  If v_Info区县 Is Null Then 
    v_Info区县 := v_区县 || ',,,'; 
  End If; 
  --只有市没有区县，判断区县只有虚拟级 
  If Not v_Code市 Is Null And v_区县 Is Null Then 
    Select Count(1) 
    Into n_Count 
    From 区域 
    Where 上级编码 = v_Code市 And Nvl(是否虚拟, 0) = 0 And Nvl(是否不显示, 0) = 0 And Rownum < 2; 
    If n_Count = 0 Then 
      Select Count(1) Into n_Count From 区域 Where 上级编码 = v_Code市 And Rownum < 2; 
      If n_Count = 0 Then 
        v_Info区县 := v_Info区县 || ','; 
      Else 
        v_Info区县 := v_Info区县 || ',1'; 
      End If; 
    Else 
      v_Info区县 := v_Info区县 || ','; 
    End If; 
  Else 
    v_Info区县 := v_Info区县 || ','; 
  End If; 
  If v_Info乡镇 Is Null Then 
    v_Info乡镇 := v_乡镇 || ',,,'; 
  End If; 
  --只有区县没有乡镇，判断乡镇是否只有虚拟的下级 
  If Not v_Code区县 Is Null And v_乡镇 Is Null Then 
    Select Count(1) 
    Into n_Count 
    From 区域 
    Where 上级编码 = v_Code区县 And Nvl(是否虚拟, 0) = 0 And Nvl(是否不显示, 0) = 0 And Rownum < 2; 
    If n_Count = 0 Then 
      Select Count(1) Into n_Count From 区域 Where 上级编码 = v_Code区县 And Rownum < 2; 
      If n_Count = 0 Then 
        v_Info乡镇 := v_Info乡镇 || ','; 
      Else 
        v_Info乡镇 := v_Info乡镇 || ',1'; 
      End If; 
    Else 
      v_Info乡镇 := v_Info乡镇 || ','; 
    End If; 
  Else 
    v_Info乡镇 := v_Info乡镇 || ','; 
  End If; 
  If v_Info街道 Is Null Then 
    v_Info街道 := v_街道 || ',,,,'; 
  Else 
    v_Info街道 := v_Info街道 || ','; 
  End If; 
  v_Return := v_Info省 || '|' || v_Info市 || '|' || v_Info区县 || '|' || v_Info乡镇 || '|' || v_Info街道; 
  Return(v_Return); 
End;
/

