create Function Zl_Adviceexetimes 
( 
  医嘱id_In       病人医嘱记录.Id%Type, 
  开始时间_In     病人医嘱发送.首次时间%Type, 
  结束时间_In     病人医嘱发送.末次时间%Type, 
  执行时间方案_In 病人医嘱记录.执行时间方案%Type, 
  开始执行时间_In 病人医嘱记录.开始执行时间%Type, 
  上次打印时间_In 病人医嘱记录.上次打印时间%Type, 
  频率间隔_In     病人医嘱记录.频率间隔%Type, 
  间隔单位_In     病人医嘱记录.间隔单位%Type, 
  医嘱期效_In     病人医嘱记录.医嘱期效%Type 
) Return Varchar2 Is 
 
  --功能：计算按指定频率执行的医嘱在指定时间范围内的执行时间点，以逗号分隔(同医嘱发送程序中的函数：Calc段内分解时间) 
  --说明：1.以医嘱已经发送后应该执行的开始和结束时间为准 
  --      2.时间段内要排除暂停的时间段,次数可能因此而减少 
  --      3.参数 执行时间方案_In,开始执行时间_In,频率间隔_In,间隔单位_In 是为了避免再次访问表：病人医嘱记录 
  --        频率次数，不用传入，直接根据参数:执行时间方案_In，可以得出 
  v_Pause      Varchar2(4000); 
  v_Detailtime Varchar2(4000); 
  n_First      Number(1); 
  v_First      病人医嘱记录.执行时间方案%Type; 
  v_Normal     病人医嘱记录.执行时间方案%Type; 
  v_Mtime      Varchar(100); 
  v_Rtime      Varchar(100); 
  v_Curtime    Date; 
  v_Tmptime    Date; 
  --获取指定医嘱的暂停时间段 
  Function Getadvicepause(v_医嘱id 病人医嘱记录.Id%Type) Return Varchar2 Is 
    Cursor c_Pause Is 
      Select 操作类型, 操作时间 From 病人医嘱状态 Where 操作类型 In (6, 7) And 医嘱id = v_医嘱id Order By 操作时间; 
    v_Outstr Varchar2(4000); 
  Begin 
    For r_Advice In c_Pause Loop 
      If r_Advice.操作类型 = 6 Then 
        v_Outstr := v_Outstr || ';' || To_Char(r_Advice.操作时间, 'YYYY-MM-DD HH24:MI:SS') || ','; 
      Elsif r_Advice.操作类型 = 7 Then 
        --启用的那一秒不在暂停的范围之内 
        v_Outstr := v_Outstr || To_Char(r_Advice.操作时间 - 1 / 24 / 60 / 60, 'YYYY-MM-DD HH24:MI:SS'); 
      End If; 
    End Loop; 
    Return(Substr(v_Outstr, 2)); 
  End; 
  --断一个时间是否在暂停的时间段中 
  Function Timeispause 
  ( 
    v_Time Date, 
    v_Sect Varchar2 
  ) Return Number Is 
    v_Rest      Varchar2(4000); 
    v_Cursect   Varchar2(60); 
    v_Begintime Varchar2(30); 
    v_Endtime   Varchar2(30); 
  Begin 
    If v_Sect Is Null Then 
      Return(0); 
    End If; 
    v_Rest := v_Sect || ';'; 
    While v_Rest Is Not Null Loop 
      v_Cursect   := Substr(v_Rest, 1, Instr(v_Rest, ';') - 1); 
      v_Begintime := Substr(v_Cursect, 1, Instr(v_Cursect, ',') - 1); 
      v_Endtime   := Substr(v_Cursect, Instr(v_Cursect, ',') + 1); 
      If v_Endtime Is Null Then 
        v_Endtime := '3000-01-01 00:00:00'; --可能尚未启用或暂停的时候被停止 
      End If; 
      If To_Char(v_Time, 'YYYY-MM-DD HH24:MI:SS') >= v_Begintime And 
         To_Char(v_Time, 'YYYY-MM-DD HH24:MI:SS') <= v_Endtime Then 
        Return(1); 
      End If; 
      v_Rest := Substr(v_Rest, Instr(v_Rest, ';') + 1); 
    End Loop; 
    Return(0); 
  End; 
  --求某时间所在周的星期一的日期 
  Function Getweekbase(v_Time Date) Return Date Is 
    v_Week Number(1); 
  Begin 
    v_Week := To_Number(To_Char(v_Time, 'D')); 
    v_Week := v_Week - 1; 
    If v_Week = 0 Then 
      v_Week := 7; 
    End If; 
    Return(Trunc(v_Time - (v_Week - 1))); 
  End; 
Begin 
  --一次性临嘱快速返回 
  If 执行时间方案_In Is Null And 间隔单位_In Is Null Then 
    If 开始执行时间_In >= 开始时间_In And 开始执行时间_In <= 结束时间_In And Not (上次打印时间_In >= 开始执行时间_In) Then 
      Return(To_Char(开始执行时间_In, 'YYYY-MM-DD HH24:MI:SS')); 
    Else 
      Return(Null); 
    End If; 
  End If; 
  If 医嘱期效_In = 0 Then 
    v_Pause := Getadvicepause(医嘱id_In); 
  End If; 
 
  --执行时间方案基准 
  If Nvl(Instr(执行时间方案_In, ','), 0) > 0 Then 
    v_First  := Substr(执行时间方案_In, 1, Instr(执行时间方案_In, ',') - 1); 
    v_Normal := Substr(执行时间方案_In, Instr(执行时间方案_In, ',') + 1); 
  Else 
    v_First  := Null; 
    v_Normal := 执行时间方案_In; 
  End If; 
  If 间隔单位_In = '周' Then 
    v_Curtime := Getweekbase(开始执行时间_In); --按周执行时在医嘱开始那周的星期一作为基准 
  Else 
    v_Curtime := 开始执行时间_In; 
  End If; 
  If 间隔单位_In = '周' Then 
    If v_First Is Not Null Then 
      If v_Curtime = Getweekbase(开始时间_In) Then 
        n_First := 1; 
      End If; 
    End If; 
    While v_Curtime <= 结束时间_In Loop 
      If Nvl(n_First, 0) = 1 Then 
        v_Rtime := v_First || '-'; 
      Else 
        v_Rtime := v_Normal || '-'; 
      End If; 
      n_First := 0; 
      --1/8:00-3/8:00-5/8:00 
      While v_Rtime Is Not Null Loop 
        v_Mtime   := Substr(v_Rtime, 1, Instr(v_Rtime, '-') - 1); 
        v_Tmptime := v_Curtime + To_Number(Substr(v_Mtime, 1, Instr(v_Mtime, '/') - 1)) - 1; 
        v_Mtime   := Substr(v_Mtime, Instr(v_Mtime, '/') + 1); 
        If Instr(v_Mtime, ':') = 0 Then 
          v_Mtime := v_Mtime || ':00'; 
        End If; 
        v_Tmptime := Trunc(v_Tmptime) + (To_Date(v_Mtime, 'HH24:MI:SS') - Trunc(To_Date(v_Mtime, 'HH24:MI:SS'))); 
        If v_Tmptime >= 开始时间_In And v_Tmptime <= 结束时间_In Then 
          If Timeispause(v_Tmptime, v_Pause) = 0 Then 
            v_Detailtime := v_Detailtime || ',' || To_Char(v_Tmptime, 'YYYY-MM-DD HH24:MI:SS'); 
          End If; 
        Elsif v_Tmptime > 结束时间_In Then 
          Exit; 
        End If; 
        v_Rtime := Substr(v_Rtime, Instr(v_Rtime, '-') + 1); 
      End Loop; 
      v_Curtime := Trunc(v_Curtime + 7); 
    End Loop; 
  Elsif 间隔单位_In = '天' Then 
    If v_First Is Not Null Then 
      If Trunc(开始执行时间_In) = Trunc(开始时间_In) Then 
        n_First := 1; 
      End If; 
    End If; 
    While v_Curtime <= 结束时间_In Loop 
      If Nvl(n_First, 0) = 1 Then 
        v_Rtime := v_First || '-'; 
      Else 
        v_Rtime := v_Normal || '-'; 
      End If; 
      n_First := 0; 
      If 频率间隔_In = 1 Then 
        --8:00-12:00-14:00；8-12-14 
        While v_Rtime Is Not Null Loop 
          v_Mtime := Substr(v_Rtime, 1, Instr(v_Rtime, '-') - 1); 
          If Instr(v_Mtime, ':') = 0 Then 
            v_Mtime := v_Mtime || ':00'; 
          End If; 
          v_Tmptime := Trunc(v_Curtime) + (To_Date(v_Mtime, 'HH24:MI:SS') - Trunc(To_Date(v_Mtime, 'HH24:MI:SS'))); 
          If v_Tmptime >= 开始时间_In And v_Tmptime <= 结束时间_In Then 
            If Timeispause(v_Tmptime, v_Pause) = 0 Then 
              v_Detailtime := v_Detailtime || ',' || To_Char(v_Tmptime, 'YYYY-MM-DD HH24:MI:SS'); 
            End If; 
          Elsif v_Tmptime > 结束时间_In Then 
            Exit; 
          End If; 
          v_Rtime := Substr(v_Rtime, Instr(v_Rtime, '-') + 1); 
        End Loop; 
      Else 
 
        --1/8:00-1/15:00-2/9:00 
        While v_Rtime Is Not Null Loop 
          v_Mtime   := Substr(v_Rtime, 1, Instr(v_Rtime, '-') - 1); 
          v_Tmptime := v_Curtime + To_Number(Substr(v_Mtime, 1, Instr(v_Mtime, '/') - 1)) - 1; 
          v_Mtime   := Substr(v_Mtime, Instr(v_Mtime, '/') + 1); 
          If Instr(v_Mtime, ':') = 0 Then 
            v_Mtime := v_Mtime || ':00'; 
          End If; 
          v_Tmptime := Trunc(v_Tmptime) + (To_Date(v_Mtime, 'HH24:MI:SS') - Trunc(To_Date(v_Mtime, 'HH24:MI:SS'))); 
          If v_Tmptime >= 开始时间_In And v_Tmptime <= 结束时间_In Then 
            If Timeispause(v_Tmptime, v_Pause) = 0 Then 
              v_Detailtime := v_Detailtime || ',' || To_Char(v_Tmptime, 'YYYY-MM-DD HH24:MI:SS'); 
            End If; 
          Elsif v_Tmptime > 结束时间_In Then 
            Exit; 
          End If; 
          v_Rtime := Substr(v_Rtime, Instr(v_Rtime, '-') + 1); 
        End Loop; 
      End If; 
      v_Curtime := Trunc(v_Curtime + 频率间隔_In); --因为Loop条件注意要取整 
    End Loop; 
  Elsif 间隔单位_In = '小时' Then 
    --10:00-20:00-40:00；10-20-40；02:30 
    While v_Curtime <= 结束时间_In Loop 
      v_Rtime := 执行时间方案_In || '-'; 
      While v_Rtime Is Not Null Loop 
        v_Mtime := Substr(v_Rtime, 1, Instr(v_Rtime, '-') - 1); 
        If Instr(v_Mtime, ':') = 0 Then 
          v_Tmptime := v_Curtime + (To_Number(v_Mtime) - 1) / 24; 
        Else 
          v_Tmptime := v_Curtime + (To_Number(Substr(v_Mtime, 1, Instr(v_Mtime, ':') - 1)) - 1) / 24 + 
                       To_Number(Substr(v_Mtime, Instr(v_Mtime, ':') + 1)) / 60 / 24; 
        End If; 
 
        If v_Tmptime >= 开始时间_In And v_Tmptime <= 结束时间_In Then 
          If Timeispause(v_Tmptime, v_Pause) = 0 Then 
            v_Detailtime := v_Detailtime || ',' || To_Char(v_Tmptime, 'YYYY-MM-DD HH24:MI:SS'); 
          End If; 
        Elsif v_Tmptime > 结束时间_In Then 
          Exit; 
        End If; 
        v_Rtime := Substr(v_Rtime, Instr(v_Rtime, '-') + 1); 
      End Loop; 
      v_Curtime := v_Curtime + 频率间隔_In / 24; 
    End Loop; 
  Elsif 间隔单位_In = '分钟' Then 
    --无执行时间 
    While v_Curtime <= 结束时间_In Loop 
      v_Tmptime := v_Curtime; 
      If v_Tmptime >= 开始时间_In And v_Tmptime <= 结束时间_In Then 
        If Timeispause(v_Tmptime, v_Pause) = 0 Then 
          v_Detailtime := v_Detailtime || ',' || To_Char(v_Tmptime, 'YYYY-MM-DD HH24:MI:SS'); 
        End If; 
      Elsif v_Tmptime > 结束时间_In Then 
        Exit; 
      End If; 
      v_Curtime := v_Curtime + 频率间隔_In / (24 * 60); 
    End Loop; 
  End If; 
 
  If v_Detailtime Is Not Null Then 
    v_Detailtime := Substr(v_Detailtime, 2); 
  End If; 
  Return(v_Detailtime); 
Exception 
  When Others Then 
    Return(Null); 
End Zl_Adviceexetimes;
/

