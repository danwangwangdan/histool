create Function Zl_Advicelasttime 
( 
  医嘱id_In   病人医嘱记录.Id%Type, 
  开始时间_In Date, 
  结束时间_In Date, 
  报表id_In   Zlreports.Id%Type := 0 
) Return Date Is 
  --功能：计算指定的按频率执行的医嘱在指定时间段范围内最后执行的时间 
  --参数：报表id_In：=支持按执行单重打时传入当前报表ID，以记录同一医嘱在每种单据上的最后打印时间 
  --说明：1.计算的执行次数以医嘱已经发送后应该执行的时间为准 
  --      2.时间段内要排除暂停的时间段,次数可能因此而减少 
  --      3.本函数是假定在执行时间及频率性质完全正确的情况下计算。 
  v_Begin Date; 
  v_End   Date; 
  v_Pause Varchar2(4000); 
 
  v_最后打印时间 病人医嘱记录.上次打印时间%Type; 
  v_上次打印时间 病人医嘱记录.上次打印时间%Type; 
  v_开始执行时间 病人医嘱记录.开始执行时间%Type; 
  v_上次执行时间 病人医嘱记录.上次执行时间%Type; 
  v_执行终止时间 病人医嘱记录.执行终止时间%Type; 
  v_执行时间     病人医嘱记录.执行时间方案%Type; 
  v_频率间隔     病人医嘱记录.频率间隔%Type; 
  v_间隔单位     病人医嘱记录.间隔单位%Type; 
  v_执行频率     病人医嘱记录.执行频次%Type; 
 
  n_First  Number(1); 
  v_First  病人医嘱记录.执行时间方案%Type; 
  v_Normal 病人医嘱记录.执行时间方案%Type; 
 
  v_Mtime   Varchar(100); 
  v_Rtime   Varchar(100); 
  v_Curtime Date; 
  v_Tmptime Date; 
 
  --获取指定医嘱的暂停时间段 
  Function Getadvicepause(v_医嘱id 病人医嘱记录.Id%Type) Return Varchar2 Is 
 
    Cursor c_Pause Is 
      Select 操作类型, 操作时间 From 病人医嘱状态 Where 操作类型 In (6, 7) And 医嘱id = v_医嘱id Order By 操作时间; 
 
    v_Outstr Varchar2(4000); 
  Begin 
    For r_Advice In c_Pause Loop 
      If r_Advice.操作类型 = 6 Then 
        v_Outstr := v_Outstr || ';' || To_Char(r_Advice.操作时间, 'YYYY-MM-DD HH24:MI:SS') || ','; 
      Elsif r_Advice.操作类型 = 7 Then 
        --启用的那一秒不在暂停的范围之内 
        v_Outstr := v_Outstr || To_Char(r_Advice.操作时间 - 1 / 24 / 60 / 60, 'YYYY-MM-DD HH24:MI:SS'); 
      End If; 
    End Loop; 
    Return(Substr(v_Outstr, 2)); 
  End; 
  --断一个时间是否在暂停的时间段中 
  Function Timeispause 
  ( 
    v_Time Date, 
    v_Sect Varchar2 
  ) Return Number Is 
    v_Rest      Varchar2(4000); 
    v_Cursect   Varchar2(60); 
    v_Begintime Varchar2(30); 
    v_Endtime   Varchar2(30); 
  Begin 
    If v_Sect Is Null Then 
      Return(0); 
    End If; 
 
    v_Rest := v_Sect || ';'; 
    While v_Rest Is Not Null Loop 
      v_Cursect := Substr(v_Rest, 1, Instr(v_Rest, ';') - 1); 
 
      v_Begintime := Substr(v_Cursect, 1, Instr(v_Cursect, ',') - 1); 
      v_Endtime   := Substr(v_Cursect, Instr(v_Cursect, ',') + 1); 
      If v_Endtime Is Null Then 
        v_Endtime := '3000-01-01 00:00:00'; --可能尚未启用或暂停的时候被停止 
      End If; 
 
      If To_Char(v_Time, 'YYYY-MM-DD HH24:MI:SS') >= v_Begintime And 
         To_Char(v_Time, 'YYYY-MM-DD HH24:MI:SS') <= v_Endtime Then 
        Return(1); 
      End If; 
 
      v_Rest := Substr(v_Rest, Instr(v_Rest, ';') + 1); 
    End Loop; 
    Return(0); 
  End; 
  --求某时间所在周的星期一的日期 
  Function Getweekbase(v_Time Date) Return Date Is 
    v_Week Number(1); 
  Begin 
    v_Week := To_Number(To_Char(v_Time, 'D')); 
    v_Week := v_Week - 1; 
    If v_Week = 0 Then 
      v_Week := 7; 
    End If; 
    Return(Trunc(v_Time - (v_Week - 1))); 
  End; 
Begin 
  --求定义的执行时间段在指定的执行时间段内的医嘱信息 
  --要求已发送过的:上次执行时间 is Not NULL(包括临嘱) 
  --要求是按频率执行的医嘱:执行时间方案 IS Not NULL 
  Begin 
    If 报表id_In <> 0 Then 
      Select a.开始执行时间, a.上次执行时间, a.执行终止时间, a.执行时间方案, a.频率间隔, a.间隔单位, Nvl(b.上次打印时间, To_Date('1900-01-01', 'YYYY-MM-DD')), 
             a.执行频次 
      Into v_开始执行时间, v_上次执行时间, v_执行终止时间, v_执行时间, v_频率间隔, v_间隔单位, v_上次打印时间, v_执行频率 
      From 病人医嘱记录 A, 医嘱执行打印 B 
      Where a.Id = b.医嘱id(+) And b.报表id(+) = 报表id_In And 
            ((a.上次执行时间 Is Not Null And (a.执行时间方案 Is Not Null Or a.间隔单位 = '分钟') And Nvl(a.频率间隔, 0) <> 0 And 
            a.间隔单位 Is Not Null) Or (a.执行频次 In ('一次性', '必要时', '需要时') And a.执行时间方案 Is Null And a.间隔单位 Is Null)) And 
            (开始时间_In <= a.执行终止时间 Or a.执行终止时间 Is Null) And 结束时间_In >= a.开始执行时间 And a.校对时间 Is Not Null And a.医嘱状态 <> 4 And 
            a.Id = 医嘱id_In; 
    Else 
      Select a.开始执行时间, a.上次执行时间, a.执行终止时间, a.执行时间方案, a.频率间隔, a.间隔单位, Nvl(a.上次打印时间, To_Date('1900-01-01', 'YYYY-MM-DD')), 
             a.执行频次 
      Into v_开始执行时间, v_上次执行时间, v_执行终止时间, v_执行时间, v_频率间隔, v_间隔单位, v_上次打印时间, v_执行频率 
      From 病人医嘱记录 A 
      Where ((a.上次执行时间 Is Not Null And (a.执行时间方案 Is Not Null Or a.间隔单位 = '分钟') And Nvl(a.频率间隔, 0) <> 0 And 
            a.间隔单位 Is Not Null) Or (a.执行频次 In ('一次性', '必要时', '需要时') And a.执行时间方案 Is Null And a.间隔单位 Is Null)) And 
            (开始时间_In <= a.执行终止时间 Or a.执行终止时间 Is Null) And 结束时间_In >= a.开始执行时间 And a.校对时间 Is Not Null And a.医嘱状态 <> 4 And 
            a.Id = 医嘱id_In; 
    End If; 
  Exception 
    When Others Then 
      Return(Null); 
  End; 
 
  --一次性临嘱简单计算 
  If v_执行时间 Is Null And v_间隔单位 Is Null Then 
    If v_开始执行时间 >= 开始时间_In And v_开始执行时间 <= 结束时间_In And Not (v_上次打印时间 >= v_开始执行时间) Then 
      If v_执行频率 = '必要时' Then 
        Select Max(要求时间) 
        Into v_最后打印时间 
        From 医嘱执行时间 
        Where 医嘱id = 医嘱id_In And 要求时间 Between 开始时间_In And 结束时间_In; 
        Return(v_最后打印时间); 
      Else 
        Return(v_开始执行时间); 
      End If; 
    Else 
      Return(Null); 
    End If; 
  End If; 
 
  --确定计算时间范围 
  v_Begin := 开始时间_In; 
  If v_开始执行时间 > v_Begin Then 
    v_Begin := v_开始执行时间; 
  End If; 
 
  v_End := 结束时间_In; 
  If v_执行终止时间 Is Not Null Then 
    If v_执行终止时间 < v_End Then 
      v_End := v_执行终止时间; 
      --如果停止到上次打印时间之前，则更新打印时间。 
      if v_执行终止时间< v_上次打印时间 then 
        v_上次打印时间 := To_Date('1900-01-01', 'YYYY-MM-DD'); 
      end if; 
    End If; 
  End If; 
 
  If v_上次执行时间 < v_End Then 
    v_End := v_上次执行时间; 
  End If; 
 
  v_Pause := Getadvicepause(医嘱id_In); 
 
  --执行时间方案基准 
  If Nvl(Instr(v_执行时间, ','), 0) > 0 Then 
    v_First  := Substr(v_执行时间, 1, Instr(v_执行时间, ',') - 1); 
    v_Normal := Substr(v_执行时间, Instr(v_执行时间, ',') + 1); 
  Else 
    v_First  := Null; 
    v_Normal := v_执行时间; 
  End If; 
 
  --计算执行的最后时间 
  v_Curtime := v_开始执行时间; --按小时执行的要求基准时间准确,不能是随意指定的开始时间 
 
  If v_间隔单位 = '周' Then 
    v_Curtime := Getweekbase(v_开始执行时间); --按周执行时在医嘱开始那周的星期一作为基准 
    If v_First Is Not Null Then 
      If (v_Curtime = Getweekbase(v_Begin)) Then 
        n_First := 1; 
      End If; 
    End If; 
 
    While v_Curtime <= v_End Loop 
      If Nvl(n_First, 0) = 1 Then 
        v_Rtime := v_First || '-'; 
      Else 
        v_Rtime := v_Normal || '-'; 
      End If; 
      n_First := 0; 
 
      --1/8:00-3/8:00-5/8:00 
      While v_Rtime Is Not Null Loop 
        v_Mtime   := Substr(v_Rtime, 1, Instr(v_Rtime, '-') - 1); 
        v_Tmptime := v_Curtime + To_Number(Substr(v_Mtime, 1, Instr(v_Mtime, '/') - 1)) - 1; 
 
        v_Mtime := Substr(v_Mtime, Instr(v_Mtime, '/') + 1); 
        If Instr(v_Mtime, ':') = 0 Then 
          v_Mtime := v_Mtime || ':00'; 
        End If; 
        v_Tmptime := Trunc(v_Tmptime) + (To_Date(v_Mtime, 'HH24:MI:SS') - Trunc(To_Date(v_Mtime, 'HH24:MI:SS'))); 
 
        If v_Tmptime >= v_Begin And v_Tmptime <= v_End And v_Tmptime > v_上次打印时间 Then 
          If Timeispause(v_Tmptime, v_Pause) = 0 Then 
            v_最后打印时间 := v_Tmptime; 
          End If; 
        Elsif v_Tmptime > v_End Then 
          Exit; 
        End If; 
 
        v_Rtime := Substr(v_Rtime, Instr(v_Rtime, '-') + 1); 
      End Loop; 
      v_Curtime := Trunc(v_Curtime + 7); 
    End Loop; 
  Elsif v_间隔单位 = '天' Then 
    If v_First Is Not Null Then 
      n_First := 1; 
    End If; 
 
    While v_Curtime <= v_End Loop 
      If Nvl(n_First, 0) = 1 Then 
        v_Rtime := v_First || '-'; 
      Else 
        v_Rtime := v_Normal || '-'; 
      End If; 
      n_First := 0; 
 
      If v_频率间隔 = 1 Then 
        --8:00-12:00-14:00；8-12-14 
        While v_Rtime Is Not Null Loop 
          v_Mtime := Substr(v_Rtime, 1, Instr(v_Rtime, '-') - 1); 
          If Instr(v_Mtime, ':') = 0 Then 
            v_Mtime := v_Mtime || ':00'; 
          End If; 
          v_Tmptime := Trunc(v_Curtime) + (To_Date(v_Mtime, 'HH24:MI:SS') - Trunc(To_Date(v_Mtime, 'HH24:MI:SS'))); 
 
          If v_Tmptime >= v_Begin And v_Tmptime <= v_End And v_Tmptime > v_上次打印时间 Then 
            If Timeispause(v_Tmptime, v_Pause) = 0 Then 
              v_最后打印时间 := v_Tmptime; 
            End If; 
          Elsif v_Tmptime > v_End Then 
            Exit; 
          End If; 
 
          v_Rtime := Substr(v_Rtime, Instr(v_Rtime, '-') + 1); 
        End Loop; 
      Else 
        --1/8:00-1/15:00-2/9:00 
        While v_Rtime Is Not Null Loop 
          v_Mtime   := Substr(v_Rtime, 1, Instr(v_Rtime, '-') - 1); 
          v_Tmptime := v_Curtime + To_Number(Substr(v_Mtime, 1, Instr(v_Mtime, '/') - 1)) - 1; 
 
          v_Mtime := Substr(v_Mtime, Instr(v_Mtime, '/') + 1); 
          If Instr(v_Mtime, ':') = 0 Then 
            v_Mtime := v_Mtime || ':00'; 
          End If; 
          v_Tmptime := Trunc(v_Tmptime) + (To_Date(v_Mtime, 'HH24:MI:SS') - Trunc(To_Date(v_Mtime, 'HH24:MI:SS'))); 
 
          If v_Tmptime >= v_Begin And v_Tmptime <= v_End And v_Tmptime > v_上次打印时间 Then 
            If Timeispause(v_Tmptime, v_Pause) = 0 Then 
              v_最后打印时间 := v_Tmptime; 
            End If; 
          Elsif v_Tmptime > v_End Then 
            Exit; 
          End If; 
 
          v_Rtime := Substr(v_Rtime, Instr(v_Rtime, '-') + 1); 
        End Loop; 
      End If; 
      v_Curtime := Trunc(v_Curtime + v_频率间隔); --因为Loop条件注意要取整 
    End Loop; 
  Elsif v_间隔单位 = '小时' Then 
    --10:00-20:00-40:00；10-20-40；02:30 
    While v_Curtime <= v_End Loop 
      v_Rtime := v_执行时间 || '-'; 
      While v_Rtime Is Not Null Loop 
        v_Mtime := Substr(v_Rtime, 1, Instr(v_Rtime, '-') - 1); 
 
        If Instr(v_Mtime, ':') = 0 Then 
          v_Tmptime := v_Curtime + (To_Number(v_Mtime) - 1) / 24; 
        Else 
          v_Tmptime := v_Curtime + (To_Number(Substr(v_Mtime, 1, Instr(v_Mtime, ':') - 1)) - 1) / 24 + 
                       To_Number(Substr(v_Mtime, Instr(v_Mtime, ':') + 1)) / 60 / 24; 
        End If; 
 
        If v_Tmptime >= v_Begin And v_Tmptime <= v_End And v_Tmptime > v_上次打印时间 Then 
          If Timeispause(v_Tmptime, v_Pause) = 0 Then 
            v_最后打印时间 := v_Tmptime; 
          End If; 
        Elsif v_Tmptime > v_End Then 
          Exit; 
        End If; 
 
        v_Rtime := Substr(v_Rtime, Instr(v_Rtime, '-') + 1); 
      End Loop; 
      v_Curtime := v_Curtime + v_频率间隔 / 24; 
    End Loop; 
  Elsif v_间隔单位 = '分钟' Then 
    --无执行时间 
    While v_Curtime <= v_End Loop 
      v_Tmptime := v_Curtime; 
 
      If v_Tmptime >= v_Begin And v_Tmptime <= v_End And v_Tmptime > v_上次打印时间 Then 
        If Timeispause(v_Tmptime, v_Pause) = 0 Then 
          v_最后打印时间 := v_Tmptime; 
        End If; 
      Elsif v_Tmptime > v_End Then 
        Exit; 
      End If; 
 
      v_Curtime := v_Curtime + v_频率间隔 / (24 * 60); 
    End Loop; 
  End If; 
 
  Return(v_最后打印时间); 
End Zl_Advicelasttime;
/

