create Function Zl_AdviceNextTime(医嘱id_In 病人医嘱记录.ID%Type) Return Date As 
  --功能：获取指定长期医嘱(可选频率)的下次执行时间,用于判断预定执行终止时间的医嘱自动停止 
	v_入院日期 Date; 
  v_开始时间 Date; 
  v_上次时间 Date; 
  v_执行时间 病人医嘱记录.执行时间方案%Type; 
  v_频率间隔 病人医嘱记录.频率间隔%Type; 
  v_间隔单位 病人医嘱记录.间隔单位%Type; 
 
	n_First		Number(1); 
	v_First		病人医嘱记录.执行时间方案%Type; 
	v_Normal	病人医嘱记录.执行时间方案%Type; 
 
	v_MTime   病人医嘱记录.执行时间方案%Type; 
  v_RTime   病人医嘱记录.执行时间方案%Type; 
 
  v_curTime Date; 
  v_tmpTime Date; 
 
  --求某时间所在周的星期一的日期 
  Function GetWeekBase(v_Time Date) Return Date Is 
    v_Week Number(1); 
  Begin 
    v_Week := To_Number(To_Char(v_Time, 'D')); 
    v_Week := v_Week - 1; 
    If v_Week = 0 Then 
      v_Week := 7; 
    End If; 
    Return(Trunc(v_Time - (v_Week - 1))); 
  End; 
Begin 
  Begin 
    Select A.开始执行时间, A.上次执行时间, A.执行时间方案, A.频率间隔, A.间隔单位,B.入院日期 
    Into v_开始时间, v_上次时间, v_执行时间, v_频率间隔, v_间隔单位, v_入院日期 
    From 病人医嘱记录 A,病案主页 B 
    Where A.病人ID=B.病人ID And A.主页ID=B.主页ID And A.ID = 医嘱id_In; 
  Exception 
    When Others Then 
      Null; 
  End; 
 
  If v_开始时间 Is Not Null And (v_执行时间 Is Not Null Or v_间隔单位 = '分钟') And Nvl(v_频率间隔, 0) <> 0 And v_间隔单位 Is Not Null Then 
		IF Nvl(Instr(v_执行时间,','),0)>0 Then 
			v_First:=Substr(v_执行时间,1,Instr(v_执行时间,',')-1); 
			v_Normal:=Substr(v_执行时间,Instr(v_执行时间,',')+1); 
		Else 
			v_First:=Null; 
			v_Normal:=v_执行时间; 
		End IF; 
 
    v_curTime := v_开始时间; 
 
    If v_间隔单位 = '周' Then 
			If (GetWeekBase(v_开始时间) = GetWeekBase(v_入院日期)) And v_入院日期 Is Not NULL And v_First Is Not NULL Then 
				n_First:=1; 
			End IF; 
      v_curTime := GetWeekBase(v_开始时间); 
 
			While True Loop 
				If Nvl(n_First,0)=1 Then 
					v_RTime := v_First||'-'; 
				Else 
					v_RTime := v_Normal||'-'; 
				End IF; 
				n_First:=0; 
 
        --1/8:00-3/8:00-5/8:00 
        While v_RTime Is Not Null Loop 
          v_MTime   := Substr(v_RTime, 1, Instr(v_RTime, '-') - 1); 
          v_tmpTime := v_curTime + To_Number(Substr(v_MTime, 1, Instr(v_MTime, '/') - 1)) - 1; 
 
          v_MTime := Substr(v_MTime, Instr(v_MTime, '/') + 1); 
          If Instr(v_MTime, ':') = 0 Then 
            v_MTime := v_MTime || ':00'; 
          End If; 
          v_tmpTime := Trunc(v_tmpTime) + (To_Date(v_MTime, 'HH24:MI:SS') - Trunc(To_Date(v_MTime, 'HH24:MI:SS'))); 
          If v_tmpTime >= v_开始时间 And (v_tmpTime > v_上次时间 Or v_上次时间 Is Null) Then 
            Return(v_tmpTime); 
          End If; 
 
          v_RTime := Substr(v_RTime, Instr(v_RTime, '-') + 1); 
        End Loop; 
        v_curTime := v_curTime + 7; 
      End Loop; 
    Elsif v_间隔单位 = '天' Then 
			If (Trunc(v_开始时间) = Trunc(v_入院日期)) And v_入院日期 Is Not NULL And v_First Is Not NULL Then 
				n_First:=1; 
			End IF; 
 
      While True Loop 
				If Nvl(n_First,0)=1 Then 
					v_RTime := v_First||'-'; 
				Else 
					v_RTime := v_Normal||'-'; 
				End IF; 
				n_First:=0; 
 
				If v_频率间隔 = 1 Then 
          --8:00-12:00-14:00；8-12-14 
          While v_RTime Is Not Null Loop 
            v_MTime := Substr(v_RTime, 1, Instr(v_RTime, '-') - 1); 
            If Instr(v_MTime, ':') = 0 Then 
              v_MTime := v_MTime || ':00'; 
            End If; 
            v_tmpTime := Trunc(v_curTime) + (To_Date(v_MTime, 'HH24:MI:SS') - Trunc(To_Date(v_MTime, 'HH24:MI:SS'))); 
            If v_tmpTime >= v_开始时间 And (v_tmpTime > v_上次时间 Or v_上次时间 Is Null) Then 
              Return(v_tmpTime); 
            End If; 
 
            v_RTime := Substr(v_RTime, Instr(v_RTime, '-') + 1); 
          End Loop; 
        Else 
          --1/8:00-1/15:00-2/9:00 
          While v_RTime Is Not Null Loop 
            v_MTime   := Substr(v_RTime, 1, Instr(v_RTime, '-') - 1); 
            v_tmpTime := v_curTime + To_Number(Substr(v_MTime, 1, Instr(v_MTime, '/') - 1)) - 1; 
 
            v_MTime := Substr(v_MTime, Instr(v_MTime, '/') + 1); 
            If Instr(v_MTime, ':') = 0 Then 
              v_MTime := v_MTime || ':00'; 
            End If; 
            v_tmpTime := Trunc(v_tmpTime) + (To_Date(v_MTime, 'HH24:MI:SS') - Trunc(To_Date(v_MTime, 'HH24:MI:SS'))); 
            If v_tmpTime >= v_开始时间 And (v_tmpTime > v_上次时间 Or v_上次时间 Is Null) Then 
              Return(v_tmpTime); 
            End If; 
 
            v_RTime := Substr(v_RTime, Instr(v_RTime, '-') + 1); 
          End Loop; 
        End If; 
        v_curTime := v_curTime + v_频率间隔; 
      End Loop; 
    Elsif v_间隔单位 = '小时' Then 
      --10:00-20:00-40:00；10-20-40；02:30 
      While True Loop 
        v_RTime := v_执行时间 || '-'; 
        While v_RTime Is Not Null Loop 
          v_MTime := Substr(v_RTime, 1, Instr(v_RTime, '-') - 1); 
 
          If Instr(v_MTime, ':') = 0 Then 
            v_tmpTime := v_curTime + (To_Number(v_MTime) - 1) / 24; 
          Else 
            v_tmpTime := v_curTime + (To_Number(Substr(v_MTime, 1, Instr(v_MTime, ':') - 1)) - 1) / 24 + 
                         To_Number(Substr(v_MTime, Instr(v_MTime, ':') + 1)) / 60 / 24; 
          End If; 
          If v_tmpTime >= v_开始时间 And (v_tmpTime > v_上次时间 Or v_上次时间 Is Null) Then 
            Return(v_tmpTime); 
          End If; 
 
          v_RTime := Substr(v_RTime, Instr(v_RTime, '-') + 1); 
        End Loop; 
        v_curTime := v_curTime + v_频率间隔 / 24; 
      End Loop; 
    Elsif v_间隔单位 = '分钟' Then 
      --无执行时间 
      While True Loop 
        v_tmpTime := v_curTime; 
 
        If v_tmpTime >= v_开始时间 And (v_tmpTime > v_上次时间 Or v_上次时间 Is Null) Then 
          Return(v_tmpTime); 
        End If; 
 
        v_curTime := v_curTime + v_频率间隔 / (24 * 60); 
      End Loop; 
    End If; 
  End If; 
 
  Return(To_Date('1900-01-01', 'YYYY-MM-DD')); 
End;
/

