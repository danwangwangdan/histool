create Function zl_AdviceSendCheck 
( 
  医嘱id_In 病人医嘱记录.Id%Type, 
  附加_In   Varchar2 := Null 
) Return Varchar2 
--功能:门诊医嘱发送时，对医嘱的相关内容进行检查，并返回提示及处理结果。 
  --参数：医嘱id_In=要发送的每一条的医嘱ID 
  --      附加_In=额外的附加参数信息，可选参数 
  --返回："处理结果|提示信息",处理结果=0-正常,1-询问提示,2-禁止；处理结果为0时，无需返回提示信息及分隔符。 
 As 
  v_Return Varchar2(200); 
Begin 
  v_Return := Null; 
  Return v_Return; 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End zl_AdviceSendCheck;
/

