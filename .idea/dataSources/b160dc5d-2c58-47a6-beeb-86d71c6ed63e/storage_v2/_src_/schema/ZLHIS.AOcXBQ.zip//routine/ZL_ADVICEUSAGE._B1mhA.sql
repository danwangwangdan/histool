create Function zl_AdviceUsage( 
	AdviceID In 病人医嘱记录.Id%Type, 
	MediShow In Number:=0) 
	--单一药品时是否显现药品：0-不显示，1-要显示；多种药品时肯定显现药品 
Return Varchar2 Is 
	vUsage			Varchar2(500); 
	vMedis0			Varchar2(500); 
	vMedis1			Varchar2(500); 
	vEvery			Varchar2(20); 
	vCount			Number; 
	vFrequency		Varchar2(500); 
Begin 
	vCount:=0; 
	vMedis0:=''; 
	vMedis1:=''; 
	For r_Medi In ( 
		Select L.单次用量,I.计算单位,I.名称 
		From 诊疗项目目录 I, 
			(Select L.序号,L.诊疗项目id,L.单次用量 
			From 病人医嘱记录 L 
			Where L.相关id=AdviceID) L 
		Where L.诊疗项目id=I.Id 
		Order By L.序号) 
	Loop 
		vCount:=vCount+1; 
		vEvery:=To_char(r_Medi.单次用量); 
		If Substr(vEvery,1,1)='.' Then 
			vEvery:='0'||vEvery; 
		End If; 
		vMedis0:=vMedis0||','||vEvery||Trim(r_Medi.计算单位); 
		vMedis1:=vMedis1||','||r_Medi.名称||vEvery||Trim(r_Medi.计算单位); 
	End Loop; 
 
	If vCount<2 Then 
		If Medishow=0 Then 
			vUsage:=Substr(vMedis0,2); 
		Else 
			vUsage:=Substr(vMedis1,2); 
		End If; 
	Else 
		vUsage:='分别'||Substr(vMedis1,2); 
	End If; 
 
	Select 医嘱内容||','||执行频次 
		Into vFrequency 
	From 病人医嘱记录 
	Where Id=AdviceID; 
 
	vUsage:='  用法:每次'||vUsage||','||vFrequency; 
 
	Return(vUsage); 
End zl_AdviceUsage;
/

