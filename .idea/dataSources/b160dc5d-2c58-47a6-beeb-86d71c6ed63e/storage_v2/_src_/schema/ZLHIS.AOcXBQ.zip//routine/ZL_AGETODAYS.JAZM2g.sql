create function ZL_AgeToDays(strAge_IN varchar2) 
return number IS 
  v_index number; 
  v_return number; 
begin 
  v_return := 0; 
 
  case 
    when instr(strAge_IN,'岁') > 0 then v_return := ZL_GetNumber(strAge_IN) * 365; 
    when instr(strAge_IN,'月') > 0 then v_return := ZL_GetNumber(strAge_IN) * 30; 
    when instr(strAge_IN,'周') > 0 then v_return := ZL_GetNumber(strAge_IN) * 7; 
    when instr(strAge_IN,'天') > 0 then v_return := ZL_GetNumber(strAge_IN); 
    else v_return := 0; 
  end case; 
 
  return v_return; 
Exception 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
end ZL_AgeToDays;
/

