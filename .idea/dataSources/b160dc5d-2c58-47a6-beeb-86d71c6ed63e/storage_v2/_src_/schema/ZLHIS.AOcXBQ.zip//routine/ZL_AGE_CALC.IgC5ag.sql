create Function Zl_Age_Calc 
( 
  病人id_In   病人信息.病人id%Type, 
  出生日期_In Date := Null, 
  计算日期_In Date := Null 
) Return Varchar2 
--功能:根据出生日期计算年龄.当天登记病人,保持年龄不变. 
  --返回:1天以内：X小时[X分钟],1天至1月以内：X天[X小时],1月至1岁以内：X月[X天],1岁至儿童年龄上限：X岁[X月],>=儿童年龄上限：X岁 
  --说明:1天以内，是指按出生日期24小时算;1月以内，是指对天计算；比如7.8日出生，8.8日才算1月;1岁以内，也是对天计算。;“以内”都是指“<”。 
 As 
  d_出生日期      Date; 
  d_计算日期      Date; 
  n_Days          Number; 
  n_Months        Number; 
  v_年龄          病人信息.年龄%Type; 
  n_Upperagelimit Number; --参数:年龄上限 
 
  v_Return Varchar2(20); --由于病人信息等相关表的年龄字段为10个字符，所以最大允许10个字符或5个汉字 
Begin 
  --当天登记的病人不用重算年龄 
  If Nvl(病人id_In, 0) <> 0 Then 
    Begin 
      Select 年龄 
      Into v_年龄 
      From 病人信息 
      Where 病人id = 病人id_In And Floor(Sysdate - 登记时间) = 0 And 年龄 Is Not Null; 
    Exception 
      When Others Then 
        Null; 
    End; 
    If v_年龄 Is Not Null Then 
      v_Return := v_年龄; 
      Return v_Return; 
    End If; 
  End If; 
 
  If 出生日期_In Is Null Then 
    If Nvl(病人id_In, 0) <> 0 Then 
      Select 出生日期 Into d_出生日期 From 病人信息 Where 病人id = 病人id_In; 
    End If; 
    If d_出生日期 Is Null Then 
      Return Null; 
    End If; 
  Else 
    d_出生日期 := 出生日期_In; 
  End If; 
  If 计算日期_In Is Null Then 
    Select Sysdate Into d_计算日期 From Dual; 
  Else 
    d_计算日期 := 计算日期_In; 
  End If; 
  --如果出生日期大于计算日期,则直接为0小时 
  If (d_计算日期 - d_出生日期) < 0 Then 
    v_Return := '0小时'; 
    Return v_Return; 
  End If; 
  --获取儿童年龄的上限 
  Begin 
    Select Nvl(参数值, 14) 
    Into n_Upperagelimit 
    From zlParameters 
    Where 系统 = 100 And Nvl(模块, 0) = 0 And 参数号 = 147; 
  Exception 
    When Others Then 
      n_Upperagelimit := 14; 
  End; 
  n_Months := Trunc(Months_Between(d_计算日期, d_出生日期)); 
  If n_Months < 12 * n_Upperagelimit Then 
    --小于1岁的情况 
    If n_Months < 12 Then 
      --小于1月 
      If n_Months < 1 Then 
        n_Days := Trunc(d_计算日期 - d_出生日期); 
        --一天以内 
        If n_Days = 0 Then 
          n_Days := Trunc((d_计算日期 - d_出生日期) * 24 * 60); 
          If Mod(n_Days, 60) = 0 Then 
            v_Return := n_Days / 60 || '小时'; 
          Else 
            v_Return := Floor(n_Days / 60) || '小时' || Mod(n_Days, 60) || '分钟'; 
          End If; 
        Else 
          --一天至一月  精确到小时 :X天X小时 
          n_Days := Trunc((d_计算日期 - d_出生日期) * 24); 
          If Mod(n_Days, 24) = 0 Then 
            v_Return := n_Days / 24 || '天'; 
          Else 
            v_Return := Floor(n_Days / 24) || '天' || Mod(n_Days, 24) || '小时'; 
          End If; 
        End If; 
      Else 
        --大于1月 
        n_Days := Trunc(Add_Months(d_计算日期, -1 * n_Months) - d_出生日期); 
        If n_Days >= 31 Then 
          --针对计算日期是2月份最后一天,出生日期刚好大于2月份最后一天且当天不是本月的最后一天 
          --如：计算日期：2016-02-29   出生日期：2015-01-30 
          n_Months := n_Months + 1; 
          n_Days   := n_Days - 31; 
        End If; 
        If n_Days = 0 Then 
          v_Return := n_Months || '月'; 
        Else 
          v_Return := n_Months || '月' || n_Days || '天'; 
        End If; 
      End If; 
    Else 
      --1岁到小于婴儿年龄上限的情况 
      If Mod(n_Months, 12) = 0 Then 
        v_Return := n_Months / 12 || '岁'; 
      Else 
        v_Return := Floor(n_Months / 12) || '岁' || Mod(n_Months, 12) || '月'; 
      End If; 
    End If; 
  Else 
    --大于等于婴儿年龄上限(直接X岁) 
    v_Return := Floor(n_Months / 12) || '岁'; 
  End If; 
  Return v_Return; 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zl_Age_Calc;
/

