create Function Zl_Age_Check 
( 
  年龄_In     病人信息.年龄%Type, 
  出生日期_In Date := Null, 
  计算日期_In Date := Null 
) Return Varchar2 
--年龄格式:X小时[X分钟];X天[X小时];X月[X天];X岁[X月] 
 As 
  v_Return           Varchar2(1000); 
  v_Info             Varchar2(1000); 
  v_Tmpone           Varchar2(20); 
  v_Tmptwo           Varchar2(20); 
  v_Unitone          Varchar2(4); 
  v_Unittwo          Varchar2(4); 
  n_Ageformatcorrect Number(1); 
  n_Ageformat        Number(1); 
  v_Age              病人信息.年龄%Type; 
  v_Birthday         Varchar2(20); 
Begin 
  v_Info             := '1|年龄格式只能为:X小时[X分钟] 或 X天[X小时] 或 X月[X天] 或 X岁[X月]，并且X为正整数。'; 
  n_Ageformatcorrect := 0; 
  --检查年龄格式是否正确 
  For I In 1 .. 4 Loop 
    If I = 1 Then 
      v_Unitone := '岁'; 
      v_Unittwo := '月'; 
    Elsif I = 2 Then 
      v_Unitone := '月'; 
      v_Unittwo := '天'; 
    Elsif I = 3 Then 
      v_Unitone := '天'; 
      v_Unittwo := '小时'; 
    Else 
      v_Unitone := '小时'; 
      v_Unittwo := '分钟'; 
    End If; 
    --1:X岁[X月],2:X月[X天],3:X天,4:X小时[X分钟] 
    If Instr(年龄_In, v_Unitone, 1) > 0 And n_Ageformatcorrect = 0 Then 
      If Instr(年龄_In, v_Unitone, 1) = 1 Then 
        v_Return := v_Info; 
        Return v_Return; 
      Else 
        v_Tmpone := Substr(年龄_In, 1, Instr(年龄_In, v_Unitone, 1) - 1); 
        --岁前面必须为数字 
        If Translate(v_Tmpone, '\0123456789', '\') Is Null Then 
          If To_Number(v_Tmpone) > 200 And v_Unitone = '岁' Then 
            v_Return := '1|年龄格式为:X岁时，岁数不能大于200岁。'; 
            Return v_Return; 
          Elsif To_Number(v_Tmpone) >= 12 And v_Unitone = '月' Then 
            v_Return := '1|年龄格式为:X月时，月份数必须小于12个月。'; 
            Return v_Return; 
          Elsif To_Number(v_Tmpone) >= 31 And v_Unitone = '天' Then 
            v_Return := '1|年龄格式为:X天时，天数必须小于31天。'; 
            Return v_Return; 
          Elsif To_Number(v_Tmpone) >= 24 And v_Unitone = '小时' Then 
            v_Return := '1|年龄格式为:X小时时，小时数必须小于24小时。'; 
            Return v_Return; 
          End If; 
          If Instr(年龄_In, v_Unitone, 1) + Length(v_Unitone) - 1 = Length(年龄_In) Then 
            n_Ageformatcorrect := I; 
            Exit; 
          Else 
            v_Tmpone := Substr(年龄_In, Instr(年龄_In, v_Unitone, 1) + Length(v_Unitone)); 
            If Instr(v_Tmpone, v_Unittwo, 1) = 0 Or Length(v_Tmpone) = Length(v_Unittwo) Or 
               Substr(v_Tmpone, Length(v_Tmpone) - Length(v_Unittwo) + 1, Length(v_Unittwo)) <> v_Unittwo Then 
              v_Return := v_Info; 
              Return v_Return; 
            Else 
              v_Tmptwo := Substr(v_Tmpone, 1, Length(v_Tmpone) - Length(v_Unittwo)); 
              If Translate(v_Tmptwo, '\0123456789', '\') Is Null Then 
                If To_Number(v_Tmptwo) >= 12 And v_Unittwo = '月' Then 
                  v_Return := '1|年龄格式为:[X岁X月]时，月份数必须小于12个月。'; 
                  Return v_Return; 
                Elsif To_Number(v_Tmptwo) >= 31 And v_Unittwo = '天' Then 
                  v_Return := '1|年龄格式为:[X月X天]时，天数必须小于31天。'; 
                  Return v_Return; 
                Elsif To_Number(v_Tmptwo) >= 60 And v_Unittwo = '分钟' Then 
                  v_Return := '1|年龄格式为:[X小时X分钟]时，分钟数必须小于60分钟。'; 
                  Return v_Return; 
                Elsif To_Number(v_Tmptwo) >= 24 And v_Unittwo = '小时' Then 
                  v_Return := '1|年龄格式为:[X天X小时]时，小时数必须小于24小时。'; 
                  Return v_Return; 
                Else 
                  n_Ageformatcorrect := I; 
                  Exit; 
                End If; 
              Else 
                v_Return := v_Info; 
                Return v_Return; 
              End If; 
            End If; 
          End If; 
        Else 
          v_Return := v_Info; 
          Return v_Return; 
        End If; 
      End If; 
    End If; 
  End Loop; 
 
  --年龄不再上述任何一个范围:如年龄为:51、1周1天 
  If n_Ageformatcorrect = 0 Then 
    v_Return := v_Info; 
    Return v_Return; 
  End If; 
  --年龄格式正确，检查年龄段是否在出生日期段内 
  If 出生日期_In Is Null Then 
    Return Null; 
  End If; 
  v_Birthday := To_Char(出生日期_In, 'YYYY-MM-DD hh24:mi:ss'); 
  If Substr(v_Birthday, 12) = '00:00:00' Then 
    v_Birthday := Substr(v_Birthday, 1, 10); 
  Else 
    v_Birthday := Substr(v_Birthday, 1, 16); 
  End If; 
  v_Age := Zl_Age_Calc(0, 出生日期_In, 计算日期_In); 
  --计算根据出生日期计算出来的年龄在那一个段 
  n_Ageformat := 0; 
  v_Tmpone    := ''; 
  If Instr(v_Age, '岁', 1) > 0 Then 
    n_Ageformat := 1; 
    v_Tmpone    := 'X岁[X月]'; 
  Elsif Instr(v_Age, '月', 1) > 0 Then 
    n_Ageformat := 2; 
    v_Tmpone    := 'X月[X天]'; 
  Elsif Instr(v_Age, '天', 1) > 0 Then 
    n_Ageformat := 3; 
    v_Tmpone    := 'X天[小时]'; 
  Elsif Instr(v_Age, '小时', 1) > 0 Then 
    n_Ageformat := 4; 
    v_Tmpone    := 'X小时[X分钟]'; 
  End If; 
  v_Return := ''; 
  If n_Ageformat = 0 Then 
    v_Return := '1|计算年龄的函数：Zl_Age_Calc 存在问题,请直接与开发商联系。'; 
    Return v_Return; 
  End If; 
  --检查根据出生日期计算出来的年龄段和传入的年龄年龄段是否相同 
  If n_Ageformatcorrect <> n_Ageformat Then 
    v_Return := '1|年龄[' || 年龄_In || ']与出生日期计算出来的年龄[' || v_Age || ']在格式上不一致，'; 
    v_Return := v_Return || '当前年龄格式应该为:' || v_Tmpone || '。'; 
    Return v_Return; 
  End If; 
  --同一时间段内则坚持年龄是否相等 
  If 年龄_In <> v_Age Then 
    v_Return := '0|年龄[' || 年龄_In || ']与出生日期不一致，' || v_Birthday || '出生到现在应该是[' || v_Age || ']。'; 
  End If; 
  Return v_Return; 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zl_Age_Check;
/

