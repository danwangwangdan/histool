create Function Zl_Billclass 
( 
  病人id_In 病人信息.病人id%Type, 
  主页id_In 病案主页.主页id%Type := Null, 
  险类_In   病案主页.险类%Type := 0 
) Return Varchar2 As 
  -------------------------------------------------- 
  --获取病人的票据使用类别 
  --编制:刘兴洪 
  -------------------------------------------------- 
Begin 
  If Nvl(险类_In, 0) = 0 Then 
    Return '普通病人'; 
  Else 
    Return '医保病人'; 
  End If; 
End Zl_Billclass;
/

