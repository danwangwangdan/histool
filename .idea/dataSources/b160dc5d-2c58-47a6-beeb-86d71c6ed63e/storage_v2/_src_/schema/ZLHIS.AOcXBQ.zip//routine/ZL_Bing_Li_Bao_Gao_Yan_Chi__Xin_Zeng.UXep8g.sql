create function Zl_病理报告延迟_新增 
( 
  病理医嘱ID_IN      病理报告延迟.病理医嘱ID%Type, 
  延迟原因_IN    病理报告延迟.延迟原因%Type, 
  延迟天数_IN    病理报告延迟.延迟天数%Type, 
  临时诊断_IN    病理报告延迟.临时诊断%Type, 
  转达人_IN      病理报告延迟.转达人%Type, 
  登记人_IN      病理报告延迟.登记人%Type, 
  登记时间_IN    病理报告延迟.登记时间%Type 
) return number Is 
PRAGMA AUTONOMOUS_TRANSACTION; 
v_id 病理报告延迟.ID%Type; 
Begin 
  --获取延迟报告ID 
  select 病理报告延迟_ID.NEXTVAL into v_id from dual; 
 
  --写入报告延迟记录 
  insert into 病理报告延迟(ID, 病理医嘱ID, 延迟原因,延迟天数,临时诊断,转达人,登记人,登记时间,当前状态) 
  values(v_id, 病理医嘱ID_IN, 延迟原因_IN, 延迟天数_IN, 临时诊断_IN, 转达人_IN,登记人_IN,登记时间_IN, 0); 
 
  commit; 
 
  return v_id; 
Exception 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
End Zl_病理报告延迟_新增;
/

