create function ZL_病理标本配置_新增 
( 
       标本名称_IN 病理检查标本.标本名称%Type, 
       标本部位_IN 病理检查标本.标本部位%Type, 
       标本类型_IN 病理检查标本.标本类型%Type, 
       默认标本量_IN   病理检查标本.默认标本量%Type, 
       默认制片数_IN 病理检查标本.默认制片数%Type, 
       简码_IN     病理检查标本.简码%Type, 
       备注_IN     病理检查标本.备注%Type 
)return number is 
PRAGMA AUTONOMOUS_TRANSACTION; 
 
       v_标本配置ID 病理检查标本.ID%Type; 
begin 
  select 病理检查标本_ID.NEXTVAL into  v_标本配置ID  from dual; 
 
  insert into 病理检查标本(ID, 标本名称, 标本部位,标本类型,默认标本量,默认制片数,简码,备注) 
  values(v_标本配置ID, 标本名称_IN, 标本部位_IN, 标本类型_IN, 默认标本量_IN, 默认制片数_IN, 简码_IN,备注_IN); 
 
  insert into 诊疗检查部位(类型,编码,名称,分组,备注,方法) 
  values('病理',v_标本配置ID,标本名称_IN,标本部位_IN,备注_IN, '0标本;0蜡块;0玻片;0白片;0其他'); 
 
  commit; 
 
  return v_标本配置ID; 
 
Exception 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
end ZL_病理标本配置_新增;
/

