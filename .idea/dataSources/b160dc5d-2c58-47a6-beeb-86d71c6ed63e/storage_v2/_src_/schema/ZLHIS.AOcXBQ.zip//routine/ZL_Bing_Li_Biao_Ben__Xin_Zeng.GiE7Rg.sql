create function Zl_病理标本_新增 
( 
  医嘱ID_IN   病理标本信息.医嘱ID%Type, 
  标本名称_IN 病理标本信息.标本名称%Type, 
  标本类型_IN 病理标本信息.标本类型%Type, 
  采集部位_IN 病理标本信息.采集部位%Type, 
  标本数量_IN 病理标本信息.数量%Type, 
  材料类别_IN 病理标本信息.材料类别%Type, 
  原有编号_IN 病理标本信息.原有编号%Type, 
  存放位置_IN 病理标本信息.存放位置%Type, 
  接收日期_IN 病理标本信息.接收日期%Type, 
  备注信息_IN 病理标本信息.备注%Type 
) return number Is 
PRAGMA AUTONOMOUS_TRANSACTION; 
 
v_标本ID 病理标本信息.标本ID%Type; 
 
Begin 
  select 病理标本信息_标本ID.NEXTVAL into  v_标本ID  from dual; 
 
  insert into 病理标本信息(标本ID,医嘱ID,标本名称,标本类型,采集部位,数量,材料类别,原有编号,存放位置,接收日期,备注) 
  values(v_标本ID, 医嘱ID_IN, 标本名称_IN, 标本类型_IN, 采集部位_IN, 标本数量_IN, 材料类别_IN, 原有编号_IN, 存放位置_IN, 接收日期_IN, 备注信息_IN); 
 
  commit; 
 
  return  v_标本ID; 
Exception 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
End Zl_病理标本_新增;
/

