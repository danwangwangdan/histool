create function ZL_病理材料_材料遗失 
( 
       归档ID_IN      病理归档信息.ID%Type, 
       遗失数量_IN    病理遗失信息.遗失数量%Type, 
       遗失日期_IN    病理遗失信息.遗失日期%Type, 
       登记人_IN      病理遗失信息.登记人%Type 
)return number is 
PRAGMA AUTONOMOUS_TRANSACTION; 
       v_遗失ID       病理遗失信息.ID%Type; 
       v_存放状态     病理归档信息.存放状态%Type; 
       v_已借数量     number(5); 
       v_遗失数量     number(5); 
       v_材料数量     number(5); 
 
       v_Error    varchar(255); 
       Err_Custom Exception; 
begin 
  --查询借阅数量(排除已遗失的或部分归还的借阅关联，如果归还状态为3或者2，系统将做遗失处理) 
  select nvl(sum(借阅数量), 0) into v_已借数量 from 病理借阅关联 where 归还状态=0 and 归档ID=归档ID_IN; 
  select nvl(sum(遗失数量), 0) into v_遗失数量 from 病理遗失信息 where 归档ID=归档ID_IN; 
  select ZL_病理材料_获取数量(归档ID_IN) into v_材料数量 from dual; 
 
  if v_已借数量 + v_遗失数量 + 遗失数量_IN > v_材料数量 then 
      v_Error := '材料遗失处理数量大于材料实际数量,不能进行处理。'; 
      Raise Err_Custom; 
  end if; 
 
  select 病理遗失信息_ID.NEXTVAL into v_遗失ID from dual; 
 
  insert into 病理遗失信息(id,借阅ID,归档ID,遗失数量,遗失原因,遗失日期,登记人) 
  values(v_遗失ID,null,归档ID_IN,遗失数量_IN,'材料遗失处理',遗失日期_IN,登记人_IN); 
 
  --更新材料存放及借阅状态 
  ZL_病理材料_更新状态(归档ID_IN); 
 
  commit; 
 
  select 存放状态 into v_存放状态 from 病理归档信息 where Id=归档ID_IN; 
 
  return v_存放状态; 
Exception 
  When Err_Custom Then 
    Raise_Application_Error(-20101, '[ZLSOFT]' || v_Error || '[ZLSOFT]'); 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
end ZL_病理材料_材料遗失;
/

