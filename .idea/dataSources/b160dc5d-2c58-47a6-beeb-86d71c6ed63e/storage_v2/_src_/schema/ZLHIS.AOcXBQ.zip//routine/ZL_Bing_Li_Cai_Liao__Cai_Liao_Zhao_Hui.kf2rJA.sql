create function ZL_病理材料_材料找回 
( 
       归档ID_IN      病理归档信息.ID%Type, 
       找回数量_IN    病理遗失信息.遗失数量%Type, 
       登记人_IN      病理遗失信息.登记人%Type 
)return number is 
PRAGMA AUTONOMOUS_TRANSACTION; 
       v_遗失ID     病理遗失信息.ID%Type; 
       v_存放状态   病理归档信息.存放状态%Type; 
begin 
 
  select 病理遗失信息_ID.NEXTVAL into v_遗失ID from dual; 
 
  insert into 病理遗失信息(id,借阅ID,归档ID,遗失数量,遗失原因,遗失日期,登记人) 
  values(v_遗失ID,null,归档ID_IN, -1 * 找回数量_IN, '材料找回处理',sysdate,登记人_IN); 
 
  --更新材料存放及借阅状态 
  ZL_病理材料_更新状态(归档ID_IN); 
 
  commit; 
 
  select 存放状态 into v_存放状态 from 病理归档信息 where Id=归档ID_IN; 
 
  return v_存放状态; 
Exception 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
end ZL_病理材料_材料找回;
/

