create function ZL_病理材料_获取数量 
( 
       归档ID_IN    病理归档信息.ID%Type 
)return number is 
       v_材料数量 number(5); 
       v_材料来源 病理归档信息.资料来源%Type; 
       v_来源ID   病理归档信息.病理医嘱ID%Type; 
 
       v_Error    varchar(255); 
       Err_Custom Exception; 
begin 
  begin 
    Select 资料来源, decode(资料来源, 1, 材块ID, 2, 制片ID, 3, 特检ID, 0) into v_材料来源, v_来源ID from 病理归档信息 where ID=归档ID_IN; 
  exception 
    When Others Then 
      v_Error := '未找到对应的材料信息，材料数量获取失败。'; 
      Raise Err_Custom; 
  end; 
 
  case 
    when v_材料来源 = 1 then --来源蜡块 
       select 蜡块数 into v_材料数量 from 病理取材信息 where 材块ID=v_来源ID; 
 
    when v_材料来源 = 2 then --来源切片 
       select 制片数 into v_材料数量  from 病理制片信息 where ID=v_来源ID; 
 
    when v_材料来源 = 3 then --来源特检 
       v_材料数量 := 1; 
    else null; 
  end case; 
 
  return v_材料数量; 
exception 
  When Err_Custom Then 
    Raise_Application_Error(-20101, '[ZLSOFT]' || v_Error || '[ZLSOFT]'); 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
end ZL_病理材料_获取数量;
/

