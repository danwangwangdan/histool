create function ZL_病理档案_材料入档 
( 
       档案ID_IN      病理档案信息.ID%Type, 
       病理医嘱ID_IN  病理归档信息.病理医嘱ID%Type, 
       材料来源_IN    病理归档信息.资料来源%Type, 
       来源ID_IN      病理归档信息.材块ID%Type 
)return number is 
PRAGMA AUTONOMOUS_TRANSACTION; 
       v_归档ID  病理归档信息.ID%Type; 
begin 
 
  select 病理归档信息_ID.NEXTVAL into v_归档ID from dual; 
 
  case 
    when 材料来源_IN = 1 then --来源蜡块 
       insert into 病理归档信息(ID, 档案ID, 病理医嘱ID, 资料来源,材块ID,存放状态, 借阅状态) 
       values(v_归档ID, 档案ID_IN, 病理医嘱ID_IN,材料来源_In,来源ID_In,0,0); 
 
       update 病理取材信息 set 归档状态= 1 where 材块ID=来源ID_In; 
 
    when 材料来源_IN = 2 then --来源切片 
       insert into 病理归档信息(ID, 档案ID, 病理医嘱ID, 资料来源,制片ID,存放状态, 借阅状态) 
       values(v_归档ID, 档案ID_IN, 病理医嘱ID_IN, 材料来源_In,来源ID_In,0, 0); 
 
       update 病理制片信息 set 归档状态= 1 where ID=来源ID_In; 
 
    when 材料来源_IN = 3 then --来源特检 
       insert into 病理归档信息(ID, 档案ID, 病理医嘱ID, 资料来源,特检ID,存放状态, 借阅状态) 
       values(v_归档ID, 档案ID_IN, 病理医嘱ID_IN, 材料来源_In,来源ID_In,0,0); 
 
       update 病理特检信息 set 归档状态= 1 where ID=来源ID_In; 
 
    when 材料来源_IN = 4 then --来源档案 
       insert into 病理归档信息(ID, 档案ID, 资料来源,病理医嘱ID,存放状态, 借阅状态) 
       values(v_归档ID, 档案ID_IN, 材料来源_In,来源ID_In,0,0); 
    else null; 
  end case; 
 
  commit; 
 
  return v_归档ID; 
 
Exception 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
end ZL_病理档案_材料入档;
/

