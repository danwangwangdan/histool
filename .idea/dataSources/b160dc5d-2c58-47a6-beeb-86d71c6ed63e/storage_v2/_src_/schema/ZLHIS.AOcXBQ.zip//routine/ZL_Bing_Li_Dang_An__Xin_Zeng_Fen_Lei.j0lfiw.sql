create Function Zl_病理档案_新增分类 
( 
  分类名称_IN        病理档案分类.分类名称%Type, 
  材料类型_IN        病理档案分类.材料类型%Type, 
  报表名称_IN        病理档案分类.报表名称%Type, 
  创建人_IN          病理档案分类.创建人%Type, 
  创建时间_IN        病理档案分类.创建时间%Type, 
  备注_IN            病理档案分类.备注%Type 
) return Number Is 
PRAGMA AUTONOMOUS_TRANSACTION; 
       v_分类ID   病理档案分类.ID%Type; 
Begin 
       select 病理档案分类_ID.nextval into v_分类ID from dual; 
 
       insert into 病理档案分类(ID,分类名称,材料类型,报表名称, 创建人,创建时间,备注) 
       values(v_分类ID, 分类名称_IN,材料类型_IN,报表名称_IN, 创建人_IN, 创建时间_IN, 备注_IN); 
 
       commit; 
 
       return  v_分类ID; 
Exception 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
End Zl_病理档案_新增分类;
/

