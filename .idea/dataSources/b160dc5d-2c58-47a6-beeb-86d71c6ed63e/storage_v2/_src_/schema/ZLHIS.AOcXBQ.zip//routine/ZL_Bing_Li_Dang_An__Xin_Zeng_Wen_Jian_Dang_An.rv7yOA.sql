create Function Zl_病理档案_新增文件档案 
( 
  档案名称_IN        病理档案信息.档案名称%Type, 
  档案编号_IN        病理档案信息.档案编号%Type, 
  检查范围_IN        病理档案信息.检查范围%Type, 
  分类ID_IN          病理档案信息.分类ID%Type, 
  开始日期_IN        病理档案信息.开始日期%Type, 
  结束日期_IN        病理档案信息.结束日期%Type, 
  创建日期_IN        病理档案信息.创建日期%Type, 
  创建人_IN          病理档案信息.创建人%Type, 
  所属房间_IN        病理档案信息.所属房间%Type, 
  所属柜号_IN        病理档案信息.所属柜号%Type, 
  所属抽屉_IN        病理档案信息.所属抽屉%Type, 
  详细地址_IN        病理档案信息.详细地址%Type, 
  档案说明_IN        病理档案信息.档案说明%Type 
) return Number Is 
PRAGMA AUTONOMOUS_TRANSACTION; 
       v_档案ID   病理档案信息.ID%Type; 
Begin 
       select 病理档案信息_ID.nextval into v_档案ID from dual; 
 
       insert into 病理档案信息(ID, 档案名称,档案编号,检查范围,分类ID,开始日期,结束日期,创建人,创建日期,档案说明,所属房间,所属柜号,所属抽屉,详细地址,档案状态) 
       values(v_档案ID, 档案名称_IN, 档案编号_IN, 检查范围_IN, 分类ID_IN, 开始日期_IN, 结束日期_IN, 创建人_IN,创建日期_IN,档案说明_IN, 所属房间_IN,所属柜号_IN,所属抽屉_IN,详细地址_IN, 0); 
 
       commit; 
 
       return  v_档案ID; 
Exception 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
End Zl_病理档案_新增文件档案;
/

