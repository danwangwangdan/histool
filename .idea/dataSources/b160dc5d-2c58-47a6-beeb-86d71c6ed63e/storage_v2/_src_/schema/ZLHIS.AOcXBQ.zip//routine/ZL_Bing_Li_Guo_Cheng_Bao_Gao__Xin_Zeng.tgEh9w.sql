create function Zl_病理过程报告_新增 
( 
  病理医嘱ID_IN      病理过程报告.病理医嘱ID%Type, 
  标本名称_IN    病理过程报告.标本名称%Type, 
  报告类型_IN    病理过程报告.报告类型%Type, 
  报告子项_IN    病理过程报告.报告子项%Type, 
  检查意见_IN    病理过程报告.检查意见%Type, 
  检查结果_IN    病理过程报告.检查结果%Type, 
  报告医师_IN    病理过程报告.报告医师%Type, 
  报告日期_IN    病理过程报告.报告日期%Type, 
  报告图像_IN    病理过程报告.报告图像%Type, 
  备注_IN        病理过程报告.备注%Type 
) return number Is 
PRAGMA AUTONOMOUS_TRANSACTION; 
v_id 病理过程报告.ID%Type; 
Begin 
  --获取过程报告ID 
  select 病理过程报告_ID.NEXTVAL into v_id from dual; 
 
  --写入过程报告记录 
  insert into 病理过程报告(ID, 病理医嘱ID, 标本名称,报告类型,报告子项,检查结果,检查意见,报告图像,报告医师,报告日期,当前状态,备注) 
  values(v_id, 病理医嘱ID_IN, 标本名称_IN, 报告类型_IN,报告子项_IN, 检查结果_IN, 检查意见_IN,报告图像_IN,报告医师_IN,报告日期_IN, 0,备注_IN); 
 
  commit; 
 
  return v_id; 
Exception 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
End Zl_病理过程报告_新增;
/

