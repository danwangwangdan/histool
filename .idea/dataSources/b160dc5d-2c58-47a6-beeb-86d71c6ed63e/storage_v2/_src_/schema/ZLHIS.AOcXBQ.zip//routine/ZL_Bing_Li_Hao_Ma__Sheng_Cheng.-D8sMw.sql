create Function Zl_病理号码_生成 
( 
  Id_In       病理号码规则.Id%Type, 
  当前序号_In 病理号码记录.当前序号%Type 
) Return Varchar2 Is 
  Cursor c_Patholnumrule(v_Id 病理号码规则.Id%Type) Is 
    Select 年, 月, 日, 类型, 年份位数, 序号位数, 前缀 From 病理号码规则 Where Id = v_Id; 
  r_Patholnumrule c_Patholnumrule%Rowtype; 
 
  v_Year   Varchar2(4); 
  v_Month  Varchar2(2); 
  v_Day    Varchar2(2); 
  v_Curnum Varchar2(18); 
 
  v_Error Varchar(255); 
  Err_Custom Exception; 
Begin 
 
  Open c_Patholnumrule(Id_In); 
 
  Fetch c_Patholnumrule 
    Into r_Patholnumrule; 
 
  If c_Patholnumrule%Rowcount = 0 Then 
    Close c_Patholnumrule; 
    v_Error := '不能读取病理号码生成规则，过程终止。'; 
    Raise Err_Custom; 
  End If; 
 
  v_Year  := ''; 
  v_Month := ''; 
  v_Day   := ''; 
 
  If r_Patholnumrule.年 = 1 Then 
    If r_Patholnumrule.年份位数 = 4 Then 
      Select To_Char(Sysdate, 'yyyy') Into v_Year From Dual; 
    Else 
      Select To_Char(Sysdate, 'yy') Into v_Year From Dual; 
    End If; 
  End If; 
 
  If r_Patholnumrule.月 = 1 Then 
    Select To_Char(Sysdate, 'mm') Into v_Month From Dual; 
  End If; 
 
  If r_Patholnumrule.日 = 1 Then 
    Select To_Char(Sysdate, 'dd') Into v_Day From Dual; 
  End If; 
 
  v_Curnum := 当前序号_In; 
  If Length(v_Curnum) < Nvl(r_Patholnumrule.序号位数, 0) Then 
    v_Curnum := Lpad('0', r_Patholnumrule.序号位数 - Length(v_Curnum), 0) || v_Curnum; 
  End If; 
 
  Return Nvl(r_Patholnumrule.前缀, '') || v_Year || v_Month || v_Day || v_Curnum; 
 
  Close c_Patholnumrule; 
Exception 
  When Err_Custom Then 
    Raise_Application_Error(-20101, '[ZLSOFT]' || v_Error || '[ZLSOFT]'); 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
End Zl_病理号码_生成;
/

