create Function Zl_病理号码_序号获取(Id_In 病理号码规则.Id%Type) Return Number Is 
 
  Cursor c_Patholnumrule(v_Id 病理号码规则.Id%Type) Is 
    Select 年, 月, 日 From 病理号码规则 Where ID = v_Id; 
  r_Patholnumrule c_Patholnumrule%RowType; 
 
  v_Curnum Number; 
 
  v_Year  Number; 
  v_Month Number; 
  v_Day   Number; 
  v_Error Varchar(255); 
  Err_Custom Exception; 
Begin 
 
  Open c_Patholnumrule(Id_In); 
 
  Fetch c_Patholnumrule 
    Into r_Patholnumrule; 
 
  If c_Patholnumrule%RowCount = 0 Then 
    Close c_Patholnumrule; 
    v_Error := '不能读取病理号码生成规则，过程终止。'; 
    Raise Err_Custom; 
  End If; 
 
  v_Year  := 0; 
  v_Month := 0; 
  v_Day   := 0; 
 
  If r_Patholnumrule.年 = 1 Then 
    Select To_Char(Sysdate, 'yyyy') Into v_Year From Dual; 
  End If; 
 
  If r_Patholnumrule.月 = 1 Then 
    Select To_Char(Sysdate, 'mm') Into v_Month From Dual; 
  End If; 
 
  If r_Patholnumrule.日 = 1 Then 
    Select To_Char(Sysdate, 'dd') Into v_Day From Dual; 
  End If; 
 
  Begin 
    Select 当前序号 
    Into v_Curnum 
    From 病理号码记录 
    Where 号码规则id = Id_In And 年 = v_Year And 月 = v_Month And 日 = v_Day; 
  Exception 
 
    When No_Data_Found Then 
      Begin 
        Select 当前序号 
        Into v_Curnum 
        From 病理号码记录 
        Where 类型 = Id_In - 1 And 年 = v_Year And 月 = v_Month And 日 = v_Day; 
      Exception 
        When Others Then 
          v_Curnum := 0; 
      End; 
 
    When Others Then 
      v_Curnum := 0; 
  End; 
 
  Close c_Patholnumrule; 
 
  Return v_Curnum + 1; 
 
Exception 
  When Err_Custom Then 
    Raise_Application_Error(-20101, '[ZLSOFT]' || v_Error || '[ZLSOFT]'); 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zl_病理号码_序号获取;
/

