create function Zl_病理会诊_新增 
( 
  病理医嘱ID_IN      病理会诊信息.病理医嘱ID%Type, 
  申请医师_IN    病理会诊信息.申请医师%Type, 
  会诊单位_IN    病理会诊信息.会诊单位%Type, 
  会诊医师_IN    病理会诊信息.会诊医师%Type, 
  会诊时间_IN    病理会诊信息.会诊时间%Type, 
  截止时间_IN    病理会诊信息.截止时间%Type, 
  会诊类型_IN    病理会诊信息.会诊类型%Type, 
  检查描述_IN    病理会诊信息.检查描述%Type 
) return number Is 
PRAGMA AUTONOMOUS_TRANSACTION; 
v_id 病理会诊信息.ID%Type; 
Begin 
  --获取申请ID 
  select 病理会诊信息_ID.NEXTVAL into v_id from dual; 
 
  --写入申请记录 
  insert into 病理会诊信息(id,病理医嘱ID,申请医师,会诊单位,会诊医师,会诊时间,截止时间,会诊类型,检查描述,当前状态) 
  values(v_id, 病理医嘱ID_IN, 申请医师_IN, 会诊单位_IN, 会诊医师_IN, 会诊时间_IN,截止时间_IN,会诊类型_IN,检查描述_IN,0); 
 
  commit; 
 
  return v_id; 
Exception 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
End Zl_病理会诊_新增;
/

