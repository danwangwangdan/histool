create Function Zl_病理借阅_新增借阅 
( 
  借阅人_IN        病理借阅信息.借阅人%Type, 
  借阅日期_IN      病理借阅信息.借阅时间%Type, 
  证件类型_IN      病理借阅信息.证件类型%Type, 
  证件号码_IN      病理借阅信息.证件号码%Type, 
  借阅押金_IN      病理借阅信息.押金%Type, 
  借阅天数_IN      病理借阅信息.借阅天数%Type, 
  联系电话_IN      病理借阅信息.联系电话%Type, 
  联系地址_IN      病理借阅信息.联系地址%Type, 
  借阅原因_IN      病理借阅信息.借阅原因%Type, 
  登记人_IN        病理借阅信息.登记人%Type, 
  备注说明_IN      病理借阅信息.备注%Type, 
  借阅类型_IN      病理借阅信息.借阅类型%Type 
) return Number Is 
PRAGMA AUTONOMOUS_TRANSACTION; 
       v_借阅ID   病理借阅信息.ID%Type; 
Begin 
       select 病理借阅信息_ID.nextval into v_借阅ID from dual; 
 
       insert into 病理借阅信息(ID, 借阅人,借阅时间,证件类型,证件号码,押金,借阅天数,联系电话,联系地址,借阅原因,登记人,备注,借阅类型,归还状态) 
       values(v_借阅ID, 借阅人_IN, 借阅日期_IN, 证件类型_IN, 证件号码_IN, 借阅押金_IN, 借阅天数_IN, 联系电话_IN,联系地址_IN,借阅原因_IN, 登记人_IN,备注说明_IN,借阅类型_IN, 0); 
 
       commit; 
 
       return  v_借阅ID; 
Exception 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
End Zl_病理借阅_新增借阅;
/

