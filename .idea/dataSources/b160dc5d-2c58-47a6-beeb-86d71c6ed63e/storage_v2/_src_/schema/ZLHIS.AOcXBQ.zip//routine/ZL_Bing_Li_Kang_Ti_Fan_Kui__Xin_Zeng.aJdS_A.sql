create function Zl_病理抗体反馈_新增 
( 
  抗体ID_IN      病理抗体反馈.抗体ID%Type, 
  参考病理号_IN  病理抗体反馈.参考病理号%Type, 
  实验类型_IN    病理抗体反馈.实验类型%Type, 
  抗体评价_IN    病理抗体反馈.抗体评价%Type, 
  反馈时间_IN    病理抗体反馈.反馈时间%Type, 
  反馈医生_IN    病理抗体反馈.反馈医生%Type, 
  反馈意见_IN    病理抗体反馈.反馈意见%Type 
) return number Is 
PRAGMA AUTONOMOUS_TRANSACTION; 
v_id 病理抗体反馈.ID%Type; 
Begin 
  select 病理抗体反馈_Id.Nextval into v_id from dual; 
 
  insert into 病理抗体反馈(ID, 抗体ID,参考病理号,实验类型,抗体评价,反馈时间,反馈医生,反馈意见) 
  values(v_id, 抗体ID_IN, 参考病理号_IN, 实验类型_IN, 抗体评价_IN, 反馈时间_IN, 反馈医生_IN, 反馈意见_IN); 
 
  commit; 
 
  return v_id; 
Exception 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
End Zl_病理抗体反馈_新增;
/

