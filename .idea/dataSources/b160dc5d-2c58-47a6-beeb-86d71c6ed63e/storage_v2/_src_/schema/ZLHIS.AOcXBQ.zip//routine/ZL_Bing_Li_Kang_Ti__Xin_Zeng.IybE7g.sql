create function Zl_病理抗体_新增 
( 
  抗体名称_IN 病理抗体信息.抗体名称%Type, 
  使用人份_IN 病理抗体信息.使用人份%Type, 
  已用人份_IN 病理抗体信息.已用人份%Type, 
  生产日期_IN 病理抗体信息.生产日期%Type, 
  有效期_IN   病理抗体信息.有效期%Type, 
  过期日期_IN 病理抗体信息.过期日期%Type, 
  克隆性_IN   病理抗体信息.克隆性%Type, 
  作用对象_IN 病理抗体信息.作用对象%Type, 
  理化性质_IN 病理抗体信息.理化性质%Type, 
  应用情况_IN 病理抗体信息.应用情况%Type, 
  登记人_IN   病理抗体信息.登记人%Type, 
  登记时间_IN 病理抗体信息.登记时间%Type, 
  备注_IN     病理抗体信息.备注%Type 
) return Number Is 
PRAGMA AUTONOMOUS_TRANSACTION; 
v_抗体ID 病理抗体信息.抗体ID%Type; 
Begin 
  select 病理抗体信息_抗体ID.NEXTVAL into v_抗体ID from dual; 
 
  insert into 病理抗体信息(抗体ID,抗体名称,使用人份,已用人份,生产日期,有效期,过期日期,克隆性,作用对象,理化性质,应用情况,登记人,登记时间,使用状态,备注) 
  values(v_抗体ID, 抗体名称_IN, 使用人份_IN, 已用人份_IN, 生产日期_IN, 
         有效期_IN, 过期日期_IN, 克隆性_IN, 作用对象_IN, 理化性质_IN, 应用情况_IN,登记人_IN,登记时间_IN,1,备注_IN); 
 
  commit; 
 
  return v_抗体ID; 
Exception 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
End Zl_病理抗体_新增;
/

