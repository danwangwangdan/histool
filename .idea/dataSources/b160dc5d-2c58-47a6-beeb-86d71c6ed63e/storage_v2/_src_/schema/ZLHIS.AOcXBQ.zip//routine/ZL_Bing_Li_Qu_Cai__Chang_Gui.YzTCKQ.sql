create function zl_病理取材_常规 
( 
  病理医嘱ID_IN  病理取材信息.病理医嘱ID%Type, 
  申请ID_IN      病理取材信息.申请ID%Type, 
  标本ID_IN      病理取材信息.标本ID%Type, 
  标本名称_IN    病理取材信息.标本名称%Type, 
  取材位置_IN    病理取材信息.取材位置%Type, 
  形状_IN        病理取材信息.形状%Type, 
  蜡块数_IN      病理取材信息.蜡块数%Type, 
  制片数_IN      病理制片信息.制片数%Type, 
  主取医师_IN    病理取材信息.主取医师%Type, 
  副取医师_IN    病理取材信息.副取医师%Type, 
  是否蜡块_IN    病理取材信息.是否蜡块%Type, 
  是否脱钙_IN    病理取材信息.是否脱钙%Type, 
  记录医师_IN    病理取材信息.记录医师%Type, 
  取材时间_IN    病理取材信息.取材时间%Type 
) return varchar2 Is 
PRAGMA AUTONOMOUS_TRANSACTION; 
 
v_id 病理取材信息.材块ID%Type; 
v_seqNum 病理取材信息.序号%Type; 
 
Begin 
  --获取最大材块号序号 
  begin 
    select  nvl(max(序号), 0) into v_seqNum from 病理取材信息 where 病理医嘱ID=病理医嘱ID_IN; 
  exception 
    When Others Then v_seqNum := 0; 
  end; 
 
  v_seqNum := v_seqNum + 1; 
  select 病理取材信息_材块ID.Nextval into v_id from dual; 
 
  --写入取材记录 
  insert into 病理取材信息(材块ID, 序号, 病理医嘱ID, 申请ID, 标本ID, 标本名称,取材位置,形状,蜡块数,主取医师,副取医师,是否蜡块,是否脱钙,记录医师,取材时间,确认状态) 
  values(v_id, v_seqNum, 病理医嘱ID_IN, 申请ID_IN, 标本ID_IN, 标本名称_IN, 取材位置_IN,形状_IN, 蜡块数_IN,主取医师_IN,副取医师_IN,是否蜡块_IN,是否脱钙_IN,记录医师_IN,取材时间_IN,0); 
 
  --写入制片记录 
  insert into 病理制片信息(ID,病理医嘱ID,材块ID,申请ID,制片类型,制片方式,制片数,当前状态) 
  values(病理制片信息_ID.NEXTVAL,病理医嘱ID_IN,v_id,申请ID_IN,0,0,制片数_IN,0); 
 
  commit; 
 
  return v_id || '-' || v_seqNum; 
Exception 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
End Zl_病理取材_常规;
/

