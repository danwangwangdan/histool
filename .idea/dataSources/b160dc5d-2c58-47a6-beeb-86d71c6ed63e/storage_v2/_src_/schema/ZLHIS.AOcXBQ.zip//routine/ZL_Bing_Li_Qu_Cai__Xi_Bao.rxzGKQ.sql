create function Zl_病理取材_细胞 
( 
  病理医嘱ID_IN  病理取材信息.病理医嘱ID%Type, 
  申请ID_IN      病理取材信息.申请ID%Type, 
  标本ID_IN      病理取材信息.标本ID%Type, 
  标本名称_IN    病理取材信息.标本名称%Type, 
  颜色_IN        病理取材信息.颜色%Type, 
  性质_IN        病理取材信息.性质%Type, 
  标本量_IN      病理取材信息.标本量%Type, 
  制片数_IN      病理制片信息.制片数%Type, 
  是否蜡块_IN    病理取材信息.是否蜡块%Type, 
  细胞块数_IN    病理取材信息.蜡块数%Type, 
  主取医师_IN    病理取材信息.主取医师%Type, 
  副取医师_IN    病理取材信息.副取医师%Type, 
  记录医师_IN    病理取材信息.记录医师%Type, 
  取材时间_IN    病理取材信息.取材时间%Type 
) return varchar2 Is 
PRAGMA AUTONOMOUS_TRANSACTION; 
 
v_id 病理取材信息.材块ID%Type; 
v_seqNum 病理取材信息.序号%Type; 
v_slicesCount number; 
 
Begin 
  --获取最大材块号序号 
  begin 
    select  nvl(max(序号), 0) into v_seqNum from 病理取材信息 where 病理医嘱ID=病理医嘱ID_IN; 
  exception 
    When Others Then v_seqNum := 0; 
  end; 
 
  v_seqNum := v_seqNum + 1; 
  select 病理取材信息_材块ID.Nextval into v_id from dual; 
 
 
  --写入取材记录 
  insert into 病理取材信息(材块ID,序号, 病理医嘱ID, 申请ID, 标本ID, 标本名称,颜色,性质,标本量,是否蜡块,蜡块数,主取医师,副取医师,记录医师,取材时间,确认状态) 
  values(v_id, v_seqNum, 病理医嘱ID_IN, 申请ID_IN, 标本ID_IN, 标本名称_IN,颜色_IN,性质_IN, 标本量_IN,是否蜡块_IN,细胞块数_IN,主取医师_IN,副取医师_IN,记录医师_IN,取材时间_IN,0); 
 
  if 制片数_IN is null then 
     v_slicesCount := 1; 
  elsif 制片数_IN <= 0 then 
     v_slicesCount := 1; 
  else 
     v_slicesCount := 制片数_IN; 
  end if; 
 
  --写入制片记录 
  insert into 病理制片信息(ID,病理医嘱ID,材块ID,申请ID,制片类型,制片方式,制片数,当前状态) 
  values(病理制片信息_ID.NEXTVAL,病理医嘱ID_IN,v_id,申请ID_IN,2, 0, v_slicesCount, 0); 
 
  commit; 
 
  return v_id || '-' || v_seqNum; 
Exception 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
End Zl_病理取材_细胞;
/

