create function Zl_病理申请_特检项目_新增 
( 
  病理医嘱ID_IN      病理特检信息.病理医嘱ID%Type, 
  材块ID_IN      病理特检信息.材块ID%Type, 
  申请ID_IN      病理特检信息.申请ID%Type, 
  抗体ID_IN      病理特检信息.抗体ID%Type, 
  特检类型_IN    病理特检信息.特检类型%Type, 
  特检细目_IN    病理特检信息.特检细目%Type, 
  补费状态_IN    病理申请信息.补费状态%Type, 
  项目顺序_IN    病理特检信息.项目顺序%Type, 
  是否补做_IN    number := 0 
) return number Is 
PRAGMA AUTONOMOUS_TRANSACTION; 
v_id 病理特检信息.ID%Type; 
v_补做 病理特检信息.制作类型%Type; 
Begin 
  --获取特检信息ID 
  select 病理特检信息_ID.NEXTVAL into v_id from dual; 
 
  v_补做 := -1; 
  if 是否补做_IN = 0 then 
     v_补做 := 0; 
  end if; 
 
  --写入申请记录 
  insert into 病理特检信息(ID,病理医嘱ID,材块ID,申请ID,抗体ID,特检类型,特检细目,项目顺序,制作类型,当前状态,清单状态) 
  values(v_id,病理医嘱ID_IN, 材块ID_IN, 申请ID_IN, 抗体ID_IN, 特检类型_IN,特检细目_IN,项目顺序_IN, v_补做, 0,0); 
 
  --更新检查过程 
  if v_补做 = -1 then 
     case 
       when 特检类型_IN = 0 then 
         update 病理检查信息 set 免疫过程=1 where 病理医嘱ID=病理医嘱ID_IN; 
       when 特检类型_IN = 1 then 
         update 病理检查信息 set 特染过程=1 where 病理医嘱ID=病理医嘱ID_IN; 
       when 特检类型_IN = 2 then 
         update 病理检查信息 set 分子过程=1 where 病理医嘱ID=病理医嘱ID_IN; 
       else null; 
     end case; 
  end if; 
 
  --更新抗体使用人份 
  update 病理抗体信息 set 已用人份=已用人份+1 where 抗体ID=抗体ID_IN; 
 
  --更新申请补费状态 
  update 病理申请信息　set 补费状态=补费状态_IN where 申请ID=申请ID_IN and 补费状态<>1; 
 
  commit; 
 
  return v_id; 
Exception 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
End Zl_病理申请_特检项目_新增;
/

