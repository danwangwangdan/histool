create function Zl_病理申请_特检项目_重做 
( 
  ID_IN          病理特检信息.ID%Type 
) return number Is 
PRAGMA AUTONOMOUS_TRANSACTION; 
  cursor c_SpeExamInf is 
         select 病理医嘱ID,材块ID,抗体ID,特检类型,特检细目,项目顺序 from 病理特检信息 where Id=ID_IN; 
 
  r_SpeExamInf  c_SpeExamInf%RowType; 
  v_newid      病理特检信息.ID%Type; 
  v_count   病理特检信息.制作类型%Type; 
 
  v_Error    varchar(255); 
  Err_Custom Exception; 
Begin 
 
  Open c_SpeExamInf; 
  Fetch c_SpeExamInf Into r_SpeExamInf; 
 
  If c_SpeExamInf%Rowcount = 0 Then 
    Close c_SpeExamInf; 
    v_Error := '不能正确读取病理特检信息的相关数据，请检查项目ID是否为有效数据。'; 
    Raise Err_Custom; 
  End If; 
 
  v_count := 0; 
  begin 
    select nvl(max(制作类型), 0) into v_count from 病理特检信息 
    where 材块Id=r_SpeExamInf.材块ID and 抗体Id=r_SpeExamInf.抗体ID and 特检类型=r_SpeExamInf.特检类型 and 特检细目=r_SpeExamInf.特检细目; 
  exception 
    when others then v_count := 0; 
  end; 
 
  select 病理特检信息_ID.NEXTVAL into v_newid from dual; 
 
  --特检项目重做 
  insert into 病理特检信息(ID, 病理医嘱ID,材块ID,申请ID,抗体ID,特检类型,特检细目,项目顺序,制作类型,当前状态,清单状态) 
  select v_newid as ID,病理医嘱ID,材块ID,申请ID,抗体ID,特检类型, 特检细目,项目顺序,v_count+1,0,0 from 病理特检信息 where ID=ID_IN; 
 
  --更新检查过程 
  case 
    when r_SpeExamInf.特检类型 = 0 then 
      update 病理检查信息 set 免疫过程=1 where 病理医嘱ID=r_SpeExamInf.病理医嘱ID; 
 
    when r_SpeExamInf.特检类型 = 1 then 
      update 病理检查信息 set 特染过程=1 where 病理医嘱ID=r_SpeExamInf.病理医嘱ID; 
 
    when r_SpeExamInf.特检类型 = 2 then 
      update 病理检查信息 set 分子过程=1 where 病理医嘱ID=r_SpeExamInf.病理医嘱ID; 
 
    else null; 
  end case; 
 
  --更新抗体使用情况 
  update 病理抗体信息 set 已用人份=已用人份+1 where 抗体ID=r_SpeExamInf.抗体ID; 
 
  commit; 
 
  return v_newid; 
 
  close c_SpeExamInf; 
Exception 
  When Err_Custom Then 
    Raise_Application_Error(-20101, '[ZLSOFT]' || v_Error || '[ZLSOFT]'); 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
End Zl_病理申请_特检项目_重做;
/

