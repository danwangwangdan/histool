create function Zl_病理申请_新增 
( 
  病理医嘱ID_IN      病理申请信息.病理医嘱ID%Type, 
  申请人_IN      病理申请信息.申请人%Type, 
  申请时间_IN    病理申请信息.申请时间%Type, 
  申请类型_IN    病理申请信息.申请类型%Type, 
  补费状态_IN    病理申请信息.补费状态%Type, 
  申请细目_IN    病理申请信息.申请细目%Type, 
  申请描述_IN    病理申请信息.申请描述%Type 
) return number Is 
PRAGMA AUTONOMOUS_TRANSACTION; 
v_id 病理申请信息.申请ID%Type; 
Begin 
  --获取申请ID 
  select 病理申请信息_申请ID.NEXTVAL into v_id from dual; 
 
  --写入申请记录 
  insert into 病理申请信息(申请ID, 病理医嘱ID, 申请人,申请时间,申请类型,补费状态,申请细目,申请描述,申请状态,是否打印) 
  values(v_id, 病理医嘱ID_IN, 申请人_IN, 申请时间_IN, 申请类型_IN,补费状态_IN,申请细目_IN,申请描述_IN,0,0); 
 
  --更新检查过程 
  case 
    when 申请类型_IN = 0 then update 病理检查信息 set 免疫过程=1 where 病理医嘱ID=病理医嘱ID_IN;  --免疫组化 
    when 申请类型_IN = 1 then update 病理检查信息 set 特染过程=1 where 病理医嘱ID=病理医嘱ID_IN;  --特殊染色 
    when 申请类型_IN = 2 then update 病理检查信息 set 分子过程=1 where 病理医嘱ID=病理医嘱ID_IN;  --分子病理 
    when 申请类型_IN = 3 then update 病理检查信息 set 制片过程=1 where 病理医嘱ID=病理医嘱ID_IN;  --再制片 
    when 申请类型_IN = 4 then update 病理检查信息 set 取材过程=1 where 病理医嘱ID=病理医嘱ID_IN;  --再取材 
    else null; 
  end case; 
 
  commit; 
 
  return v_id; 
Exception 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
End Zl_病理申请_新增;
/

