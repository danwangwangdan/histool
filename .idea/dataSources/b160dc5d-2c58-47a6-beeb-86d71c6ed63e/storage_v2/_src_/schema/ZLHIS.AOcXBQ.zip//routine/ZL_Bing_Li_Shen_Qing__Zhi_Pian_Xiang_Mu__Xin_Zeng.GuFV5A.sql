create function Zl_病理申请_制片项目_新增 
( 
  病理医嘱ID_IN      病理制片信息.病理医嘱ID%Type, 
  材块ID_IN      病理制片信息.材块ID%Type, 
  申请ID_IN      病理制片信息.申请ID%Type, 
  制片类型_IN    病理制片信息.制片类型%Type, 
  制片方式_IN    病理制片信息.制片方式%Type, 
  制片数量_IN    病理制片信息.制片数%Type 
) return number Is 
PRAGMA AUTONOMOUS_TRANSACTION; 
v_id       病理制片信息.ID%Type; 
Begin 
  --获取特检信息ID 
  select 病理制片信息_ID.NEXTVAL into v_id from dual; 
 
  --写入制片记录 
  insert into 病理制片信息(ID, 病理医嘱ID, 材块ID,申请ID,制片类型,制片数,制片方式,当前状态,清单状态) 
  values(v_id, 病理医嘱ID_IN, 材块ID_IN, 申请ID_IN, 制片类型_IN, 制片数量_IN, 制片方式_IN, 0,0); 
 
  --更新病理执行过程状态 
  update 病理检查信息 set 制片过程=1 where 病理医嘱ID=病理医嘱ID_IN; 
 
  commit; 
 
  return v_id; 
Exception 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
End Zl_病理申请_制片项目_新增;
/

