create function Zl_病理套餐关联_新增 
( 
  套餐ID_IN   病理套餐关联.套餐ID%Type, 
  抗体ID_IN   病理套餐关联.抗体ID%Type, 
  抗体顺序_IN 病理套餐关联.抗体顺序%Type 
) return number Is 
PRAGMA AUTONOMOUS_TRANSACTION; 
v_id 病理套餐关联.ID%Type; 
Begin 
  select 病理套餐关联_Id.Nextval into v_id from dual; 
 
  insert into 病理套餐关联(ID, 套餐ID,抗体ID,抗体顺序) values(v_id, 套餐ID_IN, 抗体ID_IN,抗体顺序_IN); 
 
  commit; 
 
  return v_id; 
Exception 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
End Zl_病理套餐关联_新增;
/

