create function Zl_病理套餐_新增 
( 
  套餐名称_IN   病理套餐信息.套餐名称%Type, 
  套餐类别_IN   病理套餐信息.套餐类别%Type, 
  套餐说明_IN   病理套餐信息.套餐说明%Type, 
  创建时间_IN   病理套餐信息.创建时间%Type, 
  创建人_IN     病理套餐信息.创建人%Type 
) return number Is 
PRAGMA AUTONOMOUS_TRANSACTION; 
v_id 病理套餐信息.套餐ID%Type; 
Begin 
  select 病理套餐信息_套餐ID.Nextval into v_id from dual; 
 
  insert into 病理套餐信息(套餐ID,套餐名称,套餐类别,套餐说明,创建人,创建时间) 
  values(v_id, 套餐名称_IN, 套餐类别_IN,套餐说明_IN, 创建人_IN, 创建时间_IN); 
 
  commit; 
 
  return v_id; 
Exception 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
End Zl_病理套餐_新增;
/

