create function Zl_病理脱钙_开始 
( 
  标本ID_IN    病理脱钙信息.标本ID%Type, 
  开始时间_IN  病理脱钙信息.开始时间%Type, 
  所需时长_IN  病理脱钙信息.所需时长%Type, 
  操作员_IN    病理脱钙信息.操作员%Type 
) return number Is 
PRAGMA AUTONOMOUS_TRANSACTION; 
v_id 病理脱钙信息.ID%Type; 
Begin 
  select 病理脱钙信息_Id.Nextval into v_id from dual; 
 
  insert into 病理脱钙信息(ID, 标本ID,开始时间,所需时长,当前缸次,操作员,完成状态) 
  values(v_id, 标本ID_IN, 开始时间_IN, 所需时长_IN, 1, 操作员_IN, 0); 
 
  commit; 
 
  return v_id; 
Exception 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
End Zl_病理脱钙_开始;
/

