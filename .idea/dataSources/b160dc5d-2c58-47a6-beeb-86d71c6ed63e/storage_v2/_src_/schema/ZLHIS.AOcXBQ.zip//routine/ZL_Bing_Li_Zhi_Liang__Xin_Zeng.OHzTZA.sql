create function Zl_病理质量_新增 
( 
  病理医嘱ID_IN           病理质量信息.病理医嘱ID%Type, 
  评价项目_IN             病理质量信息.评价项目%Type, 
  评价结果_IN             病理质量信息.评价结果%Type, 
  评价意见_IN             病理质量信息.评价意见%Type, 
  改进方法_IN             病理质量信息.改进方法%Type, 
  备注_IN                 病理质量信息.备注%Type, 
  评价人_IN               病理质量信息.评价人%Type, 
  评价时间_IN             病理质量信息.评价时间%Type 
) return number Is 
PRAGMA AUTONOMOUS_TRANSACTION; 
 
  v_ID 病理质量信息.ID%Type; 
 
Begin 
  select 病理质量信息_ID.NEXTVAL into  v_ID  from dual; 
 
  insert into 病理质量信息(ID,病理医嘱ID,评价项目,评价结果,评价意见,改进方法,备注,评价人,评价时间) 
  values(v_ID, 病理医嘱ID_IN, 评价项目_IN, 评价结果_IN, 评价意见_IN, 改进方法_IN, 备注_IN,评价人_IN,评价时间_IN); 
 
  commit; 
 
  return  v_ID; 
Exception 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
End Zl_病理质量_新增;
/

