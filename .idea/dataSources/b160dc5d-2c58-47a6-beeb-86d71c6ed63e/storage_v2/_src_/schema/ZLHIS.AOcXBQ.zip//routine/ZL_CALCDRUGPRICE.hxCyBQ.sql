create Function Zl_Calcdrugprice 
( 
  药房id_In   药品库存.库房id%Type, 
  药品id_In   药品库存.药品id%Type, 
  数量_In     药品库存.可用数量%Type, 
  出库算法_In Number, 
  Decprice_In Number, 
  Dec_In      Number 
) Return Number Is 
  --功能:返回变价药品的时价 
  --参数: 
  --     数量_In 本次需要发送或者是新开药品的数量 
  --     出库算法_In 0-按批次先进先出，1-按效期最近先出 
  --     Decprice_In 金额小数位数 
  --     Dec_In 价格小数位 
  n_时价     门诊费用记录.实收金额%Type; 
  n_首批时价 门诊费用记录.实收金额%Type; 
  n_总金额   Number; 
  n_总数量   Number; 
  n_当前数量 Number; 
  n_Cnt      Number; 
Begin 
  If 数量_In <= 0 Then 
    Return 0; 
  End If; 
  n_总金额 := 0; 
  n_总数量 := 数量_In; 
  For Rs In (Select Nvl(批次, 0) As 批次, Nvl(可用数量, 0) As 库存, Nvl(零售价, Nvl(Decode(Nvl(实际数量, 0), 0, 0, 实际金额 / 实际数量), 0)) As 时价 
             From 药品库存 
             Where 库房id = 药房id_In And 药品id = 药品id_In And Nvl(可用数量, 0) > 0 And 性质 = 1 And 
                   (Nvl(批次, 0) = 0 Or 效期 Is Null Or 效期 > Trunc(Sysdate)) 
             Order By Decode(出库算法_In, 1, 效期, To_Date('2008-08-08', 'yyyy-mm-dd')), Nvl(批次, 0)) Loop 
    --第一个批次的时价 
    n_Cnt := n_Cnt + 1; 
    If n_Cnt = 1 Then 
      n_首批时价 := Round(Rs.时价, Decprice_In); 
    End If; 
    If n_总数量 = 0 Then 
      Exit; 
    End If; 
    If n_总数量 <= Rs.库存 Then 
      n_当前数量 := n_总数量; 
    Else 
      n_当前数量 := Rs.库存; 
    End If; 
    n_总金额 := n_总金额 + Round(n_当前数量 * Round(Rs.时价, Decprice_In), Dec_In); 
    n_总数量 := n_总数量 - n_当前数量; 
    If n_总数量 = 0 Then 
      Exit; 
    End If; 
  End Loop; 
  If n_总数量 <> 0 Then 
    -- 库存不够,只涉及一个批次时以首批时价为准，否则以第一批或者平均价都不合适 
    If n_Cnt = 1 Then 
      n_时价 := n_首批时价; 
    Else 
      n_时价 := 0; 
    End If; 
  Else 
    If n_Cnt = 1 Then 
      n_时价 := n_首批时价; 
    Else 
      n_时价 := Round(n_总金额 / 数量_In, Decprice_In); 
    End If; 
  End If; 
  Return n_时价; 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zl_Calcdrugprice;
/

