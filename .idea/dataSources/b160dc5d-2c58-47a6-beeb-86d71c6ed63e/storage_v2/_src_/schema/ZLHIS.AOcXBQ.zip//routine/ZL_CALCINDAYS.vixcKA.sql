create Function zl_CalcInDays 
( 
	病人id_In	Number, 
	主页id_In	Number, 
	婴儿_In		Number:=0, 
	住院日期_In	Date:=Sysdate				--指定某一具体日期时的住院天数 
) Return Number As 
 
	d_入院时间	病案主页.入院日期%Type; 
	d_出院时间	病案主页.出院日期%Type; 
	n_Days		Number(18); 
Begin 
 
	n_Days:=0; 
 
	d_入院时间:=Null; 
	d_出院时间:=Null; 
	Begin 
		Select Nvl(b.出生时间,a.入院日期),Nvl(a.出院日期,Sysdate) Into d_入院时间,d_出院时间 
		From 病案主页 a, 
			病人新生儿记录 b 
		Where a.病人id=病人id_In And a.主页id=主页id_In 
			And a.病人id=b.病人id(+) And a.主页id=b.主页id(+) And b.序号(+)=婴儿_In; 
 
	Exception 
		When Others Then d_入院时间:=Null; 
	End; 
 
	If d_入院时间 Is Not Null Then 
		If Trunc(住院日期_In)>Trunc(d_出院时间) Then 
			Select Trunc(d_出院时间)-Trunc(d_入院时间)+1 Into n_Days From dual; 
		Else 
			Select Trunc(住院日期_In)-Trunc(d_入院时间)+1 Into n_Days From dual; 
		End If; 
	End If; 
 
	Return(n_Days); 
End;
/

