create Function zl_CalcInDaysNew 
( 
	文件id_IN   In 病人护理文件.Id%Type, 
	病人ID_IN   In 病案主页.病人ID%Type, 
	主页ID_IN   In 病案主页.主页ID%Type, 
	住院日期_In In Date:=Sysdate				--指定某一具体日期时的住院天数 
) Return Number As 
 
	d_入院时间	病案主页.入院日期%Type; 
	d_出院时间	病案主页.出院日期%Type; 
	d_开始时间	病人护理文件.开始时间%Type; 
	n_Days		Number(18); 
	n_Bady		number(18); 
	N_BADYBILL	Number(18); 
	N_AddDay	Number(18); 
Begin 
 
	n_Days:=0; 
	n_Bady:=0; 
	N_BADYBILL:=0; 
	N_AddDay:=1; 
	d_入院时间:=Null; 
	d_出院时间:=Null; 
	d_开始时间:=Null; 
	--提取体温单开始时间 
	Begin 
		SELECT 开始时间,婴儿 INTO d_开始时间,n_Bady from 病人护理文件 where ID=文件ID_IN; 
		Exception 
			When Others Then d_开始时间:=Null; 
	End ; 
 
	--如果是婴儿开始时间以出生时间为准 
	IF n_bady<>0 THEN 
		Begin 
			SELECT A.出生时间 INTO d_入院时间 
			FROM 病人新生儿记录 A 
				WHERE  A.病人ID =病人ID_IN AND A.主页ID =主页ID_IN AND A.序号=n_Bady; 
			Exception 
				When Others Then d_入院时间:=d_开始时间; 
		End ; 
		Begin 
			SELECT NVL(参数值,0) INTO N_BADYBILL FROM ZLPARAMETERS WHERE 模块=1255 AND 参数名='婴儿体温单首日天数显示0';	--婴儿体温单首日天数从0开始还是从1开始 
		Exception 
			When Others Then N_BADYBILL :=0; 
		End; 
	End IF ; 
 
	IF d_入院时间 IS NULL THEN 
		d_入院时间:=d_开始时间; 
	End IF ; 
 
	--提取体温单的实际结束时间 
	Begin 
		SELECT DECODE(SIGN(A.出院时间 - B.发生时间), 1,A.出院时间 ,B.发生时间) INTO d_出院时间 
		From 
			(SELECT MAX(NVL(终止时间, SYSDATE)) AS 出院时间,MAX(病人ID) 病人ID,MAX(主页ID) 主页ID 
			FROM 病人变动记录 
				WHERE 开始时间 IS NOT NULL AND 病人ID = 病人ID_IN AND 主页ID =主页ID_IN) A, 
			(SELECT NVL(发生时间,SYSDATE) 发生时间,病人ID,主页ID 
				FROM 
					(SELECT MAX(发生时间) 发生时间,MAX(A.病人ID) 病人ID,MAX(A.主页ID) 主页ID FROM 病人护理文件 A,病人护理数据 B 
				WHERE A.ID=B.文件ID AND A.ID=文件ID_IN)) B 
		WHERE A.病人ID=B.病人ID AND A.主页ID=B.主页ID; 
 
		Exception 
			When Others Then d_出院时间:=sysdate; 
	End; 
	 
	IF N_BADYBILL=1 THEN 
		N_AddDay:=0; 
	ELSE 
		N_AddDay:=1; 
	End IF ; 
 
	If d_入院时间 Is Not Null Then 
		If Trunc(住院日期_In)>Trunc(d_出院时间) Then 
			Select Trunc(d_出院时间)-Trunc(d_入院时间)+N_AddDay Into n_Days From dual; 
		Else 
			Select Trunc(住院日期_In)-Trunc(d_入院时间)+N_AddDay Into n_Days From dual; 
		End If; 
	End If; 
 
	Return(n_Days); 
Exception 
	When Others Then 
		Zl_Errorcenter(Sqlcode, Sqlerrm); 
End zl_CalcInDaysNew;
/

