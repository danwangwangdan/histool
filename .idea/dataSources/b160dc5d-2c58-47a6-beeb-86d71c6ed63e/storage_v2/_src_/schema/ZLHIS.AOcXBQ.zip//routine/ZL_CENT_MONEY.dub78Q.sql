create Function Zl_Cent_Money 
( 
  Money_In In Number, 
  Type_In  In Number := 2 
) Return Number As 
  n_Sign Integer; 
  n_Temp Number(16, 5); 
  n_金额 Number(16, 5); 
  n_Mode Number(1); 
Begin 
  --         0.不处理 
  --         1.采取四舍五入法,eg:0.51=0.50;0.56=0.60 
  --         2.补整收法,eg:0.51=0.60,0.56=0.60 
  --         3.舍分收法,eg:0.51=0.50,0.56=0.50 
  --        4.四舍六入五成双,eg:0.14=0.10,0.16=0.20,0.151=0.20,0.15=0.20,0.25=0.20 
  --           四舍六入五成双,详见我国科学技术委员会正式颁布的《数字修约规则》,但根据vb的Round函数,若被舍弃的数字包括几位数字时，不对该数字进行连续修约 
  --           即银行家舍入法:四舍六入五考虑，五后非零就进一，五后皆零看奇偶，五前为偶应舍去，五前为奇要进一 
  --         5.三七作五、二舍八入,对角进行处理，不需要先对分币进行舍入,即0.24(含)以下都舍掉角，0.75(含)以上都进角，0.25-0.74处理为0.5。 
  --         6.五舍六入:eg:0.15=0.10:0.16=0.2:   刘兴洪 问题:34519  日期:2010-12-06 09:58:02 
 
  n_Mode := To_Number(Substr(Nvl(zl_GetSysParameter(14) || '000', '000'), Type_In, 1)); 
  n_Sign := Sign(Money_In); 
  n_金额 := Abs(Money_In); 
  If n_Mode = 1 Then 
    --1.四舍五入法,eg:0.51=0.50;0.56=0.60 
    n_Temp := n_Sign * Round(n_金额, 1); 
    Return n_Temp; 
  End If; 
  If n_Mode = 2 Then 
    ----2.补整收法,eg:0.51=0.60,0.56=0.60 
    n_Temp := n_Sign * Ceil(n_金额 * 10) / 10; 
    Return n_Temp; 
  End If; 
  If n_Mode = 3 Then 
    ----3.舍分收法,eg:0.51=0.50,0.56=0.50 
    n_Temp := n_Sign * Floor(n_金额 * 10) / 10; 
    Return n_Temp; 
  End If; 
  If n_Mode = 4 Then 
    ----4.四舍六入五成双,由于Oracle没有相关函数,算法复杂,暂不支持 
    n_Temp := n_Sign * n_金额; 
    Return n_Temp; 
  End If; 
  If n_Mode = 5 Then 
    ----5.三七作五、二舍八入,eg:0.29=0,0.30=0.50,0.79=0.50,0.80=1.00 
    n_Temp := Round(n_金额 - Floor(n_金额), 1); 
    If n_Temp >= 0.8 Then 
      n_Temp := 1; 
    Elsif n_Temp < 0.3 Then 
      n_Temp := 0; 
    Else 
      n_Temp := 0.5; 
    End If; 
    n_Temp := Floor(n_金额) + n_Temp; --5.三七作五、二舍八入,eg:0.24=0,0.25=0.50,0.74=0.50,0.75=1.00 
    n_Temp := n_Sign * n_Temp; 
    Return n_Temp; 
  End If; 
  If n_Mode = 6 Then 
    ----6.五舍六入 
    n_Temp := n_Sign * Round(n_金额 - 0.01, 1); 
    Return n_Temp; 
  End If; 
  Return Money_In; 
Exception 
  When Others Then 
    Return Null; 
End Zl_Cent_Money;
/

