create Function zl_ClinicExeDept 
( 
  病人id_In     病人信息.病人id%Type, 
  主页id_In     病案主页.主页id%Type, 
  诊疗类别_In   诊疗项目目录.类别%Type, 
  项目id_In     诊疗项目目录.ID%Type, 
  药品id_In     收费项目目录.ID%Type, 
  病人科室id_In 病人医嘱记录.病人科室id%Type, 
  开嘱科室id_In 病人医嘱记录.开嘱科室id%Type 
  --功能:获取指定诊疗项目在医嘱下达时的执行科室 
  --参数： 
  ----主页id_In：住院病人的主页ID，如果为NULL表示门诊病人。 
  ----药品id_In：按规格下达药品医嘱时，为对应规格的药品ID；其他情况传入为Null。 
  --返回:具体的执行科室ID，如果返回Null，则由根据程序规则处理 
) Return Number As 
  v_Return Number; 
Begin 
  v_Return := Null; 
  Return v_Return; 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End zl_ClinicExeDept;
/

