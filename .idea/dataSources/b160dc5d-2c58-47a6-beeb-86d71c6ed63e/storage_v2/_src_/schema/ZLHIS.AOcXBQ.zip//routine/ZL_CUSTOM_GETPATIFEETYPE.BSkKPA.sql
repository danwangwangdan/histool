create Function Zl_Custom_Getpatifeetype 
( 
  操作类型_In Number, 
  病人id_In   病人信息.病人id%Type := Null, 
  身份证号_In 病人信息.身份证号%Type := Null 
) Return Varchar2 Is 
  -------------------------------------------------------------------------------------------------- 
  --功能:用户自定义获取指定病人费别函数 
  --入参: 
  --     操作类型_In:0-绑定身份;1-挂号操作 
  --     病人id_In:病人ID 
  --     身份证号_In:身份证号 
  --返回:费别 
  -------------------------------------------------------------------------------------------------- 
  v_费别    病人信息.费别%Type; 
  v_Err_Msg Varchar2(200); 
  Err_Item Exception; 
Begin 
  Select 名称 Into v_费别 From 费别 Where 缺省标志 = 1 And Rownum < 2; 
  Return v_费别; 
Exception 
  When Err_Item Then 
    Raise_Application_Error(-20101, '[ZLSOFT]+' || v_Err_Msg || '+[ZLSOFT]'); 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zl_Custom_Getpatifeetype;
/

