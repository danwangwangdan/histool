create Function Zl_Date_Half(Date_In In Date) Return Date 
AS 
    v_下午算半天     Number(1); 
Begin 
   If Date_In Is Null Then 
      Return Null; 
   Elsif To_Char(Date_In, 'hh24') < 12 Then 
      Return Trunc(Date_In); 
   Else 
      v_下午算半天:=To_Number(Nvl(ZL_GetSysParameter(100),0)); 
      IF v_下午算半天=1 THEN 
            Return Trunc(Date_In) + 0.5; 
      ELSE 
	        Return Trunc(Date_In); 
      End IF; 
   End If; 
Exception 
   When Others Then 
      Return Null; 
End Zl_Date_Half;
/

