create Function Zl_Dic_Search 
( 
  Dic_Name_In In Varchar2, 
  Wildcard_In In Varchar2, 
  Leftnull_In In Number 
) Return t_Dic_Rowset Is 
  t_Return   t_Dic_Rowset := t_Dic_Rowset(); 
  v_Dic_Name Varchar2(100); 
  v_Code_Ask Varchar2(100); 
  v_Name_Ask Varchar2(100); 
  e_Noset Exception; 
Begin 
  v_Dic_Name := Upper(Dic_Name_In); 
  v_Code_Ask := Upper(Wildcard_In) || '%'; 
  If Leftnull_In = 0 Then 
    v_Name_Ask := '%' || Upper(Wildcard_In) || '%'; 
  Else 
    v_Name_Ask := Upper(Wildcard_In) || '%'; 
  End If; 
 
  If v_Dic_Name = 'ICD疾病编码' Or v_Dic_Name = '损伤中毒外因' Or v_Dic_Name = '肿瘤编码' Or v_Dic_Name = 'ICD手术编码' Or 
     v_Dic_Name = '中医疾病' Or v_Dic_Name = '中医病证' Then 
    Select t_Dic_Record(编码, 名称, 简码) Bulk Collect 
    Into t_Return 
    From 疾病编码目录 
    Where (类别 = 'D' And v_Dic_Name = 'ICD疾病编码' Or 类别 = 'Y' And v_Dic_Name = '损伤中毒外因' Or 
          类别 = 'M' And v_Dic_Name = '肿瘤编码' Or 类别 = 'S' And v_Dic_Name = 'ICD手术编码' Or 类别 = 'B' And v_Dic_Name = '中医疾病' Or 
          类别 = 'Z' And v_Dic_Name = '中医病证') And (编码 Like v_Code_Ask Or 名称 Like v_Name_Ask Or 简码 Like v_Name_Ask); 
  Elsif v_Dic_Name = '常见传染病' Then 
    Select t_Dic_Record(编码, 名称, 简码) Bulk Collect 
    Into t_Return 
    From 疾病编码目录 
    Where (类别 = 'D' And 编码 < 'B' And (名称 Like '%麻风%' Or 名称 Like '%斑疹伤寒%' Or 名称 Like '%脊髓%灰质炎%') Or 
          类别 = 'D' And 编码 < 'C' And 
          (名称 Like '鼠疫%' Or 名称 Like '%霍乱%' Or 名称 Like '艾滋病%' Or 名称 Like '%HIV%' Or 名称 Like '病毒性肝炎%' Or 名称 Like '麻疹%' Or 
          名称 Like '%出血热%' Or 名称 Like '%狂犬病%' Or 名称 Like '%乙型脑炎%' Or 名称 Like '%登革热%' Or 名称 Like '%痢疾%' Or 
          名称 Like '%肺结核%' Or 名称 Like '%伤寒%' Or 名称 Like '%脑脊髓膜炎%' Or 名称 Like '%百日咳%' Or 名称 Like '%白喉%' Or 
          名称 Like '%新生儿破伤风%' Or 名称 Like '%猩红热%' Or 名称 Like '%布鲁氏%' Or 名称 Like '%淋病%' Or 名称 Like '梅毒%' Or 
          名称 Like '%钩端螺旋%' Or 名称 Like '%血吸虫病%' Or 名称 Like '%疟疾%' Or 名称 Like '流行性腮腺炎%' Or 名称 Like '风疹%' Or 
          名称 Like '%黑热%' Or 名称 Like '%包虫病%' Or 名称 Like '%丝虫病%' Or 名称 Like '%感染性腹泻%') Or 
          类别 = 'D' And 编码 < 'M' And 
          (名称 Like '非典型%肺炎%' Or 名称 Like '%禽流感%' Or 名称 Like '%炭疽%' Or 名称 Like '%流行性感冒%' Or 名称 Like '%出血性%结膜炎%')) And 
          (编码 Like v_Code_Ask Or 名称 Like v_Name_Ask Or 简码 Like v_Name_Ask); 
 
  Elsif v_Dic_Name = '西医常见病' Or v_Dic_Name = '中医常见病' Then 
    Select t_Dic_Record(L.编码, N.名称, N.简码) Bulk Collect 
    Into t_Return 
    From 疾病诊断目录 L, 疾病诊断别名 N 
    Where L.ID = N.诊断id And (L.类别 = 1 And v_Dic_Name = '西医常见病' Or L.类别 = 2 And v_Dic_Name = '中医常见病') And 
          (L.编码 Like v_Code_Ask Or N.名称 Like v_Name_Ask Or N.简码 Like v_Name_Ask); 
 
  Elsif v_Dic_Name = '西药名称' Or v_Dic_Name = '中成药名称' Or v_Dic_Name = '草药名称' Or v_Dic_Name = '草药配方' Or 
        v_Dic_Name = '检验项目' Or v_Dic_Name = '检查项目' Or v_Dic_Name = '治疗项目' Or v_Dic_Name = '手术项目' Or v_Dic_Name = '麻醉项目' Or 
        v_Dic_Name = '护理等级' Or v_Dic_Name = '护理常规' Or v_Dic_Name = '膳食项目' Or v_Dic_Name = '输血项目' Or v_Dic_Name = '输氧项目' Or 
        v_Dic_Name = '其他诊疗' Then 
    Select t_Dic_Record(L.编码, N.名称, N.简码) Bulk Collect 
    Into t_Return 
    From 诊疗项目目录 L, 诊疗项目别名 N 
    Where L.ID = N.诊疗项目id And 
          (L.类别 = '5' And v_Dic_Name = '西药名称' Or L.类别 = '6' And v_Dic_Name = '中成药名称' Or 
          L.类别 = '7' And v_Dic_Name = '草药名称' Or L.类别 = '8' And v_Dic_Name = '草药配方' Or 
          L.类别 = 'C' And v_Dic_Name = '检验项目' Or L.类别 = 'D' And v_Dic_Name = '检查项目' Or 
          L.类别 = 'E' And v_Dic_Name = '治疗项目' Or L.类别 = 'F' And v_Dic_Name = '手术项目' Or 
          L.类别 = 'G' And v_Dic_Name = '麻醉项目' Or L.类别 = 'H' And L.操作类型 = '1' And v_Dic_Name = '护理等级' Or 
          L.类别 = 'H' And L.操作类型 = '0' And v_Dic_Name = '护理常规' Or L.类别 = 'I' And v_Dic_Name = '膳食项目' Or 
          L.类别 = 'K' And v_Dic_Name = '输血项目' Or L.类别 = 'L' And v_Dic_Name = '输氧项目' Or 
          L.类别 = 'Z' And v_Dic_Name = '其他诊疗') And 
          (L.编码 Like v_Code_Ask Or N.名称 Like v_Name_Ask Or N.简码 Like v_Name_Ask); 
 
  Elsif v_Dic_Name = '部门' Then 
    Select t_Dic_Record(编码, 名称, 简码) Bulk Collect 
    Into t_Return 
    From 部门表 
    Where 编码 Like v_Code_Ask Or 名称 Like v_Name_Ask Or 简码 Like v_Name_Ask; 
  Elsif v_Dic_Name = '人员' Then 
    Select t_Dic_Record(编号, 姓名, 简码) Bulk Collect 
    Into t_Return 
    From 人员表 
    Where (编号 Like v_Code_Ask Or 姓名 Like v_Name_Ask Or 简码 Like v_Name_Ask) And 
          (撤档时间 = To_Date('3000-01-01', 'YYYY-MM-DD') Or 撤档时间 Is Null); 
  Elsif v_Dic_Name = '地区' Then 
    Select t_Dic_Record(编码, 名称, 简码) Bulk Collect 
    Into t_Return 
    From 地区 
    Where 编码 Like v_Code_Ask Or 名称 Like v_Name_Ask Or 简码 Like v_Name_Ask; 
  Elsif v_Dic_Name = '检查类型' Then 
    Select t_Dic_Record(编码, 名称, 简码) Bulk Collect 
    Into t_Return 
    From 诊疗检查类型 
    Where 编码 Like v_Code_Ask Or 名称 Like v_Name_Ask Or 简码 Like v_Name_Ask; 
  Elsif v_Dic_Name = '造影剂' Then 
    Select t_Dic_Record(编码, 名称, 简码) Bulk Collect 
    Into t_Return 
    From 造影剂 
    Where 编码 Like v_Code_Ask Or 名称 Like v_Name_Ask Or 简码 Like v_Name_Ask; 
  Elsif v_Dic_Name = '检验标本' Then 
    Select t_Dic_Record(编码, 名称, 简码) Bulk Collect 
    Into t_Return 
    From 诊疗检验标本 
    Where 编码 Like v_Code_Ask Or 名称 Like v_Name_Ask Or 简码 Like v_Name_Ask; 
  Elsif v_Dic_Name = '检验类型' Then 
    Select t_Dic_Record(编码, 名称, 简码) Bulk Collect 
    Into t_Return 
    From 诊疗检验类型 
    Where 编码 Like v_Code_Ask Or 名称 Like v_Name_Ask Or 简码 Like v_Name_Ask; 
  Elsif v_Dic_Name = '麻醉类型' Then 
    Select t_Dic_Record(编码, 名称, 简码) Bulk Collect 
    Into t_Return 
    From 诊疗麻醉类型 
    Where 编码 Like v_Code_Ask Or 名称 Like v_Name_Ask Or 简码 Like v_Name_Ask; 
  Elsif v_Dic_Name = '手术规模' Then 
    Select t_Dic_Record(编码, 名称, 简码) Bulk Collect 
    Into t_Return 
    From 诊疗手术规模 
    Where 编码 Like v_Code_Ask Or 名称 Like v_Name_Ask Or 简码 Like v_Name_Ask; 
  Else 
    Raise e_Noset; 
  End If; 
  Return t_Return; 
Exception 
  When e_Noset Then 
    Raise_Application_Error(-20101, '[ZLSOFT]未设置的字典！[ZLSOFT]'); 
End Zl_Dic_Search;
/

