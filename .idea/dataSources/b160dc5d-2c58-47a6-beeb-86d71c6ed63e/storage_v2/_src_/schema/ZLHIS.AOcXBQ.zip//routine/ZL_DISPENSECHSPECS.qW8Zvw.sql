create Function Zl_Dispensechspecs 
( 
  药名id_In   药品规格.药名id%Type, 
  形态_In     药品规格.中药形态%Type, --0-散装，1-中药饮片，2-免煎剂 
  数量_In     药品库存.可用数量%Type, --按剂量单位传入 
  付数_In     药品库存.可用数量%Type, 
  药房_In     药品库存.库房id%Type, 
  分离发药_In Integer := 0, --分离分药模式,只能处理定价.不能处理实价药品 
  场合_In     Number := 1, -- 1-门诊 ，2-住院 
  药品ids_In  Varchar2 := Null --指定药品的分配 
) Return Varchar2 As 
  --返回:药品id,数量;药品id,数量;...(散装只选择一个规格) 
  --                             不能完全分配时返回:剂量为6和10的情况下,17克的分配=23755,6;23756,10|1 
  --                             不能分配时返回空,例如:剂量为6和10的情况下,3克的分配 
  n_本次数量     药品库存.可用数量%Type; 
  n_总数量       药品库存.可用数量%Type; 
  n_包数         药品库存.可用数量%Type; 
  n_总包数       药品库存.可用数量%Type; 
  n_剩余数量     药品库存.可用数量%Type := 0; 
  v_分配结果     Varchar2(1000); 
  n_可用数量     药品库存.可用数量%Type; 
  n_总数量tmp    药品库存.可用数量%Type; 
  n_上次总数量   药品库存.可用数量%Type; 
  n_本次数量tmp  药品库存.可用数量%Type; 
  n_减少数量     药品库存.可用数量%Type; 
  n_上次计量系数 药品库存.可用数量%Type; 
  n_方式         药品出库检查.检查方式%Type; 
  --Select Zl_Dispensechspecs(7366,2,28,1,76) as txt From dual 
  --可能存在不同批次的,所以要汇总 
  Cursor c_Medi(v_药品ids Varchar) Is 
    Select a.药品id, b.剂量系数, Decode(场合_In, 2, b.住院可否分零, b.门诊可否分零) As 可否分零, Sum(a.可用数量) * b.剂量系数 可用数量 
    From 药品库存 A, 药品规格 B, 收费项目目录 C 
    Where a.药品id = b.药品id And b.药名id = 药名id_In And a.药品id = c.Id And Decode(分离发药_In, 1, c.是否变价, 0) = 0 And 库房id = 药房_In And 
          a.性质 = 1 And b.中药形态 = 形态_In And (Nvl(a.批次, 0) = 0 Or a.效期 Is Null Or a.效期 > Trunc(Sysdate)) And 
          (b.药品id In (Select Column_Value From Table(f_Num2list(v_药品ids))) Or v_药品ids Is Null) And c.服务对象 In (场合_In, 3) 
    Group By a.药品id, b.剂量系数, Decode(场合_In, 2, b.住院可否分零, b.门诊可否分零) 
    Having Nvl(Sum(a.可用数量), 0) > 0 
    Order By b.剂量系数 Desc, 可用数量; 
  --不限定库存的时候 
  Cursor c_Medi_Nostock Is 
    Select b.药品id, b.剂量系数, Decode(场合_In, 2, b.住院可否分零, b.门诊可否分零) As 可否分零, 数量_In As 可用数量 
    From 药品规格 B, 收费项目目录 C 
    Where b.药名id = 药名id_In And b.药品id = c.Id And b.中药形态 = 形态_In And 
          (b.药品id In (Select Column_Value From Table(f_Num2list(药品ids_In))) Or 药品ids_In Is Null) And c.服务对象 In (场合_In, 3) 
    Order By b.剂量系数 Desc; 
 
  Type t_Medi Is Table Of c_Medi%Rowtype; 
  r_Medi t_Medi; 
Begin 
  Open c_Medi(Null); 
  Fetch c_Medi Bulk Collect 
    Into r_Medi; 
  Close c_Medi; 
  n_可用数量 := 0; 
  For J In 1 .. r_Medi.Count Loop 
    n_可用数量 := n_可用数量 + r_Medi(J).可用数量; 
  End Loop; 
 
  If n_可用数量 < 数量_In Then 
    Select Nvl(Max(检查方式), 0) Into n_方式 From 药品出库检查 Where 库房id = 药房_In; 
    If n_方式 <> 2 Then 
      Open c_Medi_Nostock; 
      Fetch c_Medi_Nostock Bulk Collect 
        Into r_Medi; 
      Close c_Medi_Nostock; 
      n_可用数量 := 0; 
      For J In 1 .. r_Medi.Count Loop 
        n_可用数量 := n_可用数量 + r_Medi(J).可用数量; 
      End Loop; 
    End If; 
  Elsif 药品ids_In Is Not Null Then 
    Open c_Medi(药品ids_In); 
    Fetch c_Medi Bulk Collect 
      Into r_Medi; 
    Close c_Medi; 
  End If; 
 
  If Not r_Medi Is Null Then 
    For J In 0 .. r_Medi.Count - 1 Loop 
      --第二层循环是为了处理"大规格"优先时不能完成分配的情况,例如:剂量为6和10的情况下,12克的分配 
      v_分配结果 := Null; 
      n_总数量   := 数量_In; 
      n_总包数   := 0; 
      n_剩余数量 := 0; 
      For I In 1 + J .. r_Medi.Count Loop 
        --按剂量大小的倒序分配满足了"最少用包原则" 
        --总数量(3)可能小于剂量系数(5),存在不能分零的情况 
        --如果总数量刚好等于所有规格的库存之和,但大于任何一种规格的库存,这种特殊情况因处理复杂,实用价值不高,不处理(返回空) 
        n_本次数量 := 0; 
        n_包数     := 0; 
        If n_总数量 <= r_Medi(I).可用数量 Then 
          If n_总数量 >= r_Medi(I).剂量系数 Then 
            If r_Medi(I).可否分零 = 1 Then 
              --不分零 
              n_包数     := Floor(n_总数量 / r_Medi(I).剂量系数); 
              n_本次数量 := n_包数 * r_Medi(I).剂量系数; 
            Else 
              n_包数     := n_总数量 / r_Medi(I).剂量系数; 
              n_本次数量 := n_总数量; 
            End If; 
          End If; 
 
          --这里处理连续的两种规格分配时，大包用后，小包不能用的情况。比如：规格为小包为6g/包，大包为10g/包，现在总量是22g，如果是原来的方式，则是大包2包，余2g 分不尽， 
          --                                                   现修改为在大包分了两包后，小包分不尽的时候，则将已分的大包循环减一个计量系数，这里大包的计量系数为10g， 
          --                                                  已分了20g，现在减10g，就余下12g，然后小包就可以分尽了。最后结果就为大包 1包10g，小包2包12g。 
          --如果中间隔了一个规格，本分支不能解决。比如：三个规格，前两种分不尽，后两种也分不尽，只有第一种和第三种才分的尽的，这种情况应该不多。 
          If ((n_总数量 < r_Medi(I).剂量系数 And n_总数量 > 0) Or n_总数量 - n_本次数量 <> 0) And I <> 1 + J And v_分配结果 Is Not Null Then 
            n_减少数量 := 0; 
            --每次减上次的总量，都将减的数量累加起来。 
            n_总数量tmp := n_总数量 + n_上次计量系数; 
            n_减少数量  := n_减少数量 + n_上次计量系数; 
            Loop 
              --循环减，直到将上次分配的减完。 
              Exit When n_总数量tmp >= n_上次总数量; 
              If r_Medi(I).可否分零 = 1 Then 
                --不分零的才会出现这种 
                n_本次数量tmp := Floor(n_总数量tmp / r_Medi(I).剂量系数) * r_Medi(I).剂量系数; 
              End If; 
              --如果能够分尽，则更新本次的数量，并将上次的数量重新修改。 
              If n_总数量tmp = n_本次数量tmp Then 
                n_包数     := Floor(n_总数量tmp / r_Medi(I).剂量系数); 
                n_本次数量 := n_本次数量tmp; 
                If n_上次总数量 - n_总数量 - n_减少数量 = 0 Then 
                  --如果上次分配的被减完了，则删除上次分配的结果。 
                  v_分配结果 := Substr(v_分配结果, 1, Instr(v_分配结果, ';', -1) - 1); 
                Else 
                  v_分配结果 := Substr(v_分配结果, 1, Instr(v_分配结果, ',', -1)) || (n_上次总数量 - n_总数量 - n_减少数量); 
                End If; 
                --这里由于上次的数量发生了变化，所以总数量也要修改。 
                n_总数量 := n_总数量 + n_减少数量; 
                Exit; 
              End If; 
              n_总数量tmp := n_总数量tmp + n_上次计量系数; 
              n_减少数量  := n_减少数量 + n_上次计量系数; 
            End Loop; 
          End If; 
 
          If n_总数量 >= r_Medi(I).剂量系数 Then 
            If 付数_In * n_本次数量 <= r_Medi(I).可用数量 Then 
              If v_分配结果 Is Null Then 
                v_分配结果 := r_Medi(I).药品id || ',' || n_本次数量; 
              Else 
                v_分配结果 := v_分配结果 || ';' || r_Medi(I).药品id || ',' || n_本次数量; 
              End If; 
 
              n_上次总数量   := n_总数量; 
              n_总包数       := n_总包数 + n_包数; 
              n_总数量       := n_总数量 - n_本次数量; 
              n_上次计量系数 := r_Medi(I).剂量系数; 
              If 形态_In = 0 Then 
                Exit; --散装只能使用一种规格 
              End If; 
            End If; 
          End If; 
        Elsif n_总数量 >= r_Medi(I).剂量系数 And n_总数量 > r_Medi(I).可用数量 And n_总数量 <= n_可用数量 Then 
          --处理了单个规格库存不足，但是所有规格的总数量够用的情况。（这里处理为如果某一个规格数量不足，就能用多少用多少） 
          If r_Medi(I).可否分零 = 1 Then 
            --不分零 
            n_包数     := Floor(r_Medi(I).可用数量 / r_Medi(I).剂量系数); 
            n_本次数量 := n_包数 * r_Medi(I).剂量系数; 
          Else 
            n_包数     := r_Medi(I).可用数量 / r_Medi(I).剂量系数; 
            n_本次数量 := r_Medi(I).可用数量; 
          End If; 
 
          If 付数_In * n_本次数量 <= n_可用数量 Then 
            If v_分配结果 Is Null Then 
              v_分配结果 := r_Medi(I).药品id || ',' || n_本次数量; 
            Else 
              v_分配结果 := v_分配结果 || ';' || r_Medi(I).药品id || ',' || n_本次数量; 
            End If; 
            n_上次总数量   := n_总数量; 
            n_总包数       := n_总包数 + n_包数; 
            n_总数量       := n_总数量 - n_本次数量; 
            n_可用数量     := n_可用数量 - n_本次数量; 
            n_上次计量系数 := r_Medi(I).剂量系数; 
            If 形态_In = 0 Then 
              Exit; --散装只能使用一种规格 
            End If; 
          End If; 
        End If; 
      End Loop; 
      If n_总数量 = 0 Then 
        n_剩余数量 := 0; 
        Exit; 
      Elsif n_剩余数量 = 0 And v_分配结果 Is Not Null Then 
        n_剩余数量 := n_总数量; 
      End If; 
    End Loop; 
  End If; 
 
  If n_总数量 = 0 Or n_剩余数量 <> 0 Then 
    --检查是否适用"倍量优先原则" 
    If n_剩余数量 <> 0 Then 
      n_总数量 := 数量_In - n_剩余数量; 
    Else 
      n_总数量 := 数量_In; 
    End If; 
    For I In 1 .. r_Medi.Count Loop 
      If n_总数量 >= r_Medi(I).剂量系数 And n_总数量 <= r_Medi(I).可用数量 Then 
        n_包数     := Floor(n_总数量 / r_Medi(I).剂量系数); 
        n_本次数量 := n_包数 * r_Medi(I).剂量系数; 
        If n_总数量 = n_本次数量 And 付数_In * n_本次数量 <= r_Medi(I).可用数量 Then 
          If n_包数 <= n_总包数 Then 
            If n_剩余数量 <> 0 Then 
              v_分配结果 := r_Medi(I).药品id || ',' || n_本次数量 || '|' || n_剩余数量; 
            Else 
              v_分配结果 := r_Medi(I).药品id || ',' || n_本次数量; 
            End If; 
          End If; 
          Exit; 
        End If; 
      End If; 
    End Loop; 
 
    Return v_分配结果; 
  Else 
    Return Null; 
  End If; 
End Zl_Dispensechspecs;
/

