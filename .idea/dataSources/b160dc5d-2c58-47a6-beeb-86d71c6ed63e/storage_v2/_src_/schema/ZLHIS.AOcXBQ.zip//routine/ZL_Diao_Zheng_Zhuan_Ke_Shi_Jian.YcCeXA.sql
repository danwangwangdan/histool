create Function       Zl_调整转科时间
(
	住院号_In   Number,
  自动调整_In Number
) Return Varchar2 As
	v_Return Varchar2(50) := '转科时间调整完成！';
	v_病人id Number := 0;
	v_主页id Number := 0;
  v_开始时间 Date;
  v_终止时间 Date;
	Pragma Autonomous_Transaction;
Begin
    Select 病人id,主页id Into v_病人id,v_主页id From 病案主页 Where 住院号=住院号_In;
    --只调整最后一次的转科记录
    Select max(开始时间),Max(终止时间) Into v_开始时间,v_终止时间 From 病人变动记录 Where 病人id=v_病人id And 主页ID=v_主页id And 终止原因=3;
    If v_终止时间 Is Null Then
       v_Return := '该病人不是转科病人！';
       Return(v_Return);
    Else
       Update 病人变动记录 Set 终止时间=v_开始时间+1/(24*60*60) Where 终止原因=3 And 终止时间=v_终止时间;
       Update 病人变动记录 Set 开始时间=v_开始时间+1/(24*60*60) Where 开始原因=3 And 开始时间=v_终止时间;
       Commit;
		   v_Return := '转科时间调整完成！';
       Return(v_Return);
	  End If;
Exception
	When Others Then
    v_Return := '转科时间调整失败！';
		Return(v_Return);
End Zl_调整转科时间;
/

