create Function Zl_Eprsplit(p_String Varchar2, p_Separator Varchar2, p_Element Integer) 
  Return Varchar2 As 
  --实现VB的Split功能,返回在p_String中以p_Separator为分隔的第p_Element个元素串 
  v_String Varchar2(32767); 
Begin 
  v_String := p_String || p_Separator; 
  For I In 1 .. p_Element - 1 Loop 
    v_String := Substr(v_String, Instr(v_String, p_Separator) + 1); 
  End Loop; 
  Return Substr(v_String, 1, Instr(v_String, p_Separator) - 1); 
Exception 
  When Others Then 
    Return Null; 
End Zl_Eprsplit;
/

