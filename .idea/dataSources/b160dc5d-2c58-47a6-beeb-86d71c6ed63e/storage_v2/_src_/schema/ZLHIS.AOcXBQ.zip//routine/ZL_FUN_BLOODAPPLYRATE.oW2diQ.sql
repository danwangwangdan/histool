create Function Zl_Fun_Bloodapplyrate 
( 
  名称_In In 诊疗项目目录.名称%Type, 
  指标_In In Varchar2 
) Return Varchar2 
--功能:返回在输血申请单上显示的检验指标 
  --参数：名称_In 输血项目名称   诊疗项目目录.名称 
  --      指标_In 字符串，半角的逗号分割，对应  诊治所见项目.中文名,指标结果的审核时间，时间可能没有，没有时用 无表示。 
  --      指标名1,时间1,指标名2,时间2,指标名3,无,指标4,时间4,指标5,无,...... 
  --返回值：字符串格式，指标中文名|(0/1)，0-不显示当前提取到的结果，1－要显示结果。用半角的竖线和逗号分割， 
  --                 如：指标1|1,指标2|1,指标3|0,指标4|1,指标5|0 
  --用户可在该过程添加代码 
 As 
  v_Return       Varchar2(4000); 
  v_Tmp指标      Varchar2(4000); 
  v_中文名       Varchar2(200); 
  v_名称符合     Varchar2(4000); 
  v_名称时间符合 Varchar2(4000); 
  n_有效时间     Number(18); 
  v_Tmp时间      Varchar2(200); 
  d_时间         部门表.撤档时间%Type; 
  n_时间差       Number(18); 
  d_Cur          部门表.撤档时间%Type; 
  n_Pos          Number(6); 
Begin 
  If 1 = 1 Then 
    v_Return := 指标_In; 
    Return v_Return; 
  Else 
    --以下为例子代码，仅供参考 
    --例子：血红蛋白,2015-01-23 12:11:23,乙肝表面抗体,2015-01-23 12:11:23,乙肝核心抗体,2015-01-23 12:11:23,甲型肝炎抗体测定,2015-01-23 12:11:23,人免疫缺陷病毒抗体测定,2015-01-23 12:11:23,其它抗体,无 
    --返回：想显示的结果 例：血红蛋白,内抗体 
    --说明：此过程为示例过程，使用时请跟据实际应用做相应调整 
    --     示例功能：对于 输全血 项目要求，在输血申请单上只显示满足以下两个条件中的一个的指标结果。 
    --              1、指标中文名为：血红蛋白,乙肝表面抗体,乙肝核心抗体，同时指标结果在24小时内。 
    --              2、指标中文名为：甲型肝炎抗体测定,人免疫缺陷病毒抗体测定 
    If 名称_In = '输全血' Then 
      v_名称符合     := ',甲型肝炎抗体测定,人免疫缺陷病毒抗体测定,'; 
      v_名称时间符合 := ',血红蛋白,乙肝表面抗体,乙肝核心抗体,'; 
      n_有效时间     := 24 * 60 * 60; 
    Elsif 名称_In = '静脉血' Then 
      Null; 
      --对于其它项目可以在此加代码 
    End If; 
    v_Tmp指标 := 指标_In || ','; 
    d_Cur     := Sysdate; 
    While v_Tmp指标 Is Not Null Loop 
      n_时间差 := 0; 
      --获取指标中文名   v_中文名 
      n_Pos     := Instr(v_Tmp指标, ','); 
      v_中文名  := Substr(v_Tmp指标, 1, n_Pos - 1); 
      v_Tmp指标 := Substr(v_Tmp指标, n_Pos + 1); 
      --获取指标产生的时间   d_时间 
      n_Pos     := Instr(v_Tmp指标, ','); 
      v_Tmp时间 := Substr(v_Tmp指标, 1, n_Pos - 1); 
      v_Tmp指标 := Substr(v_Tmp指标, n_Pos + 1); 
      If v_Tmp时间 <> '无' Then 
        d_时间 := To_Date(v_Tmp时间, 'YYYY-MM-DD HH24:MI:SS'); 
        --指标结果和当前时间差，n_时间差  单位 秒 
        Select (d_Cur - d_时间) * 24 * 60 * 60 Into n_时间差 From Dual; 
      End If; 
      If Instr(v_名称符合, ',' || v_中文名 || ',') > 0 Then 
        v_Return := v_Return || ',' || v_中文名; 
      Elsif Instr(v_名称时间符合, ',' || v_中文名 || ',') > 0 And n_时间差 < n_有效时间 Then 
        v_Return := v_Return || ',' || v_中文名; 
      End If; 
    End Loop; 
    Return v_Return; 
  End If; 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zl_Fun_Bloodapplyrate;
/

