create Function zl_fun_CustomExpenses 
( 
  病人ID_In     In 病案主页.病人ID%Type, 
  主页ID_In     In 病案主页.主页ID%Type, 
  来源_In       In Number, 
  医嘱ID_In     In 病人医嘱记录.ID%Type, 
  相关ID_In     In 病人医嘱记录.相关ID%Type, 
  期效_in       In 病人医嘱记录.医嘱期效%Type, 
  医嘱频率_In   In 病人医嘱记录.执行频次%Type, 
  诊疗项目ID_In In 诊疗项目目录.id%Type, 
  收费细目ID_In In 收费项目目录.ID%Type, 
  执行部门id_In In 部门表.ID%Type, 
  诊疗类别_In   In 诊疗项目目录.类别%Type, 
  收费类别_in   In 收费项目目录.类别%Type, 
  医嘱总量_In   In 病人医嘱记录.总给予量%Type, 
  单量_in       In 病人医嘱记录.单次用量%Type, 
  计价数量_In   In 诊疗收费关系.收费数量%Type, 
  费用性质_In   In 诊疗收费关系.费用性质%Type, 
  计算方式_in   In 诊疗项目目录.计算方式%Type 
) Return Varchar2 Is 
  ---------------------------------- 
  --功能：医嘱发送时，如果收费对照为自定义的，则会调用此过程，决定改收费项目是否收取，收取的次数； 
  --规则： 
  --      1、医嘱发送时诊疗项目的收费方式为9-自定义时，当判断收费项目是否要收取时，会调用一次此过程；获取是否收取，以及收取的数量； 
  --      2、如果多条医嘱的多个收费方式都是自定义，则会循环调用 
  --参数： 
  --      主页ID  :门诊传入0；住院=主页ID 
  --      医嘱ID_In；当前循环的医嘱ID 
  --      相关ID_In：当前循环的医嘱ID对应的组ID，如果本身就是组ID，则为空 
  --      诊疗项目ID_In：当前循环到的医嘱对应的诊疗项目ID 
  --      期效_in：1=临嘱，0-长嘱 
  --      收费细目ID_In：当前循环到的医嘱对应的收费项目ID 
  --      执行部门id_In=当前医嘱的执行科室； 
  --      医嘱总量_In=当前医嘱的总量； 
  --      费用性质_In=0-基础费用；1-床旁或术中加收；2-加班加收(下班时间和节假日) 
  --      计算方式_in=0-不明确；1-计量执行(如药品、材料)；2-计时执行(如理疗)；3-计次(这种方式下，计算单位通常为"次") 
  --返回： 
  --      是否收取(1,0):收取数次   例如：1:1  即要收取，收取一个数次；0:0即代表不收取(注意最后的收费数量会乘以计价数量) 
  --      收取数次可不指定；则按收费对照中默认的数量来收取，可返回是否收取：1  /  0  即可； 
  ----------------------------------- 
  Err_Custom Exception; 
  v_Error Varchar2(255); 
 
Begin 
 
  Return '1'; 
 
Exception 
  When Err_Custom Then 
    Return Null; 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End zl_fun_CustomExpenses;
/

