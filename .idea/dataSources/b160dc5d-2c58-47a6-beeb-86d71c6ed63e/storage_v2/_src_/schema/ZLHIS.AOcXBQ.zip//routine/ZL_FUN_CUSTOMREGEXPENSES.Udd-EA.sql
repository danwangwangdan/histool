create Function Zl_Fun_Customregexpenses 
( 
  病人id_In In 病人信息.病人id%Type, 
  险类_In   In 病人信息.险类%Type, 
  号码_In   In 挂号安排.号码%Type 
) Return Varchar2 
  --    功能：挂号附加费处理项目用户自定义函数 
  --    参数： 
  --        病人ID_In：病人信息.病人ID 
  --        险类_In：病人信息.险类 
  --        号码_In: 挂号安排.号码 
  --    返回: 收费细目ID,多个用逗号分隔,返回NULL时，不处理 
 Is 
Begin 
  Return Null; 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zl_Fun_Customregexpenses;
/

