create Function Zl_Fun_DEPRECIATION ( 
	v_Period IN VARCHAR2 := '', 
v_OutRoomID IN NUMBER := 0, 
v_CardID IN NUMBER := 0 
) 
RETURN NUMBER 
AS 
v_Return NUMBER := 0; 
BEGIN 
	SELECT 本月折旧 
	INTO v_Return 
	FROM 部门折旧数据 
	where 	(期间=v_Period OR v_Period IS NULL) 
 		AND (部门ID=v_OutRoomID OR v_OutRoomID =0) 
		AND (卡片ID=v_CardID OR v_CardID =0) ; 
 
	RETURN (v_Return); 
END Zl_Fun_DEPRECIATION;
/

