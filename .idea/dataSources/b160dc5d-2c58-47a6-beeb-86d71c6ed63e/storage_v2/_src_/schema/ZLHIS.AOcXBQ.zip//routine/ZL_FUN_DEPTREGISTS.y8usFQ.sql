create FUNCTION Zl_Fun_DeptRegists( 
    zlBeginTime IN Date, 
    zlEndTime IN Date := sysdate, 
    v_RegistItemID IN NUMBER := 0, 
    v_RegistDeptID IN NUMBER := 0 
) 
    RETURN NUMBER 
AS 
    v_Return NUMBER := 0; 
Begin 
    SELECT sum(已挂数) 
    INTO v_Return 
    FROM 病人挂号汇总 
    WHERE 日期 BETWEEN trunc(zlBeginTime) AND trunc(zlEndTime)+1-1/24/60/60 
        AND (项目ID=v_RegistItemID OR v_RegistItemID=0) 
        AND (科室id=v_RegistDeptID OR v_RegistDeptID=0); 
    v_Return:=NVL(v_Return,0); 
    RETURN (v_Return); 
End Zl_Fun_DeptRegists;
/

