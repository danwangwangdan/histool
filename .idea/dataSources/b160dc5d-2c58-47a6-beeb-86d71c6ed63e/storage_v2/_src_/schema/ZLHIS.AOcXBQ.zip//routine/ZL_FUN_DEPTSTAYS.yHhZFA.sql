create FUNCTION Zl_Fun_DeptStays( 
    zlBeginTime IN Date, 
    zlEndTime IN Date := sysdate, 
    v_StayDeptID IN NUMBER := 0 
) 
    RETURN NUMBER 
AS 
    v_Return NUMBER := 0; 
Begin 
    IF trunc(zlBeginTime)=trunc(zlEndTime) then 
        SELECT count(*) 
        INTO v_Return 
        FROM 病人变动记录 
        WHERE 开始时间<trunc(zlEndTime)+1 
            AND (终止时间>trunc(zlEndTime)+1 OR 终止时间 IS null) 
            AND (科室id=v_StayDeptID OR v_StayDeptID=0); 
    else 
        SELECT sum(trunc(LEAST(nvl(终止时间,zlEndTime),zlEndTime))-trunc(GREATEST(开始时间,zlBeginTime))) 
        INTO v_Return 
        FROM 病人变动记录 
        WHERE 开始时间<trunc(zlEndTime)+1 
            AND (终止时间>=trunc(zlBeginTime) OR 终止时间 IS null) 
            AND (科室id=v_StayDeptID OR v_StayDeptID=0); 
    End IF; 
    v_Return:=NVL(v_Return,0); 
    RETURN (v_Return); 
End Zl_Fun_DeptStays;
/

