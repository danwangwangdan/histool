create Function Zl_Fun_DEVCHANGE ( 
zlBeginTime IN Date, 
zlEndTime IN Date := sysdate, 
v_OutRoomID  IN NUMBER := 0, 
v_CardID IN NUMBER := 0 
) 
RETURN NUMBER 
AS 
v_Return NUMBER := 0; 
BEGIN 
	SELECT SUM(原值) 
	INTO v_Return 
	FROM 设备变动记录 A 
	WHERE A.审批日期 BETWEEN TRUNC(zlBeginTime) AND TRUNC(zlEndTime)+1-1/24/60/60 
		AND A.变动类型=1   and (使用部门id=v_outRoomID or v_outRoomID=0) 
		and  (A.卡片ID=v_CardID OR v_CardID=0) ; 
	RETURN (v_Return); 
END Zl_Fun_DEVCHANGE;
/

