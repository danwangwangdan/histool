create Function Zl_Fun_Devicenumber 
( 
  Zlbegintime In Date, 
  Zlendtime   In Date := Sysdate, 
  科室编码_In In Varchar2 := '', 
  标识码_In   In Varchar2 := '' 
) Return Number As 
  v_Return Number := 0; 
  M科室id  Number(18); 
Begin 
  Begin 
    Select ID Into M科室id From 部门表 Where 编码 = 科室编码_In; 
  Exception 
    When Others Then 
      M科室id := 0; 
  End; 
  Select Sum(Nvl(数量, 0)) 
  Into v_Return 
  From (Select Sum(Nvl(付数, 0) * Nvl(数次, 0)) As 数量 
         From 住院费用记录 A, 收费项目目录 B 
         Where A.发生时间 Between Trunc(Zlbegintime) And Trunc(Zlendtime) + 1 - 1 / 24 / 60 / 60 And A.收费细目id = B.ID And 
               B.编码 = 标识码_In And A.执行部门id = Nvl(M科室id, 0) 
         Union All 
         Select Sum(Nvl(付数, 0) * Nvl(数次, 0)) As 数量 
         From 门诊费用记录 A, 收费项目目录 B 
         Where A.发生时间 Between Trunc(Zlbegintime) And Trunc(Zlendtime) + 1 - 1 / 24 / 60 / 60 And A.收费细目id = B.ID And 
               B.编码 = 标识码_In And A.执行部门id = Nvl(M科室id, 0)); 
  v_Return := Nvl(v_Return, 0); 
  Return(v_Return); 
End Zl_Fun_Devicenumber;
/

