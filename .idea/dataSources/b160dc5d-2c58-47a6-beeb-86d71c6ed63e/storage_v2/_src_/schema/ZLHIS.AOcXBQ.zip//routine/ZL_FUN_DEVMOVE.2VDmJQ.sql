create FUNCTION Zl_Fun_DevMove ( 
    zlBeginTime IN Date, 
    zlEndTime IN Date := sysdate, 
    v_OutRoomID IN NUMBER := 0, 
    v_InRoomID IN NUMBER := 0 
) 
    RETURN NUMBER 
AS 
    v_Return NUMBER := 0; 
BEGIN 
    SELECT SUM(金额) 
    INTO v_Return 
    FROM 设备收发记录 D,设备目录 L 
    WHERE D.设备id=L.id 
        AND D.审核日期 BETWEEN trunc(zlBeginTime) AND trunc(zlEndTime)+1-1/24/60/60 
        AND D.单据=3 
        AND (D.库房id+0=v_OutRoomID OR v_OutRoomID=0) 
        AND (D.发送部门ID+0=v_InRoomID OR v_InRoomID=0); 
    RETURN (v_Return); 
END Zl_Fun_DevMove;
/

