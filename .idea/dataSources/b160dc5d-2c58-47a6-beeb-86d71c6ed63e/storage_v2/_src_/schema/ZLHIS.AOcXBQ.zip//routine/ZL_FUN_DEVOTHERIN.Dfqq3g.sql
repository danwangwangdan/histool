create FUNCTION Zl_Fun_DevOtherIn ( 
    zlBeginTime IN Date, 
    zlEndTime IN Date := sysdate, 
    v_DataKind IN NUMBER := 1, 
    v_InRoomID IN NUMBER := 0, 
    v_InKindID IN NUMBER := 0 
) 
    RETURN NUMBER 
AS 
    v_Return NUMBER := 0; 
BEGIN 
    SELECT decode(v_DataKind,1,sum(发票金额),2,sum(应摊运杂费),3,sum(金额),0) 
    INTO v_Return 
    FROM 设备收发记录 D,设备目录 L 
    WHERE D.设备id=L.id 
        AND D.审核日期 BETWEEN trunc(zlBeginTime) AND trunc(zlEndTime)+1-1/24/60/60 
        AND D.单据=2 
        AND (D.库房id+0=v_InRoomID OR v_InRoomID=0) 
        AND (D.入出类别id+0=v_InKindID OR v_InKindID=0); 
    RETURN (v_Return); 
END Zl_Fun_DevOtherIn;
/

