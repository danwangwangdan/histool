create Function Zl_Fun_DevReject ( 
zlBeginTime IN Date, 
zlEndTime IN Date := sysdate, 
	v_DataKind IN NUMBER := 1, 
v_OutRoomID IN NUMBER := 0, 
v_OutKindID IN NUMBER := 0 
) 
RETURN NUMBER 
AS 
v_Return NUMBER := 0; 
BEGIN 
	SELECT Decode(v_DataKind,1,SUM(B.原值),2,SUM(B.清理费),3,SUM(B.残值),0) 
	INTO v_Return 
	FROM 设备卡片 A,设备变动记录 B 
	WHERE A.ID=B.卡片ID And B.变动类型=3 
		AND B.审批日期 BETWEEN trunc(zlBeginTime) AND trunc(zlEndTime)+1-1/24/60/60 
		AND (B.使用部门ID+0=v_OutRoomID Or v_OutRoomID=0) 
		AND (B.下帐类别=v_OutKindID Or v_OutKindID=0); 
	RETURN (v_Return); 
END Zl_Fun_DevReject;
/

