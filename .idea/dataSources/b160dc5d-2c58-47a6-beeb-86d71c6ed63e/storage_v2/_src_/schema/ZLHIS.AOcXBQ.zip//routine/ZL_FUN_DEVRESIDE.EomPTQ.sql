create Function Zl_Fun_DEVRESIDE ( 
zlBeginTime IN Date, 
zlEndTime IN Date := sysdate, 
v_OutRoomID IN NUMBER := 0, 
v_InRoomID IN NUMBER := 0 
) 
RETURN NUMBER 
AS 
v_Return NUMBER := 0; 
BEGIN 
	SELECT SUM(原值) 
	INTO v_Return 
	FROM 设备变动记录 A 
	WHERE A.审批日期 BETWEEN TRUNC(zlBeginTime) AND TRUNC(zlEndTime)+1-1/24/60/60 
		AND A.变动类型=0 
		AND (A.使用部门id=v_OutRoomID OR v_OutRoomID =0 ) 
		AND (a.发送id=v_InRoomID OR v_InRoomID =0 ); 
	RETURN (v_Return); 
END Zl_Fun_DEVRESIDE;
/

