create FUNCTION Zl_Fun_DEVTAKECARE  ( 
    zlBeginTime IN Date, 
    zlEndTime IN Date := sysdate, 
    v_DataKind  IN NUMBER := 1, 
    v_OutRoomID IN NUMBER := 0 
) 
    RETURN NUMBER 
AS 
    v_Return NUMBER := 0; 
BEGIN 
	SELECT DECODE(v_DataKind,1,SUM(保养费),2,SUM(材料费),3,SUM(其它),0) 
	INTO v_Return 
	FROM 设备保养记录 
	WHERE 日期 BETWEEN TRUNC(zlBeginTime) AND TRUNC(zlEndTime)+1-1/24/60/60 
	AND (使用部门id+0=v_OutRoomID OR v_OutRoomID=0); 
	RETURN (v_Return); 
END Zl_Fun_DEVTAKECARE;
/

