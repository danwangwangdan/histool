create FUNCTION Zl_Fun_DoctorRegists( 
    zlBeginTime IN Date, 
    zlEndTime IN Date := sysdate, 
    v_Doctor IN VARCHAR2 := '' 
) 
    RETURN NUMBER 
AS 
    v_Return NUMBER := 0; 
Begin 
    SELECT sum(已挂数) 
    INTO v_Return 
    FROM 病人挂号汇总 
    WHERE 日期 BETWEEN trunc(zlBeginTime) AND trunc(zlEndTime)+1-1/24/60/60 
        AND (医生姓名=v_Doctor OR v_Doctor=0); 
    v_Return:=NVL(v_Return,0); 
    RETURN (v_Return); 
End Zl_Fun_DoctorRegists;
/

