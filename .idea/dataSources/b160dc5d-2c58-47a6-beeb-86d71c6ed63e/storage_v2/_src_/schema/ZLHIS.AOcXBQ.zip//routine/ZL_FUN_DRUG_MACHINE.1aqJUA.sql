create Function Zl_Fun_Drug_Machine 
( 
  库房id_In   In 部门表.Id%Type, 
  药品剂型_In In 药品剂型.名称%Type, 
  收发id_In   In 药品收发记录.Id%Type := Null 
) Return 药品设备接口.编号%Type Is 
 
  v_Code 药品设备接口.编号%Type; 
 
Begin 
 
  --功能：计算参数对应的接口编号 
  --说明：药品自动化设备接口部件的专用函数。 
  --参数： 
  --  收发ID_In：扩展参数，标准调用不传入 
 
  Begin 
    Select a.编号 
    Into v_Code 
    From 药品设备接口 A, 
         Xmltable('//root/bm' Passing a.扩展信息 Columns 库房id Number(18) Path 'id', 剂型编码 Varchar2(20) Path 'jxbm') B, 药品剂型 C 
    Where b.剂型编码 = c.编码 And a.停用日期 Is Null And a.启用日期 Is Not Null And b.库房id = 库房id_In And c.名称 = 药品剂型_In And 
          Rownum < 2; 
  Exception 
    When Others Then 
      Begin 
        Select a.编号 
        Into v_Code 
        From 药品设备接口 A, 
             Xmltable('//root/bm' Passing a.扩展信息 Columns 库房id Number(18) Path 'id', 剂型编码 Varchar2(20) Path 'jxbm') B 
        Where a.停用日期 Is Null And a.启用日期 Is Not Null And (b.剂型编码 = '' Or b.剂型编码 Is Null) And b.库房id = 库房id_In And 
              Rownum < 2; 
      Exception 
        When Others Then 
          v_Code := Null; 
      End; 
  End; 
 
  Return v_Code; 
 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zl_Fun_Drug_Machine;
/

