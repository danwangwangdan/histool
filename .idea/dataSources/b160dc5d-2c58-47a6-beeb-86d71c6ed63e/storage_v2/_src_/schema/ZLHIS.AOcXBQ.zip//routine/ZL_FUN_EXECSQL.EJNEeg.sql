create Function ZL_FUN_ExecSql 
  ( 
  Sql_In in Varchar2:='' 
  ) 
  return varchar2 
Is 
  vSql varchar2(4000); 
  RSql_Out varchar2(1000); 
begin 
  vSql:=Sql_In; 
  execute immediate vSql into RSql_Out; 
  return RSql_Out; 
Exception 
  When Others Then  Return '[zlsoft]Error[zlsoft]:'||SQLERRM; 
End ZL_FUN_ExecSql;
/

