create Function Zl_Fun_Getbatchnum 
( 
  药品id_In   药品批号对照.药品id%Type, 
  生产厂家_In 药品批号对照.生产厂家%Type, 
  批号_In     药品批号对照.批号%Type, 
  成本价_In   药品批号对照.成本价%Type, 
  售价_In     药品批号对照.售价%Type, 
  新批次_In   药品批号对照.批次%Type 
) Return Number Is 
  --功能：药品入库产生入库记录时根据传递过来的参数找对应的批次 
  --返回值：查询到的批次，如果批次>0则说明找到了批次,如果批次=0则说明没有找到 
  --参数： 
  --     生产厂家_in：入库传递过来的生产商 
  --     批号_in：入库时录入的批号 
  --     成本价_in 入库时的成本价 
  --     售价_in  入库时的售价 
  -- 
  n_批次     药品批号对照.批次%Type; 
  n_药库包装 药品规格.药库包装%Type; 
  n_是否变价 收费项目目录.是否变价%Type; 
Begin 
  --只处理生产厂家和批号不为空的情况 
  If 生产厂家_In Is not Null And 批号_In  Is Not Null Then 
    Begin 
      Select 批次 
      Into n_批次 
      From 药品批号对照 
      Where 药品id = 药品id_In And Nvl(生产厂家, 'a') = Nvl(生产厂家_In, 'a') And Nvl(批号, 'b') = Nvl(批号_In, 'b') And 成本价 = 成本价_In And 
            售价 = 售价_In; 
    Exception 
      When Others Then 
        n_批次 := 新批次_In; 
 
        Insert Into 药品批号对照 
          (药品id, 生产厂家, 批号, 批次, 成本价, 售价) 
        Values 
          (药品id_In, 生产厂家_In, 批号_In, 新批次_In, 成本价_In,售价_In); 
    End; 
  End If; 
 
  Return(n_批次); 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zl_Fun_Getbatchnum;
/

