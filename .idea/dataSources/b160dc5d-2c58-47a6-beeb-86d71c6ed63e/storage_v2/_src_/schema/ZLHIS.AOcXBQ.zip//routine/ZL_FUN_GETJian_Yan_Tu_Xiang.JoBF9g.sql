create Function Zl_FUN_Get检验图像 
( 
  Key_In In number, 
  Type_In In varchar2, 
  Pos_In In Number 
  --参数说明： 
  --Key_In：数据记录的关键字 
  --Pos_In：从0开始不断读取，直到返回为空 
) Return Varchar2 Is 
  l_Clob   Clob; 
  v_Buffer Varchar2(2000); 
  n_Amount Number := 2000; 
  n_Offset Number := 1; 
Begin 
 
  SELECT 图像点 INTO l_Clob FROM  检验图像结果 WHERE 标本id = Key_In and 图像类型 = Type_In; 
 
  n_Offset := n_Offset + Pos_In * n_Amount; 
  Dbms_Lob.Read(l_Clob, n_Amount, n_Offset, v_Buffer); 
  Return v_Buffer; 
Exception 
  When Others Then 
    Return Null; 
End Zl_FUN_Get检验图像;
/

