create Function Zl_Fun_Get临床出诊预约状态 
( 
  记录id_In   In 临床出诊记录.Id%Type, 
  预约时间_In In 病人挂号记录.预约时间%Type, 
  序号_In     临床出诊序号控制.序号%Type := Null, 
  预约方式_In 预约方式.名称%Type := Null, 
  合作单位_In 挂号合作单位.名称%Type := Null, 
  收费预约_In Number := 0 
) Return Varchar2 As 
  --功能：判断出诊记录在预约时间是否可预约 
  --入参： 
  --返回： 
  --     格式：预约状态|提示信息，如："1|预约时间不在当前上班时段时间范围内。" 
  --     预约状态： 
  --         0-可预约 
  --         ====================================================== 
  --         1-不可预约，预约时间不在当前上班时段时间范围内 
  --         2-不可预约，当前上班时段禁止预约 
  --         3-不可预约，当前上班时段在预约时间时已停诊 
  --         4-不可预约，当前上班时段剩余可预约数为零 
  --         ====================================================== 
  --         5-不可预约，当前预约时间在法定节假日时间范围内，不上班 
  --         6-不可预约，当前预约时间在法定节假日时间范围内，禁止预约 
  --         7-不可预约，当前预约时间在法定节假日不允许预约的时间范围内 
  --         8-不可预约，当前预约时间在法定节假日不允许挂号的时间范围内 
  --         9-不可预约，当前预约时间在法定节假日时间范围内，已停诊 
  --         ====================================================== 
  --         10-不可预约，当前预约方式禁止预约 
  --         11-不可预约，当前预约方式可预约数不足 
  --         ====================================================== 
  --         12-不可预约，当前合作单位禁止预约 
  --         13-不可预约，当前合作单位可预约数不足 
  --         ====================================================== 
  --         14-不可预约，当前序号禁止预约 
  --         15-不可预约，当前序号已经被使用 
  --         16-不可预约，当前序号不可用 
  -- 
  n_号源id         临床出诊记录.号源id%Type; 
  n_是否分时段     临床出诊记录.是否分时段%Type; 
  n_预约控制       临床出诊记录.预约控制%Type; 
  d_停诊开始时间   临床出诊记录.停诊开始时间%Type; 
  d_停诊终止时间   临床出诊记录.停诊终止时间%Type; 
  v_停诊原因       临床出诊记录.停诊原因%Type; 
  n_限约数         临床出诊记录.限约数%Type; 
  n_已约数         临床出诊记录.已约数%Type; 
  n_独占           临床出诊记录.是否独占%Type; 
  n_控制方式       临床出诊挂号控制记录.控制方式%Type; 
  n_数量           临床出诊挂号控制记录.数量%Type; 
  n_数量限制       临床出诊挂号控制记录.数量%Type; 
  n_序号控制       临床出诊记录.是否序号控制%Type; 
  v_预约方式       临床出诊挂号控制记录.名称%Type; 
  n_类型           临床出诊挂号控制记录.类型%Type; 
  n_预约方式限约数 临床出诊记录.限约数%Type; 
  n_预约方式已约数 临床出诊记录.已约数%Type; 
  n_挂号状态       临床出诊序号控制.挂号状态%Type; 
  n_是否预约       临床出诊序号控制.是否预约%Type; 
 
  n_假日控制状态 临床出诊号源.假日控制状态%Type; 
 
  v_允许预约 法定假日表.允许预约%Type; 
  v_允许挂号 法定假日表.允许挂号%Type; 
  n_Count    Number(2); 
  n_已使用   Number(5); 
Begin 
  Begin 
    Select a.号源id, a.是否分时段, a.预约控制, a.停诊开始时间, a.停诊终止时间, a.停诊原因, Nvl(限约数, 限号数), 已约数, 是否独占, 是否序号控制 
    Into n_号源id, n_是否分时段, n_预约控制, d_停诊开始时间, d_停诊终止时间, v_停诊原因, n_限约数, n_已约数, n_独占, n_序号控制 
    From 临床出诊记录 A 
    Where a.Id = 记录id_In And 预约时间_In Between 开始时间 And 终止时间; 
  Exception 
    When Others Then 
      Return '1|预约时间不在当前上班时段时间范围内。'; 
  End; 
 
  --预约方式检查 
  If 预约方式_In Is Not Null Then 
    Begin 
      Select 控制方式 
      Into n_控制方式 
      From 临床出诊挂号控制记录 
      Where 类型 = 2 And 性质 = 1 And 记录id = 记录id_In And 名称 = 预约方式_In And Rownum < 2; 
    Exception 
      When Others Then 
        Begin 
          Select 控制方式 
          Into n_控制方式 
          From 临床出诊挂号控制记录 
          Where 类型 = 2 And 性质 = 1 And 记录id = 记录id_In And Rownum < 2; 
        Exception 
          When Others Then 
            Null; 
        End; 
    End; 
    If n_控制方式 = 0 Then 
      Return '10|当前预约方式禁止预约。'; 
    End If; 
    If n_控制方式 = 1 Or n_控制方式 = 2 Then 
      Select Nvl(限约数, 限号数) Into n_预约方式限约数 From 临床出诊记录 Where ID = 记录id_In; 
      If n_独占 = 0 Then 
        Begin 
          Select 数量 
          Into n_数量 
          From 临床出诊挂号控制记录 
          Where 类型 = 2 And 性质 = 1 And 名称 = 预约方式_In And 记录id = 记录id_In; 
        Exception 
          When Others Then 
            n_数量 := Null; 
        End; 
        If n_数量 Is Not Null Then 
          If n_控制方式 = 1 Then 
            n_预约方式限约数 := Round(n_预约方式限约数 * n_数量 / 100); 
          Else 
            n_预约方式限约数 := n_数量; 
          End If; 
          Select Count(1) 
          Into n_预约方式已约数 
          From 病人挂号记录 
          Where 出诊记录id = 记录id_In And 记录状态 = 1 And 预约方式 = 预约方式_In; 
          If n_预约方式已约数 >= n_预约方式限约数 Then 
            Return '11|当前预约方式可预约数不足。'; 
          End If; 
        End If; 
      Else 
        --限数量独占 
        Begin 
          Select 数量 
          Into n_数量 
          From 临床出诊挂号控制记录 
          Where 类型 = 2 And 性质 = 1 And 名称 = 预约方式_In And 记录id = 记录id_In; 
        Exception 
          When Others Then 
            n_数量 := Null; 
        End; 
        If n_数量 Is Not Null Then 
          If n_控制方式 = 1 Then 
            n_预约方式限约数 := Round(n_预约方式限约数 * n_数量 / 100); 
          Else 
            n_预约方式限约数 := n_数量; 
          End If; 
          Select Count(1) 
          Into n_预约方式已约数 
          From 病人挂号记录 
          Where 出诊记录id = 记录id_In And 记录状态 = 1 And 预约方式 = 预约方式_In; 
          If n_预约方式已约数 >= n_预约方式限约数 Then 
            Return '11|当前预约方式可预约数不足。'; 
          End If; 
        Else 
          If 收费预约_In = 0 Then 
            For r_限制 In (Select 数量, 名称, 类型 From 临床出诊挂号控制记录 Where 性质 = 1 And 记录id = 记录id_In) Loop 
              If r_限制.类型 = 1 Then 
                Select Count(1) 
                Into n_已使用 
                From 病人挂号记录 
                Where 出诊记录id = 记录id_In And 合作单位 = r_限制.名称 And 记录状态 = 1; 
              Else 
                Select Count(1) 
                Into n_已使用 
                From 病人挂号记录 
                Where 出诊记录id = 记录id_In And 预约方式 = r_限制.名称 And 记录状态 = 1; 
              End If; 
              If n_控制方式 = 1 Then 
                n_数量限制 := Nvl(n_数量限制, 0) + Round(r_限制.数量 * n_预约方式限约数 / 100) - Nvl(n_已使用, 0); 
              Else 
                n_数量限制 := Nvl(n_数量限制, 0) + r_限制.数量 - Nvl(n_已使用, 0); 
              End If; 
            End Loop; 
            Select Count(1) Into n_已使用 From 病人挂号记录 Where 出诊记录id = 记录id_In And 记录状态 = 1; 
            If n_预约方式限约数 - n_数量限制 - n_已使用 > 0 Then 
              Null; 
            Else 
              Return '11|当前预约方式可预约数不足。'; 
            End If; 
          Else 
            For r_限制 In (Select 数量, 名称, 类型 
                         From 临床出诊挂号控制记录 
                         Where 性质 = 1 And 类型 = 2 And 记录id = 记录id_In) Loop 
              Select Count(1) 
              Into n_已使用 
              From 病人挂号记录 
              Where 出诊记录id = 记录id_In And 预约方式 = r_限制.名称 And 记录状态 = 1; 
              If n_控制方式 = 1 Then 
                n_数量限制 := Nvl(n_数量限制, 0) + Round(r_限制.数量 * n_预约方式限约数 / 100) - Nvl(n_已使用, 0); 
              Else 
                n_数量限制 := Nvl(n_数量限制, 0) + r_限制.数量 - Nvl(n_已使用, 0); 
              End If; 
            End Loop; 
            Select Count(1) Into n_已使用 From 病人挂号记录 Where 出诊记录id = 记录id_In And 记录状态 = 1; 
            If n_预约方式限约数 - n_数量限制 - n_已使用 > 0 Then 
              Null; 
            Else 
              Return '11|当前预约方式可预约数不足。'; 
            End If; 
          End If; 
        End If; 
      End If; 
    End If; 
    If n_控制方式 = 3 Then 
      If n_序号控制 = 1 Then 
        If 收费预约_In = 0 Then 
          Begin 
            Select 数量, 名称, 类型 
            Into n_预约方式限约数, v_预约方式, n_类型 
            From 临床出诊挂号控制记录 
            Where 性质 = 1 And 记录id = 记录id_In And 序号 = 序号_In; 
          Exception 
            When Others Then 
              n_预约方式限约数 := Null; 
          End; 
          If n_预约方式限约数 Is Not Null Then 
            If v_预约方式 <> 预约方式_In Or n_类型 = 1 Then 
              Return '11|当前预约方式可预约数不足。'; 
            End If; 
            Select Nvl(Max(1), 0) 
            Into n_预约方式已约数 
            From 病人挂号记录 
            Where 出诊记录id = 记录id_In And 号序 = 序号_In; 
            If n_预约方式已约数 >= n_预约方式限约数 Then 
              Return '11|当前预约方式可预约数不足。'; 
            End If; 
          End If; 
        Else 
          Begin 
            Select 数量, 名称, 类型 
            Into n_预约方式限约数, v_预约方式, n_类型 
            From 临床出诊挂号控制记录 
            Where 性质 = 1 And 类型 = 2 And 记录id = 记录id_In And 序号 = 序号_In; 
          Exception 
            When Others Then 
              n_预约方式限约数 := Null; 
          End; 
          If n_预约方式限约数 Is Not Null Then 
            If v_预约方式 <> 预约方式_In Then 
              Return '11|当前预约方式可预约数不足。'; 
            End If; 
            Select Nvl(Max(1), 0) 
            Into n_预约方式已约数 
            From 病人挂号记录 
            Where 出诊记录id = 记录id_In And 号序 = 序号_In; 
            If n_预约方式已约数 >= n_预约方式限约数 Then 
              Return '11|当前预约方式可预约数不足。'; 
            End If; 
          End If; 
        End If; 
      Else 
        If 收费预约_In = 0 Then 
          For r_限制 In (Select 数量, 名称, 类型 
                       From 临床出诊挂号控制记录 
                       Where 性质 = 1 And 记录id = 记录id_In And 序号 = 序号_In) Loop 
            If r_限制.名称 <> 预约方式_In Or r_限制.类型 = 1 Then 
              If r_限制.类型 = 1 Then 
                Select Count(1) 
                Into n_已使用 
                From 临床出诊序号控制 A, 病人挂号记录 B 
                Where a.记录id = 记录id_In And a.预约顺序号 Is Not Null And Nvl(a.挂号状态, 0) <> 0 And a.备注 = b.号序 And 
                      b.合作单位 = r_限制.名称 And b.记录状态 = 1; 
              Else 
                Select Count(1) 
                Into n_已使用 
                From 临床出诊序号控制 A, 病人挂号记录 B 
                Where a.记录id = 记录id_In And a.预约顺序号 Is Not Null And Nvl(a.挂号状态, 0) <> 0 And a.备注 = b.号序 And 
                      b.预约方式 = r_限制.名称 And b.记录状态 = 1; 
              End If; 
              n_数量限制 := Nvl(n_数量限制, 0) + r_限制.数量 - Nvl(n_已使用, 0); 
            Else 
              Select Count(1) 
              Into n_预约方式已约数 
              From 临床出诊序号控制 A, 病人挂号记录 B 
              Where a.记录id = 记录id_In And a.预约顺序号 Is Not Null And Nvl(a.挂号状态, 0) <> 0 And a.备注 = b.号序 And 
                    b.预约方式 = 预约方式_In And b.记录状态 = 1; 
              If n_预约方式已约数 >= n_预约方式限约数 Then 
                Return '11|当前预约方式可预约数不足。'; 
              End If; 
            End If; 
          End Loop; 
          Select Count(1) 
          Into n_已使用 
          From 临床出诊序号控制 A 
          Where a.记录id = 记录id_In And a.预约顺序号 Is Not Null And Nvl(a.挂号状态, 0) <> 0 And 序号 = 序号_In; 
          Select Nvl(限约数, 限号数) Into n_预约方式限约数 From 临床出诊记录 Where ID = 记录id_In; 
          If n_预约方式限约数 - n_数量限制 - n_已使用 > 0 Then 
            Null; 
          Else 
            Return '11|当前预约方式可预约数不足。'; 
          End If; 
        Else 
          For r_限制 In (Select 数量, 名称, 类型 
                       From 临床出诊挂号控制记录 
                       Where 性质 = 1 And 类型 = 2 And 记录id = 记录id_In And 序号 = 序号_In) Loop 
            If r_限制.名称 <> 预约方式_In Then 
              Select Count(1) 
              Into n_已使用 
              From 临床出诊序号控制 A, 病人挂号记录 B 
              Where a.记录id = 记录id_In And a.预约顺序号 Is Not Null And Nvl(a.挂号状态, 0) <> 0 And a.备注 = b.号序 And 
                    b.预约方式 = r_限制.名称 And b.记录状态 = 1; 
              n_数量限制 := Nvl(n_数量限制, 0) + r_限制.数量 - Nvl(n_已使用, 0); 
            Else 
              Select Count(1) 
              Into n_预约方式已约数 
              From 临床出诊序号控制 A, 病人挂号记录 B 
              Where a.记录id = 记录id_In And a.预约顺序号 Is Not Null And Nvl(a.挂号状态, 0) <> 0 And a.备注 = b.号序 And 
                    b.预约方式 = 预约方式_In And b.记录状态 = 1; 
              If n_预约方式已约数 >= n_预约方式限约数 Then 
                Return '11|当前预约方式可预约数不足。'; 
              End If; 
            End If; 
          End Loop; 
          Select Count(1) 
          Into n_已使用 
          From 临床出诊序号控制 A 
          Where a.记录id = 记录id_In And a.预约顺序号 Is Not Null And Nvl(a.挂号状态, 0) <> 0 And 序号 = 序号_In; 
          Select Nvl(限约数, 限号数) Into n_预约方式限约数 From 临床出诊记录 Where ID = 记录id_In; 
          If n_预约方式限约数 - n_数量限制 - n_已使用 > 0 Then 
            Null; 
          Else 
            Return '11|当前预约方式可预约数不足。'; 
          End If; 
        End If; 
      End If; 
    End If; 
  End If; 
 
  --合作单位检查 
  If 合作单位_In Is Not Null Then 
    Begin 
      Select 控制方式 
      Into n_控制方式 
      From 临床出诊挂号控制记录 
      Where 类型 = 1 And 性质 = 1 And 记录id = 记录id_In And 名称 = 合作单位_In And Rownum < 2; 
    Exception 
      When Others Then 
        Begin 
          Select 控制方式 
          Into n_控制方式 
          From 临床出诊挂号控制记录 
          Where 类型 = 1 And 性质 = 1 And 记录id = 记录id_In And Rownum < 2; 
        Exception 
          When Others Then 
            Null; 
        End; 
    End; 
    If n_控制方式 = 0 Then 
      Return '12|当前合作单位禁止预约。'; 
    End If; 
    If n_控制方式 = 1 Or n_控制方式 = 2 Then 
      Select Nvl(限约数, 限号数) Into n_预约方式限约数 From 临床出诊记录 Where ID = 记录id_In; 
      If n_独占 = 0 Then 
        Begin 
          Select 数量 
          Into n_数量 
          From 临床出诊挂号控制记录 
          Where 类型 = 1 And 性质 = 1 And 名称 = 合作单位_In And 记录id = 记录id_In; 
        Exception 
          When Others Then 
            n_数量 := Null; 
        End; 
        If n_数量 Is Not Null Then 
          If n_控制方式 = 1 Then 
            n_预约方式限约数 := Round(n_预约方式限约数 * n_数量 / 100); 
          Else 
            n_预约方式限约数 := n_数量; 
          End If; 
          Select Count(1) 
          Into n_预约方式已约数 
          From 病人挂号记录 
          Where 出诊记录id = 记录id_In And 记录状态 = 1 And 合作单位 = 合作单位_In; 
          If n_预约方式已约数 >= n_预约方式限约数 Then 
            Return '13|当前合作单位可预约数不足。'; 
          End If; 
        End If; 
      Else 
        --限数量独占 
        Begin 
          Select 数量 
          Into n_数量 
          From 临床出诊挂号控制记录 
          Where 类型 = 1 And 性质 = 1 And 名称 = 合作单位_In And 记录id = 记录id_In; 
        Exception 
          When Others Then 
            n_数量 := Null; 
        End; 
        If n_数量 Is Not Null Then 
          If n_控制方式 = 1 Then 
            n_预约方式限约数 := Round(n_预约方式限约数 * n_数量 / 100); 
          Else 
            n_预约方式限约数 := n_数量; 
          End If; 
          Select Count(1) 
          Into n_预约方式已约数 
          From 病人挂号记录 
          Where 出诊记录id = 记录id_In And 记录状态 = 1 And 合作单位 = 合作单位_In; 
          If n_预约方式已约数 >= n_预约方式限约数 Then 
            Return '13|当前合作单位可预约数不足。'; 
          End If; 
        Else 
          For r_限制 In (Select 数量, 名称, 类型 From 临床出诊挂号控制记录 Where 性质 = 1 And 记录id = 记录id_In) Loop 
            If r_限制.类型 = 1 Then 
              Select Count(1) 
              Into n_已使用 
              From 病人挂号记录 
              Where 出诊记录id = 记录id_In And 合作单位 = r_限制.名称 And 记录状态 = 1; 
            Else 
              Select Count(1) 
              Into n_已使用 
              From 病人挂号记录 
              Where 出诊记录id = 记录id_In And 预约方式 = r_限制.名称 And 记录状态 = 1; 
            End If; 
            If n_控制方式 = 1 Then 
              n_数量限制 := Nvl(n_数量限制, 0) + Round(r_限制.数量 * n_预约方式限约数 / 100) - Nvl(n_已使用, 0); 
            Else 
              n_数量限制 := Nvl(n_数量限制, 0) + r_限制.数量 - Nvl(n_已使用, 0); 
            End If; 
          End Loop; 
          Select Count(1) Into n_已使用 From 病人挂号记录 Where 出诊记录id = 记录id_In And 记录状态 = 1; 
          If n_预约方式限约数 - n_数量限制 - n_已使用 > 0 Then 
            Null; 
          Else 
            Return '13|当前合作单位可预约数不足。'; 
          End If; 
        End If; 
      End If; 
    End If; 
    If n_控制方式 = 3 Then 
      If n_序号控制 = 1 Then 
        Begin 
          Select 数量, 名称, 类型 
          Into n_预约方式限约数, v_预约方式, n_类型 
          From 临床出诊挂号控制记录 
          Where 性质 = 1 And 记录id = 记录id_In And 序号 = 序号_In; 
        Exception 
          When Others Then 
            n_预约方式限约数 := Null; 
        End; 
        If n_预约方式限约数 Is Not Null Then 
          If v_预约方式 <> 合作单位_In Or n_类型 = 1 Then 
            Return '13|当前合作单位可预约数不足。'; 
          End If; 
          Select Nvl(Max(1), 0) 
          Into n_预约方式已约数 
          From 病人挂号记录 
          Where 出诊记录id = 记录id_In And 号序 = 序号_In; 
          If n_预约方式已约数 >= n_预约方式限约数 Then 
            Return '13|当前合作单位可预约数不足。'; 
          End If; 
        End If; 
      Else 
        For r_限制 In (Select 数量, 名称, 类型 
                     From 临床出诊挂号控制记录 
                     Where 性质 = 1 And 记录id = 记录id_In And 序号 = 序号_In) Loop 
          If r_限制.名称 <> 合作单位_In Or r_限制.类型 = 1 Then 
            If r_限制.类型 = 1 Then 
              Select Count(1) 
              Into n_已使用 
              From 临床出诊序号控制 A, 病人挂号记录 B 
              Where a.记录id = 记录id_In And a.预约顺序号 Is Not Null And Nvl(a.挂号状态, 0) <> 0 And a.备注 = b.号序 And 
                    b.合作单位 = r_限制.名称 And b.记录状态 = 1; 
            Else 
              Select Count(1) 
              Into n_已使用 
              From 临床出诊序号控制 A, 病人挂号记录 B 
              Where a.记录id = 记录id_In And a.预约顺序号 Is Not Null And Nvl(a.挂号状态, 0) <> 0 And a.备注 = b.号序 And 
                    b.预约方式 = r_限制.名称 And b.记录状态 = 1; 
            End If; 
            n_数量限制 := Nvl(n_数量限制, 0) + r_限制.数量 - Nvl(n_已使用, 0); 
          Else 
            Select Count(1) 
            Into n_预约方式已约数 
            From 临床出诊序号控制 A, 病人挂号记录 B 
            Where a.记录id = 记录id_In And a.预约顺序号 Is Not Null And Nvl(a.挂号状态, 0) <> 0 And a.备注 = b.号序 And b.合作单位 = 合作单位_In And 
                  b.记录状态 = 1; 
            If n_预约方式已约数 >= n_预约方式限约数 Then 
              Return '13|当前合作单位可预约数不足。'; 
            End If; 
          End If; 
        End Loop; 
        Select Count(1) 
        Into n_已使用 
        From 临床出诊序号控制 A 
        Where a.记录id = 记录id_In And a.预约顺序号 Is Not Null And Nvl(a.挂号状态, 0) <> 0 And 序号 = 序号_In; 
        Select Nvl(限约数, 限号数) Into n_预约方式限约数 From 临床出诊记录 Where ID = 记录id_In; 
        If n_预约方式限约数 - n_数量限制 - n_已使用 > 0 Then 
          Null; 
        Else 
          Return '13|当前合作单位可预约数不足。'; 
        End If; 
      End If; 
    End If; 
  End If; 
 
  --0-不作预约限制;1-该号别禁止预约;2-仅禁止三方机构平台的预约 
  If Nvl(n_预约控制, 0) = 1 Then 
    Return '2|当前上班时段禁止预约。'; 
  End If; 
 
  If d_停诊开始时间 Is Not Null And Not (Nvl(n_序号控制, 0) = 1 And Nvl(n_是否分时段, 0) = 1) Then 
    If 预约时间_In >= d_停诊开始时间 And 预约时间_In <= d_停诊终止时间 Then 
      Return '3|当前上班时段在预约时间时已停诊，不能预约！'; 
    End If; 
  End If; 
 
  If Nvl(n_限约数, 0) > 0 Then 
    If Nvl(n_限约数, 0) - Nvl(n_已约数, 0) <= 0 Then 
      Return '4|当前上班时段剩余可预约数为零，不能继续预约！'; 
    End If; 
  End If; 
 
  If Nvl(n_是否分时段, 0) = 0 Then 
    --不分时段 
    Begin 
      Select Nvl(b.假日控制状态, 0) Into n_假日控制状态 From 临床出诊号源 B Where b.Id = n_号源id; 
    Exception 
      When Others Then 
        n_假日控制状态 := 0; 
    End; 
 
    --1.查找包含预约时间的节假日 
    Begin 
      Select 允许预约, 允许挂号 
      Into v_允许预约, v_允许挂号 
      From 法定假日表 A 
      Where a.性质 = 0 And 预约时间_In Between a.开始日期 And a.终止日期 + 1 - 1 / 24 / 60 / 60 And Rownum < 2; 
    Exception 
      When Others Then 
        Return '0|正常预约。'; 
    End; 
 
    --假日控制状态：0-不上班;1-上班且开放预约;2-上班但不开放预约;3-受节假日设置控制 
    If Nvl(n_假日控制状态, 0) = 0 Then 
      --不上班的肯定是不能预约的 
      Return '5|当前预约时间在法定节假日时间范围内，不上班。'; 
    Elsif Nvl(n_假日控制状态, 0) = 1 Then 
      Return '0|正常预约。'; 
    Elsif Nvl(n_假日控制状态, 0) = 2 Then 
      --在节假日时间范围内，则不能预约 
      Return '6|当前预约时间在法定节假日时间范围内，禁止预约。'; 
    Elsif Nvl(n_假日控制状态, 0) = 3 Then 
      --没有"允许挂号"就一定没有"允许预约" 
      If v_允许挂号 Is Not Null Then 
        --2.检查是否有包含预约时间的"允许挂号" 
        Select Max(1) 
        Into n_Count 
        From Table(f_Str2list(v_允许挂号, ';')) 
        Where 预约时间_In Between To_Date(Column_Value, 'yyyy-mm-dd') And 
              To_Date(Column_Value, 'yyyy-mm-dd') + 1 - 1 / 24 / 60 / 60 And Rownum < 2; 
 
        If Nvl(n_Count, 0) <> 0 Then 
          --3.检查是否有包含预约时间的"允许预约" 
          Select Max(1) 
          Into n_Count 
          From Table(f_Str2list(v_允许预约, ';')) 
          Where 预约时间_In Between To_Date(Column_Value, 'yyyy-mm-dd') And 
                To_Date(Column_Value, 'yyyy-mm-dd') + 1 - 1 / 24 / 60 / 60 And Rownum < 2; 
 
          If Nvl(n_Count, 0) = 0 Then 
            --不在"允许预约"时间范围内，则不能预约 
            Return '7|当前预约时间在法定节假日不允许预约的时间范围内，不能预约。'; 
          Else 
            Return '0|正常预约。'; 
          End If; 
        Else 
          Return '8|当前预约时间在法定节假日不允许挂号的时间范围内，不能预约。'; 
        End If; 
      Else 
        --没有设置"允许挂号"/"允许预约"表示停诊，肯定不能预约 
        Return '9|当前预约时间在法定节假日时间范围内，已停诊，不能预约。'; 
      End If; 
    End If; 
  Else 
    --分时段 
    If Nvl(序号_In, 0) <> 0 Then 
      Begin 
        Select Nvl(是否预约, 0), Nvl(挂号状态, 0) 
        Into n_是否预约, n_挂号状态 
        From 临床出诊序号控制 
        Where 记录id = 记录id_In And 序号 = 序号_In; 
      Exception 
        When Others Then 
          Return '16|当前选择的序号不可用。'; 
      End; 
      If n_是否预约 = 0 Then 
        Return '14|当前选择的序号禁止预约。'; 
      End If; 
      If n_挂号状态 <> 0 Then 
        Return '15|当前选择的序号已经被使用。'; 
      End If; 
    End If; 
    Return '0|正常预约。'; 
  End If; 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zl_Fun_Get临床出诊预约状态;
/

