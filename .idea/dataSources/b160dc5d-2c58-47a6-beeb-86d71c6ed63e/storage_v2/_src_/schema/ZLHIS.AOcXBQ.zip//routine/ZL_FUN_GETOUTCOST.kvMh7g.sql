create Function Zl_FUN_Getoutcost 
( 
  药品id_In 药品库存.药品id%Type, 
  批次_In   药品库存.批次%Type, 
  库房id_In 药品库存.库房id%Type 
) Return Number Is 
  n_平均成本价 药品库存.平均成本价%Type; 
Begin 
  Begin 
    Select 平均成本价 
    Into n_平均成本价 
    From 药品库存 
    Where  性质=1 and 药品id = 药品id_In And Nvl(批次, 0) = Nvl(批次_In, 0) And 库房id = 库房id_In; 
 
    if n_平均成本价 is null then 
      Select 成本价 
      Into n_平均成本价 
      From (Select 成本价 
             From 药品规格 
             Where 药品id = 药品id_In 
             Union All 
             Select 成本价 From 材料特性 Where 材料id = 药品id_In); 
    end if; 
  Exception 
    When Others Then 
      Select 成本价 
      Into n_平均成本价 
      From (Select 成本价 
             From 药品规格 
             Where 药品id = 药品id_In 
             Union All 
             Select 成本价 From 材料特性 Where 材料id = 药品id_In); 
  End; 
  Return(n_平均成本价); 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zl_FUN_Getoutcost;
/

