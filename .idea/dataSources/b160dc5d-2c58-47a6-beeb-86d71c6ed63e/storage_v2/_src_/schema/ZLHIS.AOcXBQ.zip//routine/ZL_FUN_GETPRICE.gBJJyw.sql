create Function Zl_Fun_Getprice 
( 
  药品id_In     In 药品库存.药品id%Type, 
  库房id_In     In 药品库存.库房id%Type, 
  总出库数量_In In 药品库存.实际数量%Type, 
  备货材料_In   In Number := 0, 
  备货批次_In   In Number := Null 
) Return Varchar2 Is 
  ---------------------------------- 
  --功能：根据传过来的参数返回出库药品、卫材的售价|原售价|成本价|剩余数量，中间用“|”隔断；剩余数量等于0表示数量足够，大于0则表示数量不够 
  --规则： 
  --      1、循环游标判断总出库数量与游标中每条记录数量是否充足，如果充足就是总数量，不充足挨个遍历直到数量直到遍历完并退出 
  --      2、售价计算方式：定价取收费价目表现价，时价取药品库存表中零售价，取到的售价为平均价格 
  --      3、成本价计算方式：库房等于0，则表示没有明确库房或者发药分离模式，那么成本价直接取规格里面价格，如果有库房id，则取药品库存表中平均成本价 
  --参数： 
  --      药品id_In：药品id、卫材id 
  --      库房id_In：发药库房 
  --      总出库数量_In；总出库数量 
  --      备货材料_In：只有高值卫材才需要传入，非0表示是高值卫材 
  --      备货材料批次_In：只有高值卫材才需要传入，非空表示是高值卫材的批次 
  ----------------------------------- 
  n_Outmode    Number; 
  n_类别       Number; 
  n_分批       药品规格.药房分批%Type; 
  n_时价       收费项目目录.是否变价%Type; 
  v_名称       收费项目目录.名称%Type; 
  n_当前单价   收费价目.现价%Type; 
  n_标准单价   收费价目.现价%Type; 
  n_成本价     药品规格.成本价%Type; 
  n_当前成本价 药品规格.成本价%Type; 
  n_总金额     Number; 
  n_总成本     Number; 
  n_总出库数量 药品库存.实际数量%Type; 
  n_当前数量   药品库存.实际数量%Type; 
  n_数量       药品库存.实际数量%Type; 
 
  Err_Custom Exception; 
  v_Error Varchar2(255); 
 
  Cursor c_Stock Is 
    Select 库房id, 药品id, 批次, Nvl(可用数量, 0) As 可用数量, Nvl(实际数量, 0) As 实际数量, Nvl(实际金额, 0) As 实际金额, Nvl(实际差价, 0) As 实际差价, 零售价, 
           Nvl(平均成本价, 0) As 平均成本价 
    From 药品库存 
    Where 药品id = 药品id_In And 库房id = 库房id_In And 性质 = 1 And Nvl(可用数量, 0) > 0 And 
          Decode(备货材料_In, 0, 0, Nvl(批次, 0)) = Decode(备货材料_In, 0, 0, Nvl(备货批次_In, 0)) And 
          (Nvl(批次, 0) = 0 Or 效期 Is Null Or 效期 > Trunc(Sysdate)) 
    Order By Decode(n_Outmode, 1, 效期, Null), Nvl(批次, 0); 
Begin 
  --药品分批出库方式 
  Select Zl_To_Number(Nvl(zl_GetSysParameter(150), 0)) Into n_Outmode From Dual; 
  --判断是药品还是卫材，0是卫材，1是药品，2是其他 
  Select Decode(类别, '4', 0, '5', 1, '6', 1, '7', 1, 2) As 类别 Into n_类别 From 收费项目目录 Where ID = 药品id_In; 
 
  If n_类别 = 2 Then 
    --只有药品和卫材才允许取值，其他不允许调用该函数 
    Raise Err_Custom; 
  End If; 
  --取基本信息 
  If n_类别 = 0 Then 
    --卫材 
    Select Nvl(a.在用分批, 0) As 分批, Nvl(b.是否变价, 0), b.名称, c.现价, a.成本价 
    Into n_分批, n_时价, v_名称, n_标准单价, n_成本价 
    From 材料特性 A, 收费项目目录 B, 收费价目 C 
    Where a.材料id = b.Id And b.Id = c.收费细目id And b.Id = 药品id_In And Sysdate Between c.执行日期 And c.终止日期; 
  Elsif n_类别 = 1 Then 
    --药品 
    Select Nvl(a.药房分批, 0) As 分批, Nvl(b.是否变价, 0), b.名称, c.现价, a.成本价 
    Into n_分批, n_时价, v_名称, n_标准单价, n_成本价 
    From 药品规格 A, 收费项目目录 B, 收费价目 C 
    Where a.药品id = b.Id And b.Id = c.收费细目id And b.Id = 药品id_In And Sysdate Between c.执行日期 And c.终止日期; 
  End If; 
 
  n_总出库数量 := 总出库数量_In; 
  n_总金额     := 0; 
  n_总成本     := 0; 
  n_数量       := 0; 
 
  If 库房id_In = 0 Then 
    --库房id等于0这种不确定库房的情况，随便显示一个价格给用户看 
    n_当前成本价 := n_成本价; 
    --售价,取售价库房id不为0的情况没有，随便取的一个价格 
    n_当前单价 := n_标准单价; 
    Return n_当前单价 || '|' || n_当前成本价 || '|' || n_总出库数量; 
  End If; 
 
  For r_Stock In c_Stock Loop 
    If n_分批 = 1 Or n_时价 = 1 Then 
      --对于不分批的时价只可能分解一次,分解不完上面判断了.它分解是为了计算单价. 
      --每次分解取小者,库存不够分解不完在上面判断. 
      If n_总出库数量 <= Nvl(r_Stock.可用数量, 0) Then 
        n_当前数量 := n_总出库数量; 
      Else 
        n_当前数量 := Nvl(r_Stock.可用数量, 0); 
      End If; 
 
      --售价 
      If n_时价 = 1 Then 
        If r_Stock.实际数量 <> 0 Then 
          n_当前单价 := Nvl(r_Stock.零售价, Nvl(r_Stock.实际金额 / r_Stock.实际数量, 0)); 
        Else 
          n_当前单价 := Nvl(r_Stock.零售价, n_标准单价); 
        End If; 
      Elsif n_分批 = 1 Then 
        n_当前单价 := n_标准单价; 
      End If; 
 
      --成本价 
      n_当前成本价 := r_Stock.平均成本价; 
 
    Else 
      --定价不分批 
      n_当前数量 := n_总出库数量; 
      --售价 
      n_当前单价 := n_标准单价; 
      --成本价 
      n_当前成本价 := r_Stock.平均成本价; 
    End If; 
 
    n_数量       := n_数量 + n_当前数量; 
    n_总出库数量 := n_总出库数量 - n_当前数量; 
    n_总金额     := n_总金额 + n_当前数量 * n_当前单价; 
    n_总成本     := n_总成本 + n_当前数量 * n_当前成本价; 
    If n_总出库数量 = 0 Then 
      Exit; 
    End If; 
  End Loop; 
 
  If n_数量 <> 0 Then 
    n_当前单价   := n_总金额 / n_数量; 
    n_当前成本价 := n_总成本 / n_数量; 
  Else 
    --无库存价格直接从收费价目取现价和直接从规格表取成本价 
    n_当前单价   := n_标准单价; 
    n_当前成本价 := n_成本价; 
    n_总出库数量 := 总出库数量_In; 
  End If; 
  Return n_当前单价 || '|' || n_当前成本价 || '|' || n_总出库数量; 
 
Exception 
  When Err_Custom Then 
    Return Null; 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zl_Fun_Getprice;
/

