create Function Zl_Fun_Getsignpar 
( 
  场合_In   Number, --0-门诊医嘱和病历；1-住院医生医嘱和病历；2-住院护士医嘱；3-医技医嘱和报告；4-护理记录和护理病历；5-药品发药；6-LIS;7-PACS; 
  部门id_In Number := 0 --不传入部门表示只判断场合是否启用,传入-1（抗菌药物审核时，如果判断是否分科室启用） 
) Return number Is 
  Result number; --返回0表示未启用，1表示启用 
  Cursor c_Sign Is 
    Select 部门id, 场合 From 电子签名启用部门 Where 场合 = 场合_In; 
  r_Sign c_Sign%Rowtype; 
 
  v_Par   Varchar2(100); 
  n_场合  Number(2); 
  b_Count Boolean := False; 
Begin 
  v_Par := Zl_Getsysparameter(25); 
  --先判断电子签名是否启用 
  If Not (v_Par Is Null Or v_Par = '0') Then 
    --判断场合是否启用 
    v_Par := Zl_Getsysparameter(26); 
    If v_Par Is Not Null Then 
      If 场合_In <= 1 Then 
        n_场合 := 场合_In + 1; 
      Else 
        n_场合 := 场合_In; 
      End If; 
      v_Par := Substr(v_Par, n_场合, 1); 
      If v_Par = '1' Then 
        If 部门id_In <> 0  Then 
          For r_Sign In c_Sign Loop 
            b_Count := True; 
            If r_Sign.部门id = 部门id_In Then 
              Return(1); 
              Exit; 
            End If; 
          End Loop; 
          If b_Count = False Then 
            --启用了场合，未启用任何部门则表示不按科室控制 
            Result := 1; 
          End If; 
        Else 
          --未传入部门，则只判断场合是否启用 
          Result := 1; 
        End If; 
      End If; 
    End If; 
  End If; 
  if Result is null then 
    Result:=0; 
  end if; 
  Return(Result); 
End Zl_Fun_Getsignpar;
/

