create Function Zl_Fun_Get输血执行登记(医嘱id_In In 病人医嘱记录.Id%Type) Return Varchar2 Is 
  n_Count 病人医嘱执行.本次数次%Type; 
  n_Boold Number; --是否用血库系统 
  v_Tmp   Varchar2(4000); 
  n_Bags  Number; --血库配血袋数 
  --功能：对 输血途径 医嘱执行登记 
  --参数：医嘱id_In 主医嘱ID 
  --返回：固定格式字符串， 登记一次所填写的数量，是否启用血库，血袋总数。例：0.33333<SPLIT>1<SPLIT>3 
  --说明：后台数据以5位小数四舍五入保存，界面提示和判断时要乘上血袋总数四舍五入取整进行比较 
Begin 
  Select Count(1) Into n_Boold From zlSystems Where 编号 = 2200; 
  If n_Boold = 1 Then 
    n_Boold := Nvl(zl_GetSysParameter(236), 0); 
  End If; 
  If n_Boold = 1 Then 
    v_Tmp := 'Select Zl_Get_输血执行次数(:1) as 数量 From Dual'; 
    Execute Immediate v_Tmp 
      Into n_Bags 
      Using 医嘱id_In; 
  End If; 
  If n_Bags Is Null Then 
    n_Count := 1; 
  Else 
    n_Count := Round(1 / n_Bags, 5); 
  End If; 
  v_Tmp := To_Char(n_Count, '0.99999') || '<SPLIT>' || Nvl(n_Boold, 0) || '<SPLIT>' || Nvl(n_Bags, 0); 
  Return v_Tmp; 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zl_Fun_Get输血执行登记;
/

