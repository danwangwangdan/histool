create Function Zl_Fun_InAccount( 
    zlBeginTime IN Date, 
    zlEndTime IN Date := sysdate, 
    v_IncomeItemID IN NUMBER := 0, 
    v_RequestDeptID IN NUMBER := 0, 
    v_StayDeptID IN NUMBER := 0, 
    v_ExecuteDeptID IN NUMBER := 0, 
    v_QuotaTax IN NUMBER:=100 
) 
    RETURN NUMBER 
AS 
    v_Return NUMBER := 0; 
Begin 
    SELECT ROUND(sum(实收金额)*v_QuotaTax/100,2) 
    INTO v_Return 
    FROM 住院费用记录 
    WHERE 登记时间 BETWEEN trunc(zlBeginTime) AND trunc(zlEndTime)+1-1/24/60/60 
        AND 门诊标志=2 AND 记帐费用=1 
        AND (收入项目id IN (SELECT ID FROM 收入项目 START WITH ID=v_IncomeItemID CONNECT BY PRIOR ID=上级id) OR v_IncomeItemID=0) 
        AND (开单部门id=v_RequestDeptID OR v_RequestDeptID=0) 
        AND (病人科室id=v_StayDeptID OR v_StayDeptID=0) 
        AND (执行部门id=v_ExecuteDeptID OR v_ExecuteDeptID=0); 
    v_Return:=NVL(v_Return,0); 
    RETURN (v_Return); 
End Zl_Fun_InAccount;
/

