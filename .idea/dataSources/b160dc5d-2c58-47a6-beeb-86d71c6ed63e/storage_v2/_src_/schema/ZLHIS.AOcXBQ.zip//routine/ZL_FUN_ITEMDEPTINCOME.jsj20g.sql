create Function Zl_Fun_ItemDeptIncome( 
    zlBeginTime IN Date, 
    zlEndTime IN Date := sysdate, 
    v_ExseItemID IN NUMBER := 0, 
    v_RequestDeptID IN NUMBER := 0, 
    v_StayDeptID IN NUMBER := 0, 
    v_ExecuteDeptID IN NUMBER := 0, 
    v_QuotaTax IN NUMBER:=100 
) 
    RETURN NUMBER 
AS 
    v_Return NUMBER := 0; 
Begin 
    SELECT ROUND(sum(实收金额)*v_QuotaTax/100,2) 
    INTO v_Return 
    FROM (Select 实收金额 FROM 门诊费用记录 
          WHERE 登记时间 BETWEEN trunc(zlBeginTime) AND trunc(zlEndTime)+1-1/24/60/60 
           AND (收费细目id=v_ExseItemID OR v_ExseItemID=0) 
           AND (开单部门id=v_RequestDeptID OR v_RequestDeptID=0) 
           AND (病人科室id=v_StayDeptID OR v_StayDeptID=0) 
           AND (执行部门id=v_ExecuteDeptID OR v_ExecuteDeptID=0) Union all 
          Select 实收金额 FROM 住院费用记录 
          WHERE 登记时间 BETWEEN trunc(zlBeginTime) AND trunc(zlEndTime)+1-1/24/60/60 
           AND (收费细目id=v_ExseItemID OR v_ExseItemID=0) 
           AND (开单部门id=v_RequestDeptID OR v_RequestDeptID=0) 
           AND (病人科室id=v_StayDeptID OR v_StayDeptID=0) 
           AND (执行部门id=v_ExecuteDeptID OR v_ExecuteDeptID=0) 
    ); 
    v_Return:=NVL(v_Return,0); 
    RETURN (v_Return); 
End Zl_Fun_ItemDeptIncome;
/

