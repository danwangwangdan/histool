create FUNCTION Zl_Fun_MediOtherOut ( 
    zlBeginTime IN Date, 
    zlEndTime IN Date := sysdate, 
    v_DataKind IN NUMBER := 1, 
    v_MediKind IN NUMBER := 0, 
    v_OutRoomID IN NUMBER := 0, 
    v_OutKindID IN NUMBER := 0 
) 
    RETURN NUMBER 
AS 
    v_Return NUMBER := 0; 
Begin 
    SELECT decode(v_DataKind,1,sum(零售金额),2,sum(成本金额),3,sum(差价),0) 
    INTO v_Return 
    FROM 药品收发记录 D,药品目录 L,药品信息 I 
    WHERE D.药品id=L.药品id AND L.药名id=I.药名id 
        AND D.审核日期 BETWEEN trunc(zlBeginTime) AND trunc(zlEndTime)+1-1/24/60/60 
        AND D.单据=11 
        AND (D.库房id+0=v_OutRoomID OR v_OutRoomID=0) 
        AND (D.入出类别id+0=v_OutKindID OR v_OutKindID=0) 
        AND (v_MediKind=0 
            OR I.材质分类='西成药' AND v_MediKind=1 
            OR I.材质分类='中草药' AND v_MediKind=2 
            OR I.材质分类='中成药' AND v_MediKind=3); 
    v_Return:=NVL(v_Return,0); 
    RETURN (v_Return); 
End Zl_Fun_MediOtherOut;
/

