create FUNCTION Zl_Fun_MediPayout ( 
    zlBeginTime IN Date, 
    zlEndTime IN Date := sysdate, 
    v_ProviderID IN NUMBER := 0, 
    v_PayMode IN VARCHAR2 := '', 
    v_PayKind IN NUMBER := 0 
) 
    RETURN NUMBER 
AS 
    v_Return NUMBER := 0; 
Begin 
    SELECT sum(金额) 
    INTO v_Return 
    FROM 付款记录 
    WHERE 审核日期 BETWEEN trunc(zlBeginTime) AND trunc(zlEndTime)+1-1/24/60/60 
        AND (单位id+0=v_ProviderID OR v_ProviderID=0) 
        AND (结算方式=v_PayMode OR v_PayMode is null) 
        AND (v_PayKind=0 
            OR 预付款=0 AND v_PayKind=1 
            OR 预付款=1 AND v_PayKind=2); 
    v_Return:=NVL(v_Return,0); 
    RETURN (v_Return); 
End Zl_Fun_MediPayout;
/

