create FUNCTION Zl_Fun_MtlOtherIn ( 
    zlBeginTime		IN Date, 
    zlEndTime		IN Date := sysdate, 
    v_MtlType		IN NUMBER := 0, 
    v_InStoreRoomID	IN NUMBER := 0, 
    v_InOutID		IN NUMBER := 0 
) 
	RETURN NUMBER 
AS 
	v_Return NUMBER := 0; 
BEGIN 
    SELECT sum(nvl(D.金额,0)) INTO v_Return 
    FROM 物资收发记录 D,物资目录 L 
    WHERE D.物资id=L.id 
        AND D.审核日期 BETWEEN trunc(zlBeginTime) AND trunc(zlEndTime)+1-1/24/60/60 
        AND D.单据=2 
        AND (D.库房id+0=v_InStoreRoomID OR v_InStoreRoomID=0) 
        AND (D.入出类别id+0=v_InOutID OR v_InOutID=0) 
        AND (v_MtlType=0 
            OR L.物资类别='医用物资' AND v_MtlType=1 
            OR L.物资类别='普通物资' AND v_MtlType=2); 
    RETURN (v_Return); 
END Zl_Fun_MtlOtherIn;
/

