create Function Zl_Fun_Pati_Calorie 
( 
  病人id_In In 病人信息.病人id%Type, 
  主页id_In In 病人信息.主页id%Type, 
  挂号id_In In 病人挂号记录.Id%Type 
) Return Varchar2 Is 
 
  --功能：通过病人信息，计算出病人的热量需要量 
  v_Return  Varchar2(500); 
  n_Sex     Number(1); 
  n_Age     Number(5); 
  n_Age_Var Number(10, 2); 
  n_High    Number(5); 
  n_Weight  Number(5); 
  n_Calorie Number(10); 
  n_Err     Number(1) := 1; 
  v_Tmp     Varchar2(500); 
 
  --获取年龄字符串的数值 
  Function Get_Age(年龄_In In Varchar2) Return Number Is 
    v_Tmp Varchar2(100) := ''; 
    N     Number(3) := 1; 
  Begin 
    Loop 
      If N > Length(年龄_In) Then 
        Exit; 
      End If; 
      If Regexp_Like(Substr(年龄_In, N, 1), '[0-9]') Then 
        v_Tmp := v_Tmp || Substr(年龄_In, N, 1); 
      Else 
        Exit; 
      End If; 
      N := N + 1; 
    End Loop; 
 
    Return v_Tmp; 
  End; 
 
Begin 
 
  If 主页id_In Is Null And 挂号id_In Is Null Then 
    Return Null; 
  End If; 
 
  --性别 
  Begin 
    Select Decode(性别, '男', 1, '女', 2, Null), 年龄 Into n_Sex, v_Tmp From 病人信息 Where 病人id = 病人id_In; 
  Exception 
    When Others Then 
      Select Null, Null Into n_Sex, v_Tmp From Dual; 
  End; 
 
  --年龄 
  If v_Tmp Is Null Then 
    Select 0, 0, 0 Into n_Age, n_Age_Var, n_Err From Dual; 
  Else 
    If v_Tmp Like '%岁%' Then 
      n_Age     := Get_Age(v_Tmp); 
      n_Age_Var := 1; 
    Elsif v_Tmp Like '%月%' Then 
      n_Age     := Get_Age(v_Tmp); 
      n_Age_Var := Round(1 / 12, 2); 
    Elsif v_Tmp Like '%天%' Or v_Tmp Like '%日%' Then 
      n_Age     := Get_Age(v_Tmp); 
      n_Age_Var := Round(1 / 365, 2); 
    Elsif v_Tmp Like '%小时%' Or v_Tmp Like '%分%' Then 
      n_Age     := 1; 
      n_Age_Var := Round(1 / 365, 2); 
    Else 
      Select 0, 0, 0 Into n_Age, n_Age_Var, n_Err From Dual; 
    End If; 
  End If; 
 
  If 主页id_In Is Not Null Then 
    --住院 
 
    --身高 
    Begin 
      Select 身高, 体重 Into n_High, n_Weight From 病案主页 Where 病人id = 病人id_In And 主页id = 主页id_In; 
      If Nvl(n_High, 0) = 0 Or Nvl(n_Weight, 0) = 0 Then 
        n_Err := 0; 
      End If; 
    Exception 
      When Others Then 
        Select 0, 0, 0 Into n_High, n_Weight, n_Err From Dual; 
    End; 
 
  Else 
    --门诊 
 
    --身高 
    Begin 
      Select b.记录内容 
      Into n_High 
      From 病人护理记录 A, 病人护理内容 B 
      Where a.Id = b.记录id And a.病人id = 病人id_In And a.主页id = 挂号id_In And a.病人来源 = 1 And b.项目名称 = '身高'; 
    Exception 
      When Others Then 
        Select 0, 0 Into n_High, n_Err From Dual; 
    End; 
 
    --体重 
    Begin 
      Select b.记录内容 
      Into n_Weight 
      From 病人护理记录 A, 病人护理内容 B 
      Where a.Id = b.记录id And a.病人id = 病人id_In And a.主页id = 挂号id_In And a.病人来源 = 1 And b.项目名称 = '体重'; 
    Exception 
      When Others Then 
        Select 0, 0 Into n_Weight, n_Err From Dual; 
    End; 
 
  End If; 
 
  --计算需要量 
  Select Nvl(n_High, 0), Nvl(n_Weight, 0) Into n_High, n_Weight From Dual; 
  If n_Sex = 1 Then 
    n_Calorie := 66.5 + 13.8 * n_Weight + 5.0 * n_High - 6.8 * n_Age * n_Age_Var; 
    If n_Err = 0 Then 
      v_Return := '66.5 + 13.8 * ' || n_Weight || 'KG + 5.0 * ' || n_High || 'CM - 6.8 * ' || 
                  Round(n_Age * n_Age_Var, 2) || '岁 = 异常'; 
    Else 
      v_Return := '66.5 + 13.8 * ' || n_Weight || 'KG + 5.0 * ' || n_High || 'CM - 6.8 * ' || 
                  Round(n_Age * n_Age_Var, 2) || '岁 = ' || n_Calorie; 
    End If; 
  Else 
    n_Calorie := 655.1 + 9.6 * n_Weight + 1.8 * n_High - 4.7 * n_Age * n_Age_Var; 
    If n_Err = 0 Then 
      v_Return := '655.1 + 9.6 * ' || n_Weight || 'KG + 1.8 * ' || n_High || 'CM - 4.7 * ' || 
                  Round(n_Age * n_Age_Var, 2) || '岁 = 异常'; 
    Else 
      v_Return := '655.1 + 9.6 * ' || n_Weight || 'KG + 1.8 * ' || n_High || 'CM - 4.7 * ' || 
                  Round(n_Age * n_Age_Var, 2) || '岁 = ' || n_Calorie; 
    End If; 
  End If; 
 
  Return v_Return; 
 
End Zl_Fun_Pati_Calorie;
/

