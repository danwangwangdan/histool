create Function zl_fun_PIVACustom 
( 
  配药id_In     In 输液配药记录.ID%type 
) Return Varchar2 Is 
  ---------------------------------- 
  --功能：静配配药时，根据药品的配药类型，使用单量，给药途径确定收费的材料id； 
  --返回： 
  --      收费项目id1m收取数次；收费项目id2,收费数次   例如：12,1;13,2  即要收费项目id为12的收取一次费用，收费项目id为13的收取两次费用 
  ----------------------------------- 
  v_Temp   varchar2(500); 
  Err_Custom Exception; 
  v_Error Varchar2(255); 
  v_IsSpecial varchar2(20); 
Begin 
  v_Temp:=''; 
  for r_item in (select distinct A.药品id,A.配药类型,F.名称 给药途径,D.单量,G.剂量系数 from 输液药品属性 A,输液配药记录 B,输液配药内容 C,药品收发记录 D,病人医嘱记录 E,诊疗项目目录 F,药品规格 G where B.医嘱id=E.id and E.诊疗项目id=F.id and B.Id=C.记录ID and C.收发ID=D.ID and D.药品ID=A.药品ID and D.药品ID=G.药品ID and 
    B.Id= 配药id_In) loop 
    --判断是否为胰岛素 
    if r_item.配药类型='胰岛素' then 
      --1ml注射器,收费数次 
      v_IsSpecial:=''; 
    end if; 
 
    if r_item.配药类型='肿瘤药' then 
      --根据给药途径判断 
       if  r_item.给药途径='泵注' then 
         --60ml注射器,收费数次 
         v_Temp:=''; 
       else 
         --20ml注射器,收费数次 
          v_Temp:=''; 
       end if; 
       exit; 
    end if; 
 
    if r_item.配药类型='营养液' then 
       --各个收费项目分别连接 
       v_Temp:=''; 
 
       exit; 
    end if; 
 
    --判断特殊药品；找出对应的收费id 
    if  r_item.药品id='1' then 
      --60ml注射器,收费数次 
      v_Temp:=''; 
    elsif v_Temp is null then 
      --20ml注射器,收费数次 
      v_Temp:=''; 
    end if; 
 
  end loop; 
  Return v_Temp || v_IsSpecial; 
Exception 
  When Err_Custom Then 
    Return Null; 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End zl_fun_PIVACustom;
/

