create Function Zl_Fun_Regcustomname Return Varchar2 
  --    功能：挂号附加费名称用户自定义函数 
  --    返回: 格式:功能名称|收费细目ID1,收费细目ID2...返回NULL不加载菜单 
 Is 
Begin 
  Return Null; 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zl_Fun_Regcustomname;
/

