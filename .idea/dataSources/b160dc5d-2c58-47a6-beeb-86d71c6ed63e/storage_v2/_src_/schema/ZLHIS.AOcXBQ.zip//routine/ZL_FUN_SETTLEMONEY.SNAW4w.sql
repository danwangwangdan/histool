create FUNCTION Zl_Fun_SettleMoney( 
    zlBeginTime IN Date, 
    zlEndTime IN Date := sysdate, 
    v_Tollman IN VARCHAR2 := '', 
    v_PayMode IN VARCHAR2 := '' 
) 
    RETURN NUMBER 
AS 
    v_Return NUMBER := 0; 
Begin 
    IF v_PayMode='冲预交' THEN 
        SELECT sum(冲预交) 
        INTO v_Return 
        FROM 病人预交记录 
        WHERE 记录性质 IN (2,12) 
            AND 结帐ID IN ( 
                SELECT ID 
                FROM 病人结帐记录 
                WHERE 收费时间 BETWEEN trunc(zlBeginTime) AND trunc(zlEndTime)+1-1/24/60/60 
                    AND (操作员姓名=v_Tollman OR v_Tollman is null)); 
    ELSE 
        SELECT sum(冲预交) 
        INTO v_Return 
        FROM 病人预交记录 
        WHERE 收款时间 BETWEEN trunc(zlBeginTime) AND trunc(zlEndTime)+1-1/24/60/60 
            AND 记录性质 IN (2,12) 
            AND (操作员姓名=v_Tollman OR v_Tollman is null) 
            AND (结算方式=v_PayMode OR v_PayMode is null); 
    End IF; 
    v_Return:=NVL(v_Return,0); 
    RETURN (v_Return); 
End Zl_Fun_SettleMoney;
/

