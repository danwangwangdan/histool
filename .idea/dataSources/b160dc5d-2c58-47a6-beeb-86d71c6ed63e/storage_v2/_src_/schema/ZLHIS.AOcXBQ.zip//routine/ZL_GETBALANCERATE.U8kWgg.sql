create Function Zl_Getbalancerate 
( 
  v_库房id 药品收发记录.库房id%Type, 
  v_药品id 药品收发记录.药品id%Type, 
  v_批次   药品收发记录.批次%Type, 
  v_零售价 药品收发记录.零售价%Type 
) Return Number Is 
  v_实际金额 药品收发记录.零售金额%Type; 
  v_实际差价 药品收发记录.差价%Type; 
  v_成本价   药品收发记录.成本价%Type; 
  v_差价率   药品收发记录.差价%Type; 
  v_实际数量 药品库存.实际数量%Type; 
  n_Nostock  Number(1); 
Begin 
  n_Nostock := 0; 
 
  --取出库库房的差价率 
  Begin 
    Select Nvl(实际数量, 0), Nvl(实际金额, 0) 实际金额, Nvl(实际差价, 0) 实际差价, Nvl(上次采购价, 0) As 成本价 
    Into v_实际数量, v_实际金额, v_实际差价, v_成本价 
    From 药品库存 
    Where 库房id + 0 = v_库房id And 药品id = v_药品id And 性质 = 1 And Nvl(批次, 0) = v_批次; 
  Exception 
    When Others Then 
      v_实际数量 := 0; 
      v_实际金额 := 0; 
      v_实际差价 := 0; 
      v_成本价   := 0; 
      n_Nostock  := 1; 
  End; 
 
  If v_实际数量 = 0 Or v_实际金额 = 0 Then 
    --库存数量或库存金额为0时，按库存中的上次采购价，规格中的成本价，规格中的差价率的顺序计算差价率 
    If n_Nostock = 1 Or v_成本价 < 0 Or (n_Nostock = 0 And v_实际数量 = 0) Then 
      Begin 
        Select Nvl(成本价, 0), Nvl(指导差价率, 0) / 100 Into v_成本价, v_差价率 From 药品规格 Where 药品id = v_药品id; 
      Exception 
        When Others Then 
          v_成本价 := 0; 
          v_差价率 := 0.1304348; 
      End; 
    End If; 
   
    If v_成本价 >= 0 Then 
      If v_零售价 <> 0 Then 
        v_差价率 := (v_零售价 - v_成本价) / v_零售价; 
      End If; 
    End If; 
  Else 
    --库存数量或库存金额不为0时，按出库库房的当前差价率作为出库差价率 
    v_差价率 := v_实际差价 / v_实际金额; 
  End If; 
 
  Return(v_差价率); 
End;
/

