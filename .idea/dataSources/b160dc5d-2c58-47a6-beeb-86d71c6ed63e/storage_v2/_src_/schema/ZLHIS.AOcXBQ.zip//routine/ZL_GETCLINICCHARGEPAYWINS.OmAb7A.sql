create Function Zl_Getclinicchargepaywins(Nos_In Varchar2) 
--功能:获取本次收费的发药窗口 
  --返回:执行部门ID|发药窗口;... 
 Return Varchar2 Is 
  v_发药窗口 Varchar2(4000); 
  v_Paywin   Varchar2(100); 
  Function Getnotpaydrugwinds 
  ( 
    病人id_In 门诊费用记录.病人id%Type, 
    药房id_In 门诊费用记录.执行部门id%Type 
  ) Return Varchar2 Is 
    v_Temp Varchar2(100); 
  Begin 
    For c_发药窗口 In (Select 发药窗口 
                   From 未发药品记录 
                   Where 单据 = 8 And 发药窗口 Is Not Null And 病人id = 病人id_In And 库房id = 药房id_In 
                   Order By 已收费 Desc, 填制日期 Desc) Loop 
      v_Temp := c_发药窗口.发药窗口; 
      Exit; 
    End Loop; 
    Return v_Temp; 
  End; 
 
  Function Getdefaultpaydrugwinds 
  ( 
    收费类别_In 门诊费用记录.收费类别%Type, 
    药房id_In   门诊费用记录.执行部门id%Type 
  ) Return Varchar2 Is 
    v_西窗   Varchar2(100); 
    n_西药房 Number(18); 
 
    v_成窗   Varchar2(100); 
    n_成药房 Number(18); 
    v_中窗   Varchar2(100); 
    n_中药房 Number(18); 
    v_Temp   Varchar2(1000); 
 
    n_药房id    Number(18); 
    v_Split_Str Varchar2(4000); 
  Begin 
    v_Temp := Null; 
    If 收费类别_In = '5' Then 
      v_西窗   := zl_GetSysParameter(11, 1121); 
      n_西药房 := To_Number(zl_GetSysParameter(6, 1121)); 
      If Instr(v_西窗, ':') > 0 Then 
        --旧数据没有存药房ID 
        v_Temp := v_西窗; 
      Elsif n_西药房 > 0 And Nvl(v_西窗, '-') <> '-' Then 
        v_Temp := n_西药房 || ':' || v_西窗; 
 
      End If; 
    Elsif 收费类别_In = '6' Then 
      v_成窗   := zl_GetSysParameter(12, 1121); 
      n_成药房 := To_Number(zl_GetSysParameter(8, 1121)); 
      If Instr(v_成窗, ':') > 0 Then 
        v_Temp := v_成窗; 
      Elsif n_成药房 > 0 And Nvl(v_成窗, '-') <> '-' Then 
        v_Temp := n_成药房 || ':' || v_成窗; 
      End If; 
    Elsif 收费类别_In = '7' Then 
      v_中窗   := zl_GetSysParameter(10, 1121); 
      n_中药房 := To_Number(zl_GetSysParameter(7, 1121)); 
      If Instr(v_中窗, ':') > 0 Then 
        v_Temp := v_中窗; 
      Elsif n_中药房 > 0 And Nvl(v_中窗, '-') <> '-' Then 
        v_Temp := n_中药房 || ':' || v_中窗; 
      End If; 
    Else 
      Return Null; 
    End If; 
 
    If v_Temp Is Null Then 
      Return Null; 
    End If; 
 
    --发药窗口格式:"药房ID:发药窗口,药房ID:发药窗口" 
    v_Split_Str := v_Temp || ','; 
    While v_Split_Str Is Not Null Loop 
      v_Temp := Substr(v_Split_Str, 1, Instr(v_Split_Str, ',') - 1); 
 
      n_药房id := To_Number(Substr(v_Temp, 1, Instr(v_Temp, ':') - 1)); 
      v_Temp   := Substr(v_Temp, Instr(v_Temp, ':') + 1); 
 
      If n_药房id = 药房id_In Then 
        Return v_Temp; 
      End If; 
      v_Split_Str := Substr(v_Split_Str, Instr(v_Split_Str, ',') + 1); 
    End Loop; 
    Return Null; 
  End; 
 
Begin 
 
  v_发药窗口 := Null; 
  For c_发药窗口 In (Select Distinct 执行部门id, 收费类别, 发药窗口, 病人id 
                 From 门诊费用记录 A 
                 Where 记录状态 = 0 And a.记录性质 = 1 And a.收费类别 In ('5', '6', '7') And 
                       NO In (Select Column_Value From Table(f_Str2list(Nos_In)))) Loop 
 
    If Instr(';' || Nvl(v_发药窗口, '-'), ';' || c_发药窗口.执行部门id || '|') = 0 Then 
      --a.存在未发药的，先以未发药的为准 
      v_Paywin := Getnotpaydrugwinds(c_发药窗口.病人id, c_发药窗口.执行部门id); 
      If v_Paywin Is Null Then 
        v_Paywin := c_发药窗口.发药窗口; 
      End If; 
      If v_Paywin Is Null Then 
        --b.获取缺省的发药窗口 
        v_Paywin := Getdefaultpaydrugwinds(c_发药窗口.收费类别, c_发药窗口.执行部门id); 
      End If; 
      If v_Paywin Is Null Then 
        --b.根据闲忙或平均方式获取发药窗口 
        v_Paywin := Zl_Get发药窗口(c_发药窗口.执行部门id); 
      End If; 
      v_发药窗口 := v_发药窗口 || ';' || c_发药窗口.执行部门id || '|' || v_Paywin; 
    End If; 
  End Loop; 
 
  Return v_发药窗口; 
 
Exception 
  When Others Then 
    Return v_发药窗口; 
End Zl_Getclinicchargepaywins;
/

