create Function Zl_Get床位占用数 
( 
  分类_In   Number := 0, 
  科室id_In 住院日报.科室id%Type, 
  日期_In   住院日报.日期%Type 
) 
-------------------------------------------------------------------------------------------------------------------------------------- 
  --功能:Zl_Get床位占用数 
  --入参: 
  --      分类_in:0--获取共用病区的床位数 1--获取家庭病床数 
  --      科室id_In:科室值 
  --      日期_In ：统计输入日期 可能是yyyy-mm-dd 的格式 
  --   共用病区的床位数参看例子： Select *  FROM 病人变动记录 WHERE 科室id = 57 AND trunc(开始时间) >= trunc(to_date('2006-11-21','yyyy-mm-dd')) 
  --                              AND trunc(终止时间) <= trunc(to_date('2006-11-21','yyyy-mm-dd'))  And  病区id = 57 and 科室id <> 病区id 
  --   家庭病床数参看例子：Select Distinct trunc(开始时间) as 日期,病人id, 主页id, 科室id From 病人变动记录 
  --                               Where 开始原因 Not In (1,5,9,10) And 床位等级id Is Null And 床号 Is Null  and 科室id = 57 AND 
  --                              trunc(开始时间) >= trunc(to_date('2006-11-21','yyyy-mm-dd')) 
  --                              AND trunc(终止时间) <= trunc(to_date('2006-11-21','yyyy-mm-dd')) 
  --                       注意：bln提取24小时内出院病人参数 
  -- 
  --返回:根据科室id_In，返回科室占用共用病区的床位数或者家庭病床数 
  -------------------------------------------------------------------------------------------------------------------------------------- 
 Return Number Is 
  n_床位占用数 Number; 
Begin 
  n_床位占用数 := 0; 
  If 分类_In = 0 Then 
    --Select Count(病区id) 
    --Into n_床位占用数 
    --From 病人变动记录 
    --Where 科室id = 科室id_In And Trunc(开始时间) = Trunc(日期_In) And Trunc(终止时间) <= Trunc(日期_In) and 科室id <> 病区id And 病区id = 
    n_床位占用数 := 0; 
  End If; 
  If 分类_In = 1 Then 
    n_床位占用数 := 0; 
    --Select Sum(家庭病床数) 
    --Into n_床位占用数 
    --From (Select Distinct Trunc(开始时间) As 日期, 病人id, 主页id, 科室id, 1 As 家庭病床数 
    --       From 病人变动记录 
    --       Where tRunc(开始时间) = Trunc(日期_In) And Trunc(终止时间) <= Trunc(日期_In) And 开始原因 Not In (1, 5, 9, 10) And 
    --             床位等级id Is Null And 床号 Is Null) A, 病案主页 B 
    --Where A.病人id = B.病人id And A.主页id = B.主页id And Nvl(B.主页id, 0) <> 0 
  End If; 
  Return n_床位占用数; 
Exception 
  When Others Then 
    Return n_床位占用数; 
End Zl_Get床位占用数;
/

