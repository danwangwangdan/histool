create Function Zl_Get发药窗口(药房id_In 药品库存.库房id%Type) 
--功能:获取发药窗口 
  --返回:返回发药窗口 
 Return Varchar2 Is 
  Pragma Autonomous_Transaction; 
 
  v_发药窗口 Varchar2(200); 
  n_Assign   Number(5); 
  n_Temp     Number(18); 
  v_编码     发药窗口.编码%Type; 
 
Begin 
  --n_Assign:0-忙闲优化方式;1-平均分配方式 
  n_Assign := Nvl(zl_GetSysParameter(19), 0); 
  If n_Assign = 0 Then 
    --0-忙闲优化方式 
    Begin 
      Select 发药窗口 
      Into v_发药窗口 
      From (Select 发药窗口, Sum(Num) As Num 
             From (Select 名称 As 发药窗口, 0 As Num 
                    From 发药窗口 
                    Where 上班否 = 1 And Nvl(专家, 0) = 0 And 药房id = 药房id_In 
                    Union 
                    Select 发药窗口, Count(发药窗口) As Num 
                    From 未发药品记录 A 
                    Where 填制日期 Between Trunc(Sysdate) And Trunc(Sysdate + 1) - 1 / 24 / 60 / 60 And 
                          发药窗口 In (Select 名称 From 发药窗口 Where 上班否 = 1 And Nvl(专家, 0) = 0 And 药房id = 药房id_In) And Not Exists 
                     (Select 1 
                           From 门诊费用记录 B 
                           Where b.No = a.No And b.记录性质 = Decode(a.单据, 8, 1, 24, 1, 0) And Nvl(b.费用状态, 0) = 1) 
                    Group By 发药窗口) 
             Group By 发药窗口 
             Order By Num) 
      Where Rownum <= 1; 
    Exception 
      When Others Then 
        v_发药窗口 := Null; 
    End; 
    Return v_发药窗口; 
  End If; 
  --1-平均分配方式 
 
  v_发药窗口 := Null; 
  v_编码     := Null; 
  n_Temp     := 0; 
  For c_窗口 In (Select 编码, 名称 As 发药窗口, Nvl(当前分配, 0) As 活动 
               From 发药窗口 
               Where 上班否 = 1 And Nvl(专家, 0) = 0 And 药房id = 药房id_In 
               Order By 编码) Loop 
    If v_编码 Is Null Then 
      v_编码     := c_窗口.编码; 
      v_发药窗口 := c_窗口.发药窗口; 
    End If; 
    If Nvl(c_窗口.活动, 0) = 1 Then 
      n_Temp := 1; 
    End If; 
    If n_Temp = 1 And Nvl(c_窗口.活动, 0) = 0 Then 
      v_发药窗口 := c_窗口.发药窗口; 
      v_编码     := c_窗口.编码; 
      Exit; 
    End If; 
  End Loop; 
  If v_编码 Is Not Null Then 
    Update 发药窗口 Set 当前分配 = Decode(编码, v_编码, 1, 0) Where 药房id = 药房id_In; 
    Commit; 
  End If; 
  Return v_发药窗口; 
Exception 
  When Others Then 
    Return v_发药窗口; 
End Zl_Get发药窗口;
/

