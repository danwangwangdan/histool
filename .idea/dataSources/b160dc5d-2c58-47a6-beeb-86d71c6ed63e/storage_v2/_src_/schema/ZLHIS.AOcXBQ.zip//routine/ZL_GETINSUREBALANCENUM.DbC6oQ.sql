create Function Zl_Getinsurebalancenum 
( 
  记录id_In In 保险结算记录.记录id%Type, 
  No_In     In 门诊费用记录.No%Type 
) Return Number Is 
  ------------------------------------------------------------------------------------------- 
  --功能:针对门诊收费按多单据一次结算分单据退费模式增加此过程， 
  --     用于获取单据对应保险结算记录的序号 
  --入参: 
  --      记录id_In - 收费结帐ID 
  --      NO_In - 单据号 
  --返回: 
  --      单据对应的保险结算记录的序号 
  --说明: 
  --      因为无法知道渠道人员是否会在"保险结算记录"中增加"NO"列， 
  --      也有可能增加列的列名不是"NO"，而是其它的，如"单据号"等。 
  --      所以，增加此函数由渠道人员自己定义，只要得到"序号"，就能确定单据与保险结算记录的对应关系。 
  --调用过程： 
  --      Zl_保险结算记录_作废 
  ------------------------------------------------------------------------------------------- 
  v_Sql  Varchar2(4000); 
  n_序号 Number(18); 
Begin 
  If No_In Is Null Then 
    Return Null; 
  End If; 
 
  v_Sql := 'Select Max(序号) From 保险结算记录 Where 记录ID = :1 And NO = :2 And Rownum < 2'; 
  Execute Immediate v_Sql 
    Into n_序号 
    Using 记录id_In, No_In; 
  Return n_序号; 
End Zl_Getinsurebalancenum;
/

