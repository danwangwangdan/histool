create Function Zl_Getmd5(p_Str Varchar2) Return Varchar2 Is 
Begin 
  If p_Str Is Null Then 
    Return Null; 
  Else 
    Return Utl_Raw.Cast_To_Raw(Dbms_Obfuscation_Toolkit.Md5(Input_String => p_Str)); 
  End If; 
End Zl_Getmd5;
/

