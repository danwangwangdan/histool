create Function ZL_GetNumber(strValue_IN varchar2) 
return number IS 
       v_temp varchar2(200) ; 
       v_return varchar2(200) ; 
       idx number :=1 ; 
Begin 
     WHILE(idx <= LENGTH(strValue_IN) ) LOOP 
         v_temp := SUBSTR(strValue_IN,idx,1) ; 
         IF( (ASCII(UPPER(v_temp)) >= 48 AND ASCII(UPPER(v_temp)) <= 57)) THEN 
             v_return := v_return||v_temp ; 
         End IF ; 
         idx := idx + 1 ; 
     End LOOP ; 
 
     return v_return ; 
Exception 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
End ZL_GetNumber;
/

