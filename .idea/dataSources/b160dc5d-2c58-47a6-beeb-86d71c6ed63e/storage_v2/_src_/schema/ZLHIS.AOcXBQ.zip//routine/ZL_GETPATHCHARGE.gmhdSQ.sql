create Function Zl_Getpathcharge 
( 
  病人id_In   病案主页.病人id%Type, --不确定病人时传入0 
  主页id_In   病案主页.主页id%Type, --不确定病人时传入0 
  路径id_In   临床路径项目.路径id%Type, 
  版本号_In   临床路径项目.版本号%Type, 
  阶段id_In   临床路径项目.阶段id%Type, --没有指定阶段时,根据当前天数来确定缺省的阶段 
  天数_In     病人路径执行.天数%Type, --当前阶段正在执行的天数 
  入院时间_In Date, --病人入院或入科时间,用于计算上次执行时间(频率为每n天m次时),不确定病人时传入当前系统时间 
  分支ID_In   临床路径项目.分支ID%Type := Null    --用于分支路径的费用估算 
) Return Number As 
  v_Error Varchar2(255); 
  Err_Custom Exception; 
 
  v_Tmp Varchar2(1000); 
  n_Tmp Number(8); 
 
  v_费别         病案主页.费别%Type; 
  n_实收金额     Number(16, 5); 
  n_应收金额     Number(16, 5); 
  n_主项金额     Number(16, 5); 
  n_实收合计     Number(16, 5); 
  n_计费总量     Number(16, 5); 
  n_总量         Number(16, 5); 
  n_汇总计算折扣 Number(1); 
  n_主收入id     Number(8); 
  n_次数         Number(8); 
  n_Day          Number(8); --当前天数的星期数 
  n_Lastday      Number(8); 
 
  l_采集方法 Boolean; 
  l_中药煎法 Boolean; 
  l_中药用法 Boolean; 
  l_给药途径 Boolean; 
  l_输血途径 Boolean; 
 
  v_Lasttype   诊疗项目目录.类别%Type; 
  n_Lastsum    路径医嘱内容.总给予量%Type; 
  n_Last相关id 路径医嘱内容.相关id%Type; 
  n_Lastid     路径医嘱内容.Id%Type; 
  n_Lastamount Number(8); 
  n_Last付数   Number(8); 
  l_Last煎法   Boolean; 
  l_Do         Boolean; 
  l_Firstday   Boolean; 
 
  n_阶段id     临床路径阶段.Id%Type; 
  n_前一阶段id 临床路径阶段.Id%Type; 
  l_Rate       t_Strlist; 
 
  --取药品相关信息(未明确规格时,取其中一个规格) 
  Cursor Mediinfo 
  ( 
    诊疗项目id_In Number, 
    收费细目id_In Number 
  ) Is 
    Select g.Id As 收费细目id, Nvl(f.剂量系数, 1) As 剂量系数, f.住院可否分零, Nvl(g.是否变价, 0) 是否变价, h.缺省价格, h.现价, g.屏蔽费别, h.收入项目id, 
           Nvl(h.附术收费率, 1) 附术收费率 
    From 药品规格 F, 收费项目目录 G, 收费价目 H 
    Where f.药名id = 诊疗项目id_In And f.药品id = Nvl(收费细目id_In, f.药品id) And f.药品id = g.Id And g.Id = h.收费细目id And 
          Sysdate Between h.执行日期 And Nvl(h.终止日期, Sysdate + 1) 
    Order By g.编码; 
  r_Medi Mediinfo%Rowtype; 
 
  --功能:获取指天数所属的缺省时间阶段ID 
  Function Getphaseid(n_Day Number) Return Number As 
    n_Id 临床路径阶段.Id%Type; 
  Begin 
    For R In (Select ID 
              From 临床路径阶段 
              Where n_Day Between Nvl(开始天数, n_Day) And Nvl(结束天数, Nvl(开始天数, n_Day)) And 路径id = 路径id_In And 版本号 = 版本号_In And NVL(分支ID,0)=NVL(分支ID_In,0) 
              Order By Decode(父id, Null, 0, 1), 序号) Loop 
      n_Id := r.Id; 
      Exit; 
    End Loop; 
    Return n_Id; 
  End Getphaseid; 
 
  --功能:获取指时间阶段(不能是分支)的前一时间阶段id 
  Function Getprephaseid(n_阶段id 临床路径阶段.Id%Type) Return Number As 
    n_Id 临床路径阶段.Id%Type; 
    n_父ID 临床路径阶段.父ID%Type; 
  Begin 
    Select Nvl(Max(父ID), 0) into n_父ID From 临床路径阶段 Where ID=n_阶段id; 
    If n_父ID = 0 Then 
      n_父ID:=n_阶段id; 
    End If; 
    Select Nvl(Max(b.Id), 0) 
    Into n_Id 
    From 临床路径阶段 A, 临床路径阶段 B 
    Where a.路径id = b.路径id And a.版本号 = b.版本号 And a.Id = n_父ID And b.序号 = a.序号 - 1 And b.父id Is Null; 
    Return n_Id; 
  End Getprephaseid; 
 
  --功能:获取指定路径项目的开始执行天数(入院时间为第一天) 
  Function Getitembeginday(n_路径项目id 临床路径项目.Id%Type) Return Number As 
    n_Preday Number(8); 
    n_Id     临床路径阶段.Id%Type; 
    n_Preid  临床路径阶段.Id%Type; 
    n_Tmp    Number(8); 
    n_Return Number(8); 
  Begin 
    n_Preday := 天数_In - 1; 
    If n_Preday = 0 Or n_前一阶段id = 0 Then 
      --当前是第一天或第一个阶段 
      n_Return := 1; 
    Else 
      n_Id    := n_阶段id; 
      n_Preid := n_前一阶段id; 
      Loop 
        --检查前一阶段是否有相同的路径项目 
        Select Nvl(Count(p.Id), 0) 
        Into n_Tmp 
        From 临床路径项目 T, 临床路径项目 P 
        Where t.路径id = p.路径id And t.版本号 = p.版本号 And t.项目内容 = p.项目内容 And t.Id = n_路径项目id And p.阶段id = n_Preid; 
        If n_Tmp = 0 Then 
          Exit; 
        End If; 
 
        n_Id := n_Preid; --如果有,继续往前找 
        Select Nvl(Max(b.Id), 0) 
        Into n_Preid 
        From 临床路径阶段 A, 临床路径阶段 B 
        Where a.路径id = b.路径id And a.版本号 = b.版本号 And a.Id = n_Id And b.序号 = a.序号 - 1; 
        If n_Preid = 0 Then 
          Exit; 
        End If; 
      End Loop; 
 
      Select Nvl(开始天数, 0) Into n_Tmp From 临床路径阶段 Where ID = n_Id; 
      If n_Tmp = 0 Then 
        --不定期间的两个阶段不可能连续,所以取前一个阶段的结束天数+1 
        Select Nvl(Nvl(结束天数, 开始天数), 0) + 1 Into n_Tmp From 临床路径阶段 Where ID = n_Preid; 
      End If; 
      If n_Tmp <= 1 Then 
        n_Return := 1; 
      Else 
        n_Return := n_Tmp; 
      End If; 
    End If; 
    Return n_Return; 
  End Getitembeginday; 
 
  --功能:获取时价药品的应收金额(因为是估算,不管出库模式  ) 
  Function Get时价药品金额 
  ( 
    n_总数量     In Number, 
    n_执行科室id In Number, 
    n_收费细目id In Number 
  ) Return Number As 
    n_总金额   Number(16, 5); 
    n_可用数量 Number(16, 5); 
    n_本次数量 Number(16, 5); 
  Begin 
    n_总金额   := 0; 
    n_可用数量 := n_总数量; 
    For D In (Select Nvl(可用数量, 0) As 库存, Nvl(零售价, Nvl(Decode(Nvl(实际数量, 0), 0, 0, 实际金额 / 实际数量), 0)) As 时价 
              From 药品库存 
              Where 库房id = n_执行科室id And 药品id = n_收费细目id And Nvl(可用数量, 0) > 0 And 性质 = 1 And 
                    (Nvl(批次, 0) = 0 Or 效期 Is Null Or 效期 > Trunc(Sysdate)) 
              Order By Nvl(批次, 0)) Loop 
      If n_可用数量 <= d.库存 Then 
        n_本次数量 := n_可用数量; 
      Else 
        n_本次数量 := d.库存; 
      End If; 
      n_总金额   := n_总金额 + n_本次数量 * d.时价; 
      n_可用数量 := n_可用数量 - n_本次数量; 
      If n_可用数量 = 0 Then 
        Exit; 
      End If; 
    End Loop; 
    Return n_总金额; 
  End Get时价药品金额; 
Begin 
  Select To_Char(Sysdate, 'D') - 1 Into n_Day From Dual; 
  If n_Day = 0 Then 
    n_Day := 7; 
  End If; 
 
  If Nvl(阶段id_In, 0) = 0 Then 
    n_阶段id := Getphaseid(天数_In); 
    n_Tmp    := n_阶段id; 
  Else 
    n_阶段id := 阶段id_In; --如果当前是分支,则求缺省分支 
    Select Nvl(父id, ID) Into n_Tmp From 临床路径阶段 Where ID = n_阶段id; 
  End If; 
  n_前一阶段id := Getprephaseid(n_Tmp); 
 
  l_Firstday := False; 
  Select Nvl(开始天数, 0) Into n_Tmp From 临床路径阶段 Where ID = n_阶段id; 
  If n_Tmp = 0 Then 
    --不定期间的两个阶段不可能连续,所以取前一个阶段的结束天数+1 
    Select Nvl(Nvl(结束天数, 开始天数), 0) + 1 Into n_Tmp From 临床路径阶段 Where ID = n_前一阶段id; 
  End If; 
  If n_Tmp = 天数_In Then 
    l_Firstday := True; 
  End If; 
 
  If Nvl(病人id_In, 0) <> 0 Then 
    Select 费别 Into v_费别 From 病案主页 Where 病人id = 病人id_In And 主页id = 主页id_In; 
  End If; 
  n_汇总计算折扣 := Nvl(Zl_Getsysparameter(93), 0); 
  n_实收合计     := 0; 
 
  --院外执行和无执行的叮嘱除外,不计价的除外 
  For R In (Select Nvl(c.相关id, c.Id) As 组id, Nvl(e.序号, c.序号) As 组号, c.序号, a.Id, c.相关id, c.期效, d.类别, c.诊疗项目id, c.收费细目id, 
                   c.执行科室id, c.标本部位, c.检查方法, Nvl(c.单次用量, 1) As 单次用量, c.总给予量, c.执行频次, c.频率次数, c.频率间隔, c.间隔单位, c.执行性质, 
                   c.时间方案, Nvl(d.计算规则, 0) As 计算规则, a.执行方式 
            From 临床路径项目 A, 临床路径医嘱 B, 路径医嘱内容 C, 诊疗项目目录 D, 路径医嘱内容 E 
            Where a.路径id = 路径id_In And a.版本号 = 版本号_In And NVL(a.分支id,0)=NVL(分支ID_In,0) And a.阶段id = n_阶段id And a.执行方式 Not In (0, 3) And a.Id = b.路径项目id And 
                  b.医嘱内容id = c.Id And c.诊疗项目id = d.Id And c.执行性质 Not In (0, 5) And d.计价性质 <> 1 And c.相关id = e.Id(+) 
            Order By a.项目序号, 组号, 组id, c.序号) Loop 
    l_Do := True; 
    If r.执行方式 = 2 Then 
      l_Do := l_Firstday; --至少执行一次的项目,仅在本阶段的第一天时计算 
    End If; 
    If l_Do Then 
      --1.计算总量 
      n_次数     := 0; 
      l_中药煎法 := False; 
      l_输血途径 := False; 
      l_中药用法 := False; 
      l_采集方法 := False; 
      l_给药途径 := False; 
      If r.类别 = 'E' And r.相关id Is Not Null And r.相关id = n_Last相关id Then 
        If v_Lasttype = '7' Then 
          l_中药煎法 := True; 
        Elsif v_Lasttype = 'K' Then 
          l_输血途径 := True; 
        End If; 
      Elsif r.类别 = 'E' And r.相关id Is Null And r.Id = n_Last相关id Then 
        If l_Last煎法 Or v_Lasttype = '7' Then 
          l_中药用法 := True; 
        Elsif v_Lasttype = 'C' Then 
          l_采集方法 := True; 
        Elsif v_Lasttype In ('5', '6') Then 
          l_给药途径 := True; 
        End If; 
      End If; 
      If r.类别 In ('5', '6', '7') Then 
        Open Mediinfo(r.诊疗项目id, r.收费细目id); 
        Fetch Mediinfo 
          Into r_Medi; 
        Close Mediinfo; 
      End If; 
 
      --长嘱 
      If r.期效 = 0 Then 
        --a.主要医嘱或一并采集的检验项目,或药品(因为是估算,不考虑动态分零对数量的影响) 
        If (r.相关id Is Null And Not l_采集方法 And Not l_中药用法 And Not l_给药途径) Or (r.相关id Is Not Null And r.类别 = 'C') Or 
           r.类别 In ('5', '6', '7') Then 
 
          If r.时间方案 Is Null And (Nvl(r.频率次数, 0) = 0 Or Nvl(r.频率间隔, 0) = 0 Or r.间隔单位 Is Null) Then 
            n_次数 := 1; --持续性项目 --因为是估算,简化为不考虑起止时间,按每天一次算 
          Else 
            Select Column_Value Bulk Collect Into l_Rate From Table(f_Str2list(r.时间方案, '-')); --执行频率为"可选频率"的项目 
            Case r.间隔单位 
              When '周' Then 
                --例:每周三次： 1/8:00-3/8:00-5/8:00或1/8-3/8-5/8 
                For I In 1 .. l_Rate.Count Loop 
                  If n_Day = Substr(l_Rate(I), 1, Instr(l_Rate(I), '/') - 1) Then 
                    n_次数 := n_次数 + 1; 
                  End If; 
                End Loop; 
              When '天' Then 
                --例:每天三次：8:00-12:00-16:00 或 8:12:16 
                If r.频率间隔 = 1 Then 
                  If 天数_In = 1 Then 
                    For I In 1 .. l_Rate.Count Loop 
                      If 入院时间_In <= To_Date(To_Char(入院时间_In, 'yyyy-mm-dd') || ' ' || l_Rate(I), 'yyyy-mm-dd hh24:mi') Then 
                        n_次数 := n_次数 + 1; --入院当天 
                      End If; 
                    End Loop; 
                  Else 
                    n_次数 := r.频率次数; 
                  End If; 
                Else 
                  n_Lastday := 天数_In - Getitembeginday(r.Id); --例:两天一次： 1/8 或 1/8:00 
                  For I In 1 .. l_Rate.Count Loop 
                    If n_Lastday = Substr(l_Rate(I), 1, Instr(l_Rate(I), '/') - 1) Then 
                      n_次数 := n_次数 + 1; 
                    End If; 
                  End Loop; 
                End If; 
              When '小时' Then 
                If 天数_In = 1 Then 
                  n_次数 := Trunc(Trunc((Trunc(入院时间_In + 1) - 入院时间_In) * 24) / r.频率间隔); --入院当天 
                Else 
                  n_次数 := Trunc(24 / r.频率间隔); 
                End If; 
              When '分钟' Then 
                If 天数_In = 1 Then 
                  n_次数 := Trunc(Trunc((Trunc(入院时间_In + 1) - 入院时间_In) * 24 * 60) / r.频率间隔); --入院当天 
                Else 
                  n_次数 := Trunc((24 * 60) / r.频率间隔); 
                End If; 
            End Case; 
          End If; 
          If r.类别 = '7' Then 
            n_次数 := r.总给予量 * n_次数; 
            If r_Medi.住院可否分零 = 0 Then 
              n_总量 := n_次数 * r.单次用量 / r_Medi.剂量系数; 
            Else 
              n_总量 := n_次数 * Ceil(r.单次用量 / r_Medi.剂量系数); --总给予量=付数 
            End If; 
            n_Last付数 := n_次数; --中药煎法、用法的总给予量为付数 
          Elsif r.类别 = '5' Or r.类别 = '6' Then 
            If r_Medi.住院可否分零 = 0 Then 
              n_总量 := n_次数 * r.单次用量 / r_Medi.剂量系数; --可分零 
            Elsif r_Medi.住院可否分零 = 1 Then 
              n_总量 := Ceil(n_次数 * r.单次用量 / r_Medi.剂量系数); --不分零 
            Elsif r_Medi.住院可否分零 = 2 Then 
              n_总量 := n_次数 * Ceil(r.单次用量 / r_Medi.剂量系数); --一次性 
            Else 
              n_总量 := Ceil(n_次数 * r.单次用量 / r_Medi.剂量系数); --可否分零<0  :n天内分零使用有效,计算太复杂,按不可分零处理 
            End If; 
          Else 
            If r.计算规则 = 1 Then 
              n_总量 := Ceil(r.单次用量 * n_次数); --取最大整数--取整计算，适用于可选频率的计量、计时、计次长期医嘱。 
            Else 
              n_总量 := r.单次用量 * n_次数; 
            End If; 
          End If; 
        Elsif l_中药煎法 Or l_中药用法 Then 
          n_总量 := n_Last付数; --b.中药煎法、用法为付数 
          n_次数 := n_Lastamount; 
        Elsif l_给药途径 Then 
          n_总量 := n_Lastamount; --c.给药途径 
          n_次数 := n_Lastamount; 
        Elsif l_输血途径 Then 
          n_总量 := n_Lastamount; --d.输血途径的执行次数 
          n_次数 := n_Lastamount; 
        Elsif r.相关id Is Not Null Or l_采集方法 Then 
          n_总量 := n_Lastsum; --e.附加医嘱或标本采集方法(检查组合和手术组合不可能为长嘱,所以此段不会执行) 
          n_次数 := n_Lastamount; 
        End If; 
      Else 
        --临嘱 
        If r.类别 = '7' Then 
          n_次数 := r.总给予量; 
          If r_Medi.住院可否分零 = 0 Then 
            n_总量 := r.总给予量 * r.单次用量 / r_Medi.剂量系数; 
          Else 
            n_总量 := r.总给予量 * Ceil(r.单次用量 / r_Medi.剂量系数); --总给予量=付数 
          End If; 
        Elsif r.类别 In ('5', '6') Then 
          If Nvl(r.频率次数, 0) = 0 Or Nvl(r.频率间隔, 0) = 0 Then 
            n_次数 := 1; --一次性的临嘱药品 
            --因为没有天数,所以不按频率计算 
          Elsif r_Medi.住院可否分零 = 0 And Nvl(r.单次用量, 0) <> 0 Then 
            --可分零药品时,按总量对单量的倍数计算给药途径的次数,否则按一个频率周期的次数计算 
            n_次数 := Trunc(r.总给予量 * r_Medi.剂量系数 / r.单次用量); 
          Else 
            n_次数 := r.频率次数; 
          End If; 
          n_总量 := r.总给予量; 
        Elsif l_中药煎法 Or l_中药用法 Or l_给药途径 Then 
          n_总量 := n_Lastamount; --给药途径,中药用法,煎法的次数 
          n_次数 := n_Lastamount; 
        Elsif (r.相关id Is Null And Not l_采集方法) Or (r.相关id Is Not Null And r.类别 = 'C') Then 
          --主要医嘱或一并采集的检验项目 
          n_总量 := Nvl(r.总给予量, 1); 
          n_次数 := Ceil(n_总量 / r.单次用量); 
        Elsif l_输血途径 Then 
          n_总量 := n_Lastamount; --d.输血途径的执行次数 
          n_次数 := n_Lastamount; 
        Elsif r.相关id Is Not Null Or l_采集方法 Then 
          n_总量 := n_Lastsum; --e.附加医嘱或标本采集方法 
          n_次数 := n_Lastamount; 
        End If; 
      End If; 
      n_Lastamount := n_次数; 
      n_Lastsum    := n_总量; 
      v_Lasttype   := r.类别; 
      n_Last相关id := r.相关id; 
      n_Lastid     := r.Id; 
      l_Last煎法   := l_中药煎法; 
 
      --2.计算实收金额(不考虑加班加价) 
      n_实收金额 := 0; 
      n_应收金额 := 0; 
      n_主收入id := 0; 
      n_主项金额 := 0; 
      If r.类别 In ('4', '5', '6', '7') Then 
 
        If r_Medi.是否变价 = 0 Then 
          n_应收金额 := r_Medi.现价 * n_总量; 
        Else 
          n_应收金额 := Get时价药品金额(n_总量, r.执行科室id, r_Medi.收费细目id); 
        End If; 
        If Not (v_费别 Is Null Or r_Medi.屏蔽费别 = 1) Then 
          v_Tmp      := Zl_Actualmoney(v_费别, r_Medi.收费细目id, r_Medi.收入项目id, n_应收金额, n_总量, r.执行科室id); 
          n_实收金额 := Substr(v_Tmp, Instr(v_Tmp, ':') + 1); 
        Else 
          n_实收金额 := n_应收金额; 
        End If; 
        n_实收合计 := n_实收合计 + n_实收金额; 
 
      Else 
        For D In (Select c.类别, c.Id As 收费细目id, a.收费数量, b.收入项目id, Decode(c.是否变价, 1, b.缺省价格, b.现价) As 单价, c.是否变价, 
                         Nvl(a.从属项目, 0) As 从项, d.跟踪在用, c.屏蔽费别, Nvl(a.费用性质, 0) As 费用性质, Nvl(a.收费方式, 0) As 收费方式, b.附术收费率 
                  From 诊疗收费关系 A, 收费价目 B, 收费项目目录 C, 材料特性 D 
                  Where a.诊疗项目id = r.诊疗项目id And (r.类别 <> 'D' Or r.类别 = 'D' And a.检查部位 = r.标本部位 And a.检查方法 = r.检查方法) And 
                        a.收费项目id = b.收费细目id And a.收费项目id = c.Id And a.收费项目id = d.材料id(+) And c.服务对象 In (2, 3) And 
                        (c.撤档时间 = To_Date('3000-01-01', 'YYYY-MM-DD') Or c.撤档时间 Is Null) And Sysdate Between b.执行日期 And 
                        Nvl(b.终止日期, Sysdate + 1) And 
                        (a.收费方式 = 1 And c.类别 = '4' And a.收费项目id = r_Medi.收费细目id Or Not (a.收费方式 = 1 And c.类别 = '4')) 
                  Order By 费用性质, 从项, a.收费项目id) Loop 
          n_计费总量 := n_总量 * d.收费数量; 
 
          If d.是否变价 = 1 And (d.类别 In ('5', '6', '7') Or (d.类别 = '4' And d.跟踪在用 = 1)) Then 
            n_应收金额 := Get时价药品金额(n_计费总量, r.执行科室id, d.收费细目id); --时价非药嘱药品或跟踪在用的卫材 
          Elsif r.类别 = 'F' And r.相关id Is Not Null Then 
            n_应收金额 := d.单价 * Nvl(d.附术收费率, 100) / 100 * n_计费总量; 
          Else 
            n_应收金额 := d.单价 * n_计费总量; 
          End If; 
          If n_应收金额 <> 0 Then 
            If d.从项 = 0 And n_汇总计算折扣 = 1 And n_主收入id = 0 Then 
              n_主收入id := d.收入项目id; --SQL中主项排在前面,只取主项目的第一个收入 
            End If; 
 
            If n_主收入id <> 0 Then 
              n_主项金额 := n_主项金额 + n_应收金额; 
              n_实收金额 := n_应收金额; 
            Elsif v_费别 Is Null Or d.屏蔽费别 = 1 Then 
              n_实收金额 := n_应收金额; 
            Else 
              v_Tmp      := Zl_Actualmoney(v_费别, d.收费细目id, d.收入项目id, n_应收金额, n_计费总量, r.执行科室id); 
              n_实收金额 := Substr(v_Tmp, Instr(v_Tmp, ':') + 1); 
            End If; 
            n_实收合计 := n_实收合计 + n_实收金额; 
          End If; 
        End Loop; 
        If n_主收入id <> 0 And n_主项金额 <> 0 Then 
          v_Tmp      := Zl_Actualmoney(v_费别, 0, n_主收入id, n_主项金额); 
          n_实收金额 := Substr(v_Tmp, Instr(v_Tmp, ':') + 1); 
          n_实收合计 := n_实收合计 + n_实收金额; 
        End If; 
      End If; 
    End If; 
  End Loop; 
  Return n_实收合计; 
Exception 
  When Err_Custom Then 
    Raise_Application_Error(-20101, '[ZLSOFT]' || v_Error || '[ZLSOFT]'); 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
End Zl_Getpathcharge;
/

