create Function Zl_Getpatient 
( 
  Begintime_In In Date, 
  Endtime_In   In Date, 
  病区id_In    In 部门表.Id%Type, 
  格式id_In    In 病人护理文件.格式id%Type, 
  Type_In      In Varchar2, 
  Typeall_In   In Number := 1, 
  Split_In     In Varchar2 := ';' 
) Return t_Numlist2 
  Pipelined As 
  n_Index  Number(1); 
  v_Str    Varchar2(50); 
  n_病人id Number; 
  n_主页id Number; 
  p        Number; 
  Out_Rec  t_Numobj2 := t_Numobj2(Null, Null); 
 
  --提取对应病区科室所有在院病人 
  Cursor c_List_All Is 
    Select b.病人id, b.主页id 
    From 病人信息 a, 病案主页 b, 在院病人 c 
    Where a.病人id = b.病人id And a.主页ID = b.主页id And Nvl(b.主页id, 0) <> 0 And Nvl(b.病案状态, 0) <> 5 And b.封存时间 Is Null And 
          a.病人id = c.病人id And c.病区id = 病区id_In; 
 
  --入院三天内的病人 
  Cursor c_List_Ry Is 
    Select b.病人id, b.主页id 
    From 病人信息 a, 病案主页 b, 在院病人 c 
    Where a.病人id = b.病人id And a.主页ID = b.主页id And Nvl(b.主页id, 0) <> 0 And Nvl(b.病案状态, 0) <> 5 And b.封存时间 Is Null And 
          b.入院日期 Between Begintime_In And Endtime_In And a.病人id = c.病人id And c.病区id = 病区id_In; 
 
  --手术三天内的病人 
  Cursor c_List_Ss Is 
    Select b.病人id, b.主页id 
    From 病人信息 a, 病案主页 b, 在院病人 f, 病人护理文件 c, 病人护理数据 d, 病人护理明细 e 
    Where a.病人id = b.病人id And a.主页ID = b.主页id And a.病人id = f.病人id And Nvl(b.主页id, 0) <> 0 And f.病区id = 病区id_In And 
          Nvl(b.病案状态, 0) <> 5 And b.封存时间 Is Null And b.病人id = c.病人id And b.主页id = c.主页id And c.格式id = 格式id_In And 
          c.Id = d.文件id And d.Id = e.记录id And e.记录类型 = 4 And e.项目名称 <> '分娩' And NVL(e.复试合格,0)<>1 And e.终止版本 Is Null And 
          d.发生时间 Between Begintime_In And Endtime_In 
 
    Union 
    --从医嘱中提取病人手术信息 
    Select b.病人id, b.主页id 
    From 病人信息 a, 病案主页 b, 在院病人 f, 
         (Select d.病人id, d.主页id 
           From (Select Distinct a.病人id, a.主页id 
                  From 病人医嘱记录 a, 诊疗项目目录 b 
                  Where a.诊疗项目id = b.Id And a.诊疗类别 = 'F' And a.相关id Is Null And a.医嘱状态 In (3, 8) And 
                        a.开始执行时间 Between Begintime_In And Endtime_In 
                  Union 
                  Select Distinct a.病人id, a.主页id 
                  From 病人新生儿记录 a 
                  Where a.出生时间 Between Begintime_In And Endtime_In) d 
           Group By d.病人id, d.主页id) c 
    Where a.病人id = b.病人id And a.主页ID = b.主页id And a.病人id = f.病人id And Nvl(b.主页id, 0) <> 0 And f.病区id = 病区id_In And 
          Nvl(b.病案状态, 0) <> 5 And b.封存时间 Is Null And b.病人id = c.病人id And b.主页id = c.主页id; 
 
  --三天内体温存在超过37.5度的病人 
  Cursor c_List_Tw Is 
    Select b.病人id, b.主页id 
    From 病人信息 a, 病案主页 b, 在院病人 f, 病人护理文件 c, 病人护理数据 d, 病人护理明细 e 
    Where a.病人id = b.病人id And a.主页ID = b.主页id And a.病人id = f.病人id And Nvl(b.主页id, 0) <> 0 And f.病区id = 病区id_In And 
          Nvl(b.病案状态, 0) <> 5 And b.封存时间 Is Null And b.病人id = c.病人id And b.主页id = c.主页id And c.格式id = 格式id_In And 
          c.Id = d.文件id And d.Id = e.记录id And e.记录类型 = 1 And e.项目序号 = 1 And 
          Length(Translate(e.记录内容, '-.0123456789' || e.记录内容, '-.0123456789')) = Length(e.记录内容) And 
          Zl_To_Number(e.记录内容) >= 37.5 And e.终止版本 Is Null And d.发生时间 Between Begintime_In And Endtime_In; 
 
  --危/重病人 
  Cursor c_List_Wz Is 
    Select b.病人id, b.主页id 
    From 病人信息 a, 病案主页 b, 在院病人 f 
    Where a.病人id = b.病人id And a.主页ID = b.主页id And a.病人id = f.病人id And Nvl(b.主页id, 0) <> 0 And f.病区id = 病区id_In And 
          Nvl(b.病案状态, 0) <> 5 And b.封存时间 Is Null And Instr(',' || '危,重' || ',', ',' || b.当前病况 || ',') > 0; 
 
  --转入三天内的病人 
  Cursor c_List_Zr Is 
    Select b.病人id, b.主页id 
    From 病人信息 a, 病案主页 b, 病人变动记录 c, 在院病人 f 
    Where a.病人id = b.病人id And a.主页ID = b.主页id And Nvl(b.主页id, 0) <> 0 And b.病人id = c.病人id And b.主页id = c.主页id And 
          a.病人id = f.病人id And f.病区id = 病区id_In And Nvl(b.病案状态, 0) <> 5 And b.封存时间 Is Null And Nvl(c.附加床位, 0) = 0 And 
          c.病区id + 0 = f.病区id And c.开始原因 In (3, 15) And c.开始时间 Is Not Null And b.状态 = 0 And c.开始时间 Between Begintime_In And 
          Endtime_In; 
 
  -- 一级及以上护理等级的病人 
  Cursor c_List_Yj Is 
    Select b.病人id, b.主页id 
    From 病人信息 a, 病案主页 b, 在院病人 f 
    Where a.病人id = b.病人id And a.主页ID = b.主页id And a.病人id = f.病人id And Nvl(b.主页id, 0) <> 0 And f.病区id = 病区id_In And 
          Nvl(b.病案状态, 0) <> 5 And b.封存时间 Is Null And Zl_Patittendgrade(b.病人id, b.主页id) <= 1; 
 
  --分娩后三天内的病人 
  Cursor c_List_Fm Is 
    Select b.病人id, b.主页id 
    From 病人信息 a, 病案主页 b, 在院病人 f, 病人护理文件 c, 病人护理数据 d, 病人护理明细 e 
    Where a.病人id = b.病人id And a.主页ID = b.主页id And a.病人id = f.病人id And 
          Nvl(b.主页id, 
 
              0) <> 0 And f.病区id = 病区id_In And Nvl(b.病案状态, 0) <> 5 And b.封存时间 Is Null And b.病人id = c.病人id And 
          b.主页id = c.主页id And c.格式id = 格式id_In And c.Id = d.文件id And d.Id = e.记录id And e.记录类型 = 4 And e.项目名称 = '分娩' And 
          e.终止版本 Is Null And d.发生时间 Between Begintime_In And Endtime_In; 
 
  Type v_病人id_Type Is Table Of 病案主页.病人id%Type; 
  v_病人id v_病人id_Type; 
  Type v_主页id_Type Is Table Of 病案主页.主页id%Type; 
  v_主页id v_主页id_Type; 
Begin 
 
  v_Str := Type_In || Split_In; 
 
  If Typeall_In = 1 Then 
    Open c_List_All; 
    Fetch c_List_All Bulk Collect 
      Into v_病人id, v_主页id; 
    Close c_List_All; 
    For i In 1 .. v_病人id.Count Loop 
      Out_Rec.C1 := v_病人id(i); 
      Out_Rec.C2 := v_主页id(i); 
      Pipe Row(Out_Rec); 
    End Loop; 
  Else 
    Loop 
      p := Instr(v_Str, Split_In); 
      Exit When(Nvl(p, 0) = 0); 
      n_Index := Trim(Substr(v_Str, 1, p - 1)); 
      If n_Index Is Not Null Then 
        If n_Index = 0 Then 
          Open c_List_Ry; 
          Fetch c_List_Ry Bulk Collect 
            Into v_病人id, v_主页id; 
          Close c_List_Ry; 
        Elsif n_Index = 1 Then 
          Open c_List_Ss; 
          Fetch c_List_Ss Bulk Collect 
            Into v_病人id, v_主页id; 
          Close c_List_Ss; 
        Elsif n_Index = 2 Then 
          Open c_List_Tw; 
          Fetch c_List_Tw Bulk Collect 
            Into v_病人id, v_主页id; 
          Close c_List_Tw; 
        Elsif n_Index = 3 Then 
          Open c_List_Wz; 
          Fetch c_List_Wz Bulk Collect 
            Into v_病人id, v_主页id; 
          Close c_List_Wz; 
        Elsif n_Index = 4 Then 
          Open c_List_Zr; 
          Fetch c_List_Zr Bulk Collect 
            Into v_病人id, v_主页id; 
          Close c_List_Zr; 
        Elsif n_Index = 5 Then 
          Open c_List_Yj; 
          Fetch c_List_Yj Bulk Collect 
            Into v_病人id, v_主页id; 
          Close c_List_Yj; 
        Elsif n_Index = 6 Then 
          Open c_List_Fm; 
          Fetch c_List_Fm Bulk Collect 
            Into v_病人id, v_主页id; 
          Close c_List_Fm; 
        End If; 
 
        For i In 1 .. v_病人id.Count Loop 
          Out_Rec.C1 := v_病人id(i); 
          Out_Rec.C2 := v_主页id(i); 
          Pipe Row(Out_Rec); 
        End Loop; 
      End If; 
      v_Str := Substr(v_Str, p + 1); 
    End Loop; 
  End If; 
  Return; 
Exception 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
End Zl_Getpatient;
/

