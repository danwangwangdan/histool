create Function Zl_Getpatienttype(科室id_In In 部门表.Id%Type) Return Varchar2 Is 
  --模块：体温单批量录入。 
  --函数功能说明：自定义需要返回的筛选条件。 
  --规则：必须按照目前顺依次往后添加需要的筛选条件。 
  v_Type   Varchar2(1000); 
  v_Deptex Varchar2(50); 
  v_Cktj   Varchar2(100); 
Begin 
 
  Begin 
    Select 工作性质 Into v_Deptex From 部门性质说明 Where 部门id = 科室id_In; 
  Exception 
    When Others Then 
      v_Deptex := '所有'; 
  End; 
 
  If v_Deptex = '所有' Or v_Deptex = '产科' Then 
    v_Cktj := ';分娩后三天内的病人'; 
  Else 
    v_Cktj := ';'; 
  End If; 
 
  v_Type := '入院三天内的病人;手术三天内的病人;三天内体温存在超过37.5度的病人;危/重病人;转入三天内的病人;一级及以上护理等级的病人' || v_Cktj; 
 
  Return v_Type; 
Exception 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
End Zl_Getpatienttype;
/

