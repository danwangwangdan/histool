create Function Zl_Getsequencebeforperons 
( 
  业务id_In   Number := Null, 
  业务类型_In Number := Null, 
  排队号码_In Number := Null, 
  队列名称_In 排队叫号队列.队列名称%Type := Null 
  --功能：获取指定排队号码前面还有几位未诊的病人数 
  --     本函数主要供其他过程调用,用户可以根据实际产生的规则,来获取前几位未诊病人数 
  --参数： 
  --    业务ID_In：传入的是挂号ID 
  --    业务类型_In: 传入排队业务类型 
  --    排队号码_IN:排队号码 
 
) Return Number Is 
  n_Count Number(18); 
Begin 
  If 排队号码_In Is Null Then 
    Return 0; 
  End If; 
  If Nvl(业务id_In, 0) = 0 Then 
    Return 0; 
  End If; 
  Select Count(*) 
  Into n_Count 
  From 排队叫号队列 
  Where 排队号码 < 排队号码_In And Nvl(业务类型, 0) = 业务类型_In And 队列名称 = 队列名称_In; 
 
  Return n_Count; 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zl_Getsequencebeforperons;
/

