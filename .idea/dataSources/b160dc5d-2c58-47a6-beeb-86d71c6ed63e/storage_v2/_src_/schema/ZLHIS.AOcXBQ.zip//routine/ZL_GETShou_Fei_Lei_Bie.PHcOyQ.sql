create Function Zl_Get收费类别 
( 
  单据_In   药品收发记录.单据%Type, 
  No_In     药品收发记录.No%Type, 
  库房id_In 药品收发记录.库房id%Type := Null 
) Return Number Is 
  v_值       Number(18); 
  v_收费类别 Varchar(2); 
Begin 
  v_值 := 0; 
  For v_Item In (Select Distinct 费用id 
                 From 药品收发记录 
                 Where 单据 = 单据_In And NO = No_In And 库房id = Nvl(库房id_In, 库房id)) Loop 
    Select 收费类别 
    Into v_收费类别 
    From (Select 收费类别 
           From 门诊费用记录 
           Where ID = v_Item.费用id 
           Union All 
           Select 收费类别 From 住院费用记录 Where ID = v_Item.费用id); 
    If v_收费类别 = '7' Then 
      If v_值 = 0 Then 
        v_值 := 2; 
      Elsif v_值 = 1 Then 
        v_值 := 3; 
      End If; 
    Else 
      If v_值 = 0 Then 
        v_值 := 1; 
      Elsif v_值 = 2 Then 
        v_值 := 3; 
      End If; 
    End If; 
  End Loop; 
  Return v_值; 
Exception 
  When Others Then 
    Return 1; 
End;
/

