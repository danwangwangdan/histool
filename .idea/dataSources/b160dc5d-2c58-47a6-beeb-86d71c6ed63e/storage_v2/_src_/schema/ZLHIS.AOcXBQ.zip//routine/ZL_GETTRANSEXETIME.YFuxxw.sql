create Function Zl_Gettransexetime 
( 
  开始执行时间_In In Date, 
  上次执行时间_In In Date, 
  频率间隔_In     In Number, 
  间隔单位_In     In Varchar2, 
  执行时间方案_In In Varchar2 
) Return Date As 
  v_Exe       Varchar2(200); 
  v_Exeplan   Varchar2(200); 
  v_Exetime   Date; 
  v_Tmptime   Varchar2(50); 
  v_Split     Number; 
  v_Plan      Varchar2(20); 
  v_Stop      Boolean; 
  v_Cycle     Number; 
  v_Adddate   Number; 
  v_Addhour   Number; 
  v_Addminute Number; 
  b_Tmp       Boolean; 
Begin 
  v_Exetime := 开始执行时间_In; 
  v_Split   := 频率间隔_In; 
  v_Stop    := False; 
  v_Cycle   := 0; 
  b_Tmp     := False; 
 
  v_Exeplan := 执行时间方案_In; 
  If Instr(执行时间方案_In, ',') > 0 Then 
    If Trunc(上次执行时间_In) <= Trunc(开始执行时间_In) Then 
      v_Exeplan := Substr(执行时间方案_In, 1, Instr(执行时间方案_In, ',') - 1); 
      b_Tmp     := True; 
    Else 
      v_Exeplan := Substr(执行时间方案_In, Instr(执行时间方案_In, ',') + 1); 
    End If; 
  End If; 
 
  While Not v_Stop Loop 
    v_Exe := v_Exeplan || '-'; 
 
    --按执行时间方案循环 
    While v_Exe Is Not Null Loop 
      v_Plan := Substr(v_Exe, 1, Instr(v_Exe, '-') - 1); 
      v_Exe  := Replace('-' || v_Exe, '-' || v_Plan || '-'); 
 
      If 间隔单位_In = '天' Then 
        --间隔单位是"天"时，始终按开始执行时间来推算当前执行时间 
        v_Exetime := 开始执行时间_In; 
 
        If 频率间隔_In = 1 Then 
          --时间间隔是1时，表示当天执行 
          v_Adddate := 0; 
        Elsif 频率间隔_In = 7 Then 
          --间隔为周 
 
          v_Adddate := To_Number(Substr(v_Plan, 1, Instr(v_Plan, '/') - 1)) - 1; 
 
          --取执行时点 
          v_Plan := Substr(v_Plan, Instr(v_Plan, '/') + 1); 
        Else 
          --取要增加的天数 
          v_Adddate := To_Number(Substr(v_Plan, 1, Instr(v_Plan, '/') - 1)) - 1; 
 
          --取执行时点 
          v_Plan := Substr(v_Plan, Instr(v_Plan, '/') + 1); 
        End If; 
      Elsif 间隔单位_In = '小时' Then 
        v_Adddate := 0; 
 
        If Instr(v_Plan, ':') = 0 Then 
          v_Addhour   := To_Number(v_Plan) - 1; 
          v_Addminute := 0; 
        Else 
          v_Addhour   := To_Number(Substr(v_Plan, 1, Instr(v_Plan, ':') - 1)) - 1; 
          v_Addminute := To_Number(Substr(v_Plan, Instr(v_Plan, ':') + 1)); 
        End If; 
      End If; 
 
      If 间隔单位_In = '天' Then 
        If 频率间隔_In = 7 Then 
          --取开始执行时间所在周的周一日期 
          v_Exetime := Trunc(v_Exetime, 'iw'); 
        End If; 
 
        --计算当前执行时间 
        v_Tmptime := To_Char(v_Exetime, 'YYYY-MM-DD') || 
                     Substr(To_Char(To_Date(v_Plan, 'hh24:mi:ss'), 'YYYY-MM-DD HH24:MI:SS'), 11); 
        v_Exetime := To_Date(v_Tmptime, 'YYYY-MM-DD HH24:MI:SS') + v_Split * v_Cycle + v_Adddate; 
      Elsif 间隔单位_In = '小时' Then 
        --间隔单位是"时"时，当前执行时间是按从开始执行时间起，按间隔小时数及执行方案累加 
        v_Exetime := 开始执行时间_In + v_Split * v_Cycle / 24 + v_Addhour / 24 + v_Addminute / 24 / 60; 
      End If; 
 
      --当前执行时间大于上次执行时，退出循环 
      If v_Exetime > 上次执行时间_In Then 
        v_Stop := True; 
        Exit; 
      End If; 
    End Loop; 
    --如果是首日时间，但是当次已经超出首日执行时间，则重算。 
    If Instr(执行时间方案_In, ',') > 0 And b_Tmp = True And v_Stop = True Then 
      If Trunc(v_Exetime) > Trunc(开始执行时间_In) Then 
        v_Exeplan := Substr(执行时间方案_In, Instr(执行时间方案_In, ',') + 1); 
        v_Stop    := False; 
        b_Tmp     := False; 
        v_Cycle   := v_Cycle - 1; 
      End If; 
    End If; 
    --循环次数 
    v_Cycle := v_Cycle + 1; 
  End Loop; 
 
  --返回当前执行时间 
  Return(v_Exetime); 
End;
/

