create Function Zl_Get组id(User_In Varchar2 := Null) Return Number Is 
  --功能:获取当前用户的所属组(缴款的所属组ID):NULL表示为空 
  v_Name   人员表.姓名%Type; 
  v_Temp   Varchar2(255); 
  n_人员id 人员表.Id%Type; 
  n_组id   人员表.Id%Type; 
Begin 
  If User_In Is Null Then 
    --操作员信息:;人员id,人员编号,人员姓名 
    v_Temp := Zl_Identity(1); 
    If Nvl(v_Temp, '0') = '0' Or Nvl(v_Temp, ' ') = ' ' Then 
      n_人员id := -1; 
    Else 
      v_Temp := Substr(v_Temp, Instr(v_Temp, ';') + 1); 
      Begin 
        n_人员id := To_Number(Substr(v_Temp, 1, Instr(v_Temp, ',') - 1)); 
      Exception 
        When Others Then 
          n_人员id := -1; 
      End; 
    End If; 
  Elsif Zl_To_Number(User_In) > 0 Then 
    n_人员id := Zl_To_Number(User_In); 
  Else 
    n_人员id := -1; 
    v_Name   := User_In; 
  End If; 
  If Nvl(n_人员id, 0) <= 0 Then 
    Select Max(a.组id) 
    Into n_组id 
    From 缴款成员组成 A, 财务缴款分组 B, 人员表 C 
    Where a.成员id = c.Id And c.姓名 = v_Name And (c.撤档时间 Is Null Or c.撤档时间 >= To_Date('3000-01-01', 'yyyy-mm-dd')) And 
          a.组id + 0 = b.Id And (b.删除日期 >= Sysdate Or b.删除日期 Is Null); 
  Else 
    Select Max(a.组id) 
    Into n_组id 
    From 缴款成员组成 A, 财务缴款分组 B 
    Where a.组id = b.Id And (b.删除日期 >= Sysdate Or b.删除日期 Is Null) And a.成员id = n_人员id; 
  End If; 
  If Nvl(n_组id, 0) <= 0 Then 
    n_组id := Null; 
  End If; 
  Return n_组id; 
End Zl_Get组id;
/

