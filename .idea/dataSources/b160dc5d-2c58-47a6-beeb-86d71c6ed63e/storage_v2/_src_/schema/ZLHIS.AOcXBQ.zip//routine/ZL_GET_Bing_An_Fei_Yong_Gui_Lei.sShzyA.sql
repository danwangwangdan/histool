create Function       Zl_get_病案费用归类
(费目_in          In varchar,
 病人id_in        In 病人信息.病人id%type,
 主页id_in        In 病案主页.主页id%type,
 归类方式_in      In Number :=0

)
------------------------------------------------------------------------------------
  --功能：根据指定的病案费目返回汇总金额
  --归类方式 0病案费目，1 收据费目，2-收入项目
  --返回：费用
  --------------------------------------------------------------------------------------
 Return number Is
  Err_Item Exception;
  v_Err_Msg Varchar2(100);
  v_费用    number(16,5);

Begin
  v_费用 :=0;
    If 归类方式_in=0 Then
        Select sum(nvl(a.结帐金额,a.实收金额)) As 费用 Into v_费用
        From 住院费用记录 a,收费项目目录 b
        Where a.病人id=病人id_in And a.主页id=主页id_in And a.记录状态<>0 And a.记录性质<>5 And a.收费细目id=b.id And instr(',' || 费目_in || ',' , ',' || nvl(b.病案费目,'其他费') || ',') >0
        ;
    Elsif 归类方式_in=1 Then
      Select sum(nvl(a.结帐金额,a.实收金额)) As 费用 Into v_费用
        From 住院费用记录 a
        Where a.病人id=病人id_in And a.主页id=主页id_in And a.记录状态<>0 And a.记录性质<>5 And  instr(',' || 费目_in || ',' , ',' || nvl(a.收据费目 ,'其他费') || ',') >0
        ;
    Else
       Select sum(nvl(a.结帐金额,a.实收金额)) As 费用 Into v_费用
        From 住院费用记录 a,收入项目 b
        Where a.病人id=病人id_in And a.主页id=主页id_in And a.记录状态<>0 And a.记录性质<>5 And a.收入项目id=b.id And instr(',' || 费目_in || ',' , ',' || nvl(b.名称,'其他费') || ',') >0
        ;
    End If;
    If v_费用=0 Or v_费用 Is Null Then
       Return 0;
    Else
        Return v_费用;
    End If;

Exception
  When Others Then
    Zl_Errorcenter(Sqlcode, Sqlerrm);
    Return v_费用;
End Zl_get_病案费用归类;


/

