create Function       Zl_get_病历提纲内容
(病人id_in        电子病历记录.病人id%type,
主页id_in         电子病历记录.主页id%Type,
病人来源_in       电子病历记录.病人来源%Type,
文件名称_in       Varchar2,
提纲_in           Varchar2
)
------------------------------------------------------------------------------------
  --功能：根据指定人员姓名获取人员编号
  --------------------------------------------------------------------------------------
 Return Varchar2 Is
  Err_Item Exception;
  v_Err_Msg Varchar2(100);
  return_ Varchar2(1024);
Begin
  return_ :='-';
 Select replace(f_list2str(Cast(Collect(内容文本) As t_Strlist),'  '),'  ' , '') As 内容文本 Into return_ From (
Select d.内容文本
                  From 电子病历记录 R, 电子病历内容 C ,电子病历内容 d ,病历文件列表 e
                  Where r.Id = c.文件id And r.病人id =病人id_in   And r.主页id=主页id_in  And r.病人来源=病人来源_in  And e.Id=r.文件id And  e.名称=文件名称_in
                  And c.内容文本 = 提纲_in  And c.对象类型=1 And c.Id=d.父id And d.终止版=0
                  Order By d.对象序号 )  ;
  If return_ Is Null Or return_='' Then
     Return '-';
  Else
      Return return_;
  End If;
Exception
  When Others Then
    Return '-';
End Zl_get_病历提纲内容;


/

