create Function       Zl_get_处方类型
(
NO_in       药品收发记录.No%type,
记录性质_in 门诊费用记录.记录性质%type
)
------------------------------------------------------------------------------------
  --功能：根据指定NO号获取本处方的处方类型
  --0和空-普通,1-儿科,2-急诊,3-精二,4-精一,5-麻醉
  --------------------------------------------------------------------------------------
 Return varchar Is
  Err_Item     Exception;
  v_Err_Msg    Varchar2(100);
  v_处方类型   未发药品记录.处方类型%Type ;
Begin
  v_处方类型 :='0';
  Select to_char(max(处方类型))  As 处方类型 Into v_处方类型 From (
    Select to_number(nvl(注册证号,0))  As 处方类型 From 药品收发记录 Where No =NO_in And 单据=decode(记录性质_in,1,8,2,9,8)
    Union All
    Select nvl(处方类型,0) As 处方类型 From 未发药品记录 Where No =NO_in And 单据=decode(记录性质_in,1,8,2,9,8) );
  Return v_处方类型;
Exception
  When Others Then
    Return '0';
End Zl_get_处方类型;


/

