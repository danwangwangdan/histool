create Function Zl_get_对码信息
( 项目类型_in In  Number ,
  项目id_in In Varchar2
)
------------------------------------------------------------------------------------
  --功能：根据指定的项目类别获取和id获取相应的匹配项目编码
 --- Select * From  TB_Dic_Detail_Comparison  t  Where t.bmlx=4
---- 1 手术
---- 2 诊断目录
---- 3 收费项目
---- 4 药品
  --------------------------------------------------------------------------------------
 Return Varchar2 Is
  Err_Item Exception;
  v_Err_Msg Varchar2(100);
  v_对码信息 Varchar2(100);
Begin
  v_对码信息 :=项目id_in;
  Select t.中心编码 Into v_对码信息 From  平台对照目录  t  Where t.类型= ''|| 项目类型_in And t.HISID=''||项目id_in And rownum < 2 ;
  Return v_对码信息;
Exception
  When Others Then
    Return  项目id_in ;
End Zl_get_对码信息;
/

