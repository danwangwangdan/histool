create Function Zl_Get_Excuteitem_Infor 
( 
  模块_In        Number, 
  病人id_In      病人信息.病人id%Type, 
  收费类别_In    Varchar2, 
  Nos_In         Varchar2, 
  收费细目ids_In Varchar2 
) Return Varchar2 Is 
  ------------------------------------------------------------------------------------------------- 
  --功能:主要是在先诊疗后结算模式下，检查某类或指定收费项目必须先结帐后再执行,该函数就是返回具体的提示信息 
  --参数:NOs_IN:本次执行的单据号 
  --     收费类别_IN:本次执行的收费类别,允许传入多个,多个时用逗号分离:比如:4,5,6,7等,为空时，不根据收费类别进行检查 
  --     收费细目IDs_in:表示本次执行的收费项目,可以为多个，用逗号分离,比如：123,456等，为空时，不按收费细目IDs进行检查 
  --     模块_IN:调用的模块号 
  --返回:返回提示信息,提示信息格式:提示方式|提示信息;空表示不进行提示(病人ID未找到时也返回空) 
  --  提示方式:1-表示提示执行;2-表示禁止执行 
  ------------------------------------------------------------------------------------------------- 
  n_Count   Number(18); 
  v_Err_Msg Varchar2(4000); 
Begin 
  Begin 
    Select 结算模式 Into n_Count From 病人信息 Where 病人id = 病人id_In; 
  Exception 
    When Others Then 
      v_Err_Msg := '无病人'; 
  End; 
 
  If v_Err_Msg Is Not Null Or Nvl(n_Count, 0) <> 1 Then 
    --病人未找到，直接返回空或未采用先诊疗后结算模式时返回空 
    Return Null; 
  End If; 
 
  If 收费类别_In Is Not Null Then 
    --发药时，必须先结账 
    If Instr(',' || 收费类别_In || ',', ',5,') <> 0 Or Instr(',' || 收费类别_In || ',', ',6,') <> 0 Or 
       Instr(',' || 收费类别_In || ',', ',7,') <> 0 Then 
      Select Count(1) 
      Into n_Count 
      From 病人未结费用 
      Where 病人id = 病人id_In And (来源途径 In (1, 4) Or 来源途径 = 3 And Nvl(主页id, 0) = 0) And Nvl(金额, 0) <> 0 And Rownum < 2; 
      If Nvl(n_Count, 0) <> 0 Then 
        --存在未结算数据，必须先结算后才允许执行 
        v_Err_Msg := '2|在领药前，必须先结算后才能领药'; 
        Return v_Err_Msg; 
      End If; 
    End If; 
    Return Null; 
  End If; 
  If Nos_In Is Not Null Then 
    --按单据处理 
    --暂无代码,以后添加限制 
    Null; 
  End If; 
 
  If 收费细目ids_In Is Not Null Then 
    --按具体项目处理 
    --暂无代码,以后添加限制 
    Null; 
  End If; 
  If Nvl(模块_In, 0) = 1341 Then 
    --处方发药 
    Select Count(1) 
    Into n_Count 
    From 病人未结费用 
    Where 病人id = 病人id_In And (来源途径 In (1, 4) Or 来源途径 = 3 And Nvl(主页id, 0) = 0) And Nvl(金额, 0) <> 0 And Rownum < 2; 
    If Nvl(n_Count, 0) <> 0 Then 
      --存在未结算数据，必须先结算后才允许执行 
      v_Err_Msg := '1|在领药前，必须先结算后才能领药'; 
      Return v_Err_Msg; 
    End If; 
  End If; 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zl_Get_Excuteitem_Infor;
/

