create Function Zl_Get_发药窗口_Average(药房id_In In 发药窗口.药房id%Type) Return Varchar2 
--功能:获取平均分配的发药窗口 
 Is 
  Pragma Autonomous_Transaction; 
  v_编码_First 发药窗口.编码%Type; 
  v_名称_First 发药窗口.名称%Type; 
  v_编码       发药窗口.编码%Type; 
  v_名称       发药窗口.名称%Type; 
  n_Count      Number(2); 
 
Begin 
 
  v_编码_First := Null; 
  v_编码       := Null; 
  n_Count      := 0; 
  For c_发药窗口 In (Select 编码, 名称 As 发药窗口, Nvl(当前分配, 0) As 活动 
                 From 发药窗口 
                 Where 上班否 = 1 And Nvl(专家, 0) = 0 And 药房id = 药房id_In 
                 Order By 编码) Loop 
    If v_编码_First Is Null Then 
      v_编码_First := c_发药窗口.编码; 
      v_名称_First := c_发药窗口.发药窗口; 
    End If; 
    If n_Count = 1 Then 
      v_编码 := c_发药窗口.编码; 
      v_名称 := c_发药窗口.发药窗口; 
      Exit; 
    End If; 
    If Nvl(c_发药窗口.活动, 0) = 1 Then 
      n_Count := 1; 
    End If; 
  End Loop; 
  If v_编码 Is Null Then 
    v_编码 := v_编码_First; 
    v_名称 := v_名称_First; 
 
  End If; 
  If v_编码 Is Null Then 
    Return Null; 
  End If; 
  Update 发药窗口 Set 当前分配 = Decode(编码, v_编码, 1, 0) Where 药房id = 药房id_In; 
  Commit; 
  Return v_名称; 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zl_Get_发药窗口_Average;
/

