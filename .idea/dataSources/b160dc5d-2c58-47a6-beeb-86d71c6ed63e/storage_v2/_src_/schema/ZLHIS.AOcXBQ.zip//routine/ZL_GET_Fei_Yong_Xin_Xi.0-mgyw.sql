create Function       Zl_get_费用信息
(类型_in In Number,
 病人id_in In 病人信息.病人id%type,
 主页id_in In 病案主页.主页id%type

)
------------------------------------------------------------------------------------
  --功能：根据指定的日期,获取期间数据
  --     类型_in 0 表示获取总费用,1 获取药品费用
  --返回：费用
  --------------------------------------------------------------------------------------
 Return number Is
  Err_Item Exception;
  v_Err_Msg Varchar2(100);
  v_费用    number(16,5);

Begin
  v_费用 :=0;
  If 类型_in=1 Then
    Select sum(实收金额) As 药品费用 Into v_费用
    From 住院费用记录
    Where 病人id=病人id_in And 主页id=主页id_in And 记录状态<>0 And 记录性质<>5 And 收费类别 In ('5','6','7') ;
  Else
    Select sum(实收金额) As 总费用 Into v_费用
    From 住院费用记录
    Where 病人id=病人id_in And 主页id=主页id_in And 记录状态<>0 And 记录性质<>5 ;
  End If;
  Return v_费用;
Exception
  When Others Then
    Zl_Errorcenter(Sqlcode, Sqlerrm);
    Return v_费用;
End Zl_get_费用信息;


/

