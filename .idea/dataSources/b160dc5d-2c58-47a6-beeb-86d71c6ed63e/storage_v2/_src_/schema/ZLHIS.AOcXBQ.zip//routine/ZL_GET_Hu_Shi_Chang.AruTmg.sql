create Function Zl_Get_护士长(部门id_In In 部门表.Id%Type) Return Varchar2 Is
	Result Varchar2(32);
Begin
	Result  := '' ;
  Select 姓名 Into Result  From
      (  Select Distinct b.编号, b.姓名, b.管理职务, c.部门id, a.Id, a.名称, Nvl(缺省, 0) As 缺省
          From 部门表 a, 人员表 b, 部门人员 c
             Where a.Id = c.部门id And c.人员id = b.Id And b.管理职务 = '护士长' And a.Id = 部门id_In
      Order By 缺省 Desc   )
           Where Rownum < 2
           ;
    Return(Result );
End Zl_Get_护士长;
/

