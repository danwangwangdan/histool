create Function       Zl_get_门诊诊断
(病人id_in 病人诊断记录.病人id%type,
主页id_in  病人诊断记录.主页id%Type
)
------------------------------------------------------------------------------------
  --功能：根据指定人员姓名获取人员编号
  --------------------------------------------------------------------------------------
 Return Varchar2 Is
  Err_Item Exception;
  v_Err_Msg Varchar2(100);
  return_ Varchar2(1024);
Begin
  return_ :='-';
  Select f_list2str(Cast(Collect(诊断描述) As t_Strlist)) || '||' || 诊断类型 || '||' || max(decode(诊断类型,11,'1','0')) Into return_ From 病人诊断记录
     Where 诊断类型  in( '1','11') And 记录来源=3 And 取消时间 Is Null And 病人id=病人id_in And 主页id=主页id_in
                Group By 诊断类型 ;
  Return return_;
Exception
  When Others Then
    Return '-';
End Zl_get_门诊诊断;


/

