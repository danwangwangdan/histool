create Function Zl_Get_Queuedate 
( 
	挂号id_In   病人挂号记录.Id%Type, 
	号码_In     病人挂号记录.号别%Type, 
	号序_In     病人挂号记录.号序%Type, 
	缺省日期_In Date := Null, 
	扩展_In     Varchar2 := Null 
	--功能：获取指定的排队时间 
	--     本函数主要供其他过程调用,读取相关的排队时间 
	--     用户可以根据实际产生的规则,来生成排队时间 
	--参数： 
	--    挂号id_In：传入的是当前挂号ID 
	--    缺省日期_In:缺省时间 
	--    号序_IN:挂号时的序号 
	--    扩展_IN：暂无用,以后扩展 
) Return Date Is 
	Err_Custom Exception; 
	n_排队挂号id 病人挂号记录.Id%Type; 
	d_发生时间   Date; 
	n_时段       Number; 
Begin 
 
	--目前排队顺序有如下几种情况: 
 
	--0.如果号别分了时段,直接返回为缺省日期; 
	--1.如果排队启用了序号控制的,则排队按序号顺序进行排队,处理规则是取当前序号的前一个序号的日期为排队日期 
	--2.如果未启用排队日期,则直接为缺省日期; 
	--3.如果缺省日期不是当天则直接为缺省日期; 
 
	Select Count(a.安排id) 
	Into n_时段 
	From 挂号安排时段 a, 挂号安排 b 
	Where a.安排id = b.Id And b.号码 = 号码_In And Rownum = 1; 
	If Nvl(n_时段, 0) > 0 Then 
		Return Nvl(缺省日期_In, Sysdate); 
	End If; 
 
	If Nvl(号序_In, 0) = 0 Or (Trunc(缺省日期_In) <> Trunc(Sysdate) And 缺省日期_In Is Not Null) Then 
		--以缺省日期为准: 
		Return Nvl(缺省日期_In, Sysdate); 
	End If; 
	If 挂号id_In = 0 Or 扩展_In Is Null Then 
		--暂无用 
		Null; 
	End If; 
 
	Begin 
		Select Max(Id) 
		Into n_排队挂号id 
		From 病人挂号记录 
		Where 号序 = 
					(Select Max(a.号序) 
					 From 病人挂号记录 a 
					 Where a.号序 < 号序_In And a.发生时间 Between Trunc(缺省日期_In) And 
								 Trunc(缺省日期_In) + 1 - 1 / 24 / 60 / 60 And 号别 = 号码_In And Not Exists 
						(Select 1 
									From 排队叫号队列 b 
									Where 业务id = a.Id And 业务类型 = 0 And Nvl(回诊序号, 0) <> 0 And 排队状态 In (2, 3, 4, 6))) And 
					发生时间 Between Trunc(缺省日期_In) And Trunc(缺省日期_In) + 1 - 1 / 24 / 60 / 60 And 号别 = 号码_In; 
	 
		If Nvl(n_排队挂号id, 0) = 0 Then 
			--取最小号 
			Select Max(Id) 
			Into n_排队挂号id 
			From 病人挂号记录 
			Where 号序 = 
						(Select Min(a.号序) 
						 From 病人挂号记录 a 
						 Where a.号序 > 号序_In And a.发生时间 Between Trunc(缺省日期_In) And 
									 Trunc(缺省日期_In) + 1 - 1 / 24 / 60 / 60 And 号别 = 号码_In And Not Exists 
							(Select 1 
										From 排队叫号队列 b 
										Where 业务id = a.Id And 业务类型 = 0 And Nvl(回诊序号, 0) <> 0 And 排队状态 In (2, 3, 4, 6))) And 
						发生时间 Between Trunc(缺省日期_In) And Trunc(缺省日期_In) + 1 - 1 / 24 / 60 / 60 And 号别 = 号码_In; 
			If Nvl(n_排队挂号id, 0) <> 0 Then 
				--减3秒 
				Begin 
					Select 排队时间 - (1 / 24 / 60 / 60) * 3 
					Into d_发生时间 
					From 排队叫号队列 
					Where 业务类型 = 0 And 业务id = n_排队挂号id; 
				Exception 
					When Others Then 
						Null; 
				End; 
			End If; 
		Else 
			Begin 
				Select 排队时间 Into d_发生时间 From 排队叫号队列 Where 业务类型 = 0 And 业务id = n_排队挂号id; 
			Exception 
				When Others Then 
					Null; 
			End; 
		 
		End If; 
	 
	Exception 
		When Others Then 
			d_发生时间   := Nvl(缺省日期_In, Sysdate); 
			n_排队挂号id := 0; 
	End; 
	If d_发生时间 Is Null Then 
		d_发生时间 := Nvl(缺省日期_In, Sysdate); 
	End If; 
	Return d_发生时间; 
End Zl_Get_Queuedate;
/

