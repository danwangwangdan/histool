create Function Zl_Get_Reference 
( 
  Type_In       In Number, --0=参考 1=参考ID 2=危急参考 3=危急参考下限 4=危急参考上限 
  项目id_In     In Number, 
  标本类型_In   In Varchar2, 
  性别_In       In Number, 
  出生日期_In   In Date, 
  仪器id_In     In Number := Null, 
  年龄_In       In Varchar2 := Null, 
  申请科室id_In In Number := Null 
) Return Varchar2 As 
 
  Cursor v_Reference_Type Is 
    Select a.Id, 
           Trim(To_Char(a.参考低值, c.格式)) || '～' || Trim(To_Char(a.参考高值, c.格式)) || 
            Decode(a.临床特征, Null, '', '成人', '', '婴儿', '', ' ' || a.临床特征) As 结果参考, b.结果类型, b.取值序列, 
           Trim(To_Char(a.警示下限, c.格式)) || '～' || Trim(To_Char(a.警示上限, c.格式)) || 
            Decode(a.临床特征, Null, '', '成人', '', '婴儿', '', ' ' || a.临床特征) As 危急参考, a.警示下限, a.警示上限, Nvl(b.多参考, 0) 多参考 
    From 检验项目参考 A, 检验项目 B, 
         (Select '9999990' || 
                   Decode(Max(Nvl(c.小数位数, -1)), 0, '', -1, '.00', Substr('.000000', 1, 1 + Max(Nvl(c.小数位数, -1)))) As 格式 
 
 
           From 检验仪器项目 C, 检验项目 D 
           Where d.诊治项目id = 项目id_In And d.诊治项目id = c.项目id(+)) C 
    Where a.项目id = 项目id_In And a.项目id = b.诊治项目id; 
 
  v_Return Varchar2(4000); 
  v_Sql    Varchar2(4000); 
 
  Type c_Type Is Ref Cursor; --声明REF游标类型 
  r_Emp v_Reference_Type%RowType; --声明一个行类型变量 
  Cur   c_Type; --声明REF游标类型的变量 
 
  v_结果类型 Number(1); 
 
  v_年数     Number(18, 1); 
  v_月数     Number(18, 1); 
  v_日数     Number(18, 1); 
  v_小时     Number(18, 1); 
  v_出生日期 Date; 
  v_Pos      Number(4); 
  v_多参考   Number(4); 
  v_Value    Number(18); 
  v_Valuerec Varchar2(255); 
  v_年龄     Varchar2(50); 
  v_结果参考 Varchar2(1000); 
  v_参考id   Number(18); 
  v_危紧参考 Varchar2(1000); 
  v_警示下限 Varchar2(1000); 
  v_警示上限 Varchar2(1000); 
  d_Sysdate  Date; 
 
  v_项目id_Bound   检验项目参考.项目id%Type; 
  v_标本类型_Bound 检验项目参考.标本类型%Type; 
  v_性别域1_Bound  检验项目参考.性别域%Type; 
  v_性别域2_Bound  检验项目参考.性别域%Type; 
  v_性别域3_Bound  检验项目参考.性别域%Type; 
  v_仪器id_Bound   检验项目参考.仪器id%Type; 
 
  v_年龄单位日_Bound   检验项目参考.年龄单位%Type; 
  v_年龄单位月_Bound   检验项目参考.年龄单位%Type; 
  v_年龄单位小时_Bound 检验项目参考.年龄单位%Type; 
  v_年龄单位年_Bound   检验项目参考.年龄单位%Type; 
 
  v_年龄单位日1_Bound   检验项目参考.年龄单位%Type; 
  v_年龄单位月1_Bound   检验项目参考.年龄单位%Type; 
  v_年龄单位小时1_Bound 检验项目参考.年龄单位%Type; 
  v_年龄单位年1_Bound   检验项目参考.年龄单位%Type; 
 
  v_临床特征_Bound   检验项目参考.临床特征%Type; 
  v_申请科室id_Bound 检验项目参考.申请科室id%Type; 
  v_年龄_1           Varchar2(50); 
  v_年龄_2           Varchar2(50); 
 
  Function Sub_Is_Number(v_In In Varchar2) Return Boolean Is 
    n_Tmp Number; 
  Begin 
    n_Tmp := To_Number(v_In); 
    If n_Tmp Is Not Null Then 
      Return True; 
    Else 
      Return False; 
    End If; 
  Exception 
    When Others Then 
      Return False; 
  End Sub_Is_Number; 
 
  Function Zlsplit 
  ( 
    v_Str       In Varchar2, 
    v_Delimiter In Varchar2, 
    v_Number    In Number 
  ) Return Varchar2 Is 
    v_Record     Varchar2(1000); 
    v_Currrecord Varchar2(1000); 
    v_Currnum    Number; 
  Begin 
    v_Record  := v_Str || v_Delimiter; 
    v_Currnum := 0; 
    While v_Record Is Not Null Loop 
      v_Currrecord := Substr(v_Record, 1, Instr(v_Record, v_Delimiter) - 1); 
      If v_Currnum = v_Number Then 
        Return(v_Currrecord); 
      End If; 
 
      v_Currnum := v_Currnum + 1; 
      v_Record  := Replace(v_Delimiter || v_Record, v_Delimiter || v_Currrecord || v_Delimiter); 
    End Loop; 
 
    Return(''); 
  End Zlsplit; 
  Function Zlval(Vstr In Varchar2) Return Number Is 
    Result Number(16, 6); 
    Intbit Number(8); 
    Strnum Varchar(10); 
  Begin 
    Strnum := ''; 
    For Intbit In 1 .. 10 Loop 
      If Instr('0123456789.', Substr(Vstr, Intbit, 1)) = 0 Then 
        Exit; 
      End If; 
      Strnum := Strnum || Substr(Vstr, Intbit, 1); 
      Null; 
    End Loop; 
    Result := To_Number(Strnum); 
    Return(Result); 
  End Zlval; 
 
Begin 
  d_Sysdate := Sysdate; 
 
  v_Sql := ' Select a.id,Trim(To_Char(A.参考低值, C.格式)) || ''～'' || Trim(To_Char(A.参考高值, C.格式)) || ' || 
           ' Decode(A.临床特征, Null, '''', ''成人'', '''', ''婴儿'','''', '' '' || A.临床特征) As 结果参考, B.结果类型, B.取值序列, ' || 
           ' Trim(To_Char(A.警示下限, C.格式)) || ''～'' || Trim(To_Char(A.警示上限, C.格式)) || ' || ' Decode(A.临床特征, Null, '''', ''成人'', '''', ''婴儿'','''', '' '' || A.临床特征) As 危急参考,a.警示下限,a.警示上限,
             nvl(b.多参考,0) 多参考 ' || ' From 检验项目参考 A, 检验项目 B, ' || ' (Select ''9999990'' || ' || 
           ' Decode(Max(Nvl(C.小数位数, -1)), 0, '''', -1, ''.00'', Substr(''.000000'', 1, 1 + Max(Nvl(C.小数位数, -1)))) As 格式 ' || 
           ' From 检验仪器项目 C, 检验项目 D ' || ' Where D.诊治项目ID = :项目ID And D.诊治项目ID = C.项目ID(+)) C ' || 
           ' Where A.项目ID = :项目ID And A.项目ID = B.诊治项目ID '; 
 
  v_项目id_Bound := 项目id_In; 
 
  v_年龄 := 年龄_In; 
  If v_年龄 = '岁' Then 
    v_年龄 := Null; 
  End If; 
 
  If v_年龄 = '月' Then 
    v_年龄 := Null; 
  End If; 
 
  If v_年龄 = '小时' Then 
    v_年龄 := Null; 
  End If; 
 
  If v_年龄 = '天' Then 
    v_年龄 := Null; 
  End If; 
 
  If Nvl(标本类型_In, '') <> '' Or 标本类型_In Is Not Null Then 
    v_Sql := v_Sql || ' And A.标本类型 = :标本类型 '; 
  Else 
    v_Sql := v_Sql || ' And (A.标本类型 = :标本类型 or 1=1) '; 
  End If; 
  v_标本类型_Bound := 标本类型_In; 
 
  If Nvl(性别_In, '') <> '' Or 性别_In Is Not Null Then 
    --V_Sql := V_Sql || ' And A.性别域 = Nvl(' || 性别_In || ', 1) '; 
    v_Sql := v_Sql || ' And decode(A.性别域,null,:性别,0,:性别,A.性别域) = Nvl(:性别, 1) '; 
 
  Else 
    v_Sql := v_Sql || ' And (decode(A.性别域,null,:性别1,0,:性别2,A.性别域) = Nvl(:性别3, 1) or 1 = 1) '; 
  End If; 
  v_性别域1_Bound := 性别_In; 
  v_性别域2_Bound := 性别_In; 
  v_性别域3_Bound := 性别_In; 
 
  If Nvl(仪器id_In, '') <> '' Or 仪器id_In Is Not Null Then 
    v_Sql := v_Sql || ' And (A.仪器id = :仪器ID Or A.仪器id Is Null) '; 
  Else 
    v_Sql := v_Sql || ' And (A.仪器id = :仪器ID Or A.仪器id Is Null or 1=1) '; 
  End If; 
  v_仪器id_Bound := 仪器id_In; 
 
  If Nvl(v_年龄, '') <> '' Or v_年龄 Is Not Null Then 
    If Instr(v_年龄, '岁') > 0 Or Instr(v_年龄, '月') > 0 Or Instr(v_年龄, '天') > 0 Or Instr(v_年龄, '小时') > 0 Or 
       Sub_Is_Number(v_年龄) Then 
      --处理日期 
      v_出生日期 := 出生日期_In; 
      v_年龄_1   := v_年龄; 
      If Instr(v_年龄_1, '岁') > 0 Then 
        v_年龄   := Substr(v_年龄_1, 1, Instr(v_年龄_1, '岁')); 
        v_年龄_2 := Substr(v_年龄_1, Instr(v_年龄_1, '岁') + 1); 
      Elsif Instr(v_年龄, '月') > 0 Then 
        v_年龄   := Substr(v_年龄_1, 1, Instr(v_年龄_1, '月')); 
        v_年龄_2 := Substr(v_年龄_1, Instr(v_年龄_1, '月') + 1); 
      Elsif Instr(v_年龄, '小时') > 0 Then 
        v_年龄   := Substr(v_年龄_1, 1, Instr(v_年龄_1, '小时') + 1); 
        v_年龄_2 := Substr(v_年龄_1, Instr(v_年龄_1, '小时') + 2); 
        If v_年龄 = '0小时' Or v_年龄 = '0时' Then 
          v_年龄 := ' '; 
        End If; 
      End If; 
      If v_年龄 Is Not Null And (v_年龄 = '成人' Or v_年龄 = '婴儿' Or v_年龄 = '岁') = False Then 
        If Substr(v_年龄, 1, 1) = '*' Then 
          v_出生日期 := Add_Months(d_Sysdate, -216); 
        Else 
          If Substr(v_年龄, Length(v_年龄)) = '月' Then 
            v_出生日期 := Add_Months(d_Sysdate, -1 * Nvl(Zlval(v_年龄), 0)); 
          Else 
            If Substr(v_年龄, Length(v_年龄)) = '天' Then 
              v_出生日期 := d_Sysdate - Nvl(Zlval(v_年龄), 0); 
            Else 
              If Substr(v_年龄, Length(v_年龄) - 1) = '小时' Then 
                If Nvl(Zlval(v_年龄), 0) <> 0 Then 
                  v_出生日期 := d_Sysdate - Nvl(Zlval(v_年龄), 0) / 24; 
                End If; 
              Else 
                v_出生日期 := Add_Months(d_Sysdate, -12 * Nvl(Zlval(v_年龄), 0)) - 1; 
              End If; 
            End If; 
          End If; 
          If v_年龄_2 Is Not Null Then 
            If Substr(v_年龄_2, Length(v_年龄_2)) = '月' Then 
              v_出生日期 := Add_Months(v_出生日期, -1 * Nvl(Zlval(v_年龄_2), 0)); 
            Else 
              If Substr(v_年龄_2, Length(v_年龄_2)) = '天' Then 
                v_出生日期 := v_出生日期 - Nvl(Zlval(v_年龄_2), 0); 
              Else 
                If Substr(v_年龄_2, Length(v_年龄_2) - 1) = '小时' Then 
                  If Nvl(Zlval(v_年龄_2), 0) <> 0 Then 
                    v_出生日期 := v_出生日期 - Nvl(Zlval(v_年龄_2), 0) / 24; 
                  End If; 
                End If; 
              End If; 
            End If; 
          End If; 
        End If; 
      End If; 
      If Not (v_出生日期 Is Null) Then 
        v_年数 := Round(Months_Between(d_Sysdate, v_出生日期) / 12 ,1); 
        v_月数 := Round(Months_Between(d_Sysdate, v_出生日期) ,1); 
        v_日数 := Round(d_Sysdate - v_出生日期 ,1); 
        v_小时 := Round((d_Sysdate - (v_出生日期 - 1 / 24)) * 24 - 1); 
      End If; 
      v_Sql := v_Sql || 'And (Decode(A.年龄单位, ''日'',:日, ''月'',:月,''小时'',:小时,:年) ' || 
               ' Between Nvl(A.年龄下限, -9999) And Nvl(A.年龄上限, 9999) )'; 
    Else 
      v_Sql := v_Sql || 'And (Decode(A.年龄单位, ''日'',:日, ''月'',:月,''小时'',:小时,:年) ' || 
               ' Between Nvl(A.年龄下限, -9999) And Nvl(A.年龄上限, 9999) or 1=1 )'; 
    End If; 
 
  Else 
    v_Sql := v_Sql || 'And (Decode(A.年龄单位, ''日'',:日, ''月'',:月,''小时'',:小时,:年) ' || 
             ' Between Nvl(A.年龄下限, -9999) And Nvl(A.年龄上限, 9999) or 1=1 )'; 
  End If; 
  v_年龄单位日_Bound   := v_日数; 
  v_年龄单位月_Bound   := v_月数; 
  v_年龄单位小时_Bound := v_小时; 
  v_年龄单位年_Bound   := v_年数; 
  If Instr(v_年龄, '成人') > 0 Or Instr(v_年龄, '婴儿') > 0 Or Instr(v_年龄, '分钟') > 0 Then 
    --处理成人和婴儿 
    v_Sql := v_Sql || ' And A.临床特征 =:年龄'; 
  Else 
    v_Sql := v_Sql || ' And (A.临床特征 =:年龄 or 1=1)'; 
    v_Sql := v_Sql || ' And instr(''婴儿,成人'',nvl(临床特征,'' '')) <= 0  '; 
  End If; 
 
  v_临床特征_Bound := Replace(v_年龄, '分钟', '婴儿'); 
 
  If Nvl(申请科室id_In, '') <> '' Or 申请科室id_In Is Not Null Then 
    v_Sql := v_Sql || ' And (A.申请科室ID = :申请科室ID Or nvl(A.申请科室ID,0) = 0) '; 
  Else 
    v_Sql := v_Sql || ' And ((A.申请科室ID = :申请科室ID Or nvl(A.申请科室ID,0) = 0) or 1=1) '; 
  End If; 
  v_申请科室id_Bound := 申请科室id_In; 
 
  If (Nvl(v_年龄, '') = '' Or v_年龄 Is Null) And (出生日期_In <> '' Or 出生日期_In Is Not Null) Then 
    --按出生日期查询 
    If Not (出生日期_In Is Null) Then 
      v_年数 := Round(Months_Between(d_Sysdate, 出生日期_In) / 12 - 0.5); 
      v_月数 := Round(Months_Between(d_Sysdate, 出生日期_In) - 0.5); 
      v_日数 := Round(d_Sysdate - 出生日期_In - 0.5); 
      v_小时 := Round((d_Sysdate - (出生日期_In - 1 / 24)) * 24 - 1); 
 
      v_Sql := v_Sql || 'And (Decode(A.年龄单位, ''日'',:日, ''月'',:月,''小时'',:小时,:年) ' || 
               ' Between Nvl(A.年龄下限, -9999) And Nvl(A.年龄上限, 9999) )'; 
    Else 
      v_Sql := v_Sql || 'And (Decode(A.年龄单位, ''日'',:日, ''月'',:月,''小时'',:小时,:年) ' || 
               ' Between Nvl(A.年龄下限, -9999) And Nvl(A.年龄上限, 9999) or 1=1 )'; 
    End If; 
 
  Else 
    v_Sql := v_Sql || 'And (Decode(A.年龄单位, ''日'',:日, ''月'',:月,''小时'',:小时,:年) ' || 
             ' Between Nvl(A.年龄下限, -9999) And Nvl(A.年龄上限, 9999) or 1=1 )'; 
  End If; 
  v_年龄单位日1_Bound   := v_日数; 
  v_年龄单位月1_Bound   := v_月数; 
  v_年龄单位小时1_Bound := v_小时; 
  v_年龄单位年1_Bound   := v_年数; 
 
  --加上排序 
  v_Sql := v_Sql || ' Order By a.默认 desc,A.临床特征 '; 
 
  If Nvl(申请科室id_In, '') <> '' Or 申请科室id_In Is Not Null Then 
    v_Sql := v_Sql || ' ,a.申请科室ID  '; 
  End If; 
 
  If Nvl(性别_In, '') <> '' Or 性别_In Is Not Null Then 
    v_Sql := v_Sql || ' ,a.性别域 desc  '; 
  Else 
    v_Sql := v_Sql || ' ,a.性别域 '; 
  End If; 
 
  v_Sql := v_Sql || ' ,a.id '; 
 
  v_Return := ''; 
  Open Cur For v_Sql 
    Using v_项目id_Bound, v_项目id_Bound, v_标本类型_Bound, v_性别域1_Bound, v_性别域2_Bound, v_性别域3_Bound, v_仪器id_Bound, v_年龄单位日_Bound, v_年龄单位月_Bound, v_年龄单位小时_Bound, v_年龄单位年_Bound, v_临床特征_Bound, v_申请科室id_Bound, v_年龄单位日1_Bound, v_年龄单位月1_Bound, v_年龄单位小时1_Bound, v_年龄单位年1_Bound; 
 
  Loop 
    Fetch Cur 
      Into r_Emp; 
    Exit When Cur%NotFound; 
    If Cur%RowCount > 0 Then 
 
      v_结果类型 := r_Emp.结果类型; 
      v_Valuerec := r_Emp.取值序列; 
      v_参考id   := r_Emp.Id; 
      v_多参考   := r_Emp.多参考; 
 
      If Nvl(v_Return, '') = '' Or v_Return Is Null Then 
        If Type_In = 2 Then 
          v_Return := r_Emp.危急参考; 
        Else 
          v_Return := r_Emp.结果参考; 
        End If; 
      Else 
        If Type_In = 2 Then 
          v_Return := v_Return || Chr(13) || Chr(10) || r_Emp.危急参考; 
        Else 
          If v_多参考 = 1 Then 
            v_Return := v_Return || Chr(13) || Chr(10) || r_Emp.结果参考; 
          End If; 
        End If; 
      End If; 
 
      --只增加第一个选出的警示参考 
      If v_警示下限 = '' Or v_警示下限 Is Null Then 
        v_警示下限 := r_Emp.警示下限; 
      End If; 
      If v_警示上限 = '' Or v_警示上限 Is Null Then 
        v_警示上限 := r_Emp.警示上限; 
      End If; 
    End If; 
  End Loop; 
 
  If v_Return = '' Or v_Return Is Null Then 
    Begin 
      Select 结果参考, 结果类型, 取值序列, ID, 危急参考, 警示下限, 警示上限 
      Into v_结果参考, v_结果类型, v_Valuerec, v_参考id, v_危紧参考, v_警示下限, v_警示上限 
      From (Select a.Id, 
                    Trim(To_Char(a.参考低值, c.格式)) || '～' || Trim(To_Char(a.参考高值, c.格式)) || 
                     Decode(a.临床特征, Null, '', '成人', '', '婴儿', '', ' ' || a.临床特征) As 结果参考, b.结果类型, b.取值序列, 
                    Trim(To_Char(a.警示下限, c.格式)) || '～' || Trim(To_Char(a.警示上限, c.格式)) || 
                     Decode(a.临床特征, Null, '', '成人', '', '婴儿', '', ' ' || a.临床特征) As 危急参考, a.警示下限, a.警示上限 
             From 检验项目参考 A, 检验项目 B, 
                  (Select '9999990' || 
                            Decode(Max(Nvl(c.小数位数, -1)), 0, '', -1, '.00', Substr('.000000', 1, 1 + Max(Nvl(c.小数位数, -1)))) As 格式 
                    From 检验仪器项目 C, 检验项目 D 
                    Where d.诊治项目id = 项目id_In And d.诊治项目id = c.项目id(+)) C 
             Where a.项目id = 项目id_In And a.项目id = b.诊治项目id 
             Order By a.默认 Desc, a.临床特征, a.性别域) 
      Where Rownum = 1; 
      If Type_In = 2 Then 
        v_Return := v_危紧参考; 
      Else 
        v_Return := v_结果参考; 
      End If; 
      --只增加第一个选出的警示参考 
      If v_警示下限 = '' Or v_警示下限 Is Null Then 
        v_警示下限 := r_Emp.警示下限; 
      End If; 
      If v_警示上限 = '' Or v_警示上限 Is Null Then 
        v_警示上限 := r_Emp.警示上限; 
      End If; 
    Exception 
      When Others Then 
        v_Return := Null; 
    End; 
  End If; 
  If v_Return <> '' Or v_Return Is Not Null Then 
 
    If v_Return = '～' Then 
      v_Return := ''; 
    Else 
      If v_结果类型 = 2 Then 
        v_Pos := Instr(v_Return, '～'); 
 
        Begin 
          Select To_Number(Substr(v_Return, 1, v_Pos - 1)) Into v_Value From Dual; 
        Exception 
          When Others Then 
            v_Value := 0; 
        End; 
        v_Return := Zlsplit(v_Valuerec, ';', v_Value); 
      End If; 
    End If; 
    If Type_In = 0 Then 
      Return v_Return; 
    Elsif Type_In = 1 Then 
      Return v_参考id; 
    Elsif Type_In = 2 Then 
      Return v_Return; 
    Elsif Type_In = 3 Then 
      Return v_警示下限; 
    Elsif Type_In = 4 Then 
      Return v_警示上限; 
    End If; 
  End If; 
  Close Cur; --关闭游标 
  Return v_Return; 
End Zl_Get_Reference;
/

