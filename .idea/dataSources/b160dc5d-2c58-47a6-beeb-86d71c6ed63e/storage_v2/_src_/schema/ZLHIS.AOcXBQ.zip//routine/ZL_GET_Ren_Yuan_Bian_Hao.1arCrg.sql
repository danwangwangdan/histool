create Function       Zl_get_人员编号
(姓名_in 人员表.姓名%type
)
------------------------------------------------------------------------------------
  --功能：根据指定人员姓名获取人员编号
  --------------------------------------------------------------------------------------
 Return Varchar2 Is
  Err_Item Exception;
  v_Err_Msg Varchar2(100);
  v_人员编号 人员表.编号%Type ;
Begin
  v_人员编号 :='-';
  Select nvl(编号,'-') Into v_人员编号 From 人员表  Where 姓名=姓名_in ;
  Return v_人员编号;
Exception
  When Others Then
    Return '-';
End Zl_get_人员编号;


/

