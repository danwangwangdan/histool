create Function Zl_Get_输血执行血型(医嘱id_In In 病人医嘱记录.Id%Type) Return Varchar2 Is 
  v_血型 血型.名称%Type; 
Begin 
  Select Max(血型) 
  Into v_血型 
  From (Select Distinct Decode(a.Abo, 'A型', 'A', 'B型', 'B', 'AB型', 'AB', 'O型', 'O', Null) As 血型 
         From 血液收发记录 a, 血液配血记录 c, (Select 病人id, 主页id, 病人来源 From 病人医嘱记录 Where Id = 医嘱id_In) b 
         Where a.配发id = c.Id And a.单据 = 6 And c.病人id = b.病人id And Nvl(c.主页id, 0) = Nvl(b.主页id, 0) And c.病人来源 = b.病人来源 And 
               c.申请id = 医嘱id_In) 
  Where Rownum < 2; 
  Return(v_血型); 
Exception 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
End;
/

