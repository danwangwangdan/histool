create Function zl_hlht_地址_出生地(
病人id_in In 病人信息.病人id%type,
默认值_in In Varchar2

) Return Varchar2 Is
  --返回结构：地址代码 只返回到县
  v_省       Varchar2(100);
  v_Code省   Varchar2(15);
  v_Info省   Varchar2(150);
  v_市       Varchar2(100);
  v_Code市   Varchar2(15);
  v_Info市   Varchar2(150);
  v_区县     Varchar2(100);
  v_Code区县 Varchar2(15);
  v_Info区县 Varchar2(150);
  v_乡镇     Varchar2(100);
  v_Code乡镇 Varchar2(15);
  v_Info乡镇 Varchar2(150);
  v_街道     Varchar2(500);
  v_Code街道 Varchar2(15);
  v_Info街道 Varchar2(550);
  v_Tmp      Varchar2(100);
  v_Adrstmp  Varchar2(500);
  n_Pos      Number(5);
  n_虚拟     Number(1);
  n_不显示   Number(1);
  n_Count    Number(3);
  v_Return   Varchar2(700);
Begin
  v_Return :='' ;
  n_Count :=0 ;
  /*Begin
        Select 省,市,县 Into v_省,v_市,v_区县 From 病人地址信息  Where 病人id=病人id_in  And 地址类别=1 ;
   Exception
      When Others Then
    			 v_省 :='' ;
           v_市 :='' ;
           v_区县 :='' ;
  End;
  If v_省 Is Not Null Or v_市 Is Not Null Or v_区县 Is Not Null Then
      If v_区县 Is Not Null Then
          Select Count(*) Into n_Count  From 区域  Where 名称 Like v_区县 || '%' And 级数=2 ;
          If n_Count = 1 Then
             Select substr(编码,1,6)  Into v_Return  From 区域  Where 名称 Like  v_区县 || '%' And 级数=2  ;
             Return(v_Return);
          End If ;
          If n_count=0 Then




             Select Count(*) Into n_count From 区域  Where 名称 Like v_市 || '%' And 级数=1  ;
             If n_count = 1 Then
                Select  substr(编码,1,6) Into v_Return From 区域 Where 名称 Like v_市 || '%' And 级数=1  ;
                Return(v_Return);
             End If ;
             If n_count=0 Then
                 Select Count(*) Into n_count From 区域  Where 名称 Like v_省 || '%' And 级数 Is Null ;
                 If n_count = 1 Then
                    Select  substr(编码,6) Into v_Return From 区域 Where 名称 Like v_省 || '%' And 级数 Is Null   ;
                    Return(v_Return);
                 End If ;
             End If ;
          End If ;
          If n_count > 1 Then
             Select Count(*) Into n_count  From 区域  Where 名称 Like  v_市 || '%' And 级数=1  ;
             If n_count=1 Then
                 Select substr(a.编码,1,6)  Into v_Return  From 区域 a ,区域 b Where a.名称 Like v_区县 || '%' And b.名称 Like v_市 || '%'
                        And a.级数=2 And a.级数=1 And a.上级编码=b.编码  ;
                  Return(v_Return);
             Else
                 Select count(*) Into n_count From 区域 Where 名称 = v_省 And 级数 Is Null ;
                 If n_count=1 Then
                    Select substr(a.编码,1,6) Into v_Return From 区域 a ,(Select substr(b.编码,1,2) As 编码 From 区域 b Where b.名称 = v_省 And b.级数 Is Null ) b
                    Where substr(a.编码,1,2)= b.编码 And a.级数=2 And a.名称 Like v_区县 || '%' ;
                    Return(v_Return);
                 End If ;
             End If ;
          End If ;
      End If ;
      If v_市 Is Not Null  Then
         Select Count(*) Into n_count  From 区域  Where 名称= v_市 ;
         If n_count = 1 Then
             Select substr(a.编码,1,6)  Into v_Return  From 区域 a   Where a.名称= v_市 ;
             Return(v_Return);
         End If ;
      End If ;
      If v_省 Is Not Null  Then
         Select substr(a.编码,1,6)  Into v_Return  From 区域 a   Where a.名称= v_省 ;
         Return(v_Return);
      End If ;
       v_Return :=默认值_in ;
      Return(v_Return);
  Else*/
      Select 出生地点 Into v_adrstmp   From  病人信息  Where 病人id=病人id_in ;
      --- 地址空直接返回默认值
      If v_adrstmp Is Null Then
         v_Return := 默认值_in ;
         Return(v_Return);
      End If ;
      If v_adrstmp Like '%本地%' Then
         v_Return := 默认值_in ;
         Return(v_Return);
      End If ;
      --- 取省级信息
      Select Count(*) Into n_count  From 区域  Where 名称 Like substr(v_adrstmp,1,2) || '%' And 级数 Is Null  ;
      --- 取到省级信息
      If n_count=1 Then
        --- 取省级名称,编码
         Select   名称 ,substr(编码,1,2)  Into  v_省,v_code省 From 区域  Where 名称 Like substr(v_adrstmp,1,2) || '%' And 级数 Is Null ;
         ---替换省级名称
         v_adrstmp := Replace(v_adrstmp,v_省,'') ;
         --- 取市级信息
         Select Count(*)  Into n_count From 区域   Where 名称 Like substr(v_adrstmp,1,2) || '%' And 编码 Like v_code省 || '%' And 级数=1   ;
          --- 取到市级信息
          If n_count=1 Then
            Select  名称 ,substr(编码,1,4)  Into  v_市,v_code市 From 区域   Where 名称 Like substr(v_adrstmp,1,2) || '%' And 编码 Like v_code省 || '%' And 级数=1 ;
              ---替换市级信息
             v_adrstmp :=replace(v_adrstmp,v_市,'') ;
             If v_adrstmp Is Null Then
                v_Return := v_code市 || '00' ;
                Return(v_Return);
             End If ;
             ---取县级信息
             Select Count(*)  Into n_count  From 区域   Where 名称 Like substr(v_adrstmp,1,2) || '%' And 编码 Like v_code市 || '%' And 级数=2   ;
             ---取到唯一县级信息
             If n_count=1 Then
                Select 名称 ,substr(编码,1,6)  Into v_区县,v_code区县 From 区域 Where 名称 Like substr(v_adrstmp,1,2) || '%' And 编码 Like v_code市 || '%' And 级数=2 ;
                v_Return := v_code区县 ;
                Return(v_Return);
             Elsif n_count=0 Then
                v_Return := v_code市 || '00' ;
                Return(v_Return);
             ---取到多条县级信息,字数可能性太多了,通过关键字截取获取县级信息,包含关键字但是有取不到唯一值则直接返回市级信息
             Else
                If instr(v_adrstmp,'市') > 0 Then
                   Select count(*)  Into n_count  From 区域  Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'市')  ) And 编码 Like  v_code市 || '%' And 级数=2  ;
                   If n_count=1 Then
                      Select 名称 , substr(编码,1,6) Into  v_区县,v_code区县 From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'市')  ) And 编码 Like  v_code市 || '%' And 级数=2   ;
                      v_Return := v_code区县 ;
                      Return(v_Return);
                   Else
                       v_Return := v_code市 || '00' ;
                       Return(v_Return);
                   End If ;
                End If ;
                If instr(v_adrstmp,'区') > 0 Then
                   Select count(*)  Into n_count  From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'区')  ) And 编码 Like  v_code市 || '%' And 级数=2  ;
                   If n_count=1 Then
                      Select 名称 , substr(编码,1,6) Into  v_区县,v_code区县 From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'区')  ) And 编码 Like  v_code市 || '%' And 级数=2   ;
                      v_Return := v_code区县 ;
                      Return(v_Return);
                   Else
                       v_Return := v_code市 || '00' ;
                       Return(v_Return);
                   End If ;
                End If ;
                If instr(v_adrstmp,'县') > 0 Then
                   Select count(*)  Into n_count  From 区域  Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'县')  ) And 编码 Like  v_code市 || '%' And 级数=2 ;
                   If n_count=1 Then
                      Select 名称 , substr(编码,1,6) Into  v_区县,v_code区县 From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'县')  ) And 编码 Like  v_code市 || '%' And 级数=2   ;
                      v_Return := v_code区县 ;
                      Return(v_Return);
                   Else
                       v_Return := v_code市 || '00' ;
                       Return(v_Return);
                   End If ;
                End If ;
                If instr(v_adrstmp,'旗') > 0 Then
                   Select count(*)  Into n_count  From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'旗')  ) And 编码 Like  v_code市 || '%' And 级数=2 ;
                   If n_count=1 Then
                      Select 名称 , substr(编码,1,6) Into  v_区县,v_code区县 From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'旗')  ) And 编码 Like  v_code市 || '%' And 级数=2   ;
                      v_Return := v_code区县 ;
                      Return(v_Return);
                   Else
                       v_Return := v_code市 || '00' ;
                       Return(v_Return);
                   End If ;
                End If ;
                If instr(v_adrstmp,'群岛') > 0 Then
                   Select count(*)  Into n_count  From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'群岛') + 1   ) And 编码 Like  v_code市 || '%' And 级数=2  ;
                   If n_count=1 Then
                      Select 名称 , substr(编码,1,6) Into  v_区县,v_code区县 From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'群岛') + 1  ) And 编码 Like  v_code市 || '%' And 级数=2   ;
                      v_Return := v_code区县 ;
                      Return(v_Return);
                   Else
                       v_Return := v_code市 || '00' ;
                       Return(v_Return);
                   End If ;
                End If ;
             End If ;


          --取到多条市级信息,目前没有,以后有在加
          Elsif n_count >1 Then
              v_Return := v_code省 || '0000' ;
              Return(v_Return);
          --- 取不到市级信息   ,直辖市,或者操作员没有填写市级信息填写类似身份证地址
          Else
              v_adrstmp :=replace(v_adrstmp,v_省,'') ;
              If v_adrstmp Is Null Then
                 v_Return := v_code省 || '0000' ;
                 Return(v_Return);
              End If ;
             Select Count(*)   Into n_count  From 区域  Where 名称 Like substr(v_adrstmp,1,2) || '%' And 编码 Like v_code省 || '%' And 级数=2   ;
             If n_count=1 Then
                 Select  名称 ,substr(编码,1,6)  Into v_区县,v_code区县 From 区域 Where 名称 Like substr(v_adrstmp,1,2) || '%' And 编码 Like v_code省 || '%' And 级数=2  ;
                v_Return := v_code区县 ;
                Return(v_Return);
             Elsif n_count=0 Then
                v_Return := v_code省 || '0000' ;
                Return(v_Return);
             Else
                If instr(v_adrstmp,'市') > 0 Then
                   Select count(*)  Into n_count From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'市')  ) And 编码 Like  v_code省 || '%' And 级数=2  ;
                   If n_count=1 Then
                      Select  名称 , substr(编码,1,6) Into  v_区县,v_code区县 From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'市')  ) And 编码 Like  v_code省 || '%' And 级数=2  ;
                      v_Return := v_code区县 ;
                      Return(v_Return);
                   Else
                       v_Return := v_code省 || '0000' ;
                       Return(v_Return);
                   End If ;
                End If ;
                If instr(v_adrstmp,'区') > 0 Then
                   Select count(*)  Into n_count From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'区')  ) And 编码 Like  v_code省 || '%' And 级数=2  ;
                   If n_count=1 Then
                      Select  名称 , substr(编码,1,6) Into  v_区县,v_code区县 From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'区')  ) And 编码 Like  v_code省 || '%' And 级数=2  ;
                      v_Return := v_code区县 ;
                      Return(v_Return);
                   Else
                       v_Return := v_code省 || '0000' ;
                       Return(v_Return);
                   End If ;
                End If ;
                If instr(v_adrstmp,'县') > 0 Then
                   Select count(*)  Into n_count From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'县')  ) And 编码 Like  v_code省 || '%' And 级数=2  ;
                   If n_count=1 Then
                      Select  名称 , substr(编码,1,6) Into  v_区县,v_code区县 From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'县')  ) And 编码 Like  v_code省 || '%' And 级数=2  ;
                      v_Return := v_code区县 ;
                      Return(v_Return);
                   Else
                       v_Return := v_code省 || '0000' ;
                       Return(v_Return);
                   End If ;
                End If ;
                If instr(v_adrstmp,'旗') > 0 Then
                   Select count(*)  Into n_count From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'旗')  ) And 编码 Like  v_code省 || '%' And 级数=2  ;
                   If n_count=1 Then
                      Select  名称 , substr(编码,1,6) Into  v_区县,v_code区县 From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'旗')  ) And 编码 Like  v_code省 || '%' And 级数=2  ;
                      v_Return := v_code区县 ;
                      Return(v_Return);
                   Else
                       v_Return := v_code省 || '0000' ;
                       Return(v_Return);
                   End If ;
                End If ;
                If instr(v_adrstmp,'群岛') > 0 Then
                   Select count(*)  Into n_count From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'群岛')  ) And 编码 Like  v_code省 || '%' And 级数=2  ;
                   If n_count=1 Then
                      Select  名称 , substr(编码,1,6) Into  v_区县,v_code区县 From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'群岛') + 1  ) And 编码 Like  v_code省 || '%' And 级数=2  ;
                      v_Return := v_code区县 ;
                      Return(v_Return);
                   Else
                       v_Return := v_code省 || '0000' ;
                       Return(v_Return);
                   End If ;
                End If ;
             End If ;
          End If ;
      --- 取不到省级信息,就取市级信息
      Else

         Select Count(*)  Into n_count  From 区域 Where 名称 Like substr(v_adrstmp,1,2) || '%'   And 级数=1  ;
          --- 取到市级信息
          If n_count=1 Then
             Select  名称 ,substr(编码,1,4)  Into v_市,v_code市 From 区域 Where 名称 Like substr(v_adrstmp,1,2) || '%'   And 级数=1  ;
             ---替换市级信息,留下县级信息
             v_adrstmp :=replace(v_adrstmp,v_市,'') ;
             If v_adrstmp Is Null Then
                v_Return := v_code市 || '00' ;
                Return(v_Return);
             End If ;
             ---取县级信息
             Select Count(*)   Into n_count From 区域 Where 名称 Like substr(v_adrstmp,1,2) || '%' And 编码 Like v_code市 || '%' And 级数=2  ;
             If n_count=1 Then
                Select  名称 ,substr(编码,1,6)  Into v_区县,v_code区县 From 区域 Where 名称 Like substr(v_adrstmp,1,2) || '%' And 编码 Like v_code市 || '%' And 级数=2  ;
                v_Return := v_code区县 ;
                Return(v_Return);
             Elsif n_count=0 Then
                v_Return := v_code市 || '00' ;
                Return(v_Return);
             Else
                If instr(v_adrstmp,'市') > 0 Then
                   Select count(*)  Into n_count From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'市')  ) And 编码 Like  v_code市 || '%' And 级数=2  ;
                   If n_count=1 Then
                      Select  名称 , substr(编码,1,6) Into v_区县,v_code区县 From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'市')  ) And 编码 Like  v_code市 || '%' And 级数=2  ;
                      v_Return := v_code区县 ;
                      Return(v_Return);
                   Else
                       v_Return := v_code市 || '00' ;
                       Return(v_Return);
                   End If ;
                End If ;
                If instr(v_adrstmp,'区') > 0 Then
                   Select count(*)  Into n_count From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'区')  ) And 编码 Like  v_code市 || '%' And 级数=2  ;
                   If n_count=1 Then
                      Select  名称 , substr(编码,1,6) Into v_区县,v_code区县 From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'区')  ) And 编码 Like  v_code市 || '%' And 级数=2  ;
                      v_Return := v_code区县 ;
                      Return(v_Return);
                   Else
                       v_Return := v_code市 || '00' ;
                       Return(v_Return);
                   End If ;
                End If ;
                If instr(v_adrstmp,'县') > 0 Then
                   Select count(*)  Into n_count From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'县')  ) And 编码 Like  v_code市 || '%' And 级数=2  ;
                   If n_count=1 Then
                      Select  名称 , substr(编码,1,6) Into v_区县,v_code区县 From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'县')  ) And 编码 Like  v_code市 || '%' And 级数=2  ;
                      v_Return := v_code区县 ;
                      Return(v_Return);
                   Else
                       v_Return := v_code市 || '00' ;
                       Return(v_Return);
                   End If ;
                End If ;
                If instr(v_adrstmp,'旗') > 0 Then
                   Select count(*)  Into n_count From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'旗')  ) And 编码 Like  v_code市 || '%' And 级数=2  ;
                   If n_count=1 Then
                      Select  名称 , substr(编码,1,6) Into v_区县,v_code区县 From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'旗')  ) And 编码 Like  v_code市 || '%' And 级数=2  ;
                      v_Return := v_code区县 ;
                      Return(v_Return);
                   Else
                       v_Return := v_code市 || '00' ;
                       Return(v_Return);
                   End If ;
                End If ;
                If instr(v_adrstmp,'群岛') > 0 Then
                   Select count(*)  Into n_count From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'群岛') + 1  ) And 编码 Like  v_code市 || '%' And 级数=2  ;
                   If n_count=1 Then
                      Select  名称 , substr(编码,1,6) Into v_区县,v_code区县 From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'群岛') + 1   ) And 编码 Like  v_code市 || '%' And 级数=2  ;
                      v_Return := v_code区县 ;
                      Return(v_Return);
                   Else
                       v_Return := v_code市 || '00' ;
                       Return(v_Return);
                   End If ;
                End If ;
             End If ;


          --取到多条信息
          Elsif n_count >1 Then
             Select Count(*) Into n_count From 区域 Where 名称 Like substr(v_adrstmp,1,3) || '%'   And 级数=1 ;
              --- 取到市级信息
              If n_count=1 Then
                 Select  名称 ,substr(编码,1,4)  Into v_市,v_code市 From 区域 Where 名称 Like substr(v_adrstmp,1,3) || '%'   And 级数=1 ;
                 v_adrstmp :=replace(v_adrstmp,v_市,'') ;
                 Select Count(*) Into n_count From 区域 Where 名称 Like substr(v_adrstmp,1,2) || '%' And 编码 Like v_code市 || '%' And 级数=2 ;
                 If n_count=1 Then
                    Select 名称 ,substr(编码,1,6)  Into v_区县,v_code区县 From 区域 Where 名称 Like substr(v_adrstmp,1,2) || '%' And 编码 Like v_code市 || '%' And 级数=2 ;
                    v_Return := v_code区县 ;
                    Return(v_Return);
                 Elsif n_count=0 Then
                    v_Return := v_code市 || '00' ;
                    Return(v_Return);
                 Else
                    If instr(v_adrstmp,'市') > 0 Then
                       Select count(*)  Into n_count From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'市')  ) And 编码 Like  v_code市 || '%' And 级数=2  ;
                       If n_count=1 Then
                          Select 名称 , substr(编码,1,6) Into  v_区县,v_code区县 From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'市')  ) And 编码 Like  v_code市 || '%' And 级数=2  ;
                          v_Return := v_code区县 ;
                          Return(v_Return);
                       Else
                           v_Return := v_code市 || '00' ;
                           Return(v_Return);
                       End If ;
                    End If ;
                    If instr(v_adrstmp,'区') > 0 Then
                       Select count(*)  Into n_count From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'区')  ) And 编码 Like  v_code市 || '%' And 级数=2  ;
                       If n_count=1 Then
                          Select 名称 , substr(编码,1,6) Into  v_区县,v_code区县 From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'区')  ) And 编码 Like  v_code市 || '%' And 级数=2  ;
                          v_Return := v_code区县 ;
                          Return(v_Return);
                       Else
                           v_Return := v_code市 || '00' ;
                           Return(v_Return);
                       End If ;
                    End If ;
                    If instr(v_adrstmp,'县') > 0 Then
                       Select count(*)  Into n_count From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'县')  ) And 编码 Like  v_code市 || '%' And 级数=2  ;
                       If n_count=1 Then
                          Select 名称 , substr(编码,1,6) Into  v_区县,v_code区县 From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'县')  ) And 编码 Like  v_code市 || '%' And 级数=2  ;
                          v_Return := v_code区县 ;
                          Return(v_Return);
                       Else
                           v_Return := v_code市 || '00' ;
                           Return(v_Return);
                       End If ;
                    End If ;
                    If instr(v_adrstmp,'旗') > 0 Then
                       Select count(*)  Into n_count From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'旗')  ) And 编码 Like  v_code市 || '%' And 级数=2  ;
                       If n_count=1 Then
                          Select 名称 , substr(编码,1,6) Into  v_区县,v_code区县 From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'旗')  ) And 编码 Like  v_code市 || '%' And 级数=2  ;
                          v_Return := v_code区县 ;
                          Return(v_Return);
                       Else
                           v_Return := v_code市 || '00' ;
                           Return(v_Return);
                       End If ;
                    End If ;
                    If instr(v_adrstmp,'群岛') > 0 Then
                       Select count(*)  Into n_count From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'群岛') + 1  ) And 编码 Like  v_code市 || '%' And 级数=2  ;
                       If n_count=1 Then
                          Select 名称 , substr(编码,1,6) Into  v_区县,v_code区县 From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'群岛') + 1  ) And 编码 Like  v_code市 || '%' And 级数=2  ;
                          v_Return := v_code区县 ;
                          Return(v_Return);
                       Else
                           v_Return := v_code市 || '00' ;
                           Return(v_Return);
                       End If ;
                    End If ;
                 End If ;
              Else

                  v_Return := 默认值_in ;
                  Return(v_Return);
              End If ;
          --- 取不到市级信息  , 取县级信息
          Else

             Select Count(*)  Into n_count From 区域 Where 名称 Like substr(v_adrstmp,1,2) || '%'  And 级数=2 ;
             If n_count=1 Then
                Select  名称 ,substr(编码,1,6)  Into v_区县,v_code区县 From 区域 Where 名称 Like substr(v_adrstmp,1,2) || '%'  And 级数=2 ;
                v_Return := v_code区县 ;
                Return(v_Return);
             Elsif n_count=0 Then
                v_Return := 默认值_in ;
                Return(v_Return);
             Else
                If instr(v_adrstmp,'市') > 0 Then
                   Select count(*) Into n_count  From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'市')  ) And 编码 Like  v_code省 || '%' And 级数=2   ;
                   If n_count=1 Then
                      Select 名称 , substr(编码,1,6) Into v_区县,v_code区县 From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'市')  ) And 编码 Like  v_code省 || '%' And 级数=2   ;
                      v_Return := v_code区县 ;
                      Return(v_Return);
                   Else
                       v_Return := 默认值_in ;
                       Return(v_Return);
                   End If ;
                End If ;
                If instr(v_adrstmp,'区') > 0 Then
                   Select count(*) Into n_count  From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'区')  ) And 编码 Like  v_code省 || '%' And 级数=2   ;
                   If n_count=1 Then
                      Select 名称 , substr(编码,1,6) Into v_区县,v_code区县 From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'区')  ) And 编码 Like  v_code省 || '%' And 级数=2   ;
                      v_Return := v_code区县 ;
                      Return(v_Return);
                   Else
                       v_Return := 默认值_in ;
                       Return(v_Return);
                   End If ;
                End If ;
                If instr(v_adrstmp,'县') > 0 Then
                   Select count(*) Into n_count  From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'县')  ) And 编码 Like  v_code省 || '%' And 级数=2   ;
                   If n_count=1 Then
                      Select 名称 , substr(编码,1,6) Into v_区县,v_code区县 From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'县')  ) And 编码 Like  v_code省 || '%' And 级数=2   ;
                      v_Return := v_code区县 ;
                      Return(v_Return);
                   Else
                       v_Return := 默认值_in ;
                       Return(v_Return);
                   End If ;
                End If ;
                If instr(v_adrstmp,'旗') > 0 Then
                   Select count(*) Into n_count  From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'旗')  ) And 编码 Like  v_code省 || '%' And 级数=2   ;
                   If n_count=1 Then
                      Select 名称 , substr(编码,1,6) Into v_区县,v_code区县 From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'旗')  ) And 编码 Like  v_code省 || '%' And 级数=2   ;
                      v_Return := v_code区县 ;
                      Return(v_Return);
                   Else
                       v_Return := 默认值_in ;
                       Return(v_Return);
                   End If ;
                End If ;
                If instr(v_adrstmp,'群岛') > 0 Then
                   Select count(*) Into n_count  From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'群岛') + 1  ) And 编码 Like  v_code省 || '%' And 级数=2   ;
                   If n_count=1 Then
                      Select 名称 , substr(编码,1,6) Into v_区县,v_code区县 From 区域 Where 名称 Like substr(v_adrstmp,1,instr(v_adrstmp,'群岛') + 1  ) And 编码 Like  v_code省 || '%' And 级数=2   ;
                      v_Return := v_code区县 ;
                      Return(v_Return);
                   Else
                       v_Return := 默认值_in ;
                       Return(v_Return);
                   End If ;
                End If ;
             End If ;
          End If ;

      End If ;

      /*
  End If ;*/
  If v_Return Is Null Then
     v_Return :=默认值_in ;
  End If ;

  Return(v_Return);
Exception
      When Others Then
   v_Return := 默认值_in ;
  Return(v_Return);
End;


/

