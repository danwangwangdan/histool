create Function zl_hlht_地址_籍贯(
病人id_in In 病人信息.病人id%type,
默认值_in In Varchar2

) Return Varchar2 Is
  --返回结构：地址代码 只返回到县
  v_省       Varchar2(100);
  v_Code省   Varchar2(15);
  v_Info省   Varchar2(150);
  v_市       Varchar2(100);
  v_Code市   Varchar2(15);
  v_Info市   Varchar2(150);
  v_区县     Varchar2(100);
  v_Code区县 Varchar2(15);
  v_Info区县 Varchar2(150);
  v_乡镇     Varchar2(100);
  v_Code乡镇 Varchar2(15);
  v_Info乡镇 Varchar2(150);
  v_街道     Varchar2(500);
  v_Code街道 Varchar2(15);
  v_Info街道 Varchar2(550);
  v_Tmp      Varchar2(100);
  v_Adrstmp  Varchar2(500);
  n_Pos      Number(5);
  n_虚拟     Number(1);
  n_不显示   Number(1);
  n_Count    Number(3);
  v_Return   Varchar2(700);
Begin
  v_Return :='' ;
  n_Count :=0 ;
  Begin
        Select 籍贯 Into v_区县 From 病人信息  Where 病人id=病人id_in  ;
   Exception
      When Others Then
           v_区县 :='' ;
  End;
      If v_区县 Is Not Null Then
          Select Count(*) Into n_Count  From 区域  Where 名称 Like v_区县 || '%' And 级数=2 ;
          If n_Count = 1 Then
             Select substr(编码,1,6)  Into v_Return  From 区域  Where 名称 Like  v_区县 || '%' And 级数=2  ;
             Return(v_Return);
          End If ;

      End If ;


  If v_Return Is Null Then
     v_Return :=默认值_in ;
  End If ;
  Return(v_Return);
Exception
      When Others Then
   v_Return := 默认值_in ;
  Return(v_Return);
End;
/

