create Function Zl_获取住院次数或主页id 
( 
  病人id_In 病案主页.病人id%Type, 
  次数_In   病案主页.主页id%Type, 
  标识_In   Integer 
) 
-------------------------------------------------------------------------------------------------------------------------------------- 
  --功能:获取住院次数或主页ID 
  --入参: 
  --      病人ID_IN:病人ID值 
  --      次数_IN:当标识_IN为1时传入实际的住院次数(排除了留观病人),当标识_IN为0时,表示传入的是主页id. 
  -- 标识_IN:1-返回指定次数的主页id,0-根据主页id返回住院次数(排除了留观病人) 
  --返回:根据病人ID，返回主页id或实际住院次数 
  -------------------------------------------------------------------------------------------------------------------------------------- 
 
 Return Integer Is 
  n_次数 病案主页.主页id%Type; 
  n_留观 病案主页.主页id%Type; 
Begin 
  If 标识_In = 1 Then 
    --根据住院次数，获取主页id 
    Begin 
      Select Max(主页id) 
      Into n_次数 
      From 病案主页 
      Where 病人id = 病人id_In And Nvl(病人性质, 0) = 0 Having Count(*) <= 次数_In; 
    Exception 
      When Others Then 
        n_次数 := 0; 
    End; 
 
    --IF n_次数=0 THEN 
    --  --获取当前的最大主页id,但要排除留观病人 
    --  SELECT max(主页id) INTO n_次数 
    --  FROM 病案主页 
    --  WHERE 病人id=病人id_In  AND nvl(病人性质,0)=0; 
    --End IF ; 
    Return n_次数; 
  Else 
    --判断是否存在留观病人 
    Begin 
      Select Count(*) 
      Into n_留观 
      From 病案主页 
      Where 病人id = 病人id_In And 主页id <= 次数_In And Nvl(病人性质, 0) <> 0; 
    Exception 
      When Others Then 
        n_留观 := 0; 
    End; 
    If n_留观 > 0 Then 
      --根据主页id，获取实际的住院次数 
      Begin 
        Select Count(*) 
        Into n_次数 
        From 病案主页 
        Where 病人id = 病人id_In And 主页id <= 次数_In And Nvl(病人性质, 0) = 0; 
      Exception 
        When Others Then 
          n_次数 := 0; 
      End; 
    Else 
      --根据住院次数，获取主页id,处理切换系统的情况. 
      Begin 
        Select Max(主页id) 
        Into n_次数 
        From 病案主页 
        Where 病人id = 病人id_In And Nvl(病人性质, 0) = 0 And 主页id <= 次数_In Having Count(*) <= 次数_In; 
      Exception 
        When Others Then 
          n_次数 := 0; 
      End; 
    End If; 
    Return n_次数; 
  End If; 
Exception 
  When Others Then 
    Return 0; 
End Zl_获取住院次数或主页id;
/

