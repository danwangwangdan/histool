create Function Zl_Identity(Type_In Number := 0) 
  --功能:获取当前用户的部门人员信息 
  --参数:Type_In=0:取部门人员信息,1:只取人员信息,2:只取部门信息 
  --返回:0=部门ID,部门名称;人员ID,人员编号,人员姓名 
  --     1=;人员ID,人员编号,人员姓名   为了保持兼容旧的程序,前面有个;号 
  --     2=部门ID,部门名称;           为了保持兼容旧的程序,后面有个;号 
 Return Varchar2 Is 
  V_Identity Varchar2(200); 
Begin 
  If Type_In = 0 Then 
    Select D.Id || ',' || D.名称 || ';' || P.Id || ',' || P.编号 || ',' || P.姓名 
    Into V_Identity 
    From 上机人员表 O, 人员表 P, 部门人员 R, 部门表 D 
    Where O.用户名 = User And O.人员id = P.Id And P.Id = R.人员id And R.缺省 = 1 And R.部门id = D.Id And Rownum < 2; 
  Elsif Type_In = 1 Then 
    Select ';' || P.Id || ',' || P.编号 || ',' || P.姓名 
    Into V_Identity 
    From 上机人员表 O, 人员表 P 
    Where O.用户名 = User And O.人员id = P.Id And Rownum < 2; 
  Else 
    Select D.Id || ',' || D.名称 || ';' 
    Into V_Identity 
    From 上机人员表 O, 部门人员 R, 部门表 D 
    Where O.用户名 = User And O.人员id = R.人员id And R.缺省 = 1 And R.部门id = D.Id And Rownum < 2; 
  End If; 
  Return V_Identity; 
Exception 
  When No_Data_Found Then 
    Begin 
      If Type_In = 2 Then 
        Select D.Id || ',' || D.名称 || ';' 
        Into V_Identity 
        From 上机人员表 O, 部门人员 R, 部门表 D 
        Where O.用户名 = User And O.人员id = R.人员id And R.部门id = D.Id And Rownum < 2; 
      Else 
        Select D.Id || ',' || D.名称 || ';' || P.Id || ',' || P.编号 || ',' || P.姓名 
        Into V_Identity 
        From 上机人员表 O, 人员表 P, 部门人员 R, 部门表 D 
        Where O.用户名 = User And O.人员id = P.Id And P.Id = R.人员id And R.部门id = D.Id And Rownum < 2; 
      End If; 
      Return V_Identity; 
    Exception 
      When No_Data_Found Then 
        Begin 
          V_Identity := ''; 
          Return V_Identity; 
        End; 
    End; 
End;
/

