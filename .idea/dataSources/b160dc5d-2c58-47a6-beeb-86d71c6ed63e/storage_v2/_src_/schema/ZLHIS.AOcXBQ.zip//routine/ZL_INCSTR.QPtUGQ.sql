create FUNCTION ZL_incstr (strval IN VARCHAR2) 
   RETURN VARCHAR2 
AS 
   strtmp   VARCHAR2 (255); 
   bytup    NUMBER        := 0; 
   bytadd   NUMBER; 
BEGIN 
   strtmp := strval; 
 
   FOR i IN REVERSE 1 .. LENGTH (strtmp) 
   LOOP 
      IF i = LENGTH (strtmp) 
      THEN 
         bytadd := 1; 
      ELSE 
         bytadd := 0; 
      END IF; 
 
      IF INSTR ('0123456789', SUBSTR (strtmp, i, 1)) > 0 
      THEN 
         IF TO_NUMBER (SUBSTR (strtmp, i, 1)) + bytadd + bytup < 10 
         THEN 
            strtmp := 
              SUBSTR (strtmp, 1, i - 1) || 
                 (TO_NUMBER (SUBSTR (strtmp, i, 1)) + bytadd + bytup) || 
                 SUBSTR (strtmp, i + 1); 
            bytup := 0; 
         ELSE 
            strtmp := SUBSTR (strtmp, 1, i - 1) || '0' || SUBSTR ( 
                                                             strtmp, 
                                                             i + 1 
                                                          ); 
            bytup := 1; 
         END IF; 
      ELSE 
         IF ASCII (SUBSTR (strtmp, i, 1)) + bytadd + bytup <= 
               ASCII (SUBSTR (strtmp, i, 1)) + 
                  (ASCII ('Z') - ASCII (UPPER (SUBSTR (strtmp, i, 1)))) 
         THEN 
            strtmp := 
              SUBSTR (strtmp, 1, i - 1) || 
                 CHR (ASCII (SUBSTR (strtmp, i, 1)) + bytadd + bytup) || 
                 SUBSTR (strtmp, i + 1); 
            bytup := 0; 
         ELSE 
            strtmp := SUBSTR (strtmp, 1, i - 1) || '0' || SUBSTR ( 
                                                             strtmp, 
                                                             i + 1 
                                                          ); 
            bytup := 1; 
         END IF; 
      END IF; 
 
      IF bytup = 0 
      THEN 
         EXIT; 
      END IF; 
   END LOOP; 
 
   RETURN (strtmp); 
END ZL_incstr;
/

