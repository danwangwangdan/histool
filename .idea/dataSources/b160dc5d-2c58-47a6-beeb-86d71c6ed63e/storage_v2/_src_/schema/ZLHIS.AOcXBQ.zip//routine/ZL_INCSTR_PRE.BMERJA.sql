create Function Zl_Incstr_Pre(Strval In Varchar2) Return Varchar2 As 
  Strtmp Varchar2(255); 
  Bytup  Number := 0; 
  Bytadd Number; 
  n_Num  Number; 
Begin 
  If Strval Is Null Then 
    Return(Strval); 
  End If; 
 
  Strtmp := Strval; 
 
  For I In Reverse 1 .. Length(Strtmp) Loop 
    If I = Length(Strtmp) Then 
      Bytadd := -1; 
    Else 
      Bytadd := 0; 
    End If; 
 
    If Instr('0123456789', Substr(Strtmp, I, 1)) > 0 Then 
      n_Num := To_Number(Substr(Strtmp, I, 1)) + Bytadd + Bytup; 
      If n_Num < 10 And n_Num >= 0 Then 
        Strtmp := Substr(Strtmp, 1, I - 1) || (To_Number(Substr(Strtmp, I, 1)) + Bytadd + Bytup) || 
                  Substr(Strtmp, I + 1); 
        Bytup  := 0; 
      Else 
        Strtmp := Substr(Strtmp, 1, I - 1) || '9' || Substr(Strtmp, I + 1); 
        Bytup  := -1; 
      End If; 
    Else 
      n_Num := Ascii(Substr(Strtmp, I, 1)); -- 
      If n_Num + Bytadd + Bytup <= n_Num + (Ascii('Z') - Ascii(Upper(Substr(Strtmp, I, 1)))) And 
         n_Num + Bytadd + Bytup >= n_Num + (Ascii('A') - Ascii(Upper(Substr(Strtmp, I, 1)))) Then 
        Strtmp := Substr(Strtmp, 1, I - 1) || Chr(Ascii(Substr(Strtmp, I, 1)) + Bytadd + Bytup) || 
                  Substr(Strtmp, I + 1); 
        Bytup  := 0; 
      Else 
        Strtmp := Substr(Strtmp, 1, I - 1) || '0' || Substr(Strtmp, I + 1); 
        Bytup  := -1; 
      End If; 
    End If; 
 
    If Bytup = 0 Then 
      Exit; 
    End If; 
  End Loop; 
 
  Return(Strtmp); 
End Zl_Incstr_Pre;
/

