create Function Zl_In_Epr_Allowed 
( 
  病人id_In In 病案主页.病人id%Type, 
  主页id_In In 病案主页.主页id%Type, 
  科室id_In In 病案主页.出院科室id%Type 
) Return Varchar2 Is 
  v_Epr_Files Varchar2(2000); --采用分号分隔的病历文件id串 
  d_From_Time Date; --开始时间，存在留观转住院时，从该事件发生时间开始 
  d_To_Time   Date; --结束时间，存在预出院时，以预出院时间为结束时间 
 
  n_In_Dept  病案主页.入院科室id%Type; --病人入院科室 
  n_Cur_Dept 病案主页.出院科室id%Type; --病人当前所在科室 
  n_Is_Again 病案主页.再入院%Type; --病人是否再入院 
  d_Out_Time 病案主页.出院日期%Type; --出院时间，用以判断病人是否出院 
  v_Out_Mode 病案主页.出院方式%Type; --出院方式，用以判断病人是否死亡 
  n_Out_24h  Number(1) := 0; --是否24小时内出院或死亡 
Begin 
  Select Nvl(Max(开始时间), Sysdate - 3650), Max(科室id) 
  Into d_From_Time, n_In_Dept 
  From 病人变动记录 
  Where 病人id = 病人id_In And 主页id = 主页id_In And 开始原因 = 9; 
 
  Select Nvl(Min(终止时间), Sysdate + 3650) 
  Into d_To_Time 
  From 病人变动记录 R 
  Where 病人id = 病人id_In And 主页id = 主页id_In And 终止原因 = 10; 
 
  Select Decode(n_In_Dept, Null, 入院科室id, n_In_Dept), 出院科室id, Nvl(再入院, 0), 出院日期, 出院方式, 
         Sign(24 - (Nvl(出院日期, 入院日期 + 2) - 入院日期) * 24) 
  Into n_In_Dept, n_Cur_Dept, n_Is_Again, d_Out_Time, v_Out_Mode, n_Out_24h 
  From 病案主页 
  Where 病人id = 病人id_In And 主页id = 主页id_In; 
 
  If n_Out_24h = 1 Then 
    Select Sign(Nvl(Count(*), 0)) 
    Into n_Out_24h 
    From (Select f.Id, f.通用, a.科室id 
           From 病历文件列表 F, 病历应用科室 A, 病历时限要求 Q 
           Where f.Id = a.文件id(+) And f.Id = q.文件id And q.事件 In ('24小时出院', '24小时死亡') And f.种类 = 2) F 
    Where f.通用 = 1 Or f.通用 = 2 And f.科室id = 科室id_In; 
  End If; 
 
  For r_Must In (Select f.Id, f.唯一, r.次数, l.份数 
                 From (Select f.Id, f.事件, f.必须, f.唯一, f.书写时限 
                        From (Select f.Id, f.编号, f.通用, a.科室id, q.事件, q.必须, q.唯一, q.书写时限 
                               From 病历文件列表 F, 病历应用科室 A, 病历时限要求 Q 
                               Where f.Id = a.文件id(+) And f.Id = q.文件id And f.种类 = 2) F 
                        Where f.通用 = 1 Or f.通用 = 2 And f.科室id = 科室id_In) F, 
                      (Select Decode(n_Out_24h, 1, 
                                       Decode(事件, '入院', Null, '出院', 
                                               Decode(v_Out_Mode, '死亡', '24小时死亡', '24小时出院'), 事件), 
                                       Decode(事件, '出院', Decode(v_Out_Mode, '死亡', '死亡', '出院'), 事件)) As 事件, 
                               时机, Decode(事件, '入院', 1, '出院', 1, Count(*)) As 次数 
                        From (Select Decode(开始原因, 1, '入院', 2, '入院', 9, '入院', 3, '转科', 7, '交班') As 事件, 
                                      '后' As 时机 
                               From 病人变动记录 
                               Where 病人id = 病人id_In And 主页id = 主页id_In And 开始时间 >= d_From_Time And 
                                     Nvl(终止时间, Sysdate) <= d_To_Time And 
                                     (科室id + 0 = 科室id_In Or 开始原因 In (1, 2, 9)) 
                               Union All 
                               Select Decode(终止原因, 3, '转科', 7, '交班', 1, '出院', 10, '出院') As 事件, 
                                      Decode(终止原因, 3, '前', 7, '前', 1, '后', 10, '后') As 时机 
                               From 病人变动记录 
                               Where 病人id = 病人id_In And 主页id = 主页id_In And 开始时间 >= d_From_Time And 
                                     终止时间 <= d_To_Time And 科室id + 0 = 科室id_In 
                               Union All 
                               Select Decode(i.操作类型, '5', '出院', '11', '死亡') As 事件, '后' As 时机 
                               From 病人医嘱记录 R, 诊疗项目目录 I 
                               Where r.诊疗项目id = i.Id And r.病人id = 病人id_In And r.主页id = 主页id_In And 
                                     r.病人科室id + 0 = 科室id_In And r.相关id Is Null And r.医嘱期效 = 1 And 
                                     r.诊疗类别 = 'Z' And i.操作类型 In ('5', '11')) 
                        Group By 事件, 时机 
                        Having 事件 Is Not Null And 时机 Is Not Null 
                        Union All 
                        Select Decode(r.诊疗类别, 'F', '手术', Decode(i.操作类型, '7', '会诊', '抢救')) As 事件, 
                               '前' As 时机, Count(*) As 次数 
                        From 病人医嘱记录 R, 诊疗项目目录 I 
                        Where r.诊疗项目id = i.Id And 
                              (r.诊疗类别 = 'F' Or r.诊疗类别 = 'Z' And i.操作类型 In ('7', '8')) And 
                              r.病人id = 病人id_In And r.主页id = 主页id_In And r.相关id Is Null And 
                              r.病人科室id + 0 = 科室id_In And r.医嘱期效 = 1 And (r.医嘱状态 = 8 Or r.医嘱状态 = 9) 
                        Group By Decode(r.诊疗类别, 'F', '手术', Decode(i.操作类型, '7', '会诊', '抢救')) 
                        Union All 
                        Select Decode(i.操作类型, '7', '会诊', '抢救') As 事件, '后' As 时机, Count(*) As 次数 
                        From 病人医嘱记录 R, 诊疗项目目录 I 
                        Where r.诊疗项目id = i.Id And r.诊疗类别 = 'Z' And i.操作类型 In ('7', '8') And 
                              r.病人id = 病人id_In And r.主页id = 主页id_In And r.相关id Is Null And 
                              r.执行科室id + 0 = 科室id_In And r.医嘱期效 = 1 And (r.医嘱状态 = 8 Or r.医嘱状态 = 9) 
                        Group By Decode(i.操作类型, '7', '会诊', '抢救') 
                        Union All 
                        Select Decode(r.诊疗类别, 'F', '手术') As 事件, '后' As 时机, Count(*) As 次数 
                        From 病人医嘱记录 R, 诊疗项目目录 I 
                        Where r.诊疗项目id = i.Id And r.诊疗类别 = 'F' And r.病人id = 病人id_In And 
                              r.主页id = 主页id_In And r.相关id Is Null And r.病人科室id + 0 = 科室id_In And 
                              r.医嘱期效 = 1 And (r.医嘱状态 = 8 Or r.医嘱状态 = 9) 
                        Group By Decode(r.诊疗类别, 'F', '手术')) R, 
                      (Select r.文件id, Count(*) As 份数 
                        From 电子病历记录 R 
                        Where r.病人id = 病人id_In And r.主页id = 主页id_In And r.病历种类 = 2 And 
                              r.科室id + 0 = 科室id_In 
                        Group By r.文件id) L 
                 Where (n_Is_Again = 1 And r.事件 = '入院' And f.事件 = '再次入院' Or 
                       n_Is_Again <> 1 And r.事件 = '入院' And f.事件 = '首次入院' Or r.事件 = f.事件) And 
                       (r.事件 = '入院' And n_In_Dept <> 科室id_In And f.唯一 = 0 Or 
                       r.事件 = '入院' And n_In_Dept = 科室id_In Or r.事件 <> '入院') And 
                       (f.唯一 = 0 And r.时机 = '后' Or 
                       f.唯一 = 1 And (r.时机 = '前' And f.书写时限 < 0 Or r.时机 = '后' And f.书写时限 >= 0)) And 
                       f.Id = l.文件id(+)) Loop 
    If r_Must.唯一 = 0 And n_Cur_Dept = 科室id_In And (d_Out_Time Is Null) Or 
       r_Must.唯一 = 1 And r_Must.次数 > Nvl(r_Must.份数, 0) Then 
      v_Epr_Files := v_Epr_Files || ';' || r_Must.Id; 
    End If; 
  End Loop; 
 
  If n_Cur_Dept = 科室id_In And d_Out_Time Is Null Then 
    For r_Must In (Select f.Id 
                   From (Select f.*, a.科室id 
                          From 病历文件列表 F, 病历应用科室 A 
                          Where f.Id = a.文件id(+) And f.种类 = 2) F, 病历时限要求 Q 
                   Where f.Id = q.文件id And (f.通用 = 1 Or f.通用 = 2 And f.科室id = 科室id_In) And q.唯一 = 1 And 
                         q.书写时限 < 0 And Instr(v_Epr_Files || ';', ';' || f.Id || ';') = 0) Loop 
      v_Epr_Files := v_Epr_Files || ';' || r_Must.Id; 
    End Loop; 
  End If; 
 
  For r_Must In (Select f.Id 
                 From (Select f.Id, f.通用, a.科室id 
                        From 病历文件列表 F, 病历应用科室 A 
                        Where f.Id = a.文件id(+) And 
                              (f.种类 = 5 Or f.种类 = 6 And d_Out_Time Is Null And f.保留 >= 0 Or 
                              f.种类 = 6 And n_Cur_Dept = 科室id_In And v_Out_Mode = '死亡' And f.保留 < 0)) F 
                 Where (f.通用 = 1 Or f.通用 = 2 And f.科室id = 科室id_In)) Loop 
    v_Epr_Files := v_Epr_Files || ';' || r_Must.Id; 
  End Loop; 
 
  If v_Epr_Files Is Not Null Then 
    v_Epr_Files := Substr(v_Epr_Files, 2); 
  End If; 
  Return(v_Epr_Files); 
Exception 
  When Others Then 
    Return Null; 
End Zl_In_Epr_Allowed;
/

