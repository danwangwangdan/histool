create Function Zl_检验审核规则_Check 
( 
  检验标本id_In   In 检验标本记录.Id%Type, 
  病人比较方式_In In Number, --为0按病人ID方式提取上次结果，>0按病人姓名方式取上次结果 
  调用程序_In     In Number := 1 --1-审核调用（此时不处理批量规则） 2-批量审核，此睦要处理批量规则 
) Return Varchar2 Is 
  v_Rule         Varchar2(4000); 
  v_结果         Varchar2(4000); 
  v_提示         检验审核规则.提示信息%Type; 
  v_Tmp提示      检验审核规则.提示信息%Type; 
  v_Sql          Varchar2(4000); 
  v_特殊规则结果 Varchar2(4000); 
  v_可否强制审核 Varchar2(1); 
  --------------------------------------------------------------- 
  --- Beging 内部函数 
  --------------------------------------------------------------- 
  -- >>>>>>>>>>>>>>>>>>  检查项目是否有效  <<<<<<<<<<<<<<<<<< 
  Function Sub_Is_Erritem(Item_In Varchar2) Return Varchar2 Is 
    n_Count  Number; 
    v_Return Varchar2(4000); 
  Begin 
    If Nvl(Zl_Val(Item_In), 0) > 0 Then 
      Select Count(诊治项目id) Into n_Count From 检验项目 Where 诊治项目id = Item_In; 
      If Nvl(n_Count, 0) <= 0 Then 
        -- 错误的项目 
        v_Return := Item_In; 
      End If; 
    Else 
      --不符合语法的错误项目 
      v_Return := Item_In; 
    End If; 
    Return v_Return; 
  End Sub_Is_Erritem; 
 
  -- >>>>>>>>>>>>>>>>>>  表达式计算函数  <<<<<<<<<<<<<<<<<< 
  -- 返回 1-true, 0-false ,其他表示错误信息 
  Function Sub_Calc_Rule 
  ( 
    Rule_In    In Varchar2, 
    v_Err_Item In Varchar2 
  ) Return Varchar2 Is 
    v_结果    Varchar2(100); 
    v_Tmp_Err Varchar2(2000); 
  Begin 
    v_Tmp_Err := v_Err_Item; 
 
    If v_Tmp_Err Is Null Then 
      If Rule_In Is Null Then 
        v_结果 := '0'; 
      Else 
        v_Sql := 'Select ''1'' as Bool from Dual Where ' || Replace(Rule_In, '('''')', '(0)'); 
        Begin 
          Execute Immediate v_Sql 
            Into v_结果; 
        Exception 
          When No_Data_Found Then 
            v_结果 := '0'; 
          When Others Then 
            v_Tmp_Err := '"' || Rule_In || '"计算错误！' || Chr(13) || Chr(10) || Substr(Sqlerrm, 1, 200); 
        End; 
      End If; 
      If v_Tmp_Err Is Null Then 
        Return v_结果; 
      Else 
        Return v_Tmp_Err; 
      End If; 
 
    Else 
      Return '错误项目：' || v_Tmp_Err; 
    End If; 
  End Sub_Calc_Rule; 
  -- >>>>>>>>>>>>>>>>>>  检查是否数字的函数  <<<<<<<<<<<<<<<<<< 
  Function Sub_Is_Number(v_In In Varchar2) Return Boolean Is 
    n_Tmp Number; 
  Begin 
    n_Tmp := To_Number(v_In); 
    If n_Tmp Is Not Null Then 
      Return True; 
    End If; 
  Exception 
    When Others Then 
      Return False; 
  End Sub_Is_Number; 
  -- >>>>>>>>>>>>>>>>>>  检查标本是否适用于规则的函数  <<<<<<<<<<<<<<<<<< 
  Function Sub_Check_Befit 
  ( 
    标本id_In In 检验标本记录.Id%Type, 
    规则id_In In 检验审核规则.Id%Type 
  ) Return Boolean Is 
    b_Return   Boolean; 
    n_诊断     Number; 
    v_病人来源 Number; 
  Begin 
    b_Return := True; 
    For r_规则 In (Select 性别, 年龄上限, 年龄下限, 年龄单位, 科室id, 急诊, 病人类型, 诊断 
                 From 检验审核规则 
                 Where ID = 规则id_In) Loop 
 
      For r_标本 In (Select 性别, 年龄数字, 年龄单位, 申请科室id, 紧急, 病人来源 
                   From 检验标本记录 A 
                   Where a.Id = 标本id_In) Loop 
 
        If r_规则.性别 Is Not Null And b_Return = True Then 
          If r_规则.性别 <> Nvl(r_标本.性别, '未知') Then 
            b_Return := False; 
          End If; 
        End If; 
 
        If Nvl(r_规则.年龄单位, '未知') = Nvl(r_标本.年龄单位, '没填') And b_Return = True Then 
          If Nvl(r_标本.年龄数字, 0) < Nvl(r_规则.年龄下限, 0) Or Nvl(r_标本.年龄数字, 0) > Nvl(r_规则.年龄上限, 0) Then 
            b_Return := False; 
          End If; 
        End If; 
 
        If Nvl(r_规则.科室id, 0) > 0 And b_Return = True Then 
          If Nvl(r_规则.科室id, 0) <> Nvl(r_标本.申请科室id, 0) Then 
            b_Return := False; 
          End If; 
        End If; 
 
        If Nvl(r_规则.急诊, 0) > 0 And b_Return = True Then 
          If Nvl(r_规则.急诊, 0) <> Nvl(r_标本.紧急, 0) Then 
            b_Return := False; 
          End If; 
        End If; 
 
        If Nvl(r_规则.病人类型, 0) > 0 And b_Return = True Then 
          If Nvl(r_标本.病人来源, 0) = 2 Then 
            v_病人来源 := 2; 
          Else 
            v_病人来源 := 1; 
          End If; 
          If Nvl(r_规则.病人类型, 0) <> v_病人来源 Then 
            b_Return := False; 
          End If; 
        End If; 
 
      End Loop; 
 
      If r_规则.诊断 Is Not Null And b_Return = True Then 
        Select Count(内容) 
        Into n_诊断 
        From 病人医嘱附件 B, 检验标本记录 A 
        Where 内容 Like '%' || r_规则.诊断 || '%' And b.项目 = '临床诊断' And a.医嘱id = b.医嘱id And a.Id = 规则id_In; 
        If n_诊断 = 0 Then 
          b_Return := False; 
        End If; 
 
      End If; 
    End Loop; 
 
    Return b_Return; 
  End Sub_Check_Befit; 
  -- >>>>>>>>>>>>>>>>>>  普通规则计算函数  <<<<<<<<<<<<<<<<<< 
  Function Sub_Rule_Check 
  ( 
    标本id_In In 检验标本记录.Id%Type, 
    规则_In   In 检验审核规则.规则%Type, 
    规则id_In In 检验审核规则.Id%Type 
  ) Return Varchar2 Is 
 
    v_Tmp_Star Varchar2(4000); 
    v_Tmp_End  Varchar2(4000); 
    v_Tmp      Varchar2(4000); 
    v_规则     Varchar2(4000); 
    v_Err_Item Varchar2(4000); 
 
    Cursor Cur_检验结果 Is 
      Select a.Id, a.检验项目id, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
      From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C 
      Where c.Id = a.检验标本id And c.Id = 标本id_In And a.诊疗项目id = b.项目id And c.仪器id = b.仪器id And b.Id = 规则id_In 
      Union 
      Select a.Id, a.检验项目id, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
      From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C 
      Where c.Id = a.检验标本id And c.Id = 标本id_In And b.项目id Is Null And b.仪器id Is Null And b.Id = 规则id_In 
      Union 
      Select a.Id, a.检验项目id, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
      From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C 
      Where c.Id = a.检验标本id And c.Id = 标本id_In And b.项目id Is Null And b.仪器id = c.仪器id And b.Id = 规则id_In 
      Union 
      Select a.Id, a.检验项目id, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
      From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C 
      Where c.Id = a.检验标本id And c.Id = 标本id_In And b.项目id = a.诊疗项目id And b.仪器id Is Null And b.Id = 规则id_In; 
 
  Begin 
 
    v_规则 := 规则_In; 
 
    --******************  解析部分(普通规则)  ****************** 
 
    For r_检查结果 In Cur_检验结果 Loop 
      If r_检查结果.检验结果 Is Null Then 
        v_规则 := Replace(v_规则, '[' || r_检查结果.检验项目id || ']', '''' || ''''); 
      Else 
        If Sub_Is_Number(r_检查结果.检验结果) = True Then 
          v_规则 := Replace(v_规则, '[' || r_检查结果.检验项目id || ']', '(' || r_检查结果.检验结果 || ')'); 
        Else 
          v_规则 := Replace(v_规则, '[' || r_检查结果.检验项目id || ']', '(''' || r_检查结果.检验结果 || ''')'); 
        End If; 
      End If; 
    End Loop; 
 
    While Instr(v_规则, '[') > 0 Loop 
      -- 处理无结果的项目 
      v_Tmp_Star := Substr(v_规则, 1, Instr(v_规则, '[') - 1); 
      v_Tmp_End  := Substr(v_规则, Instr(v_规则, ']') + 1, Length(v_规则) - Instr(v_规则, ']')); 
      v_Tmp      := Substr(v_规则, Instr(v_规则, '[') + 1, Instr(v_规则, ']') - Instr(v_规则, '[') - 1); 
      If Sub_Is_Erritem(v_Tmp) Is Not Null Then 
        v_Err_Item := v_Err_Item || ',[' || v_Tmp || ']'; 
      End If; 
 
      If Instr(Upper(v_Tmp_End), 'AND') > 0 Then 
        v_Tmp_End := '1>2' || Substr(v_Tmp_End, Instr(Upper(v_Tmp_End), 'AND') - 1); 
      Elsif Instr(Upper(v_Tmp_End), 'OR') > 0 Then 
        v_Tmp_End := '1>2' || Substr(v_Tmp_End, Instr(Upper(v_Tmp_End), 'OR') - 1); 
      Else 
        v_Tmp_End := '1>2'; 
      End If; 
      v_规则 := v_Tmp_Star || v_Tmp_End; 
    End Loop; 
 
    --******************  计算部分(普通规则)  ****************** 
    Return Sub_Calc_Rule(v_规则, v_Err_Item); 
 
  End Sub_Rule_Check; 
 
  --  特殊规则A计算函数, 返回 1-true 0-false 或 错误信息 
  Function Sub_Especial_a 
  ( 
    标本id_In In 检验标本记录.Id%Type, 
    规则_In   In 检验审核规则.规则%Type, 
    规则id_In In 检验审核规则.Id%Type 
  ) Return Varchar2 Is 
    v_规则   Varchar2(4000); --格式 A:x|N 
    v_P1     Varchar2(1000); --参数1 
    v_P2     Varchar2(1000); --参数2 
    n_Count  Number; 
    v_Return Varchar2(4000); 
    v_Sql    Varchar2(4000); 
    Cursor Cur_检验结果 Is 
      Select a.Id, a.检验项目id, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
      From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C 
      Where c.Id = a.检验标本id And c.Id = 标本id_In And a.诊疗项目id = b.项目id And c.仪器id = b.仪器id And b.Id = 规则id_In 
      Union 
      Select a.Id, a.检验项目id, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
      From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C 
      Where c.Id = a.检验标本id And c.Id = 标本id_In And b.项目id Is Null And b.仪器id Is Null And b.Id = 规则id_In 
      Union 
      Select a.Id, a.检验项目id, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
      From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C 
      Where c.Id = a.检验标本id And c.Id = 标本id_In And b.项目id Is Null And b.仪器id = c.仪器id And b.Id = 规则id_In 
      Union 
      Select a.Id, a.检验项目id, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
      From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C 
      Where c.Id = a.检验标本id And c.Id = 标本id_In And b.项目id = a.诊疗项目id And b.仪器id Is Null And b.Id = 规则id_In; 
 
  Begin 
    v_规则  := Replace(规则_In, 'A:', ''); 
    v_P1    := Substr(v_规则, 1, Instr(v_规则, '|') - 1); 
    v_P2    := Substr(v_规则, Instr(v_规则, '|') + 1, Length(v_规则) - Instr(v_规则, '|')); 
    n_Count := 0; 
 
    For r_检查结果 In Cur_检验结果 Loop 
      If r_检查结果.检验结果 = v_P1 Then 
        n_Count := n_Count + 1; 
      End If; 
    End Loop; 
 
    v_Sql := 'select ''1'' From Dual Where ' || n_Count || v_P2; 
    Begin 
      Execute Immediate v_Sql 
        Into v_Return; 
    Exception 
      When No_Data_Found Then 
        v_Return := '0'; 
    End; 
    Return v_Return; 
  Exception 
    When Others Then 
      Return '"{' || 规则_In || '}"计算错误！' || Chr(13) || Chr(10) || Substr(Sqlerrm, 1, 200); 
  End Sub_Especial_a; 
 
  --  特殊规则B计算函数 
  Function Sub_Especial_b 
  ( 
    标本id_In   In 检验标本记录.Id%Type, 
    规则_In     In 检验审核规则.规则%Type, 
    比较方式_In In Number, 
    规则id_In   In 检验审核规则.Id%Type 
  ) Return Varchar2 Is 
    v_规则     Varchar2(4000); -- 格式: B:[项目1]>[上次.项目1] 
    v_Star     Varchar2(4000); 
    v_End      Varchar2(4000); 
    v_Item     Varchar2(4000); 
    v_Err_Item Varchar2(4000); 
    n_跟踪天数 Number; 
    d_检验时间 Date; 
    v_上次结果 Varchar2(1000); 
    v_Return   Varchar2(4000); 
    Cursor Cur_检验结果 Is 
      Select a.Id, a.检验项目id, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
      From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C 
      Where c.Id = a.检验标本id And c.Id = 标本id_In And a.诊疗项目id = b.项目id And c.仪器id = b.仪器id And b.Id = 规则id_In 
      Union 
      Select a.Id, a.检验项目id, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
      From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C 
      Where c.Id = a.检验标本id And c.Id = 标本id_In And b.项目id Is Null And b.仪器id Is Null And b.Id = 规则id_In 
      Union 
      Select a.Id, a.检验项目id, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
      From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C 
      Where c.Id = a.检验标本id And c.Id = 标本id_In And b.项目id Is Null And b.仪器id = c.仪器id And b.Id = 规则id_In 
      Union 
      Select a.Id, a.检验项目id, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
      From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C 
      Where c.Id = a.检验标本id And c.Id = 标本id_In And b.项目id = a.诊疗项目id And b.仪器id Is Null And b.Id = 规则id_In; 
  Begin 
    v_规则 := Replace(规则_In, 'B:', ''); 
    Select 检验时间 Into d_检验时间 From 检验标本记录 Where ID = 标本id_In; 
 
    For r_检查结果 In Cur_检验结果 Loop 
      -- 替换[]项目 
      v_规则 := Replace(v_规则, '[' || r_检查结果.检验项目id || ']', '(''' || r_检查结果.检验结果 || ''')'); 
      -- 替换[上次.]项目 
      Select Nvl(跟踪天数, 0) Into n_跟踪天数 From 检验项目选项 Where 诊疗项目id = r_检查结果.诊疗项目id; 
      If Nvl(n_跟踪天数, 0) = 0 Then 
        n_跟踪天数 := 30; 
      End If; 
 
      If 比较方式_In <> 0 Then 
        --病人姓名 
        Select l.检验结果 
        Into v_上次结果 
        From (Select l.检验项目id, l.次数, l.检验时间, l.检验结果 
               From (Select l.病人id, l.姓名, l.性别, l.年龄, l.Id As 次数, l.检验时间, r.检验项目id, r.检验结果 
                      From 检验标本记录 L, 检验普通结果 R 
                      Where l.Id = r.检验标本id And l.报告结果 = r.记录类型 And r.检验项目id = r_检查结果.检验项目id And 
                            l.检验时间 Between d_检验时间 - n_跟踪天数 And d_检验时间 And l.Id <> 标本id_In) L, 
                    (Select l.病人id, l.姓名, l.性别, l.年龄, r.检验项目id 
                      From 检验标本记录 L, 检验普通结果 R 
                      Where r.检验项目id = r_检查结果.检验项目id And l.Id = 标本id_In And l.Id = r.检验标本id And l.报告结果 = r.记录类型) C 
               Where l.姓名 = c.姓名 And l.检验项目id = c.检验项目id) L, 检验项目 V 
        Where l.检验项目id = v.诊治项目id 
        Order By l.次数 Desc; 
      Else 
        --病人ID 
        Select l.检验结果 
        Into v_上次结果 
        From (Select l.检验项目id, l.次数, l.检验时间, l.检验结果 
               From (Select l.病人id, l.姓名, l.性别, l.年龄, l.Id As 次数, l.检验时间, r.检验项目id, r.检验结果 
                      From 检验标本记录 L, 检验普通结果 R 
                      Where l.Id = r.检验标本id And l.报告结果 = r.记录类型 And r.检验项目id = r_检查结果.检验项目id And 
                            l.检验时间 Between d_检验时间 - n_跟踪天数 And d_检验时间 And l.Id <> 标本id_In) L, 
                    (Select l.病人id, l.姓名, l.性别, l.年龄, r.检验项目id 
                      From 检验标本记录 L, 检验普通结果 R 
                      Where r.检验项目id = r_检查结果.检验项目id And l.Id = 标本id_In And l.Id = r.检验标本id And l.报告结果 = r.记录类型) C 
               Where l.病人id = c.病人id And l.检验项目id = c.检验项目id) L, 检验项目 V 
        Where l.检验项目id = v.诊治项目id 
        Order By l.次数 Desc; 
      End If; 
      v_规则 := Replace(v_规则, '[上次.' || r_检查结果.检验项目id || ']', '(''' || v_上次结果 || ''')'); 
    End Loop; 
 
    --处理剩余的项目 
    While Instr(v_规则, '[') > 0 Loop 
      v_Star := Substr(v_规则, 1, Instr(v_规则, '[') - 1); 
      v_End  := Substr(v_规则, Instr(v_规则, ']') + 1, Length(v_规则) - Instr(v_规则, ']')); 
      v_Item := Substr(v_规则, Instr(v_规则, '[') + 1, Instr(v_规则, ']') - Instr(v_规则, '[') - 1); 
 
      If Substr(v_Item, 1, 3) = '上次.' Then 
        v_Item := Substr(v_Item, 4, Length(v_Item)); 
        If Sub_Is_Erritem(v_Item) Is Not Null Then 
          v_Err_Item := v_Err_Item || ',[' || v_Item || ']'; 
        End If; 
      Else 
        -- 错误的项目 
        If Sub_Is_Erritem(v_Item) Is Not Null Then 
          v_Err_Item := v_Err_Item || ',[' || v_Item || ']'; 
        End If; 
      End If; 
      v_规则 := v_Star || '(Null)' || v_End; 
    End Loop; 
 
    v_Return := Sub_Calc_Rule(v_规则, v_Err_Item); 
    If Instr(',0,1,', ',' || v_Return || ',') <= 0 Then 
      v_Return := '"{' || 规则_In || '}"计算错误！' || Chr(13) || Chr(10) || '－－' || v_Return; 
    End If; 
    Return v_Return; 
  Exception 
    When Others Then 
      Return '"{' || 规则_In || '}"计算错误！' || Chr(13) || Chr(10) || Substr(Sqlerrm, 1, 200); 
  End Sub_Especial_b; 
 
  --  特殊规则C计算函数 
  Function Sub_Especial_c 
  ( 
    标本id_In In 检验标本记录.Id%Type, 
    规则_In   In 检验审核规则.规则%Type, 
    规则id_In In 检验审核规则.Id%Type 
  ) Return Varchar2 Is 
    v_规则     Varchar2(4000); --格式 C:[项目1],[项目2]...[项目n]|N 
    v_P1       Varchar2(4000); --参数1 
    v_P2       Varchar2(4000); --参数2 
    n_Count    Number; 
    v_比较结果 Varchar2(4000); 
    Cursor Cur_检验结果 Is 
      Select a.Id, a.检验项目id, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
      From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C 
      Where c.Id = a.检验标本id And c.Id = 标本id_In And a.诊疗项目id = b.项目id And c.仪器id = b.仪器id And b.Id = 规则id_In 
      Union 
      Select a.Id, a.检验项目id, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
      From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C 
      Where c.Id = a.检验标本id And c.Id = 标本id_In And b.项目id Is Null And b.仪器id Is Null And b.Id = 规则id_In 
      Union 
      Select a.Id, a.检验项目id, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
      From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C 
      Where c.Id = a.检验标本id And c.Id = 标本id_In And b.项目id Is Null And b.仪器id = c.仪器id And b.Id = 规则id_In 
      Union 
      Select a.Id, a.检验项目id, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
      From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C 
      Where c.Id = a.检验标本id And c.Id = 标本id_In And b.项目id = a.诊疗项目id And b.仪器id Is Null And b.Id = 规则id_In; 
  Begin 
    v_规则 := Replace(规则_In, 'C:', ''); 
    v_P1   := ',' || Substr(v_规则, 1, Instr(v_规则, '|') - 1) || ','; 
    v_P2   := Substr(v_规则, Instr(v_规则, '|') + 1, Length(v_规则) - Instr(v_规则, '|')); 
    For r_检查结果 In Cur_检验结果 Loop 
      If Instr(v_P1, ',[' || r_检查结果.检验项目id || '],') <= 0 Then 
        If Sub_Is_Number(r_检查结果.检验结果) = True Then 
          v_比较结果 := Sub_Calc_Rule(r_检查结果.检验结果 || v_P2, Null); 
          If v_比较结果 = '1' Then 
            n_Count := Nvl(n_Count, 0) + 1; 
          End If; 
        End If; 
      End If; 
    End Loop; 
 
    If Nvl(n_Count, 0) > 0 Then 
      Return '1'; 
    Else 
      Return '0'; 
    End If; 
  Exception 
    When Others Then 
      Return '"{' || 规则_In || '}"计算错误！' || Chr(13) || Chr(10) || Substr(Sqlerrm, 1, 200); 
  End Sub_Especial_c; 
 
  --  特殊规则D计算函数 
  Function Sub_Especial_d 
  ( 
    标本id_In In 检验标本记录.Id%Type, 
    规则_In   In 检验审核规则.规则%Type, 
    规则id_In In 检验审核规则.Id%Type 
  ) Return Varchar2 Is 
    v_规则 Varchar2(4000); 
    n_漏项 Number; 
    n_多项 Number; 
 
    Cursor Cur_检验结果 Is 
      Select Distinct 诊疗项目id 
      From (Select a.Id, a.检验项目id, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
             From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C 
             Where c.Id = a.检验标本id And c.Id = 标本id_In And a.诊疗项目id = b.项目id And c.仪器id = b.仪器id And b.Id = 规则id_In 
             Union 
             Select a.Id, a.检验项目id, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
             From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C 
             Where c.Id = a.检验标本id And c.Id = 标本id_In And b.项目id Is Null And b.仪器id Is Null And b.Id = 规则id_In 
             Union 
             Select a.Id, a.检验项目id, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
             From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C 
             Where c.Id = a.检验标本id And c.Id = 标本id_In And b.项目id Is Null And b.仪器id = c.仪器id And b.Id = 规则id_In 
             Union 
             Select a.Id, a.检验项目id, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
             From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C 
             Where c.Id = a.检验标本id And c.Id = 标本id_In And b.项目id = a.诊疗项目id And b.仪器id Is Null And b.Id = 规则id_In); 
  Begin 
    v_规则 := Replace(规则_In, 'D:', ''); 
    If v_规则 = '1' Or v_规则 = '3' Or v_规则 = '2' Then 
      For r_检查结果 In Cur_检验结果 Loop 
        -- 漏项 
        If v_规则 = '1' Or v_规则 = '3' Then 
          If Nvl(n_漏项, 0) = 0 Then 
            Select Count(项目) 
            Into n_漏项 
            From (Select 报告项目id As 项目 
                   From 检验报告项目 
                   Where 诊疗项目id = r_检查结果.诊疗项目id 
                   Minus 
                   Select 检验项目id As 项目 
                   From (Select a.Id, a.检验项目id, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
                          From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C 
                          Where c.Id = a.检验标本id And c.Id = 标本id_In And a.诊疗项目id = b.项目id And c.仪器id = b.仪器id And 
                                b.Id = 规则id_In And a.检验结果 Is Not Null 
                          Union 
                          Select a.Id, a.检验项目id, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
                          From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C 
                          Where c.Id = a.检验标本id And c.Id = 标本id_In And b.项目id Is Null And b.仪器id Is Null And b.Id = 规则id_In And 
                                a.检验结果 Is Not Null 
                          Union 
                          Select a.Id, a.检验项目id, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
                          From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C, 检验标本记录 D 
                          Where c.Id = a.检验标本id And c.Id <> 标本id_In And b.项目id Is Null And b.仪器id Is Null And 
                                b.Id = 规则id_In And c.医嘱id = d.医嘱id And d.Id = 标本id_In 
                          Union 
                          Select a.Id, a.检验项目id, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
                          From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C 
                          Where c.Id = a.检验标本id And c.Id = 标本id_In And b.项目id Is Null And b.仪器id = c.仪器id And 
                                b.Id = 规则id_In And a.检验结果 Is Not Null 
                          Union 
                          Select a.Id, a.检验项目id, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
                          From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C 
                          Where c.Id = a.检验标本id And c.Id = 标本id_In And b.项目id = a.诊疗项目id And b.仪器id Is Null And 
                                b.Id = 规则id_In And a.检验结果 Is Not Null)); 
          End If; 
        End If; 
        -- 多项 
        If v_规则 = '2' Or v_规则 = '3' Then 
          If Nvl(n_多项, 0) = 0 Then 
            Select Count(项目) 
            Into n_多项 
            From (Select 检验项目id As 项目 
                   From (Select a.Id, a.检验项目id, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
                          From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C 
                          Where c.Id = a.检验标本id And c.Id = 标本id_In And a.诊疗项目id = b.项目id And c.仪器id = b.仪器id And 
                                b.Id = 规则id_In And a.检验结果 Is Not Null 
                          Union 
                          Select a.Id, a.检验项目id, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
                          From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C 
                          Where c.Id = a.检验标本id And c.Id = 标本id_In And b.项目id Is Null And b.仪器id Is Null And b.Id = 规则id_In And 
                                a.检验结果 Is Not Null 
                          Union 
                          Select a.Id, a.检验项目id, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
                          From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C 
                          Where c.Id = a.检验标本id And c.Id = 标本id_In And b.项目id Is Null And b.仪器id = c.仪器id And 
                                b.Id = 规则id_In And a.检验结果 Is Not Null 
                          Union 
                          Select a.Id, a.检验项目id, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
                          From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C 
                          Where c.Id = a.检验标本id And c.Id = 标本id_In And b.项目id = a.诊疗项目id And b.仪器id Is Null And 
                                b.Id = 规则id_In And a.检验结果 Is Not Null) 
                   Minus 
                   Select 报告项目id As 项目 From 检验报告项目 Where 诊疗项目id = r_检查结果.诊疗项目id); 
          End If; 
        End If; 
      End Loop; 
 
      If v_规则 = '1' Then 
        If Nvl(n_漏项, 0) <> 0 Then 
          Return '1'; 
        Else 
          Return '0'; 
        End If; 
      Elsif v_规则 = '2' Then 
        If Nvl(n_多项, 0) <> 0 Then 
          Return '1'; 
        Else 
          Return '0'; 
        End If; 
      Else 
        If Nvl(n_漏项, 0) <> 0 Or Nvl(n_多项, 0) <> 0 Then 
          Return '1'; 
        Else 
          Return '0'; 
        End If; 
      End If; 
    Else 
      Return '"{' || 规则_In || '}"计算错误！' || Chr(13) || Chr(10) || Substr(Sqlerrm, 1, 200); 
    End If; 
  Exception 
    When Others Then 
      Return '"{' || 规则_In || '}"计算错误！' || Chr(13) || Chr(10) || Substr(Sqlerrm, 1, 200); 
  End Sub_Especial_d; 
 
  --  特殊规则E计算函数 
  Function Sub_Especial_e 
  ( 
    标本id_In   In 检验标本记录.Id%Type, 
    规则_In     In 检验审核规则.规则%Type, 
    比较方式_In In Number, 
    规则id_In   In 检验审核规则.Id%Type 
  ) Return Varchar2 Is 
    v_规则     Varchar2(4000); -- 格式: E:[标记.项目1]>[上次标记.项目1] 
    v_Star     Varchar2(4000); 
    v_End      Varchar2(4000); 
    v_Item     Varchar2(4000); 
    v_Err_Item Varchar2(4000); 
    n_跟踪天数 Number; 
    d_检验时间 Date; 
    v_上次结果 Varchar2(1000); 
    v_Return   Varchar2(4000); 
    Cursor Cur_检验结果 Is 
      Select a.Id, a.检验项目id, a.结果标志, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
      From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C 
      Where c.Id = a.检验标本id And c.Id = 标本id_In And a.诊疗项目id = b.项目id And c.仪器id = b.仪器id And b.Id = 规则id_In 
      Union 
      Select a.Id, a.检验项目id, a.结果标志, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
      From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C 
      Where c.Id = a.检验标本id And c.Id = 标本id_In And b.项目id Is Null And b.仪器id Is Null And b.Id = 规则id_In 
      Union 
      Select a.Id, a.检验项目id, a.结果标志, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
      From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C 
      Where c.Id = a.检验标本id And c.Id = 标本id_In And b.项目id Is Null And b.仪器id = c.仪器id And b.Id = 规则id_In 
      Union 
      Select a.Id, a.检验项目id, a.结果标志, a.检验结果, a.原始结果, a.原始记录时间, a.仪器id, a.诊疗项目id 
      From 检验普通结果 A, 检验审核规则 B, 检验标本记录 C 
      Where c.Id = a.检验标本id And c.Id = 标本id_In And b.项目id = a.诊疗项目id And b.仪器id Is Null And b.Id = 规则id_In; 
  Begin 
    v_规则 := Replace(规则_In, 'E:', ''); 
    Select 检验时间 Into d_检验时间 From 检验标本记录 Where ID = 标本id_In; 
 
    For r_检查结果 In Cur_检验结果 Loop 
 
      -- 替换[上次标记.]项目 
      Begin 
        Select Nvl(跟踪天数, 0) Into n_跟踪天数 From 检验项目选项 Where 诊疗项目id = r_检查结果.诊疗项目id; 
        If Nvl(n_跟踪天数, 0) = 0 Then 
          n_跟踪天数 := 30; 
        End If; 
      Exception 
        When Others Then 
          n_跟踪天数 := 30; 
      End; 
      Begin 
        If 比较方式_In <> 0 Then 
          --病人姓名 
          Select l.结果标志 
          Into v_上次结果 
          From (Select l.检验项目id, l.次数, l.检验时间, l.结果标志, l.检验结果 
                 From (Select l.病人id, l.姓名, l.性别, l.年龄, l.Id As 次数, l.检验时间, r.检验项目id, Nvl(r.结果标志, 1) As 结果标志, r.检验结果 
                        From 检验标本记录 L, 检验普通结果 R 
                        Where l.Id = r.检验标本id And l.报告结果 = r.记录类型 And r.检验项目id = r_检查结果.检验项目id And 
                              l.检验时间 Between d_检验时间 - n_跟踪天数 And d_检验时间 And l.Id <> 标本id_In) L, 
                      (Select l.病人id, l.姓名, l.性别, l.年龄, r.检验项目id 
                        From 检验标本记录 L, 检验普通结果 R 
                        Where r.检验项目id = r_检查结果.检验项目id And l.Id = 标本id_In And l.Id = r.检验标本id And l.报告结果 = r.记录类型) C 
                 Where l.姓名 = c.姓名 And l.检验项目id = c.检验项目id) L, 检验项目 V 
          Where l.检验项目id = v.诊治项目id 
          Order By l.次数 Desc; 
        Else 
          --病人ID 
 
          Select l.结果标志 
          Into v_上次结果 
          From (Select l.检验项目id, l.次数, l.检验时间, l.结果标志, l.检验结果 
                 From (Select l.病人id, l.姓名, l.性别, l.年龄, l.Id As 次数, l.检验时间, r.检验项目id, Nvl(r.结果标志, 1) As 结果标志, r.检验结果 
                        From 检验标本记录 L, 检验普通结果 R 
                        Where l.Id = r.检验标本id And l.报告结果 = r.记录类型 And r.检验项目id = r_检查结果.检验项目id And 
                              l.检验时间 Between d_检验时间 - n_跟踪天数 And d_检验时间 And l.Id <> 标本id_In) L, 
                      (Select l.病人id, l.姓名, l.性别, l.年龄, r.检验项目id 
                        From 检验标本记录 L, 检验普通结果 R 
                        Where r.检验项目id = r_检查结果.检验项目id And l.Id = 标本id_In And l.Id = r.检验标本id And l.报告结果 = r.记录类型) C 
                 Where l.病人id = c.病人id And l.检验项目id = c.检验项目id) L, 检验项目 V 
          Where l.检验项目id = v.诊治项目id 
          Order By l.次数 Desc; 
        End If; 
      Exception 
        When Others Then 
          v_上次结果 := Null; 
      End; 
      If v_上次结果 Is Null Then 
        -- 无上次结果，就当做没有违返这个规则 
        v_规则 := Replace(v_规则, '[上次.' || r_检查结果.检验项目id || ']', '(''' || r_检查结果.结果标志 || ''')'); 
        -- 替换[标记.]项目 
        v_规则 := Replace(v_规则, '[标记.' || r_检查结果.检验项目id || ']', '(''' || r_检查结果.结果标志 || ''')'); 
      Else 
        v_规则 := Replace(v_规则, '[上次.' || r_检查结果.检验项目id || ']', '(''' || v_上次结果 || ''')'); 
        -- 替换[标记.]项目 
        v_规则 := Replace(v_规则, '[标记.' || r_检查结果.检验项目id || ']', '(''' || r_检查结果.结果标志 || ''')'); 
 
      End If; 
    End Loop; 
 
    --处理剩余的项目 
    While Instr(v_规则, '[') > 0 Loop 
      v_Star := Substr(v_规则, 1, Instr(v_规则, '[') - 1); 
      v_End  := Substr(v_规则, Instr(v_规则, ']') + 1, Length(v_规则) - Instr(v_规则, ']')); 
      v_Item := Substr(v_规则, Instr(v_规则, '[') + 1, Instr(v_规则, ']') - Instr(v_规则, '[') - 1); 
 
      If Substr(v_Item, 1, 3) = '上次.' Or Substr(v_Item, 1, 3) = '标记.' Then 
        v_Item := Substr(v_Item, 4, Length(v_Item)); 
        If Sub_Is_Erritem(v_Item) Is Not Null Then 
          v_Err_Item := v_Err_Item || ',[' || v_Item || ']'; 
        End If; 
      Else 
        -- 错误的项目 
        If Sub_Is_Erritem(v_Item) Is Not Null Then 
          v_Err_Item := v_Err_Item || ',[' || v_Item || ']'; 
        End If; 
      End If; 
      v_规则 := v_Star || '(Null)' || v_End; 
    End Loop; 
 
    v_Return := Sub_Calc_Rule(v_规则, v_Err_Item); 
    If Instr(',0,1,', ',' || v_Return || ',') <= 0 Then 
      v_Return := '"{' || 规则_In || '}"计算错误！' || Chr(13) || Chr(10) || '－－' || v_Return; 
    End If; 
    Return v_Return; 
  Exception 
    When Others Then 
      Return '"{' || 规则_In || '}"计算错误！' || Chr(13) || Chr(10) || Substr(Sqlerrm, 1, 200); 
  End Sub_Especial_e; 
 
  -- >>>>>>>>>>>>>>>>>>  特殊规则计算函数  <<<<<<<<<<<<<<<<<< 
  -- 返回 1-true 0-false 或 错误信息 
  Function Sub_Rule_Especial 
  ( 
    标本id_In In 检验标本记录.Id%Type, 
    规则_In   In 检验审核规则.规则%Type, 
    方式_In   In Number, 
    规则id_In In 检验审核规则.Id%Type 
  ) Return Varchar2 Is 
 
    v_Tmp_Star Varchar2(4000); 
    v_Tmp_End  Varchar2(4000); 
    v_Tmp      Varchar2(4000); 
    v_规则     Varchar2(4000); 
    v_Err_Item Varchar2(4000); 
    v_计算结果 Varchar2(4000); 
 
  Begin 
 
    v_规则 := Upper(规则_In); 
 
    --******************  解析部分(特殊规则)  ****************** 
    While Instr(v_规则, '{') > 0 Loop 
      v_Tmp_Star := Substr(v_规则, 1, Instr(v_规则, '{') - 1); 
      v_Tmp_End  := Substr(v_规则, Instr(v_规则, '}') + 1, Length(v_规则) - Instr(v_规则, '}')); 
      v_Tmp      := Substr(v_规则, Instr(v_规则, '{') + 1, Instr(v_规则, '}') - Instr(v_规则, '{') - 1); 
      v_计算结果 := Null; 
 
      If Substr(v_Tmp, 1, 2) = 'A:' And Instr(v_Tmp, '|') > 0 Then 
        v_计算结果 := Sub_Especial_a(标本id_In, v_Tmp, 规则id_In); 
      Elsif Substr(v_Tmp, 1, 2) = 'B:' Then 
        v_计算结果 := Sub_Especial_b(标本id_In, v_Tmp, 方式_In, 规则id_In); 
      Elsif Substr(v_Tmp, 1, 2) = 'C:' And Instr(v_Tmp, '|') > 0 Then 
        v_计算结果 := Sub_Especial_c(标本id_In, v_Tmp, 规则id_In); 
      Elsif Substr(v_Tmp, 1, 2) = 'D:' Then 
        v_计算结果 := Sub_Especial_d(标本id_In, v_Tmp, 规则id_In); 
      Elsif Substr(v_Tmp, 1, 2) = 'E:' Then 
        v_计算结果 := Sub_Especial_e(标本id_In, v_Tmp, 方式_In, 规则id_In); 
      Else 
        v_Err_Item := v_Err_Item || ',{' || v_Tmp || '}'; 
        v_计算结果 := '公式错误'; 
      End If; 
 
      If v_计算结果 = '1' Then 
        v_规则 := v_Tmp_Star || '(1=1)' || v_Tmp_End; 
      Elsif v_计算结果 = '0' Then 
        v_规则 := v_Tmp_Star || '(1<>1)' || v_Tmp_End; 
      Else 
        v_规则     := v_Tmp_Star || v_Tmp_End; 
        v_Err_Item := v_Err_Item || Chr(13) || Chr(10) || v_计算结果; 
      End If; 
 
    End Loop; 
 
    --******************  计算部分(特殊规则)  ****************** 
    Return Sub_Calc_Rule(v_规则, v_Err_Item); 
 
  End Sub_Rule_Especial; 
 
  ------------------------------------------------------------------ 
  ----- end 内部函数 
  ----------------------------------------------------------------- 
 
Begin 
  v_提示         := Null; 
  v_可否强制审核 := '0'; -- 0- 可以强制审核 1-不能强制审核（有权限的除外） 
  For r_Rule In (Select * 
                 From (Select ID, 编码, 名称, 分类, 项目id, 仪器id, 科室id, 病人类型, 性别, 年龄下限, 年龄上限, 年龄单位, 诊断, 规则, 特殊规则, 规则关系, 提示信息, 急诊, 
                               有效, 审核, 备注 
                        From 检验审核规则 
                        Where (有效 = 1 Or 有效 = 调用程序_In) And 项目id Is Null And 仪器id Is Null 
                        -- 不区分仪器项目的规则 
                        Union 
                        Select a.Id, a.编码, a.名称, a.分类, a.项目id, a.仪器id, a.科室id, a.病人类型, a.性别, a.年龄下限, a.年龄上限, a.年龄单位, a.诊断, 
                               a.规则, a.特殊规则, a.规则关系, a.提示信息, a.急诊, a.有效, a.审核, a.备注 
                        From 检验普通结果 B, 检验标本记录 C, 检验审核规则 A 
                        Where (a.有效 = 1 Or a.有效 = 调用程序_In) And (a.项目id = b.诊疗项目id Or a.仪器id = c.仪器id) And c.Id = b.检验标本id And 
                              c.Id = 检验标本id_In) 
                 Order By 仪器id, 项目id) Loop 
 
    If Sub_Check_Befit(检验标本id_In, r_Rule.Id) Then 
      v_Tmp提示 := Null; 
      v_结果    := Null; 
      If r_Rule.规则 Is Not Null Then 
        --普通规则 
        v_Rule := r_Rule.规则; 
        v_结果 := Sub_Rule_Check(检验标本id_In, v_Rule, r_Rule.Id); 
        If Instr(',1,0,', ',' || v_结果 || ',') > 0 Then 
          --计算结果为true,false 
          If v_结果 = '1' Then 
            v_结果 := '(1 = 1)'; 
          Else 
            v_结果 := '(1 <> 1)'; 
          End If; 
        Else 
          --计算时出错 
          v_Tmp提示 := v_结果; 
          v_结果    := '(1 = 1)'; 
        End If; 
 
        If v_结果 = '(1 = 1)' And r_Rule.审核 = '1' Then 
          v_可否强制审核 := '1'; 
        End If; 
      End If; 
 
      If r_Rule.特殊规则 Is Not Null Then 
        --特殊规则 
        v_Rule         := r_Rule.特殊规则; 
        v_特殊规则结果 := Sub_Rule_Especial(检验标本id_In, v_Rule, 病人比较方式_In, r_Rule.Id); 
        If Instr(',0,1,', ',' || v_特殊规则结果 || ',') > 0 Then 
          If v_特殊规则结果 = '1' Then 
            v_特殊规则结果 := '(1 = 1)'; 
          Else 
            v_特殊规则结果 := '(1 <> 1)'; 
          End If; 
        Else 
          v_Tmp提示      := v_Tmp提示 || Chr(13) || Chr(10) || v_特殊规则结果; 
          v_特殊规则结果 := '(1 = 1)'; 
        End If; 
        If v_特殊规则结果 = '(1 = 1)' And r_Rule.审核 = '1' Then 
          v_可否强制审核 := '1'; 
        End If; 
      End If; 
 
      If v_Tmp提示 Is Not Null Then 
        -- 有提示,表示上面有错误，不再计算普通规则与特殊规则的结果。 
        If v_可否强制审核 = '1' Then 
          v_提示 := v_提示 || Chr(13) || Chr(10) || '*' || v_Tmp提示; 
        Else 
          v_提示 := v_提示 || Chr(13) || Chr(10) || v_Tmp提示; 
        End If; 
      Else 
        -- 计算普通规则与特殊规则的结果。 
        If v_结果 Is Null Or v_特殊规则结果 Is Null Then 
          v_Sql := v_结果 || v_特殊规则结果; 
        Else 
          v_Sql := v_结果 || r_Rule.规则关系 || v_特殊规则结果; 
        End If; 
        If v_Sql Is Not Null Then 
          v_结果 := Sub_Calc_Rule(v_Sql, Null); 
        Else 
          v_结果 := '0'; 
        End If; 
 
        If v_结果 = '1' Then 
          If v_可否强制审核 = '1' Then 
            v_提示 := v_提示 || Chr(13) || Chr(10) || '*' || r_Rule.提示信息; 
          Else 
            v_提示 := v_提示 || Chr(13) || Chr(10) || r_Rule.提示信息; 
          End If; 
        Elsif v_结果 <> '0' Then 
          If v_可否强制审核 = '1' Then 
            v_提示 := v_提示 || Chr(13) || Chr(10) || '*' || v_结果; 
          Else 
            v_提示 := v_提示 || Chr(13) || Chr(10) || v_结果; 
          End If; 
        End If; 
      End If; 
    End If; 
  End Loop; 
 
  If v_提示 Is Not Null Then 
    v_提示 := v_可否强制审核 || '|未能通过审核，原因如下：' || v_提示; 
  End If; 
 
  Return v_提示; 
Exception 
  When Others Then 
    Return '1|因审核规则计算过程发生错误意外终止！'; 
End Zl_检验审核规则_Check;
/

