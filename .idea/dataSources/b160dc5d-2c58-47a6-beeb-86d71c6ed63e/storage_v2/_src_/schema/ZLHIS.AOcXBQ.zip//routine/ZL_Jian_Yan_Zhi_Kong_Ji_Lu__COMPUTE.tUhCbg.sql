create Function Zl_检验质控记录_Compute 
( 
  仪器id_In In 检验质控记录.仪器id%Type, 
  项目id_In In 检验普通结果.检验项目id%Type, 
  日期_In   In 检验质控记录.检验时间%Type, 
  质控品_In In Varchar2 
) Return Varchar2 Is 
  Pragma Autonomous_Transaction; 
 
  n_水平数 检验仪器.质控水平数%Type := 0; 
  n_结果id 检验普通结果.Id%Type := 0; 
 
  Type t_Ctrl_Record Is Record( 
    标本id   Number(18), 
    结果id   Number(18), 
    ID       Number(18), 
    批号     Varchar2(10), 
    名称     Varchar2(50), 
    水平     Number(1), 
    均值     Number(18, 4), 
    Sd       Number(18, 4), 
    今日次   Number(18), 
    累计次   Number(18), 
    规则数   Number(18), 
    标记     Number(1), 
    规则     Varchar2(100), 
    提示     Varchar2(500), 
    开始日期 Date, 
    结束日期 Date); 
  Type t_Ctrl_Table Is Table Of t_Ctrl_Record; 
  a_Ctrls t_Ctrl_Table := t_Ctrl_Table(); 
 
  Type t_Step Is Table Of 检验仪器规则.Id%Type; 
  a_Step t_Step := t_Step(); 
  Type t_Rule_Record Is Record( 
    名称    Varchar2(20), 
    种类    Number(1), 
    形式    Number(1), 
    N       Number(2), 
    X       Number(5, 1), 
    M       Number(2), 
    P       Number(5, 3), 
    K       Number(5, 1), 
    H       Number(5, 1), 
    批范围  Number(3), 
    多水平  Number(1), 
    Y标记级 Number(1), 
    Y规则   Varchar2(20), 
    Y结束   Number(1), 
    Y提示   Varchar2(500), 
    N标记级 Number(1), 
    N规则   Varchar2(20), 
    N结束   Number(1), 
    N提示   Varchar2(500)); 
  t_Rule_Now t_Rule_Record; 
 
  n_步骤id 检验仪器规则.Id%Type; 
  v_性质   检验仪器规则.性质%Type; 
 
  v_Rerutn Varchar2(4000); 
 
  --- 当天要计算的数据点，当天有多少个数据就计算多少次。 
 
  Cursor Cur_Ctrls Is 
    Select q.标本id, r.Id As 结果id, m.Id, m.批号, m.名称, m.水平, x.均值, x.Sd, 
           Nvl(Decode(Sign(q.检验时间 - 日期_In), 0, q.测试次数), 0) As 今日次, 0 As 累计次, d.规则数, 0, '' As 规则, '' As 提示, x.开始日期, 
           Nvl(x.结束日期, m.结束日期) As 结束日期 
    From 检验质控记录 Q, 检验普通结果 R, 检验质控品 M, 
         (Select 质控品id, 项目id, 均值, Sd, 开始日期, 结束日期 
           From 检验质控均值 
           Where 开始日期 <= 日期_In And (结束日期 >= 日期_In Or 结束日期 Is Null) And 项目id = 项目id_In) X, 
         (Select Count(*) As 规则数 From 检验仪器规则 Where 仪器id = 仪器id_In And 上级id Is Null) D 
    Where q.标本id = r.检验标本id And q.质控品id = m.Id And Nvl(r.弃用结果, 0) = 0 And q.检验时间 Between 日期_In And 
          日期_In + 1 - 1 / (24 * 60 * 60) And r.检验项目id + 0 = 项目id_In And m.Id = x.质控品id(+) And m.仪器id = 仪器id_In And 
          Instr(',' || 质控品_In || ',', ',' || m.Id || ',') > 0 
    Order By m.水平; 
 
  ---------------------------------------------------- 
  --以下为各种规则形式的判断函数: 
  ---------------------------------------------------- 
  --1)即刻法失控判断子函数 
  ---------------------------------------- 
  Function f_Compute_Grubbs(t_Ctrl_Now In t_Ctrl_Record) Return Number Is 
    n_标记 检验质控报告.标记%Type; 
  Begin 
    Select Decode(Sign(r.Si上限 - Nvl(p.N3s, 0)), 1, 2, 
                   Decode(Sign(r.Si下限 - Nvl(p.N3s, 0)), 1, 2, 
                           Decode(Sign(r.Si上限 - Nvl(p.N2s, 0)) + Sign(r.Si下限 - Nvl(p.N2s, 0)), -2, 0, 1))) 
    Into n_标记 
    From 质控即刻法 P, 
         (Select Count(*) As 次数, Round((Max(结果) - Round(Avg(结果), 3)) / Round(Stddev(结果), 3), 2) As Si上限, 
                  Round((Round(Avg(结果), 3) - Min(结果)) / Round(Stddev(结果), 3), 2) As Si下限 
           From (Select Zl_Lis_Tonumber(q.质控品id, r.检验项目id, r.检验结果, r.Id) As 结果 
                  From 检验质控记录 Q, 检验普通结果 R 
                  Where q.标本id = r.检验标本id And Nvl(r.弃用结果, 0) = 0 And q.质控品id = t_Ctrl_Now.Id And 
                        (q.检验时间 + 0 < 日期_In Or q.检验时间 + 0 = 日期_In And q.测试次数 <= t_Ctrl_Now.今日次) And r.检验项目id + 0 = 项目id_In)) R 
    Where p.n(+) = r.次数; 
    Return n_标记; 
  End f_Compute_Grubbs; 
 
  ---------------------------------------- 
  --2)常用：N-Xs失控判断函数 
  Function f_Compute_Nxs(t_Ctrl_Now In t_Ctrl_Record) Return Varchar2 Is 
    n_All符合  Number(18) := 0; 
    n_上次正负 Number(1) := 0; 
  Begin 
    For n_Batch In 1 .. a_Ctrls.Count Loop 
      If t_Rule_Now.多水平 = 1 Or (a_Ctrls(n_Batch).Id = t_Ctrl_Now.Id And t_Ctrl_Now.结果id = a_Ctrls(n_Batch).结果id) Then 
        For r_List In (Select Decode(Sign(Abs(偏离) - t_Rule_Now.x), 1, 1, 0) As 符合, Decode(Sign(偏离), -1, -1, 1) As 正负 
                       From (Select (结果 - 均值) / Sd As 偏离 
                              From (Select q.检验时间, q.测试次数, s.均值, s.Sd, 
                                            Zl_Lis_Tonumber(q.质控品id, r.检验项目id, r.检验结果, r.Id) As 结果 
                                     From 检验质控记录 Q, 检验普通结果 R, 检验质控均值 S 
                                     Where q.质控品id = s.质控品id And r.检验项目id = s.项目id And q.检验时间 Between s.开始日期 And 
                                           Nvl(s.结束日期, Sysdate) And q.标本id = r.检验标本id And Nvl(r.弃用结果, 0) = 0 And 
                                           q.质控品id = (a_Ctrls(n_Batch).Id) And q.检验时间 Between t_Ctrl_Now.开始日期 And 
                                           t_Ctrl_Now.结束日期 And 
                                           (q.检验时间 + 0 < 日期_In Or q.检验时间 + 0 = 日期_In And q.测试次数 <= t_Ctrl_Now.今日次) And 
                                           r.检验项目id + 0 = 项目id_In 
                                     Order By q.检验时间 Desc, q.测试次数 Desc) 
                              Where Rownum <= t_Rule_Now.批范围)) Loop 
          If (r_List.正负 = n_上次正负) Or n_上次正负 = 0 Then 
            n_All符合 := n_All符合 + r_List.符合; 
          Else 
            n_All符合 := r_List.符合; 
          End If; 
          n_上次正负 := r_List.正负; 
        End Loop; 
      End If; --- end t_Rule_Now.多水平 = 1 Or ....... 
    End Loop; 
    If n_All符合 >= t_Rule_Now.n Then 
      Return 'Y'; 
    Else 
      Return 'N'; 
    End If; 
  End f_Compute_Nxs; 
 
  ---------------------------------------- 
  --3)常用：R-Xs失控判断函数 
  Function f_Compute_Rxs(t_Ctrl_Now In t_Ctrl_Record) Return Varchar2 Is 
    n_自偏离  Number(18, 4); 
    n_偏离    Number(18, 4); 
    n_Bat符合 Number(18) := 0; 
  Begin 
    --先获得自身的偏离，然后根据是否多水平，决定在同批内(相同时间，不同质控品)，或同一水平上一批进行比较 
    Select (结果 - 均值) / Sd 
    Into n_自偏离 
    From (Select s.均值, s.Sd, Zl_Lis_Tonumber(q.质控品id, r.检验项目id, r.检验结果, r.Id) As 结果 
           From 检验质控记录 Q, 检验普通结果 R, 检验质控均值 S 
           Where q.质控品id = s.质控品id And r.检验项目id = s.项目id And q.检验时间 Between s.开始日期 And Nvl(s.结束日期, Sysdate) And 
                 q.标本id = r.检验标本id And Nvl(r.弃用结果, 0) = 0 And q.质控品id + 0 = t_Ctrl_Now.Id And r.检验项目id + 0 = 项目id_In And 
                 q.检验时间 = 日期_In And q.测试次数 = t_Ctrl_Now.今日次); 
    For n_Batch In 1 .. a_Ctrls.Count Loop 
      If Nvl(t_Rule_Now.多水平, 0) = 1 And a_Ctrls(n_Batch).Id <> t_Ctrl_Now.Id Then 
        If t_Rule_Now.x = 4 Then 
          Select (结果 - 均值) / Sd 
          Into n_偏离 
          From (Select s.均值, s.Sd, Zl_Lis_Tonumber(q.质控品id, r.检验项目id, r.检验结果, r.Id) As 结果 
                 From 检验质控记录 Q, 检验普通结果 R, 检验质控均值 S 
                 Where q.质控品id = s.质控品id And r.检验项目id = s.项目id And q.检验时间 Between s.开始日期 And Nvl(s.结束日期, Sysdate) And 
                       q.标本id = r.检验标本id And Nvl(r.弃用结果, 0) = 0 And q.质控品id + 0 = (a_Ctrls(n_Batch).Id) And 
                       q.检验时间 Between t_Ctrl_Now.开始日期 And t_Ctrl_Now.结束日期 And q.质控品id <> t_Ctrl_Now.Id And 
                       r.检验项目id + 0 = 项目id_In And q.检验时间 = 日期_In And q.测试次数 = t_Ctrl_Now.今日次); 
          If n_自偏离 > 2 And n_偏离 < -2 Then 
            Return 'Y'; 
          End If; 
          If n_自偏离 < -2 And n_偏离 > 2 Then 
            Return 'Y'; 
          End If; 
        Else 
          Select Max(Decode(Sign(Abs(n_自偏离 - 偏离) - t_Rule_Now.x), 1, 1, 0)) 
          Into n_Bat符合 
          From (Select (结果 - 均值) / Sd As 偏离 
                 From (Select s.均值, s.Sd, Zl_Lis_Tonumber(q.质控品id, r.检验项目id, r.检验结果, r.Id) As 结果 
                        From 检验质控记录 Q, 检验普通结果 R, 检验质控均值 S 
                        Where q.质控品id = s.质控品id And r.检验项目id = s.项目id And q.检验时间 Between s.开始日期 And Nvl(s.结束日期, Sysdate) And 
                              q.标本id = r.检验标本id And Nvl(r.弃用结果, 0) = 0 And q.质控品id + 0 = (a_Ctrls(n_Batch).Id) And 
                              q.检验时间 Between t_Ctrl_Now.开始日期 And t_Ctrl_Now.结束日期 And q.质控品id <> t_Ctrl_Now.Id And 
                              r.检验项目id + 0 = 项目id_In And q.检验时间 = 日期_In And q.测试次数 = t_Ctrl_Now.今日次)); 
          If n_Bat符合 > 0 Then 
            Return 'Y'; 
          End If; 
        End If; 
      Elsif Nvl(t_Rule_Now.多水平, 0) <> 1 And a_Ctrls(n_Batch).Id = t_Ctrl_Now.Id And a_Ctrls(n_Batch) 
           .结果id = t_Ctrl_Now.结果id Then 
        If t_Rule_Now.x = 4 Then 
          Select (结果 - 均值) / Sd 
          Into n_偏离 
          From (Select q.检验时间, q.测试次数, s.均值, s.Sd, Zl_Lis_Tonumber(q.质控品id, r.检验项目id, r.检验结果, r.Id) As 结果 
                 From 检验质控记录 Q, 检验普通结果 R, 检验质控均值 S 
                 Where q.质控品id = s.质控品id And r.检验项目id = s.项目id And q.检验时间 Between s.开始日期 And Nvl(s.结束日期, Sysdate) And 
                       q.标本id = r.检验标本id And Nvl(r.弃用结果, 0) = 0 And q.质控品id = (a_Ctrls(n_Batch).Id) And 
                       q.检验时间 Between t_Ctrl_Now.开始日期 And t_Ctrl_Now.结束日期 And r.检验项目id + 0 = 项目id_In And 
                       (q.检验时间 + 0 < 日期_In Or q.检验时间 + 0 = 日期_In And q.测试次数 < t_Ctrl_Now.今日次) 
                 Order By q.检验时间 Desc, q.测试次数 Desc) 
          Where Rownum <= 1; 
          If n_自偏离 > 2 And n_偏离 < -2 Then 
            Return 'Y'; 
          End If; 
          If n_自偏离 < -2 And n_偏离 > 2 Then 
            Return 'Y'; 
          End If; 
        Else 
          Select Max(Decode(Sign(Abs(n_自偏离 - 偏离) - t_Rule_Now.x), 1, 1, 0)) 
          Into n_Bat符合 
          From (Select (结果 - 均值) / Sd As 偏离 
                 From (Select q.检验时间, q.测试次数, s.均值, s.Sd, Zl_Lis_Tonumber(q.质控品id, r.检验项目id, r.检验结果, r.Id) As 结果 
                        From 检验质控记录 Q, 检验普通结果 R, 检验质控均值 S 
                        Where q.质控品id = s.质控品id And r.检验项目id = s.项目id And q.检验时间 Between s.开始日期 And Nvl(s.结束日期, Sysdate) And 
                              q.标本id = r.检验标本id And Nvl(r.弃用结果, 0) = 0 And q.质控品id = (a_Ctrls(n_Batch).Id) And 
                              q.检验时间 Between t_Ctrl_Now.开始日期 And t_Ctrl_Now.结束日期 And r.检验项目id + 0 = 项目id_In And 
                              (q.检验时间 + 0 < 日期_In Or q.检验时间 + 0 = 日期_In And q.测试次数 < t_Ctrl_Now.今日次) 
                        Order By q.检验时间 Desc, q.测试次数 Desc) 
                 Where Rownum <= 1); 
 
          If n_Bat符合 > 0 Then 
            Return 'Y'; 
          End If; 
        End If; 
      End If; 
    End Loop; 
    Return 'N'; 
  End f_Compute_Rxs; 
 
  ---------------------------------------- 
  --4)常用：N-T失控判断函数 
  Function f_Compute_Nt(t_Ctrl_Now In t_Ctrl_Record) Return Varchar2 Is 
    n_前值 Number(18, 3) := Null; 
    n_方向 Number(18) := Null; 
  Begin 
    --该规则固定在同一水平内进行比较 
    For r_List In (Select (结果 - 均值) / Sd As 偏离 
                   From (Select q.检验时间, q.测试次数, s.均值, s.Sd, Zl_Lis_Tonumber(q.质控品id, r.检验项目id, r.检验结果, r.Id) As 结果 
                          From 检验质控记录 Q, 检验普通结果 R, 检验质控均值 S 
                          Where q.质控品id = s.质控品id And r.检验项目id = s.项目id And q.检验时间 Between s.开始日期 And Nvl(s.结束日期, Sysdate) And 
                                q.标本id = r.检验标本id And Nvl(r.弃用结果, 0) = 0 And q.质控品id = t_Ctrl_Now.Id And 
                                q.检验时间 Between t_Ctrl_Now.开始日期 And t_Ctrl_Now.结束日期 And r.检验项目id + 0 = 项目id_In And 
                                (q.检验时间 + 0 < 日期_In Or q.检验时间 + 0 = 日期_In And q.测试次数 <= t_Ctrl_Now.今日次) 
                          Order By q.检验时间 Desc, q.测试次数 Desc) 
                   Where Rownum <= t_Rule_Now.批范围) Loop 
      If n_前值 Is Null Then 
        n_方向 := 0; 
      Else 
        n_方向 := n_方向 + Sign(n_前值 - Nvl(r_List.偏离, 0)); 
      End If; 
      n_前值 := Round(Nvl(r_List.偏离, 0), 3); 
    End Loop; 
    If Abs(n_方向) + 1 >= t_Rule_Now.n Then 
      Return 'Y'; 
    Else 
      Return 'N'; 
    End If; 
  End f_Compute_Nt; 
 
  ---------------------------------------- 
  --5)常用：N-X失控判断函数 
  Function f_Compute_Nx(t_Ctrl_Now In t_Ctrl_Record) Return Varchar2 Is 
    n_正向 Number(18) := 0; 
    n_负向 Number(18) := 0; 
  Begin 
    For r_List In (Select Decode(Sign((结果 - 均值) / Sd), 1, 1, 0) As 正向, Decode(Sign((结果 - 均值) / Sd), -1, 1, 0) As 负向 
                   From (Select q.检验时间, q.测试次数, s.均值, s.Sd, Zl_Lis_Tonumber(q.质控品id, r.检验项目id, r.检验结果, r.Id) As 结果 
                          From 检验质控记录 Q, 检验普通结果 R, 检验质控均值 S 
                          Where q.质控品id = s.质控品id And r.检验项目id = s.项目id And q.检验时间 Between s.开始日期 And Nvl(s.结束日期, Sysdate) And 
                                q.标本id = r.检验标本id And Nvl(r.弃用结果, 0) = 0 And 
                                (Nvl(t_Rule_Now.多水平, 0) = 1 And Instr(',' || 质控品_In || ',', ',' || q.质控品id || ',') > 0 Or 
                                q.质控品id = t_Ctrl_Now.Id) And r.检验项目id + 0 = 项目id_In And q.检验时间 Between t_Ctrl_Now.开始日期 And 
                                t_Ctrl_Now.结束日期 And (q.检验时间 < 日期_In Or q.检验时间 = 日期_In And q.测试次数 <= t_Ctrl_Now.今日次) 
                          Order By q.检验时间 Desc, q.测试次数 Desc) 
                   --Where Rownum <= t_Rule_Now.批范围 * Decode(Nvl(t_Rule_Now.多水平, 0), 0, 1, n_水平数)) Loop 
                   Where Rownum <= t_Rule_Now.n) Loop 
      If r_List.正向 = 0 Then 
        n_正向 := 0; 
      Else 
        n_正向 := n_正向 + r_List.正向; 
      End If; 
      If r_List.负向 = 0 Then 
        n_负向 := 0; 
      Else 
        n_负向 := n_负向 + r_List.负向; 
      End If; 
    End Loop; 
    If n_正向 >= t_Rule_Now.n Or n_负向 >= t_Rule_Now.n Then 
      Return 'Y'; 
    Else 
      Return 'N'; 
    End If; 
  End f_Compute_Nx; 
 
  ---------------------------------------- 
  --6)常用：(MofN)Xs失控判断函数 
  Function f_Compute_Mnxs(t_Ctrl_Now In t_Ctrl_Record) Return Varchar2 Is 
    n_Bat符合 Number(10, 3) := 0; 
    n_All符合 Number(18) := 0; 
  Begin 
    For n_Batch In 1 .. a_Ctrls.Count Loop 
      If Nvl(t_Rule_Now.多水平, 0) = 1 Or a_Ctrls(n_Batch).Id = t_Ctrl_Now.Id And a_Ctrls(n_Batch).结果id = t_Ctrl_Now.结果id Then 
        Select Sum(Decode(Sign(Abs(偏离) - t_Rule_Now.x), 1, 1, 0)) 
        Into n_Bat符合 
        From (Select (结果 - 均值) / Sd As 偏离 
               From (Select q.检验时间, q.测试次数, s.均值, s.Sd, Zl_Lis_Tonumber(q.质控品id, r.检验项目id, r.检验结果, r.Id) As 结果 
                      From 检验质控记录 Q, 检验普通结果 R, 检验质控均值 S 
                      Where q.质控品id = s.质控品id And r.检验项目id = s.项目id And q.检验时间 Between s.开始日期 And Nvl(s.结束日期, Sysdate) And 
                            q.标本id = r.检验标本id And Nvl(r.弃用结果, 0) = 0 And q.质控品id = t_Ctrl_Now.Id And r.检验项目id + 0 = 项目id_In And 
                            q.检验时间 Between t_Ctrl_Now.开始日期 And t_Ctrl_Now.结束日期 And 
                            (q.检验时间 + 0 < 日期_In Or q.检验时间 + 0 = 日期_In And q.测试次数 <= t_Ctrl_Now.今日次) 
                      Order By q.检验时间 Desc, q.测试次数 Desc) 
               Where Rownum <= t_Rule_Now.批范围); 
        n_All符合 := n_All符合 + n_Bat符合; 
      End If; 
    End Loop; 
    If n_All符合 >= t_Rule_Now.m Then 
      Return 'Y'; 
    Else 
      Return 'N'; 
    End If; 
  End f_Compute_Mnxs; 
 
  ---------------------------------------- 
  --7)计算控制界限失控判断函数：对该规则的理解还需要继续证实 
  Function f_Compute_Limit(t_Ctrl_Now In t_Ctrl_Record) Return Varchar2 Is 
    n_基础 质控控界系数.基础%Type := 0; 
    n_系数 质控控界系数.N2%Type := 0; 
    n_累积 检验质控均值.均值%Type := 0; 
    n_界限 检验质控均值.均值%Type := 0; 
    Type t_Value_Table Is Table Of Number(18, 4); 
    a_Values  t_Value_Table; 
    n_All符合 Number(18) := 0; 
  Begin 
    --获得计算基础和系数：由于我们目前限制每批选择水平不超过9，因此只取这几个系数，否则等3（等同与1-3s） 
    Select 基础, Decode(n_水平数, 2, N2, 3, N3, 4, N4, 5, N4, 6, N6, 7, N7, 8, N7, 9, N7, 3) 
    Into n_基础, n_系数 
    From 质控控界系数 
    Where 规则 = t_Ctrl_Now.名称; 
    If n_基础 = 1 Then 
      n_界限 := Round(t_Ctrl_Now.均值 * n_系数, 4); 
    Else 
      --计算该控制品的移动平均极差R,然后计算控制界限 
      Select Round(结果, 4) Bulk Collect 
      Into a_Values 
      From (Select q.检验时间, q.测试次数, Zl_Lis_Tonumber(q.质控品id, r.检验项目id, r.检验结果, r.Id) As 结果 
             From 检验质控记录 Q, 检验普通结果 R 
             Where q.标本id = r.检验标本id And Nvl(r.弃用结果, 0) = 0 And q.质控品id = t_Ctrl_Now.Id And r.检验项目id + 0 = 项目id_In And 
                   q.检验时间 Between t_Ctrl_Now.开始日期 And t_Ctrl_Now.结束日期 And 
                   (q.检验时间 + 0 < 日期_In Or q.检验时间 + 0 = 日期_In And q.测试次数 <= t_Ctrl_Now.今日次) 
             Order By q.检验时间 Desc, q.测试次数 Desc) 
      Where Rownum <= t_Rule_Now.批范围; 
      If a_Values.Count < 2 Then 
        Return 'N'; 
      End If; 
      For n_Count In Reverse 1 .. a_Values.Count - 1 Loop 
        n_累积 := n_累积 + Round(Abs(a_Values(n_Count - 1) - a_Values(n_Count)), 4); 
      End Loop; 
      n_界限 := Round(n_累积 / (a_Values.Count - 1) * n_系数, 4); 
    End If; 
 
    --根据规则形式进行判断：0:N-P,1:X-P,2:R-P 
    If t_Rule_Now.形式 = 0 Then 
      Select Sum(Decode(Sign(结果 - n_界限), 1, 1, 0)) 
      Into n_All符合 
      From (Select 结果 
             From (Select q.检验时间, q.测试次数, Zl_Lis_Tonumber(q.质控品id, r.检验项目id, r.检验结果, r.Id) As 结果 
                    From 检验质控记录 Q, 检验普通结果 R 
                    Where q.标本id = r.检验标本id And Nvl(r.弃用结果, 0) = 0 And q.质控品id = t_Ctrl_Now.Id And r.检验项目id + 0 = 项目id_In And 
                          q.检验时间 Between t_Ctrl_Now.开始日期 And t_Ctrl_Now.结束日期 And 
                          (q.检验时间 + 0 < 日期_In Or q.检验时间 + 0 = 日期_In And q.测试次数 <= t_Ctrl_Now.今日次) 
                    Order By q.检验时间 Desc, q.测试次数 Desc) 
             Where Rownum <= t_Rule_Now.n); 
      If n_All符合 >= t_Rule_Now.n Then 
        Return 'Y'; 
      End If; 
    Elsif t_Rule_Now.形式 = 1 Then 
      Select Sign(Avg(结果) - n_界限) 
      Into n_All符合 
      From (Select 结果 
             From (Select q.检验时间, q.测试次数, Zl_Lis_Tonumber(q.质控品id, r.检验项目id, r.检验结果, r.Id) As 结果 
                    From 检验质控记录 Q, 检验普通结果 R 
                    Where q.标本id = r.检验标本id And Nvl(r.弃用结果, 0) = 0 And q.质控品id = t_Ctrl_Now.Id And r.检验项目id + 0 = 项目id_In And 
                          q.检验时间 Between t_Ctrl_Now.开始日期 And t_Ctrl_Now.结束日期 And 
                          (q.检验时间 + 0 < 日期_In Or q.检验时间 + 0 = 日期_In And q.测试次数 <= t_Ctrl_Now.今日次) 
                    Order By q.检验时间 Desc, q.测试次数 Desc) 
             Where Rownum <= t_Rule_Now.批范围); 
      If n_All符合 >= 1 Then 
        Return 'Y'; 
      End If; 
    Elsif t_Rule_Now.形式 = 2 Then 
      Select Sign(Max(结果) - Min(结果) - n_界限) 
      Into n_All符合 
      From (Select 结果 
             From (Select q.检验时间, q.测试次数, Zl_Lis_Tonumber(q.质控品id, r.检验项目id, r.检验结果, r.Id) As 结果 
                    From 检验质控记录 Q, 检验普通结果 R 
                    Where q.标本id = r.检验标本id And Nvl(r.弃用结果, 0) = 0 And q.质控品id = t_Ctrl_Now.Id And r.检验项目id + 0 = 项目id_In And 
                          q.检验时间 Between t_Ctrl_Now.开始日期 And t_Ctrl_Now.结束日期 And 
                          (q.检验时间 + 0 < 日期_In Or q.检验时间 + 0 = 日期_In And q.测试次数 <= t_Ctrl_Now.今日次) 
                    Order By q.检验时间 Desc, q.测试次数 Desc) 
             Where Rownum <= t_Rule_Now.批范围); 
      If n_All符合 >= 1 Then 
        Return 'Y'; 
      End If; 
    End If; 
    Return 'N'; 
  End f_Compute_Limit; 
 
  ---------------------------------------- 
  --8)累积和失控判断函数 
  Function f_Compute_Cusum(t_Ctrl_Now In t_Ctrl_Record) Return Varchar2 Is 
    n_累积 检验质控均值.均值%Type := 0; 
    n_偏离 检验质控均值.均值%Type := 0; 
    Type t_Value_Table Is Table Of Number(18, 4); 
    a_Values t_Value_Table; 
  Begin 
    Select Round(结果 - t_Ctrl_Now.均值, 4) Bulk Collect 
    Into a_Values 
    From (Select q.检验时间, q.测试次数, Zl_Lis_Tonumber(q.质控品id, r.检验项目id, r.检验结果, r.Id) As 结果 
           From 检验质控记录 Q, 检验普通结果 R 
           Where q.标本id = r.检验标本id And Nvl(r.弃用结果, 0) = 0 And q.质控品id = t_Ctrl_Now.Id And r.检验项目id + 0 = 项目id_In And 
                 q.检验时间 Between t_Ctrl_Now.开始日期 And t_Ctrl_Now.结束日期 And 
                 (q.检验时间 + 0 < 日期_In Or q.检验时间 + 0 = 日期_In And q.测试次数 <= t_Ctrl_Now.今日次) 
           Order By q.检验时间 Desc, q.测试次数 Desc) 
    Where Rownum <= t_Rule_Now.批范围; 
    For n_Count In Reverse 1 .. a_Values.Count Loop 
      If Sign(Abs(a_Values(n_Count)) - t_Rule_Now.k * t_Ctrl_Now.Sd) = 1 Then 
        n_偏离 := Round((Abs(a_Values(n_Count)) - t_Rule_Now.k * t_Ctrl_Now.Sd) * Sign(a_Values(n_Count)), 4); 
      Else 
        n_偏离 := 0; 
      End If; 
      If Sign(n_累积) = 0 Then 
        n_累积 := n_偏离; 
      Elsif Sign(n_累积) <> Sign(n_累积 + n_偏离) Then 
        n_累积 := n_偏离; 
      Else 
        n_累积 := n_累积 + n_偏离; 
      End If; 
    End Loop; 
    If Abs(n_累积) > t_Rule_Now.h * t_Ctrl_Now.Sd Then 
      Return 'Y'; 
    Else 
      Return 'N'; 
    End If; 
  End f_Compute_Cusum; 
 
  ---------------------------------------------------- 
  --以下为主过程 
  ---------------------------------------------------- 
Begin 
  ---------------------------------------- 
  --能否进行质控计算的基本检查 
  ---------------------------------------- 
  If 日期_In <> Trunc(日期_In) Then 
    v_Rerutn := '日期指定错误(不能指定时间)！'; 
    Return v_Rerutn; 
  End If; 
  Select Nvl(质控水平数, 0) Into n_水平数 From 检验仪器 Where ID = 仪器id_In; 
  If n_水平数 = 0 Then 
    v_Rerutn := '未设置仪器的质控水平数，不能进行失控计算！'; 
    Return v_Rerutn; 
  End If; 
  --n_水平数 := 水平数_In; 
  For Row_Ctrls In Cur_Ctrls Loop 
    a_Ctrls.Extend; 
    --     M.ID, M.批号, M.名称, M.水平, X.均值, X.Sd, 
    --           Nvl(Max(Decode(Sign(Q.检验时间 - 日期_In), 0, Q.测试次数)), 0) As 今日次, Nvl(Count(*), 0) As 累计次, 
    --           D.规则数, 0, '' As 规则 , '' As 提示 
    a_Ctrls(a_Ctrls.Count).标本id := Row_Ctrls.标本id; 
    a_Ctrls(a_Ctrls.Count).结果id := Row_Ctrls.结果id; 
    a_Ctrls(a_Ctrls.Count).Id := Row_Ctrls.Id; 
    a_Ctrls(a_Ctrls.Count).批号 := Row_Ctrls.批号; 
    a_Ctrls(a_Ctrls.Count).名称 := Row_Ctrls.名称; 
    a_Ctrls(a_Ctrls.Count).水平 := Row_Ctrls.水平; 
    a_Ctrls(a_Ctrls.Count).均值 := Row_Ctrls.均值; 
    a_Ctrls(a_Ctrls.Count).Sd := Row_Ctrls.Sd; 
    a_Ctrls(a_Ctrls.Count).今日次 := Row_Ctrls.今日次; 
    a_Ctrls(a_Ctrls.Count).累计次 := Row_Ctrls.累计次; 
    a_Ctrls(a_Ctrls.Count).规则数 := Row_Ctrls.规则数; 
    a_Ctrls(a_Ctrls.Count).规则 := Row_Ctrls.规则; 
    a_Ctrls(a_Ctrls.Count).提示 := Row_Ctrls.提示; 
 
    a_Ctrls(a_Ctrls.Count).开始日期 := Row_Ctrls.开始日期; 
    a_Ctrls(a_Ctrls.Count).结束日期 := Row_Ctrls.结束日期; 
 
  End Loop; 
 
  --If a_Ctrls.Count <> n_水平数 Then 
  --  v_Rerutn := '选择的质控品水平不符合质控要求，不能进行失控计算！'; 
  --  Return v_Rerutn; 
  --End If; 
  For n_Count In 1 .. a_Ctrls.Count Loop 
    ---- 
    ---- 
    --If a_Ctrls(n_Count).水平 <> n_Count Then 
    --  v_Rerutn := '选择的质控品水平不符合质控要求，不能进行失控计算！'; 
    --  Return v_Rerutn; 
    ---End If; 
 
    If a_Ctrls(n_Count).今日次 = 0 Then 
      v_Rerutn := (a_Ctrls(n_Count).批号) || (a_Ctrls(n_Count).名称) || '当日未进行新的质控，不能进行失控计算！'; 
      Return v_Rerutn; 
    End If; 
    -- If n_Count > 1 Then 
    --   If a_Ctrls(n_Count).今日次 <> a_Ctrls(n_Count - 1).今日次 Then 
    --     v_Rerutn := '几个质控品进行的测试次数不一致，不能进行失控计算！'; 
    ---     Return v_Rerutn; 
    --   End If; 
    -- End If; 
    a_Ctrls(n_Count).累计次 := a_Ctrls.Count; 
    If Nvl(a_Ctrls(n_Count).累计次, 0) < 3 And (Nvl(a_Ctrls(n_Count).均值, 0) = 0 Or Nvl(a_Ctrls(n_Count).Sd, 0) = 0) Then 
      v_Rerutn := (a_Ctrls(n_Count).批号) || (a_Ctrls(n_Count).名称) || '未定值，在质控不到3次时，不能进行失控计算！'; 
      Return v_Rerutn; 
    End If; 
    If Nvl(a_Ctrls(n_Count).累计次, 0) > 20 Then 
      If (Nvl(a_Ctrls(n_Count).均值, 0) = 0 Or Nvl(a_Ctrls(n_Count).Sd, 0) = 0) Then 
        v_Rerutn := (a_Ctrls(n_Count).批号) || (a_Ctrls(n_Count).名称) || '已经超过20次质控，不能再用即刻法进行失控判断。' || Chr(13) || Chr(10) || 
                    '但由于尚未定值，不能进行失控计算！'; 
        Return v_Rerutn; 
      End If; 
      If Nvl(a_Ctrls(n_Count).规则数, 0) = 0 Then 
        v_Rerutn := (a_Ctrls(n_Count).批号) || (a_Ctrls(n_Count).名称) || '已经超过20次质控，不能再用即刻法进行失控判断。' || Chr(13) || Chr(10) || 
                    '但由于仪器尚未设置质控规则，不能进行失控计算！'; 
        Return v_Rerutn; 
      End If; 
    End If; 
  End Loop; 
 
  ---------------------------------------- 
  --按质控品，循环进行多规则的计算 
  ---------------------------------------- 
  Select ID Bulk Collect 
  Into a_Step 
  From 检验仪器规则 
  Where 仪器id = 仪器id_In And 项目id = 项目id_In And Nvl(是否使用, 0) = 1 And 上级id Is Null 
  Order By 性质; 
  v_Rerutn := ''; 
  For n_Count In 1 .. a_Ctrls.Count Loop 
    If Nvl(a_Ctrls(n_Count).累计次, 0) <= 20 And (Nvl(a_Ctrls(n_Count).均值, 0) = 0 Or Nvl(a_Ctrls(n_Count).Sd, 0) = 0) Then 
      --即刻法: 
      a_Ctrls(n_Count).标记 := f_Compute_Grubbs(a_Ctrls(n_Count)); 
      If a_Ctrls(n_Count).标记 >= 0 Then 
        a_Ctrls(n_Count).规则 := '/Grubbs'; 
        a_Ctrls(n_Count).提示 := '请舍去该检测结果并纠错重新检测！'; 
      End If; 
    Else 
      --用户规则: 
      For n_Step In 1 .. a_Step.Count Loop 
        n_步骤id := a_Step(n_Step); 
        While n_步骤id <> 0 Loop 
          Select b.名称, Nvl(b.种类, 0), Nvl(b.形式, 0), Nvl(b.n, 0), Nvl(b.x, 0), Nvl(b.m, 0), Nvl(b.p, 0), Nvl(b.k, 0), 
                 Nvl(b.h, 0), Nvl(r.批范围, 0), Nvl(r.多水平, 0), Nvl(r.Y标记级, 0), r.Y规则, Nvl(r.Y结束, 0), r.Y提示, Nvl(r.N标记级, 0), 
                 r.N规则, Nvl(r.N结束, 0), r.N提示 
          Into t_Rule_Now 
          From 检验仪器规则 R, 检验质控规则 B 
          Where r.规则id = b.Id And r.Id = n_步骤id; 
          If t_Rule_Now.种类 = 1 And t_Rule_Now.形式 = 0 Then 
            v_性质 := f_Compute_Nxs(a_Ctrls(n_Count)); 
          Elsif t_Rule_Now.种类 = 1 And t_Rule_Now.形式 = 1 Then 
            v_性质 := f_Compute_Rxs(a_Ctrls(n_Count)); 
          Elsif t_Rule_Now.种类 = 1 And t_Rule_Now.形式 = 2 Then 
            v_性质 := f_Compute_Nt(a_Ctrls(n_Count)); 
          Elsif t_Rule_Now.种类 = 1 And t_Rule_Now.形式 = 3 Then 
            v_性质 := f_Compute_Nx(a_Ctrls(n_Count)); 
          Elsif t_Rule_Now.种类 = 1 And t_Rule_Now.形式 = 4 Then 
            v_性质 := f_Compute_Mnxs(a_Ctrls(n_Count)); 
          Elsif t_Rule_Now.种类 = 2 Then 
            v_性质 := f_Compute_Limit(a_Ctrls(n_Count)); 
          Elsif t_Rule_Now.种类 = 3 Then 
            v_性质 := f_Compute_Cusum(a_Ctrls(n_Count)); 
          End If; 
          If v_性质 = 'Y' Then 
            If Nvl(a_Ctrls(n_Count).标记, 0) <= Nvl(t_Rule_Now.Y标记级, 0) Then 
              a_Ctrls(n_Count).标记 := Nvl(t_Rule_Now.Y标记级, 0); 
              If Nvl(Instr(a_Ctrls(n_Count).规则, t_Rule_Now.Y规则), 0) = 0 Then 
                a_Ctrls(n_Count).规则 := RTrim(Substrb(a_Ctrls(n_Count).规则 || '/' || t_Rule_Now.Y规则, 1, 100)); 
              End If; 
            End If; 
            If Nvl(t_Rule_Now.Y结束, 0) = 1 Then 
              n_步骤id := 0; 
              a_Ctrls(n_Count).提示 := RTrim(Substrb(a_Ctrls(n_Count).提示 || ' ' || t_Rule_Now.Y提示, 1, 500)); 
            Else 
              Select Nvl(Max(ID), 0) Into n_步骤id From 检验仪器规则 Where 上级id = n_步骤id And 性质 = 'Y'; 
            End If; 
          Else 
            If a_Ctrls(n_Count).标记 < Nvl(t_Rule_Now.N标记级, 0) Then 
              a_Ctrls(n_Count).标记 := Nvl(t_Rule_Now.N标记级, 0); 
              If Nvl(Instr(a_Ctrls(n_Count).规则, t_Rule_Now.N规则), 0) = 0 Then 
                a_Ctrls(n_Count).规则 := RTrim(Substrb(a_Ctrls(n_Count).规则 || '/' || t_Rule_Now.N规则, 1, 100)); 
              End If; 
            End If; 
            If Nvl(t_Rule_Now.N结束, 0) = 1 Then 
              n_步骤id := 0; 
              a_Ctrls(n_Count).提示 := RTrim(Substrb(a_Ctrls(n_Count).提示 || ' ' || t_Rule_Now.N提示, 1, 500)); 
            Else 
              Select Nvl(Max(ID), 0) Into n_步骤id From 检验仪器规则 Where 上级id = n_步骤id And 性质 = 'N'; 
            End If; 
          End If; 
        End Loop; 
      End Loop; 
    End If; 
  End Loop; 
 
  --处理失控报告 
  For n_Count In 1 .. a_Ctrls.Count Loop 
 
    If a_Ctrls(n_Count).标记 > 0 Then 
 
      Select r.Id 
      Into n_结果id 
      From 检验质控记录 Q, 检验普通结果 R 
      Where q.标本id = r.检验标本id And Nvl(r.弃用结果, 0) = 0 And q.质控品id + 0 = (a_Ctrls(n_Count).Id) And r.检验项目id + 0 = 项目id_In And 
            q.检验时间 = 日期_In And q.测试次数 = (a_Ctrls(n_Count).今日次); 
 
      Update 检验质控报告 
      Set 标记 = a_Ctrls(n_Count).标记, 规则 = Substr(a_Ctrls(n_Count).规则, 2), 提示 = LTrim(a_Ctrls(n_Count).提示) 
      Where 结果id = n_结果id And 项目id = 项目id_In; 
 
      If Sql%Rowcount = 0 Then 
        Insert Into 检验质控报告 
          (结果id, 标记, 规则, 提示, 项目id) 
          Select r.Id, (a_Ctrls(n_Count).标记), Substr(a_Ctrls(n_Count).规则, 2), LTrim(a_Ctrls(n_Count).提示), r.检验项目id 
          From 检验质控记录 Q, 检验普通结果 R 
          Where q.标本id = r.检验标本id And Nvl(r.弃用结果, 0) = 0 And q.质控品id + 0 = (a_Ctrls(n_Count).Id) And 
                r.检验项目id + 0 = 项目id_In And q.检验时间 = 日期_In And q.测试次数 = (a_Ctrls(n_Count).今日次); 
 
      End If; 
 
      If a_Ctrls(n_Count).标记 = 1 Then 
        v_Rerutn := v_Rerutn || Chr(13) || Chr(10) || (a_Ctrls(n_Count).批号) || (a_Ctrls(n_Count).名称) || '出现警告！'; 
 
      Else 
        v_Rerutn := v_Rerutn || Chr(13) || Chr(10) || (a_Ctrls(n_Count).批号) || (a_Ctrls(n_Count).名称) || '出现失控！'; 
 
        If 日期_In = Trunc(Sysdate) Then 
          Update 检验仪器状态 
          Set 失控标记 = Substr(a_Ctrls(n_Count).规则, 2), 失控日期 = 日期_In 
          Where 仪器id = 仪器id_In And 项目id = 项目id_In; 
          If Sql%Rowcount = 0 Then 
            Insert Into 检验仪器状态 
              (仪器id, 项目id, 失控标记, 失控日期) 
            Values 
              (仪器id_In, 项目id_In, Substr(a_Ctrls(n_Count).规则, 2), 日期_In); 
          End If; 
        End If; 
      End If; 
    Else 
      --清除原有的警告和失控标记 
      Delete 检验质控报告 
      Where 结果id In (Select r.Id 
                     From 检验质控记录 Q, 检验普通结果 R 
                     Where q.标本id = r.检验标本id And q.质控品id + 0 = (a_Ctrls(n_Count).Id) And r.检验项目id + 0 = 项目id_In And 
                           q.检验时间 = 日期_In And q.测试次数 = (a_Ctrls(n_Count).今日次)); 
    End If; 
  End Loop; 
 
  If v_Rerutn Is Null Then 
    v_Rerutn := '计算完成，按规则未发现警告和失控！'; 
    If 日期_In = Trunc(Sysdate) Then 
      Delete 检验仪器状态 Where 仪器id = 仪器id_In And 项目id = 项目id_In; 
    End If; 
  Else 
    v_Rerutn := '计算完成，其中：' || v_Rerutn || Chr(13) || Chr(10) || '——请查看质控报告提示信息。'; 
  End If; 
  Commit; 
  Return v_Rerutn; 
Exception 
  When Others Then 
    Rollback; 
    Return '因失控计算过程发生错误意外终止！'; 
End Zl_检验质控记录_Compute;
/

