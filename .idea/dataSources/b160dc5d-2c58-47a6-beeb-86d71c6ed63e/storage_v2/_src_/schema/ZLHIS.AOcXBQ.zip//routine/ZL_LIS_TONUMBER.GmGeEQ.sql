create Function Zl_Lis_Tonumber 
( 
  质控品id_In   In Number, 
  检验项目id_In In Number, 
  检验结果_In   In Varchar2, 
  检验结果id_In In Number := 0 
) Return Number Is 
  n_Output     Number; 
  n_检验类型   Number; 
  v_取值序列   Varchar2(500); 
  v_序列值     Varchar2(500); 
  v_项目       Varchar2(500); 
  v_Tmp        Varchar2(500); 
  n_对数质控图 检验仪器.对数质控图%Type := 0; 
  n_小数       Number; 
  n_仪器id     Number; 
  v_质控取值   Varchar2(100); 
  Cursor Cur_Tmp Is 
    Select Column_Value As 项目 
    From Table(Cast(f_Str2list(Replace(v_取值序列, ';', ',')) As ZLTOOLS.t_Strlist)) 
    Order By Length(Column_Value) Desc; 
 
Begin 
  n_Output := 0; 
 
  Select 结果类型 Into n_检验类型 From 检验项目 Where 诊治项目id = 检验项目id_In; 
 
  If n_检验类型 = 1 Then 
    --定量 
    n_Output := To_Number(检验结果_In); 
  Else 
    --定性结果,半定量 
    Select 取值序列, 序列值, 质控取值 
    Into v_取值序列, v_序列值, v_质控取值 
    From 检验质控品项目 
    Where 质控品id = 质控品id_In And 项目id = 检验项目id_In; 
 
    If Instr('[SCO],[OD]', v_质控取值) > 0 And 检验结果id_In <> 0 Then 
      -- 酶标质控 
      If v_质控取值 = '[SCO]' Then 
        Select Nvl(Sco, 0) Into n_Output From 检验普通结果 Where ID = 检验结果id_In; 
      Else 
        Select Nvl(Od, 0) Into n_Output From 检验普通结果 Where ID = 检验结果id_In; 
      End If; 
    Else 
      If Length(v_序列值) > 0 And Length(v_取值序列) > 0 Then 
        If Instr(v_取值序列, ';') > 0 Then 
          For c_Tmp In Cur_Tmp Loop 
            If Instr(检验结果_In, c_Tmp.项目) > 0 Then 
              v_项目 := c_Tmp.项目; 
              Exit; 
            End If; 
          End Loop; 
          v_取值序列 := v_取值序列 || ';'; 
          v_序列值   := v_序列值 || ';'; 
 
          While v_取值序列 Is Not Null Loop 
            v_Tmp := Substr(v_取值序列, 1, Instr(v_取值序列, ';') - 1); 
            If v_项目 = v_Tmp Then 
              n_Output := Substr(v_序列值, 1, Instr(v_序列值, ';') - 1); 
              Exit; 
            End If; 
            v_取值序列 := Substr(v_取值序列, Instr(v_取值序列, ';') + 1); 
            v_序列值   := Substr(v_序列值, Instr(v_序列值, ';') + 1); 
          End Loop; 
        Else 
          If Instr(检验结果_In, v_取值序列) > 0 Then 
            If Instr(v_序列值, ';') <= 0 Then 
              n_Output := To_Number(v_序列值); 
            End If; 
          End If; 
        End If; 
      End If; 
    End If; 
  End If; 
 
  Select A.对数质控图, A.ID 
  Into n_对数质控图, n_仪器id 
  From 检验仪器 A, 检验质控品 B 
  Where A.ID = B.仪器id And B.ID = 质控品id_In; 
  Begin 
    Select Nvl(小数位数, 2) 
    Into n_小数 
    From 检验仪器项目 
    Where 仪器id = n_仪器id And 项目id = 检验项目id_In And Rownum < 2; 
  Exception 
    When Others Then 
      n_小数 := 2; 
  End; 
  If n_对数质控图 = 1 Then 
    If n_小数 Is Null Then 
      n_小数 := 2; 
    End If; 
    Select Log(10, n_Output) Into n_Output From Dual; 
    If Instr(To_Char(n_Output), '.') > 0 Then 
      n_Output := To_Number(Substr(To_Char(n_Output), 1, Instr(To_Char(n_Output), '.') + n_小数)); 
    End If; 
  End If; 
 
  Return n_Output; 
Exception 
  When Others Then 
    Return 0; 
End Zl_Lis_Tonumber;
/

