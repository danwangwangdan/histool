create Function Zl_Lob_Read 
( 
  Tab_In     In Number, 
  Key_In     In Varchar2, 
  Pos_In     In Number, 
  Moved_In   In Number := 0, 
  Lobtype_In In Number := 0 
  --参数说明： 
  --Tab_In：包含LOB的数据表 
  --        0-病历标记图形;1-病历文件格式;2-病历文件图形;3-病历范文格式;4-病历范文图形; 
  --        5-电子病历格式;6-电子病历图形;7-病历页面格式(图形);8-电子病历附件;9-体温重叠标记; 
  --        10-临床路径文件;11-临床路径图标;12-病历页面格式(页眉文件);13-病历页面格式(页脚文件); 
  --        14-人员证书记录;19-部门扩展信息;20-人员扩展信息; 
  --Key_In：数据记录的关键字 
  --Pos_In：从0开始不断读取，直到返回为空 
  --Moved_In: 0正常记录,1读取转储后备表记录 
  --LobType_IN:0-BLOb,1-CLOB 
) Return Varchar2 Is 
  l_Blob   Blob; 
  l_Clob   Clob; 
  v_Buffer Varchar2(32767); 
  n_Amount Number := 2000; 
  n_Offset Number := 1; 
  t_Key    t_Strlist; 
Begin 
  If Tab_In = 0 Then 
    Select 图形 Into l_Blob From 病历标记图形 Where 编码 = Key_In; 
  Elsif Tab_In = 1 Then 
    Select 内容 Into l_Blob From 病历文件格式 Where 文件id = To_Number(Key_In); 
  Elsif Tab_In = 2 Then 
    Select 图形 Into l_Blob From 病历文件图形 Where 对象id = To_Number(Key_In); 
  Elsif Tab_In = 3 Then 
    Select 内容 Into l_Blob From 病历范文格式 Where 文件id = To_Number(Key_In); 
  Elsif Tab_In = 4 Then 
    Select 图形 Into l_Blob From 病历范文图形 Where 对象id = To_Number(Key_In); 
  Elsif Tab_In = 5 Then 
    If Moved_In = 0 Then 
      Select 内容 Into l_Blob From 电子病历格式 Where 文件id = To_Number(Key_In); 
    Else 
      Select 内容 Into l_Blob From H电子病历格式 Where 文件id = To_Number(Key_In); 
    End If; 
  Elsif Tab_In = 6 Then 
    If Moved_In = 0 Then 
      Select 图形 Into l_Blob From 电子病历图形 Where 对象id = To_Number(Key_In); 
    Else 
      Select 图形 Into l_Blob From H电子病历图形 Where 对象id = To_Number(Key_In); 
    End If; 
  Elsif Tab_In = 7 Then 
    Select 图形 
    Into l_Blob 
    From 病历页面格式 
    Where 种类 = To_Number(Substr(Key_In, 1, 1)) And 编号 = Substr(Key_In, 3); 
  Elsif Tab_In = 8 Then 
    If Moved_In = 0 Then 
      Select 内容 
      Into l_Blob 
      From 电子病历附件 
      Where 病历id = To_Number(Substr(Key_In, 1, Instr(Key_In, ',') - 1)) And 序号 = Substr(Key_In, Instr(Key_In, ',') + 1); 
    Else 
      Select 内容 
      Into l_Blob 
      From H电子病历附件 
      Where 病历id = To_Number(Substr(Key_In, 1, Instr(Key_In, ',') - 1)) And 序号 = Substr(Key_In, Instr(Key_In, ',') + 1); 
    End If; 
  Elsif Tab_In = 9 Then 
    Select 标记图形 Into l_Blob From 体温重叠标记 Where 序号 = To_Number(Key_In); 
  Elsif Tab_In = 10 Then 
    Select 内容 
    Into l_Blob 
    From 临床路径文件 
    Where 路径id = To_Number(Substr(Key_In, 1, Instr(Key_In, ',') - 1)) And 文件名 = Substr(Key_In, Instr(Key_In, ',') + 1); 
  Elsif Tab_In = 11 Then 
    Select 图标 Into l_Blob From 临床路径图标 Where ID = To_Number(Key_In); 
  Elsif Tab_In = 12 Then 
    Select 页眉文件 
    Into l_Blob 
    From 病历页面格式 
    Where 种类 = To_Number(Substr(Key_In, 1, 1)) And 编号 = Substr(Key_In, 3); 
  Elsif Tab_In = 13 Then 
    Select 页脚文件 
    Into l_Blob 
    From 病历页面格式 
    Where 种类 = To_Number(Substr(Key_In, 1, 1)) And 编号 = Substr(Key_In, 3); 
  Elsif Tab_In = 14 Then 
    Select Column_Value Bulk Collect Into t_Key From Table(f_Str2list(Key_In)); 
    Select 签章信息 Into l_Clob From 人员证书记录 Where 人员id = To_Number(t_Key(1)) And Certsn = t_Key(2); 
  Elsif Tab_In = 19 Then 
    Select Column_Value Bulk Collect Into t_Key From Table(f_Str2list(Key_In)); 
    Select 图片 Into l_Blob From 部门扩展信息 Where 部门id = To_Number(t_Key(1)) And 项目 = t_Key(2); 
  Elsif Tab_In = 20 Then 
    Select Column_Value Bulk Collect Into t_Key From Table(f_Str2list(Key_In)); 
    Select 图片 Into l_Blob From 人员扩展信息 Where 人员id = To_Number(t_Key(1)) And 项目 = t_Key(2); 
  End If; 
 
  n_Offset := n_Offset + Pos_In * n_Amount; 
  If Lobtype_In = 1 Then 
    If l_Clob Is Null Then 
      v_Buffer := Null; 
    Else 
      Dbms_Lob.Read(l_Clob, n_Amount, n_Offset, v_Buffer); 
    End If; 
  Else 
    If l_Blob Is Null Then 
      v_Buffer := Null; 
    Else 
      Dbms_Lob.Read(l_Blob, n_Amount, n_Offset, v_Buffer); 
    End If; 
  End If; 
  Return v_Buffer; 
Exception 
  When No_Data_Found Then 
    Return Null; 
End Zl_Lob_Read;
/

