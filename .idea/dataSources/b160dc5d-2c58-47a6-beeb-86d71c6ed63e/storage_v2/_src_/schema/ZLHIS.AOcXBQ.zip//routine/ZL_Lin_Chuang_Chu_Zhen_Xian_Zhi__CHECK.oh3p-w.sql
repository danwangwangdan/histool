create Function Zl_临床出诊限制_Check 
( 
  记录id_In 临床出诊记录.Id%Type, 
  性别_In   病人信息.性别%Type, 
  年龄_In   病人信息.年龄%Type 
) Return Varchar2 Is 
  --功能:检查挂号的临床出诊记录是否适用病人 
  --返回:0-检查通过 
  --     1|挂号号码不适用该病人性别 
  --     2|挂号号码不适用该病人年龄 
  --     3|其他异常错误 
  v_Err_Msg Varchar2(255); 
  Err_Item Exception; 
  v_性别限制 临床出诊号源.适用性别%Type; 
  v_年龄限制 临床出诊号源.适用年龄段%Type; 
  v_最小年龄 Varchar2(500); 
  v_最大年龄 Varchar2(500); 
  n_最小天数 Number(5); 
  n_最大天数 Number(5); 
  n_年龄天数 Number(5); 
  Function Zl_年龄(Age_In Varchar2) Return Number As 
    n_计算天数 Number(5); 
  Begin 
    If Age_In Like '%岁%月' Then 
      n_计算天数 := 365 * To_Number(Substr(Age_In, 1, Instr(Age_In, '岁') - 1)) + 
                30 * To_Number(Replace(Substr(Age_In, Instr(Age_In, '岁') + 1), '月', '')); 
      Return n_计算天数; 
    End If; 
    If Age_In Like '%岁%个月' Then 
      n_计算天数 := 365 * To_Number(Substr(Age_In, 1, Instr(Age_In, '岁') - 1)) + 
                30 * To_Number(Replace(Substr(Age_In, Instr(Age_In, '岁') + 1), '个月', '')); 
      Return n_计算天数; 
    End If; 
    If Age_In Like '%月%天' Then 
      n_计算天数 := 30 * To_Number(Substr(Age_In, 1, Instr(Age_In, '月') - 1)) + 
                To_Number(Replace(Substr(Age_In, Instr(Age_In, '月') + 1), '天', '')); 
      Return n_计算天数; 
    End If; 
    If Age_In Like '%个月%天' Then 
      n_计算天数 := 30 * To_Number(Substr(Age_In, 1, Instr(Age_In, '个') - 1)) + 
                To_Number(Replace(Substr(Age_In, Instr(Age_In, '个') + 1), '天', '')); 
      Return n_计算天数; 
    End If; 
    If Age_In Like '%岁' Then 
      n_计算天数 := 365 * To_Number(Substr(Age_In, 1, Instr(Age_In, '岁') - 1)); 
      Return n_计算天数; 
    End If; 
    If Age_In Like '%月' Then 
      n_计算天数 := 30 * To_Number(Substr(Age_In, 1, Instr(Age_In, '月') - 1)); 
      Return n_计算天数; 
    End If; 
    If Age_In Like '%个月' Then 
      n_计算天数 := 30 * To_Number(Substr(Age_In, 1, Instr(Age_In, '个') - 1)); 
      Return n_计算天数; 
    End If; 
    If Age_In Like '%天' Then 
      n_计算天数 := To_Number(Substr(Age_In, 1, Instr(Age_In, '天') - 1)); 
      Return n_计算天数; 
    End If; 
    Begin 
      n_计算天数 := 365 * To_Number(Age_In); 
      Return n_计算天数; 
    Exception 
      When Others Then 
        Return Null; 
    End; 
  End; 
 
Begin 
  Begin 
    Select b.适用性别, b.适用年龄段 
    Into v_性别限制, v_年龄限制 
    From 临床出诊记录 A, 临床出诊号源 B 
    Where a.Id = 记录id_In And a.号源id = b.Id; 
  Exception 
    When Others Then 
      v_性别限制 := Null; 
      v_年龄限制 := Null; 
  End; 
 
  If v_性别限制 Is Not Null Then 
    If 性别_In <> v_性别限制 Then 
      Return '1|挂号号码不适用该病人性别'; 
    End If; 
  End If; 
 
  If v_年龄限制 Is Not Null Then 
    v_最小年龄 := Substr(v_年龄限制, 1, Instr(v_年龄限制, '~') - 1); 
    v_最大年龄 := Substr(v_年龄限制, Instr(v_年龄限制, '~') + 1); 
    n_年龄天数 := Zl_年龄(年龄_In); 
    If v_最小年龄 Is Not Null Then 
      n_最小天数 := Zl_年龄(v_最小年龄); 
    Else 
      n_最小天数 := 0; 
    End If; 
    If v_最大年龄 Is Not Null Then 
      n_最大天数 := Zl_年龄(v_最大年龄); 
    Else 
      n_最大天数 := 0; 
    End If; 
    If n_年龄天数 < n_最小天数 And n_最小天数 <> 0 Then 
      Return '2|挂号号码不适用该病人年龄'; 
    End If; 
    If n_年龄天数 > n_最大天数 And n_最大天数 <> 0 Then 
      Return '2|挂号号码不适用该病人年龄'; 
    End If; 
  End If; 
  Return 0; 
Exception 
  When Err_Item Then 
    Return '3|限制检查异常'; 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zl_临床出诊限制_Check;
/

