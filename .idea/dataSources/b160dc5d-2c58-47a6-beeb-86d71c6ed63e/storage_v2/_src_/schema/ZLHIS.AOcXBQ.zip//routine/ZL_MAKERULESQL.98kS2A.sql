create Function zl_MakeRuleSQL 
( 
	规则组号_In	In 体检规则内容.规则组号%Type, 
	性别限制_In	In 体检规则内容.性别限制%Type, 
	婚姻状况_In	In 体检规则内容.婚姻状况%Type, 
	年龄上限_In	In 体检规则内容.年龄上限%Type, 
	年龄下限_In	In 体检规则内容.年龄下限%Type, 
	体检指标id_In	In 体检规则内容.体检指标id%Type, 
	判断条件_In	In 体检规则内容.判断条件%Type, 
	指标结果_In	In 体检规则内容.指标结果%Type 
) Return Varchar2 As 
	 
	v_SQL			Varchar2(2000); 
	v_指标结果		体检规则内容.指标结果%Type; 
	v_正常结果		体检指标目录.正常结果%Type; 
	v_报警			体检任务结果.报警%Type; 
	v_AgeNumberBegin	Varchar2(20); 
	v_AgeNumberEnd		Varchar2(20); 
 
	Cursor c_Elements Is 
	      Select C.名称 As 指标项目,C.正常结果, 
		     Decode(C.类型, 1, '文本', 2, '数值', 3, '日期', 4, '逻辑') As 类型, C.单位 
	      From 体检指标目录 C 
	      Where c.ID=体检指标id_In; 
	r_Element c_Elements%RowType; 
 
	Function GetAgeDays(v_年龄 In 病人信息.年龄%Type) Return Varchar2 Is 
		v_Tmp		Varchar2(50); 
		v_AgeNumber	Varchar2(50); 
		v_AgeUnit	Varchar2(10); 
	Begin 
 
		If v_年龄 Is Null Or v_年龄 = '岁' Then 
			Return Null;		 
		End If; 
 
		If InStr(v_年龄, '岁') > 0 Then 
			 
			If InStr(v_年龄, '岁') = Length(v_年龄) Then 
			    v_Tmp := Substr(v_年龄, 1, InStr(v_年龄, '岁') - 1); 
			    v_AgeNumber := v_Tmp; 
			    v_AgeUnit :=  '岁'; 
			Else 
			    v_AgeNumber := v_年龄; 
			    v_AgeUnit := Null; 
			End If; 
 
		ElsIf InStr(v_年龄, '月') > 0 Then 
 
			If InStr(v_年龄, '月') = Length(v_年龄) Then 
			    v_Tmp := Substr(v_年龄, 1, InStr(v_年龄, '月') - 1); 
			    v_AgeNumber := v_Tmp; 
			    v_AgeUnit :=  '月'; 
			Else 
			    v_AgeNumber := v_年龄; 
			    v_AgeUnit := Null; 
			End If; 
 
		ElsIf InStr(v_年龄, '天') > 0 Then 
			If InStr(v_年龄, '天') = Length(v_年龄) Then 
			    v_Tmp := Substr(v_年龄, 1, InStr(v_年龄, '天') - 1); 
			    v_AgeNumber := v_Tmp; 
			    v_AgeUnit :=  '天'; 
			Else 
			    v_AgeNumber := v_年龄; 
			    v_AgeUnit := Null; 
			End If; 
		Else 
		    v_AgeNumber := Trim(To_Char(zl_To_Number(v_年龄))); 
		    v_AgeUnit := '岁'; 
		End If; 
		 
		If v_AgeUnit='月' Then 
			v_AgeNumber:=Trim(To_Char(zl_To_Number(v_AgeNumber)*30)); 
		ElsIf v_AgeUnit='岁' Then 
			v_AgeNumber:=Trim(To_Char(zl_To_Number(v_AgeNumber)*365)); 
		End If; 
 
		Return v_AgeNumber; 
 
	Exception 
		When Others Then Return Null; 
	End GetAgeDays; 
 
Begin 
	 
	Open c_Elements; 
	Fetch c_Elements Into r_Element; 
 
	v_SQL := 'Select a.任务id,a.病人id From 体检任务结果 a,病人信息 b,体检任务人员 T Where t.任务id=a.任务id And t.病人id=a.病人id And a.病人id=b.病人id And a.体检指标id='||Trim(To_Char(体检指标id_In)); 
 
	v_指标结果 := 指标结果_In; 
	v_正常结果 := r_Element.正常结果; 
	v_报警 := Null; 
 
	If v_指标结果='[最低值]' Then			 
		If v_正常结果 Is Not Null Then 
			v_指标结果:=zl_To_Number(Trim(Substr(v_正常结果,1,Instr(v_正常结果,'～')-1))); 
		End If; 
	ElsIf v_指标结果='[最高值]' Then 
		If v_正常结果 Is Not Null Then 
			v_指标结果:=zl_To_Number(Trim(Substr(v_正常结果,Instr(v_正常结果,'～')+1,100))); 
		End If; 
	ElsIf v_指标结果='[偏低]' Then 
		v_报警 := '偏低'; 
	ElsIf v_指标结果='[偏高]' Then			 
		v_报警 := '偏高'; 
	ElsIf v_指标结果='[异常]' Then			 
		v_报警 := '异常'; 
	End If; 
 
	If r_Element.类型='文本' Then 
		 
		If 判断条件_In='等于' Then 
			If v_报警 Is Not Null Then 
				v_SQL := v_SQL || ' And a.报警 = '''|| v_报警 || ''''; 
			Else 
				v_SQL := v_SQL || ' And a.结果 = '''|| v_指标结果 || ''''; 
			End If; 
		ElsIf 判断条件_In='大于' Then 
			v_SQL := v_SQL || ' And a.结果 > '''|| v_指标结果 || ''''; 
		ElsIf 判断条件_In='小于' Then 
			v_SQL := v_SQL || ' And a.结果 < '''|| v_指标结果 || ''''; 
		ElsIf 判断条件_In='大于等于' Then 
			v_SQL := v_SQL || ' And a.结果 >= '''|| v_指标结果 || ''''; 
		ElsIf 判断条件_In='小于等于' Then 
			v_SQL := v_SQL || ' And a.结果 <= '''|| v_指标结果 || ''''; 
		ElsIf 判断条件_In='不等于' Then 
			v_SQL := v_SQL || ' And a.结果 <> '''|| v_指标结果 || ''''; 
		ElsIf 判断条件_In='包含' Then 
			v_SQL := v_SQL || ' And a.结果 Like ''%'|| v_指标结果 || '%'''; 
		End If; 
 
	ElsIf r_Element.类型='数值' Then 
 
		If 判断条件_In='等于' Then 
			If v_报警 Is Not Null Then 
				v_SQL := v_SQL || ' And a.报警 = '''|| v_报警 || ''''; 
			Else 
				v_SQL := v_SQL || ' And zl_To_Number(a.结果) = '|| To_Char(zl_To_Number(v_指标结果)); 
			End If; 
		ElsIf 判断条件_In='大于' Then 
			v_SQL := v_SQL || ' And zl_To_Number(a.结果) >'|| To_Char(zl_To_Number(v_指标结果)); 
		ElsIf 判断条件_In='小于' Then 
			v_SQL := v_SQL || ' And zl_To_Number(a.结果) < '|| To_Char(zl_To_Number(v_指标结果)); 
		ElsIf 判断条件_In='大于等于' Then 
			v_SQL := v_SQL || ' And zl_To_Number(a.结果) >= '|| To_Char(zl_To_Number(v_指标结果)); 
		ElsIf 判断条件_In='小于等于' Then 
			v_SQL := v_SQL || ' And zl_To_Number(a.结果) <= '|| To_Char(zl_To_Number(v_指标结果)); 
		ElsIf 判断条件_In='不等于' Then 
			v_SQL := v_SQL || ' And zl_To_Number(a.结果) <> '|| To_Char(zl_To_Number(v_指标结果)); 
		ElsIf 判断条件_In='在范围内' Then 
			v_SQL := v_SQL || ' And zl_To_Number(a.结果) Between '|| Trim(Substr(v_指标结果,1,Instr(v_指标结果,'至')-1))||' And '||Trim(Substr(v_指标结果,Instr(v_指标结果,'至')+1,100)); 
		End If; 
 
	ElsIf r_Element.类型='逻辑' Then 
 
		If 判断条件_In='等于' Then 
			v_SQL := v_SQL || ' And zl_To_Number(a.结果) = '''|| v_指标结果 || '''';			 
		ElsIf 判断条件_In='不等于' Then 
			v_SQL := v_SQL || ' And a.结果 <> '''|| v_指标结果 || ''''; 
		ElsIf 判断条件_In='包含' Then 
			v_SQL := v_SQL || ' And a.结果 Like ''%'|| v_指标结果 || '%'''; 
		End If; 
 
	End If; 
	 
	If 性别限制_In Is Not Null Then 
		v_SQL := v_SQL || ' And Instr(b.性别,'''|| 性别限制_In || ''')>0'; 
	End If; 
 
	If 婚姻状况_In Is Not Null Then 
		v_SQL := v_SQL || ' And Instr(b.婚姻状况,'''|| 婚姻状况_In || ''')>0'; 
	End If; 
	 
	If 年龄上限_In Is Not Null And 年龄下限_In Is Not Null Then 
 
		v_AgeNumberBegin:=GetAgeDays(年龄上限_In); 
		v_AgeNumberEnd:=GetAgeDays(年龄下限_In); 
		 
		v_SQL := v_SQL || ' And (Sysdate-b.出生日期) Between '|| v_AgeNumberBegin || ' And ' || v_AgeNumberEnd; 
 
	ElsIf 年龄上限_In Is Not Null Then 
 
		v_AgeNumberBegin:=GetAgeDays(年龄上限_In); 
		v_SQL := v_SQL || ' And (Sysdate-b.出生日期) >= '||v_AgeNumberBegin; 
 
	ElsIf 年龄下限_In Is Not Null Then 
 
		v_AgeNumberEnd:=GetAgeDays(年龄下限_In); 
		v_SQL := v_SQL || ' And (Sysdate-b.出生日期) <= '||v_AgeNumberEnd; 
 
	End If; 
	 
	Close c_Elements; 
 
	return(v_SQL);	 
End;
/

