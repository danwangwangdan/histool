create Function Zl_Material_Getdecimal(Bytdecimaltype Number 
                                                  --0-数量,1-单价,2-金额 
                                                  ) Return Number Is 
  v_Decimal Number(2); 
  v_参数值  Zlparameters.参数值%Type; 
  v_Temp    Varchar2(50); 
  v_Intsub  Number(18); 
Begin 
  v_参数值 := Zl4_Getsysparameter(122, 0 ); 
 
  If v_参数值 Is Null Then 
    --采用默认的值 
    --  数量单价及金额的小数位数及分节符,他们之间用分号分隔,每项用减号分隔,1位小数,2位是分节符。 
    v_参数值 := '3-0;4-0;2-0'; 
  End If; 
 
  v_Temp   := v_参数值; 
  v_Intsub := Instr(v_Temp, ';', 1); 
  If Bytdecimaltype = 0 Then 
    --数量 
    v_Temp    := Substr(v_Temp, 1, v_Intsub); 
    v_Intsub  := Instr(v_Temp, '-'); 
    v_Temp    := Substr(v_Temp, 1, v_Intsub - 1); 
    v_Decimal := To_Number(v_Temp, '99'); 
    Return v_Decimal; 
  End If; 
  v_Temp   := Substr(v_Temp, v_Intsub + 1, Length(v_Temp) - v_Intsub); 
  v_Intsub := Instr(v_Temp, ';', 1); 
  If Bytdecimaltype = 1 Then 
    v_Temp    := Substr(v_Temp, 1, v_Intsub); 
    v_Intsub  := Instr(v_Temp, '-'); 
    v_Temp    := Substr(v_Temp, 1, v_Intsub - 1); 
    v_Decimal := To_Number(v_Temp, '99'); 
    Return v_Decimal; 
  End If; 
  v_Temp    := Substr(v_Temp, v_Intsub + 1, Length(v_Temp) - v_Intsub); 
  v_Intsub  := Instr(v_Temp, '-'); 
  v_Temp    := Substr(v_Temp, 1, v_Intsub - 1); 
  v_Decimal := To_Number(v_Temp, '99'); 
  Return v_Decimal; 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
    Return v_Decimal; 
End Zl_Material_Getdecimal;
/

