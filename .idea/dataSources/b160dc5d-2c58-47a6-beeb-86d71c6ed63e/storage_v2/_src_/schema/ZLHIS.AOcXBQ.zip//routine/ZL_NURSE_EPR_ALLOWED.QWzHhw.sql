create Function Zl_Nurse_Epr_Allowed 
( 
  病人id_In In 病案主页.病人id%Type, 
  主页id_In In 病案主页.主页id%Type, 
  病区id_In In 病案主页.当前病区id%Type 
) Return Varchar2 Is 
  v_Epr_Files Varchar2(2000); --采用分号分隔的病历文件id串 
  d_From_Time Date; --开始时间，存在留观转住院时，从该事件发生时间开始 
  d_To_Time   Date; --结束时间，存在预出院时，以预出院时间为结束时间 
 
  n_In_Dept  病案主页.入院病区id%Type; --病人入院所在病区 
  n_Cur_Dept 病案主页.当前病区id%Type; --病人当前所在病区 
  d_Out_Time 病案主页.出院日期%Type; --出院时间，用以判断病人是否出院 
  v_Out_Mode 病案主页.出院方式%Type; --出院方式，用以判断病人是否死亡 
Begin 
  Select Nvl(Max(开始时间), Sysdate - 3650), Max(病区id) 
  Into d_From_Time, n_In_Dept 
  From 病人变动记录 
  Where 病人id = 病人id_In And 主页id = 主页id_In And 开始原因 = 9; 
 
  Select Nvl(Min(终止时间), Sysdate + 3650) 
  Into d_To_Time 
  From 病人变动记录 R 
  Where 病人id = 病人id_In And 主页id = 主页id_In And 终止原因 = 10; 
 
  Select Decode(n_In_Dept, Null, 入院病区id, n_In_Dept), 当前病区id, 出院日期, 出院方式 
  Into n_In_Dept, n_Cur_Dept, d_Out_Time, v_Out_Mode 
  From 病案主页 
  Where 病人id = 病人id_In And 主页id = 主页id_In; 
 
  For r_Must In (Select F.ID, F.唯一, R.次数, L.份数 
                 From (Select F.ID, F.事件, F.必须, F.唯一, F.书写时限 
                        From (Select F.ID, F.编号, F.通用, A.科室id, Q.事件, Q.必须, Q.唯一, Q.书写时限 
                               From 病历文件列表 F, 病历应用科室 A, 病历时限要求 Q 
                               Where F.ID = A.文件id(+) And F.ID = Q.文件id And F.种类 = 4) F 
                        Where F.通用 = 1 Or F.通用 = 2 And F.科室id = 病区id_In) F, 
                      (Select Decode(事件, '出院', Decode(v_Out_Mode, '死亡', '死亡', '出院'), 事件) As 事件, 时机, 
                               Decode(事件, '入院', 1, '出院', 1, Count(*)) As 次数 
                        From (Select Decode(开始原因, 1, '入院', 2, '入院', 9, '入院', 3, '转科', 8, '交班') As 事件, 
                                      '后' As 时机 
                               From 病人变动记录 
                               Where 病人id = 病人id_In And 主页id = 主页id_In And 开始时间 >= d_From_Time And 
                                     终止时间 <= d_To_Time And (病区id + 0 = 病区id_In Or 开始原因 In (1, 2, 9)) 
                               Union All 
                               Select Decode(终止原因, 3, '转科', 8, '交班', 1, '出院', 10, '出院') As 事件, 
                                      Decode(终止原因, 3, '前', 8, '前', 1, '后', 10, '后') As 时机 
                               From 病人变动记录 
                               Where 病人id = 病人id_In And 主页id = 主页id_In And 开始时间 >= d_From_Time And 
                                     终止时间 <= d_To_Time And 病区id + 0 = 病区id_In) 
                        Group By 事件, 时机 
                        Having 事件 Is Not Null And 时机 Is Not Null) R, 
                      (Select R.文件id, Count(*) As 份数 
                        From 电子病历记录 R 
                        Where R.病人id = 病人id_In And R.主页id = 主页id_In And R.病历种类 = 4 And 
                              R.科室id + 0 = 病区id_In 
                        Group By R.文件id) L 
                 Where R.事件 = F.事件 And (R.事件 = '入院' And n_In_Dept <> 病区id_In And F.唯一 = 0 Or 
                       R.事件 = '入院' And n_In_Dept = 病区id_In Or R.事件 <> '入院') And 
                       (F.唯一 = 0 And R.时机 = '后' Or 
                       F.唯一 = 1 And (R.时机 = '前' And F.书写时限 < 0 Or R.时机 = '后' And F.书写时限 >= 0)) And 
                       F.ID = L.文件id(+)) Loop 
    If r_Must.唯一 = 0 And n_Cur_Dept = 病区id_In And (d_Out_Time Is Null) Or 
       r_Must.唯一 = 1 And r_Must.次数 > Nvl(r_Must.份数, 0) Then 
      v_Epr_Files := v_Epr_Files || ';' || r_Must.ID; 
    End If; 
  End Loop; 
 
  If n_Cur_Dept = 病区id_In And d_Out_Time Is Null Then 
    For r_Must In (Select F.ID 
                   From (Select F.*, A.科室id From 病历文件列表 F, 病历应用科室 A Where F.ID = A.文件id(+) And F.种类 = 4) F, 
                        病历时限要求 Q 
                   Where F.ID = Q.文件id And (F.通用 = 1 Or F.通用 = 2 And F.科室id = 病区id_In) And Q.唯一 = 1 And 
                         Q.书写时限 < 0 And Instr(v_Epr_Files || ';', ';' || F.ID || ';') = 0) Loop 
      v_Epr_Files := v_Epr_Files || ';' || r_Must.ID; 
    End Loop; 
  End If; 
 
  If v_Epr_Files Is Not Null Then 
    v_Epr_Files := Substr(v_Epr_Files, 2); 
  End If; 
  Return(v_Epr_Files); 
Exception 
  When Others Then 
    Return Null; 
End Zl_Nurse_Epr_Allowed;
/

