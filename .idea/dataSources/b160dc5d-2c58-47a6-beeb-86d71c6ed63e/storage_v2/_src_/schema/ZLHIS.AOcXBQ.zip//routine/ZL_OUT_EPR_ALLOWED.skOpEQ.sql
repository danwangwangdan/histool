create Function Zl_Out_Epr_Allowed 
--功能：返回指定科室可以为指定病人书写的门诊病历、疾病诊断证明、知情文件 
( 
  病人id_In In 病人挂号记录.病人id%Type, 
  挂号id_In In 病人挂号记录.Id%Type, 
  科室id_In In 病人挂号记录.执行部门id%Type, 
  医嘱id_In In Number 
) Return Varchar2 Is 
  v_Epr_Files  Varchar2(2000); --采用分号分隔的病历文件id串 
  n_Visit_Type Number(1); --就诊类型：0-初诊;1-复诊;2-急诊 
  n_Visit_Dept 病人挂号记录.执行部门id%Type; --就诊科室id 
Begin 
  Select Decode(急诊, 1, 2, Decode(复诊, 1, 1, 0)), 执行部门id 
  Into n_Visit_Type, n_Visit_Dept 
  From 病人挂号记录 
  Where Id = 挂号id_In And 病人id + 0 = 病人id_In; 
 
  --医嘱ID<>0表明是针对某条医嘱的 
  If 医嘱id_In = 0 Then 
	  --当前不是就诊科室，则不能书写任何病历 
	  If n_Visit_Dept <> 科室id_In Then 
	    Return Null; 
	  End If; 
  End if; 
 
  --病人在该科室发生事件对应可以书写的门诊病历 
  For r_Must In (Select f.Id 
                 From (Select f.Id, f.通用, a.科室id 
                        From 病历文件列表 f, 病历应用科室 a, 病历时限要求 r 
                        Where f.Id = a.文件id(+) And f.Id = r.文件id And f.种类 = 1 And 
                              (n_Visit_Type <> 2 And r.事件 = '门诊' Or n_Visit_Type = 0 And r.事件 = '初诊' Or 
                              n_Visit_Type = 1 And r.事件 = '复诊' Or n_Visit_Type = 2 And r.事件 = '急诊')) f 
                 Where f.通用 = 1 Or f.通用 = 2 And f.科室id = 科室id_In 
                 Minus 
                 Select 文件id 
                 From 电子病历记录 
                 Where 病人id = 病人id_In And 主页id = 挂号id_In And 病历种类 + 0 = 1 And 科室id + 0 = 科室id_In) Loop 
    v_Epr_Files := v_Epr_Files || ';' || r_Must.Id; 
  End Loop; 
 
  --非特殊所有的疾病证明报告和知情文件； 
  For r_Must In (Select f.Id 
                 From (Select f.Id, f.通用, a.科室id 
                        From 病历文件列表 f, 病历应用科室 a 
                        Where f.Id = a.文件id(+) And (f.种类 = 5 Or f.种类 = 6) And f.保留 >= 0) f 
                 Where f.通用 = 1 Or f.通用 = 2 And f.科室id = 科室id_In) Loop 
    v_Epr_Files := v_Epr_Files || ';' || r_Must.Id; 
  End Loop; 
 
  If v_Epr_Files Is Not Null Then 
    v_Epr_Files := Substr(v_Epr_Files, 2); 
  End If; 
  Return(v_Epr_Files); 
Exception 
  When Others Then 
    Return Null; 
End Zl_Out_Epr_Allowed;
/

