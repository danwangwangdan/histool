create Function zl_Owner Return Varchar2 As 
  v_User All_Users.Username%Type; 
Begin 
  Select Username Into v_User From All_Users Where User_Id = Userenv('SchemaID'); 
  Return v_User; 
End zl_Owner;
/

