create function ZL_PACS报告_内容提取 
(单据_in varchar, 
 性质_in number, 
 提纲_in varchar 
) return varchar2 as 
  v_temp     varchar2(4000); 
  v_PACS片段 varchar2(4000); 
  ----------------------------------------------------- 
  --传入三个参数,第一个参数 任务id ,第2个参数 项目id 第3个参数值 1或者其他值,传入1 代表取不正常人数 
  --传入其他值代表正常人员清单. 
  cursor c_PACS报告 is 
  -- select 内容文本 as 内容 
 Select decode(是否换行,1,decode(nvl(内容行次,0),0,l.内容文本||chr(13),l.内容文本),l.内容文本) As 内容 
      From 电子病历内容 L 
     Where L.对象类型 = 2 
       and L.对象序号 > 0 
       and l.对象属性 = '0' 
       and l.终止版 = 0 
       and 父id in 
           (select id 
              from 电子病历内容 l 
             Where L.对象类型 = 1 
               and L.对象序号 > 0 
               and l.内容文本 = 提纲_in 
               And L.文件ID In (Select Distinct A.病历id 
                                  From 病人医嘱发送 S, 病人医嘱报告 A 
                                 Where S.No = 单据_in 
                                   And S.记录性质 = 性质_in 
                                   And S.医嘱ID = A.医嘱ID)) 
       And L.文件ID In (Select Distinct A.病历id 
                          From 病人医嘱发送 S, 病人医嘱报告 A 
                         Where S.No = 单据_in 
                           And S.记录性质 = 性质_in 
                           And S.医嘱ID = A.医嘱ID) 
     Order By L.对象序号; 
 
begin 
  v_temp := ''; 
 
  for v_PACS报告 in c_PACS报告 loop 
    select v_PACS报告.内容 into v_PACS片段 from dual; 
    v_temp := v_temp || v_PACS片段; 
  end loop; 
  return(v_temp); 
end ZL_PACS报告_内容提取;
/

