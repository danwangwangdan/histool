create Function Zl_Patidaycharge 
( 
  病人id_In   病人信息.病人id%Type, 
  发生时间_In 门诊费用记录.发生时间%Type := Sysdate, 
  含划价_In   Number := Null 
) Return Number As 
  n_当日额 Number; 
  v_含划价 Number; 
  ------------------------------------------------------------------------- 
  --功能:获取指定日期的费用总额 
  --入参:含划单_IN- 存在三种状态:NULL-需要根据98参数来决定是否包含划价;1-含划价;0-不含划价 
 
Begin 
  If 含划价_In Is Null Then 
    Select Zl_To_Number(Nvl(zl_GetSysParameter(98), '0')) Into v_含划价 From Dual; --记帐报警时,是否包含划价单费用 
  Else 
    v_含划价 := 含划价_In; 
  End If; 
 
  Select Sum(Nvl(实收金额, 0)) 
  Into n_当日额 
  From (Select Nvl(Sum(实收金额), 0) As 实收金额 
         From 门诊费用记录 
         Where 病人id = 病人id_In And 记帐费用 = 1 And 记录状态 <> Decode(v_含划价, 0, 0, 999) And 发生时间 Between Trunc(发生时间_In) And 
               Trunc(发生时间_In) + 1 - 1 / 24 / 60 / 60 
         Union All 
         Select Nvl(Sum(实收金额), 0) As 实收金额 
         From 住院费用记录 
         Where 病人id = 病人id_In And 记帐费用 = 1 And 记录状态 <> Decode(v_含划价, 0, 0, 999) And 发生时间 Between Trunc(发生时间_In) And 
               Trunc(发生时间_In) + 1 - 1 / 24 / 60 / 60); 
  Return(n_当日额); 
End Zl_Patidaycharge;
/

