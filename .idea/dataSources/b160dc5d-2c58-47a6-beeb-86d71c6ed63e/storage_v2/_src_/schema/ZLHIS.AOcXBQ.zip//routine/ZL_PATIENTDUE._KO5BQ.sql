create Function Zl_Patientdue(病人id_In 病人预交记录.病人id%Type) Return Number 
--返回:指定病人的应收款余额 
 As 
  v_应收余额 病人预交记录.冲预交%Type; 
Begin 
 
  Select A.应收款总额 - Nvl(Sum(金额), 0) 
  Into v_应收余额 
  From (Select A.病人id, Sum(A.冲预交) 应收款总额 
         From 病人预交记录 A, 结算方式 B 
         Where A.病人id = 病人id_In And A.结算方式 = B.名称 And B.应收款 = 1 
         Group By 病人id) A, 病人缴款记录 B 
  Where A.病人id = B.病人id(+) And B.记录状态(+) = 1 
  Group By A.病人id, 应收款总额; 
 
  Return v_应收余额; 
Exception 
  When Others Then 
    Return 0; 
End Zl_Patientdue;
/

