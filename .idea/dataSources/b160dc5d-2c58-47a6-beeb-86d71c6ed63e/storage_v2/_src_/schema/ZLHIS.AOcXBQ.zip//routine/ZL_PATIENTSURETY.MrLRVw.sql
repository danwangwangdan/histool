create Function Zl_Patientsurety 
( 
  病人id_In 病人担保记录.病人id%Type, 
  主页id_In 病人担保记录.主页id%Type --门诊病人传入空值 
) Return Number 
--返回:当前有效的担保金额 
 As 
  Pragma Autonomous_Transaction; 
  v_担保人   病人信息.担保人%Type; 
  n_担保性质 病人担保记录.担保性质%Type; 
  n_担保额   病人担保记录.担保额%Type; 
  n_Row      Number(18); 
Begin 
  --提取当前有效担保额及有效担保记录数 
  n_Row    := 0; 
  n_担保额 := 0; 
  v_担保人 := ''; 
  For r_提保信息 In (Select 担保人, 担保额 
                     From 病人担保记录 
                     Where 病人id = 病人id_In And Nvl(主页id, 0) = Nvl(主页id_In, 0) And 
                           (到期时间 Is Null Or 到期时间 > Sysdate) And 删除标志 = 1) Loop 
    n_Row    := n_Row + 1; 
    n_担保额 := n_担保额 + r_提保信息.担保额; 
    v_担保人 := v_担保人 || ',' || r_提保信息.担保人; 
  End Loop; 
  v_担保人 := Substr(v_担保人, 2, 100); 
 
  If n_Row = 0 Then 
    Update 病人信息 Set 担保人 = Null, 担保额 = Null, 担保性质 = Null Where 病人id = 病人id_In; 
  Else 
    --提取最后一条有效担保人和担保性质 
    Select 担保性质 
    Into n_担保性质 
    From 病人担保记录 
    Where 病人id = 病人id_In And Nvl(主页id, 0) = Nvl(主页id_In, 0) And 删除标志 = 1 And 
          登记时间 = (Select Max(登记时间) 
                      From 病人担保记录 
                      Where 病人id = 病人id_In And Nvl(主页id, 0) = Nvl(主页id_In, 0) And 
                            (到期时间 Is Null Or 到期时间 > Sysdate) And 删除标志 = 1); 
 
    Update 病人信息 Set 担保人 = v_担保人, 担保额 = n_担保额, 担保性质 = n_担保性质 Where 病人id = 病人id_In; 
  End If; 
 
  Commit; 
  Return n_担保额; 
Exception 
  When Others Then 
    Rollback; 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zl_Patientsurety;
/

