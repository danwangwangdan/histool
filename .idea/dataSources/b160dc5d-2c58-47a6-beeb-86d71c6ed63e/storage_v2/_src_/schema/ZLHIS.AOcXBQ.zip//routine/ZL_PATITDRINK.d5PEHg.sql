create Function Zl_Patitdrink 
( 
  病人id_In   病案主页.病人id%Type, 
  主页id_In   病案主页.主页id%Type, 
  开始时间_In Date, 
  结束时间_In Date 
) Return Varchar2 As 
 
  --  Type v_AryStr IS VARRAY(3) OF VARCHAR2(50); 
 
  Type v_Arystr Is Table Of Varchar2(50) Index By Binary_Integer; 
  Type v_Arynum Is Table Of Number Index By Binary_Integer; 
 
  Cursor c_Advices(v_Units Varchar2) Is 
    Select D.计算单位, Nvl(Sum(A.发送数次 * C.单次用量), 0) As 总量, D.名称 
    From 病人医嘱发送 A, 病人医嘱记录 C, 诊疗项目目录 D 
    Where C.ID = A.医嘱id And C.病人id = 病人id_In And C.主页id = 主页id_In And C.诊疗类别 In ('5', '6') And 
          (A.首次时间 Between 开始时间_In And 结束时间_In - 1 / 24 / 60 / 60 Or 
          A.末次时间 Between 开始时间_In And 结束时间_In - 1 / 24 / 60 / 60) And D.ID = C.诊疗项目id And 
          Instr(v_Units, ',' || D.计算单位 || ',') > 0 
    Group By D.计算单位, D.名称; 
 
  v_单位名称 Varchar2(4000); 
 
  v_饮入量   Number(18, 4); 
  v_饮入物   Varchar2(4000); 
  v_饮入代换 Varchar2(4000); 
  v_Loop     Number(18); 
  v_Index    Number(18); 
  v_Pos      Number(18); 
  Strtmp     Varchar2(4000); 
  Strtmp2    Varchar2(4000); 
 
  m_Arystr v_Arystr; 
  m_Arynum v_Arynum; 
Begin 
  v_单位名称 := ''; 
  v_饮入代换 := ''; 
  v_饮入量   := 0; 
  v_饮入物   := ''; 
  v_Index    := 0; 
 
  --v_饮入代换:单位1,系数1;单位2,系数2 
  Select zl_GetSysParameter(62) Into v_饮入代换 From Dual; 
 
  If v_饮入代换 Is Null Then 
    Return(''); 
  End If; 
 
  Strtmp := v_饮入代换 || ';'; 
 
  v_Pos := Instr(Strtmp, ';'); 
 
  While v_Pos > 0 Loop 
 
    Strtmp2 := Substr(Strtmp, 1, v_Pos - 1); 
    Strtmp  := Substr(Strtmp, v_Pos + 1); 
 
    v_Pos := Instr(Strtmp2, ','); 
    If v_Pos > 0 Then 
      v_单位名称 := v_单位名称 || ',' || Substr(Strtmp2, 1, v_Pos - 1); 
 
      v_Index := v_Index + 1; 
      m_Arystr(v_Index) := Substr(Strtmp2, 1, v_Pos - 1); 
      m_Arynum(v_Index) := To_Number(Substr(Strtmp2, v_Pos + 1)); 
 
    End If; 
    v_单位名称 := v_单位名称 || ','; 
 
    v_Pos := Instr(Strtmp, ';'); 
 
  End Loop; 
 
  For r_Advice In c_Advices(v_单位名称) Loop 
 
    If v_Index > 0 Then 
      v_Loop := 0; 
      While v_Loop <= v_Index Loop 
        v_Loop := v_Loop + 1; 
        If m_Arystr(v_Loop) = r_Advice.计算单位 Then 
          v_饮入量 := v_饮入量 + r_Advice.总量 * m_Arynum(v_Loop); 
 
          If v_饮入物 Is Null Then 
            v_饮入物 := r_Advice.名称; 
          Else 
            v_饮入物 := v_饮入物 || ';' || r_Advice.名称; 
          End If; 
 
          Exit; 
        End If; 
      End Loop; 
    End If; 
  End Loop; 
 
  Return(Trim(To_Char(v_饮入量)) || ';' || v_饮入物); 
End Zl_Patitdrink;
/

