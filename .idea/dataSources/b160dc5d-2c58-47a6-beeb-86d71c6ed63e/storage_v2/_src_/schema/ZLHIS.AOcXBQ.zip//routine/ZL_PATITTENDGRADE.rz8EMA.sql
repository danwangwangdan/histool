create Function Zl_Patittendgrade 
( 
  病人id_In 病案主页.病人id%Type, 
  主页id_In 病案主页.主页id%Type, 
  时间_IN   date:=sysdate 
) Return Number As 
  n_等级 Number(1); 
Begin 
  Select Decode(特级, 'Y', 0, Decode(一级, 'Y', 1, Decode(二级, 'Y', 2, 3))) As 等级 
  Into n_等级 
  From (Select Decode(Sign(Instr(b.名称, '特')), 1, 'Y', Decode(Sign(Instr(b.名称, '重')), 1, 'Y', 'N')) As 特级, 
                Decode(Sign(Instr(b.名称, '一')), 1, 'Y', 
                        Decode(Sign(Instr(b.名称, '1')), 1, 'Y', 
                                Decode(Sign(Instr(b.名称, 'Ⅰ')), 1, 'Y', Decode(Sign(Instr(b.名称, 'I')), 1, 'Y', 'N')))) As 一级, 
                Decode(Sign(Instr(b.名称, '二')), 1, 'Y', 
                        Decode(Sign(Instr(b.名称, '2')), 1, 'Y', 
                                Decode(Sign(Instr(b.名称, 'Ⅱ')), 1, 'Y', Decode(Sign(Instr(b.名称, 'II')), 1, 'Y', 'N')))) As 二级 
         From 病案主页 a, 收费项目目录 b,病人变动记录 c 
         Where c.护理等级id = b.Id And a.病人id = 病人id_In And a.主页id = 主页id_In and c.病人id=a.病人id And c.主页id=a.主页id And c.护理等级id Is Not Null and c.开始时间<=时间_IN And (c.终止时间 Is Null Or c.终止时间>=时间_IN)) 
   Where rownum<2; 
  Return(n_等级); 
Exception 
  When Others Then 
    Return 3; 
End Zl_Patittendgrade;
/

