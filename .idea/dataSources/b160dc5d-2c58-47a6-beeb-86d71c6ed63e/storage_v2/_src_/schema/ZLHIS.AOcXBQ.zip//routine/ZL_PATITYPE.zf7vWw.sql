create Function Zl_Patitype(病人id_In 病人信息.病人id%Type) Return Varchar2 
--返回:病人类型 
 As 
  v_病人类型 病案主页.病人类型%Type; 
  n_险类     病人信息.险类%Type; 
Begin 
  Begin 
    Select 险类 Into n_险类 From 病人信息 Where 病人id = 病人id_In; 
  Exception 
    When Others Then 
      Null; 
  End; 
 
  If n_险类 Is Not Null Then 
    Select 名称 Into v_病人类型 From 保险类别 Where 序号 = n_险类; 
    --新开发的医保，如果没有填病人类型数据，则返回医保病人 
    Begin 
      Select 名称 Into v_病人类型 From 病人类型 Where 名称 = v_病人类型; 
    Exception 
      When Others Then 
        v_病人类型 := '医保病人'; 
    End; 
  Else 
    v_病人类型 := '普通病人'; 
  End If; 
  Return v_病人类型; 
Exception 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
End Zl_Patitype;
/

