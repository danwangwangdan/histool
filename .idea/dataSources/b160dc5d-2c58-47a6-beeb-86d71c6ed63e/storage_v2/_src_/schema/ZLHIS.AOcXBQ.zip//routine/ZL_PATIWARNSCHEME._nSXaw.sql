create Function zl_PatiWarnScheme 
( 
  病人id_In 病人信息.病人id%Type, 
  主页id_In 病案主页.主页id%Type := Null 
) Return Varchar2 As 
  v_适用病人 记帐报警线.适用病人%Type; 
  v_险类     保险类别.序号%Type; 
  v_付款码   医疗付款方式.编码%Type; 
Begin 
  If 主页id_In Is Null Then 
    Select A.险类, B.编码 
    Into v_险类, v_付款码 
    From 病人信息 A, 医疗付款方式 B 
    Where A.病人id = 病人id_In And A.医疗付款方式 = B.名称(+); 
  Else 
    Select A.险类, B.编码 
    Into v_险类, v_付款码 
    From 病案主页 A, 医疗付款方式 B 
    Where A.病人id = 病人id_In And A.主页id = 主页id_In And A.医疗付款方式 = B.名称(+); 
  End If; 
  If Nvl(v_险类, 0) > 0 Or Nvl(v_付款码, 'X') = '1' Then 
    v_适用病人 := '医保病人'; 
  Else 
    v_适用病人 := '普通病人'; 
  End If; 
  Return(v_适用病人); 
End zl_PatiWarnScheme;
/

