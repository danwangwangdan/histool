create Function Zl_Pati_Check_Execute 
( 
  内容_In         Number, 
  病人id_In       病人信息.病人id%Type, 
  主页id_In       病案主页.主页id%Type, 
  婴儿_In         Number := -1, 
  检查离院带药_In Number := 0, 
  门诊检查_In     Number := 0 
) Return Varchar2 
--功能：检查病人是否存在未执行完成的内容 
  --参数： 
  --  内容_IN：1-检查药品和卫材,2-检查其他执行项目,3-检查未发血 
  --  婴儿_IN：0=病人，1-N=婴儿，-1=不区分 
  --返回：如果存在则返回一定格式的提示信息供程序使用，否则返回空 
 As 
  v_Text  Varchar2(4000); 
  v_Drug  Varchar2(1510); 
  v_Stuff Varchar2(1510); 
  n_Count Number; 
  n_Do    Number; 
  n_共享  Number; 
  Type t_Bool Is Ref Cursor; 
  c_Bool t_Bool; 
  v_No   住院费用记录.No%Type; 
  v_项目 收费项目目录.名称%Type; 
  v_部门 部门表.名称%Type; 
  v_扣率 Varchar2(100); 
  v_Sql  Varchar2(4000); 
  v_Pars Varchar2(4000); 
Begin 
  If 内容_In = 1 Then 
    --以药品收发记录中存在未发药品为准 
    If Nvl(门诊检查_In, 0) = 0 Then 
      --住院 
      For r_Info In (Select Distinct a.No, Decode(a.收费类别, '4', 1, 0) As 卫材, d.名称 项目, c.名称 As 部门, To_Char(b.扣率) As 扣率 
                     From 住院费用记录 A, 药品收发记录 B, 部门表 C, 收费项目目录 D 
                     Where a.No = b.No And a.Id = b.费用id And a.收费细目id = d.Id And b.库房id + 0 = c.Id(+) And 
                           a.收费类别 In ('4', '5', '6', '7') And b.单据 In (9, 10, 25, 26) And Mod(b.记录状态, 3) = 1 And 
                           b.审核人 Is Null And a.病人id = 病人id_In And Nvl(a.主页id, 0) = 主页id_In And 
                           (Nvl(a.婴儿费, 0) = 婴儿_In Or 婴儿_In = -1) And Nvl(b.摘要, '大医') <> '拒发') Loop 
 
        n_Do := 1; 
        If Substr(r_Info.扣率, 2) = '3' Then 
          n_Do := 检查离院带药_In; 
        End If; 
        If n_Do = 1 Then 
          If r_Info.卫材 = 0 Then 
            If v_Drug Is Not Null Then 
              If Instr(Chr(13) || Chr(10) || v_Drug || Chr(13) || Chr(10), 
                       Chr(13) || Chr(10) || '单据[' || Nvl(r_Info.No, '') || ']中的' || Nvl(r_Info.项目, '') || '：在' || 
                        Nvl(r_Info.部门, '[未定药房]') || '未发药' || Chr(13) || Chr(10), 1) = 0 Then 
                If Lengthb(v_Drug || Chr(13) || Chr(10) || '单据[' || Nvl(r_Info.No, '') || ']中的' || Nvl(r_Info.项目, '') || '：在' || 
                           Nvl(r_Info.部门, '[未定药房]') || '未发药') <= 1000 Then 
                  v_Drug := v_Drug || Chr(13) || Chr(10) || '单据[' || Nvl(r_Info.No, '') || ']中的' || Nvl(r_Info.项目, '') || '：在' || 
                            Nvl(r_Info.部门, '[未定药房]') || '未发药'; 
                Else 
                  v_Drug := v_Drug || Chr(13) || Chr(10) || '... ...'; 
                End If; 
              End If; 
            Else 
              v_Drug := '单据[' || Nvl(r_Info.No, '') || ']中的' || Nvl(r_Info.项目, '') || '：在' || Nvl(r_Info.部门, '[未定药房]') || 
                        '未发药'; 
            End If; 
          Else 
            If v_Stuff Is Not Null Then 
              If Instr(Chr(13) || Chr(10) || v_Stuff || Chr(13) || Chr(10), 
                       Chr(13) || Chr(10) || '单据[' || Nvl(r_Info.No, '') || ']中的' || Nvl(r_Info.项目, '') || '：在' || 
                        Nvl(r_Info.部门, '[未定部门]') || '未发放' || Chr(13) || Chr(10), 1) = 0 Then 
                If Lengthb(v_Stuff || Chr(13) || Chr(10) || '单据[' || Nvl(r_Info.No, '') || ']中的' || Nvl(r_Info.项目, '') || '：在' || 
                           Nvl(r_Info.部门, '[未定部门]') || '未发放') <= 1000 Then 
                  v_Stuff := v_Stuff || Chr(13) || Chr(10) || '单据[' || Nvl(r_Info.No, '') || ']中的' || 
                             Nvl(r_Info.项目, '') || '：在' || Nvl(r_Info.部门, '[未定部门]') || '未发放'; 
                Else 
                  v_Stuff := v_Stuff || Chr(13) || Chr(10) || '... ...'; 
                End If; 
              End If; 
            Else 
              v_Stuff := '单据[' || Nvl(r_Info.No, '') || ']中的' || Nvl(r_Info.项目, '') || '：在' || Nvl(r_Info.部门, '[未定部门]') || 
                         '未发放'; 
            End If; 
          End If; 
        End If; 
      End Loop; 
 
      If v_Drug Is Not Null Then 
        v_Drug := '存在未发药品：' || Chr(13) || Chr(10) || Chr(13) || Chr(10) || v_Drug; 
      End If; 
      If v_Stuff Is Not Null Then 
        v_Stuff := '存在未发放卫材料：' || Chr(13) || Chr(10) || Chr(13) || Chr(10) || v_Stuff; 
      End If; 
 
      If v_Drug Is Not Null And v_Stuff Is Not Null Then 
        v_Text := v_Drug || Chr(13) || Chr(10) || Chr(13) || Chr(10) || v_Stuff; 
      Elsif v_Drug Is Not Null Then 
        v_Text := v_Drug; 
      Elsif v_Stuff Is Not Null Then 
        v_Text := v_Stuff; 
      End If; 
    Else 
      --门诊 
      For r_Info In (Select Distinct a.No, Decode(a.收费类别, '4', 1, 0) As 卫材, d.名称 项目, c.名称 As 部门, To_Char(b.扣率) As 扣率 
                     From 门诊费用记录 A, 药品收发记录 B, 部门表 C, 收费项目目录 D 
                     Where a.No = b.No And a.Id = b.费用id And a.收费细目id = d.Id And b.库房id + 0 = c.Id(+) And 
                           a.收费类别 In ('4', '5', '6', '7') And b.单据 In (9, 10, 25, 26) And Mod(b.记录状态, 3) = 1 And 
                           b.审核人 Is Null And a.病人id = 病人id_In And (Nvl(a.婴儿费, 0) = 婴儿_In Or 婴儿_In = -1) And 
                           Nvl(b.摘要, '大医') <> '拒发') Loop 
 
        n_Do := 1; 
        If Substr(r_Info.扣率, 2) = '3' Then 
          n_Do := 检查离院带药_In; 
        End If; 
        If n_Do = 1 Then 
          If r_Info.卫材 = 0 Then 
            If v_Drug Is Not Null Then 
              If Instr(Chr(13) || Chr(10) || v_Drug || Chr(13) || Chr(10), 
                       Chr(13) || Chr(10) || '单据[' || Nvl(r_Info.No, '') || ']中的' || Nvl(r_Info.项目, '') || '：在' || 
                        Nvl(r_Info.部门, '[未定药房]') || '未发药' || Chr(13) || Chr(10), 1) = 0 Then 
                If Lengthb(v_Drug || Chr(13) || Chr(10) || '单据[' || Nvl(r_Info.No, '') || ']中的' || Nvl(r_Info.项目, '') || '：在' || 
                           Nvl(r_Info.部门, '[未定药房]') || '未发药') <= 1000 Then 
                  v_Drug := v_Drug || Chr(13) || Chr(10) || '单据[' || Nvl(r_Info.No, '') || ']中的' || Nvl(r_Info.项目, '') || '：在' || 
                            Nvl(r_Info.部门, '[未定药房]') || '未发药'; 
                Else 
                  v_Drug := v_Drug || Chr(13) || Chr(10) || '... ...'; 
                End If; 
              End If; 
            Else 
              v_Drug := '单据[' || Nvl(r_Info.No, '') || ']中的' || Nvl(r_Info.项目, '') || '：在' || Nvl(r_Info.部门, '[未定药房]') || 
                        '未发药'; 
            End If; 
          Else 
            If v_Stuff Is Not Null Then 
              If Instr(Chr(13) || Chr(10) || v_Stuff || Chr(13) || Chr(10), 
                       Chr(13) || Chr(10) || '单据[' || Nvl(r_Info.No, '') || ']中的' || Nvl(r_Info.项目, '') || '：在' || 
                        Nvl(r_Info.部门, '[未定部门]') || '未发放' || Chr(13) || Chr(10), 1) = 0 Then 
                If Lengthb(v_Stuff || Chr(13) || Chr(10) || '单据[' || Nvl(r_Info.No, '') || ']中的' || Nvl(r_Info.项目, '') || '：在' || 
                           Nvl(r_Info.部门, '[未定部门]') || '未发放') <= 1000 Then 
                  v_Stuff := v_Stuff || Chr(13) || Chr(10) || '单据[' || Nvl(r_Info.No, '') || ']中的' || 
                             Nvl(r_Info.项目, '') || '：在' || Nvl(r_Info.部门, '[未定部门]') || '未发放'; 
                Else 
                  v_Stuff := v_Stuff || Chr(13) || Chr(10) || '... ...'; 
                End If; 
              End If; 
            Else 
              v_Stuff := '单据[' || Nvl(r_Info.No, '') || ']中的' || Nvl(r_Info.项目, '') || '：在' || Nvl(r_Info.部门, '[未定部门]') || 
                         '未发放'; 
            End If; 
          End If; 
        End If; 
      End Loop; 
 
      If v_Drug Is Not Null Then 
        v_Drug := '存在未发药品：' || Chr(13) || Chr(10) || Chr(13) || Chr(10) || v_Drug; 
      End If; 
      If v_Stuff Is Not Null Then 
        v_Stuff := '存在未发放卫材料：' || Chr(13) || Chr(10) || Chr(13) || Chr(10) || v_Stuff; 
      End If; 
 
      If v_Drug Is Not Null And v_Stuff Is Not Null Then 
        v_Text := v_Drug || Chr(13) || Chr(10) || Chr(13) || Chr(10) || v_Stuff; 
      Elsif v_Drug Is Not Null Then 
        v_Text := v_Drug; 
      Elsif v_Stuff Is Not Null Then 
        v_Text := v_Stuff; 
      End If; 
    End If; 
  Elsif 内容_In = 2 Then 
    --1.医技科室执行的项目,临床会诊 
    --2.其他类特殊项目不需管执行 
    --3.PACS已报到的(执行过程为">=2-检查中"不作为未执行完成的项目 
    If Nvl(门诊检查_In, 0) = 0 Then 
      n_Count := 1; 
      Select zl_GetSysParameter(234) Into v_Pars From Dual; 
      v_Pars := Replace(v_Pars, '|', ','); 
      For r_Info In (Select Distinct b.No, c.名称 As 项目, d.名称 As 科室, Decode(Nvl(b.执行状态, 0), 0, '未执行', 3, '正在执行') As 执行状态 
                     From 病人医嘱记录 A, 病人医嘱发送 B, 诊疗项目目录 C, 部门表 D 
                     Where a.病人id = 病人id_In And Nvl(a.主页id, 0) = 主页id_In And (Nvl(a.婴儿, 0) = 婴儿_In Or 婴儿_In = -1) And 
                           a.Id = b.医嘱id And b.执行状态 In (0, 3) And a.诊疗项目id = c.Id And b.执行部门id + 0 = d.Id And 
                           a.诊疗类别 Not In ('4', '5', '6', '7') And Not (a.诊疗类别 In ('F', 'D') And a.相关id Is Not Null) And 
                           (d.撤档时间 = To_Date('3000-01-01', 'YYYY-MM-DD') Or d.撤档时间 Is Null) And 
                           Not (a.诊疗类别 = 'D' And Nvl(b.执行过程, 0) >= 2) And 
                           (Not (a.诊疗类别 = 'Z' And Nvl(c.操作类型, '0') <> '0') Or a.诊疗类别 = 'Z' And c.操作类型 = '7') And 
                           c.Id Not In (Select Column_Value From Table(Cast(f_Num2list(v_Pars) As Zltools.t_Numlist)))) Loop 
        If Lengthb(v_Text || Chr(13) || Chr(10) || '单据[' || Nvl(r_Info.No, '') || ']中的' || Nvl(r_Info.项目, '') || '：在' || 
                   Nvl(r_Info.科室, '[未定科室]') || r_Info.执行状态) > 1000 Then 
          v_Text := v_Text || Chr(13) || Chr(10) || '... ...'; 
          Exit; 
        Else 
          v_Text := v_Text || Chr(13) || Chr(10) || '单据[' || Nvl(r_Info.No, '') || ']中的' || Nvl(r_Info.项目, '') || '：在' || 
                    Nvl(r_Info.科室, '[未定科室]') || r_Info.执行状态; 
        End If; 
 
        n_Count := n_Count + 1; 
      End Loop; 
 
      v_Text := Substr(v_Text, 3); 
    Else 
      For r_Info In (Select Distinct b.No, c.名称 As 项目, d.名称 As 科室, Decode(Nvl(b.执行状态, 0), 0, '未执行', 3, '正在执行') As 执行状态 
                     From 病人医嘱记录 A, 病人医嘱发送 B, 诊疗项目目录 C, 部门表 D 
                     Where a.病人id = 病人id_In And a.主页id Is Null And (Nvl(a.婴儿, 0) = 婴儿_In Or 婴儿_In = -1) And 
                           a.Id = b.医嘱id And b.执行状态 In (0, 3) And a.诊疗项目id = c.Id And b.执行部门id + 0 = d.Id And 
                           a.诊疗类别 Not In ('4', '5', '6', '7') And Not (a.诊疗类别 In ('F', 'D') And a.相关id Is Not Null) And 
                           (d.撤档时间 = To_Date('3000-01-01', 'YYYY-MM-DD') Or d.撤档时间 Is Null) And 
                           Not (a.诊疗类别 = 'D' And Nvl(b.执行过程, 0) >= 2) And 
                           (Not (a.诊疗类别 = 'Z' And Nvl(c.操作类型, '0') <> '0') Or a.诊疗类别 = 'Z' And c.操作类型 = '7')) Loop 
        If Lengthb(v_Text || Chr(13) || Chr(10) || '单据[' || Nvl(r_Info.No, '') || ']中的' || Nvl(r_Info.项目, '') || '：在' || 
                   Nvl(r_Info.科室, '[未定科室]') || r_Info.执行状态) > 1000 Then 
          v_Text := v_Text || Chr(13) || Chr(10) || '... ...'; 
          Exit; 
        Else 
          v_Text := v_Text || Chr(13) || Chr(10) || '单据[' || Nvl(r_Info.No, '') || ']中的' || Nvl(r_Info.项目, '') || '：在' || 
                    Nvl(r_Info.科室, '[未定科室]') || r_Info.执行状态; 
        End If; 
 
        n_Count := n_Count + 1; 
      End Loop; 
 
      v_Text := Substr(v_Text, 3); 
    End If; 
  Elsif 内容_In = 3 Then 
    v_Text := ''; 
    v_Drug := ''; 
    --检查是否安装了血库 
    Begin 
      Select 1 
      Into n_共享 
      From zlSystems 
      Where Trunc(编号 / 100) = 22 And 所有者 = Sys_Context('USERENV', 'CURRENT_SCHEMA'); 
    Exception 
      When Others Then 
        n_共享 := 0; 
    End; 
    v_Sql := 'Select Distinct a.No, d.名称 项目, c.名称 As 部门, To_Char(b.扣率) As 扣率'; 
    v_Sql := v_Sql || ' From 住院费用记录 a, 血液收发记录 b, 部门表 c, 收费项目目录 d'; 
    v_Sql := v_Sql || ' Where a.Id = b.费用id And a.收费细目id = d.Id And b.库房id + 0 = c.Id(+) And a.收费类别 =:1 And b.单据 = 6'; 
    v_Sql := v_Sql || '  And Mod(b.记录状态, 3) = 1 And b.审核人 Is Null And a.病人id =:2 And Nvl(a.主页id, 0) =:3'; 
    v_Sql := v_Sql || '  And (Nvl(a.婴儿费, 0) =:4 Or -1 =:5) And Nvl(b.摘要,:6) <>:7'; 
    --共享安装：进行未发血液的检查 
    If n_共享 = 1 Then 
      Open c_Bool For v_Sql 
        Using 'K', 病人id_In, 主页id_In, 婴儿_In, 婴儿_In, '大医', '拒发'; 
      Loop 
        Fetch c_Bool 
          Into v_No, v_项目, v_部门, v_扣率; 
        Exit When c_Bool%NotFound; 
        n_Do := 1; 
        If Substr(v_扣率, 2) = '3' Then 
          n_Do := 检查离院带药_In; 
        End If; 
        If n_Do = 1 Then 
          If v_Drug Is Not Null Then 
            If Instr(Chr(13) || Chr(10) || v_Drug || Chr(13) || Chr(10), 
                     Chr(13) || Chr(10) || '单据[' || Nvl(v_No, '') || ']中的' || Nvl(v_项目, '') || '：在' || 
                      Nvl(v_部门, '[未定血库]') || '未发血' || Chr(13) || Chr(10), 1) = 0 Then 
              If Lengthb(v_Drug || Chr(13) || Chr(10) || '单据[' || Nvl(v_No, '') || ']中的' || Nvl(v_项目, '') || '：在' || 
                         Nvl(v_部门, '[未定血库]') || '未发血') <= 1000 Then 
                v_Drug := v_Drug || Chr(13) || Chr(10) || '单据[' || Nvl(v_No, '') || ']中的' || Nvl(v_项目, '') || '：在' || 
                          Nvl(v_部门, '[未定血库]') || '未发血'; 
              Else 
                v_Drug := v_Drug || Chr(13) || Chr(10) || '... ...'; 
              End If; 
            End If; 
          Else 
            v_Drug := '单据[' || Nvl(v_No, '') || ']中的' || Nvl(v_项目, '') || '：在' || Nvl(v_部门, '[未定血库]') || '未发血'; 
          End If; 
        End If; 
      End Loop; 
      Close c_Bool; 
      If v_Drug Is Not Null Then 
        v_Drug := '存在未发放的血液：' || Chr(13) || Chr(10) || Chr(13) || Chr(10) || v_Drug; 
      End If; 
      v_Text := v_Drug; 
    End If; 
  End If; 
  Return v_Text; 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zl_Pati_Check_Execute;
/

