create Function zl_PeisGetNextNo 
( 
  外检记录id_In	Number, 
  体检人员id_In	Number, 
  表名_In		Varchar2, 
  字段_In		Varchar2, 
  内容_In		Varchar2 
) Return Varchar2 As 
	v_PreCode		Varchar2(100); 
	v_No			Varchar2(100); 
	n_No			Number(18); 
	n_Have		Number(1); 
	a_Return t_Strlist := t_Strlist(); 
	--------------------------------------------------------------------------------------------------------------- 
	Function GetSplitString(Str_In In Varchar2) Return t_Strlist As 
		v_Str   Long Default Str_In || ','; 
		v_Index Number; 
		v_List  t_Strlist := t_Strlist(); 
 
		Begin 
		Loop 
			v_Index := Instr(v_Str, ','); 
		Exit When(Nvl(v_Index, 0) = 0); 
			v_List.Extend; 
			v_List(v_List.Count) := Trim(Substr(v_Str, 1, v_Index - 1)); 
			v_Str := Substr(v_Str, v_Index + 1); 
		End Loop; 
		Return v_List; 
	End; 
Begin 
  	------------------------------------------------------------------------------------------- 
	If 表名_In='病人信息' And 字段_In='健康号' Then 
		Select Max(b.编码) Into v_PreCode From 体检外检记录 a,体检团体目录 b Where a.ID=外检记录id_In And a.体检团体id=b.ID; 
		If v_PreCode Is Not Null Then 
			v_No:=NextNo(124,0,v_PreCode); 
		End If; 
	End If; 
	------------------------------------------------------------------------------------------- 
	If 表名_In='影像检查记录' And 字段_In='检查号' And 内容_In Is Not Null Then	 
		--执行科室id,影像类别 
		a_Return:=GetSplitString(内容_In); 
		v_No:=NextNo(123, To_Number(a_Return(0)), Trim(To_Char(a_Return(0))));	 
	End If; 
	------------------------------------------------------------------------------------------- 
	If 表名_In='影像检查记录' And 字段_In='检查UID' And 内容_In Is Not Null Then	 
		--医嘱id,发送号,检查UID 
		a_Return:=GetSplitString(内容_In); 
		Select Max(1) Into n_Have From 影像检查记录 a Where a.医嘱id<>To_Number(a_Return(0)) And a.发送号<>To_Number(a_Return(1)) And 检查UID=Trim(To_Char(a_Return(2))); 
		If n_Have=1 Then 
			v_No:='A'||v_No; 
		Else 
			v_No:=Trim(To_Char(a_Return(2))); 
		End If; 
	End If; 
	------------------------------------------------------------------------------------------- 
	If 表名_In='影像检查序列' And 字段_In='序列UID' And 内容_In Is Not Null Then	 
		--检查UID,序列UID 
		a_Return:=GetSplitString(内容_In); 
		Select Max(1) Into n_Have From 影像检查序列 a Where a.序列UID=Trim(To_Char(a_Return(1))) And a.检查UID<>Trim(To_Char(a_Return(0))); 
		If n_Have=1 Then 
			v_No:='B'||v_No; 
		Else 
			v_No:=Trim(To_Char(a_Return(2))); 
		End If; 
	End If; 
	------------------------------------------------------------------------------------------- 
	If 表名_In='影像检查图象' And 字段_In='图像UID' And 内容_In Is Not Null Then	 
		--序列UID,图像UID 
		a_Return:=GetSplitString(内容_In); 
		Select Max(1) Into n_Have From 影像检查图象 a Where a.图像UID=Trim(To_Char(a_Return(1))) And a.序列UID<>Trim(To_Char(a_Return(0))); 
		If n_Have=1 Then 
			v_No:='C'||v_No; 
		Else 
			v_No:=Trim(To_Char(a_Return(2))); 
		End If; 
	End If; 
	------------------------------------------------------------------------------------------- 
	If 表名_In='病理检查信息' And 字段_In='病理号' And 内容_In Is Not Null Then	 
		--检查类型 
		a_Return:=GetSplitString(内容_In); 
		n_No:=ZL_病理号码_序号获取(To_Number(a_Return(0))); 
		v_No:=ZL_病理号码_生成(To_Number(a_Return(0)),n_No); 
		ZL_病理号码_序号更新(To_Number(a_Return(0)),n_No); 
	End If; 
	 
	------------------------------------------------------------------------------------------- 
	Return(v_No); 
End;
/

