create Function zl_PeisOutsideCLobRead 
( 
	表名_In	In	Varchar2, 
	字段_In	In	Varchar2, 
	参数_In	In	VarChar2, 
	位置_In	In	Number			--从0开始不断读取，直到返回为空 
) Return Varchar2 Is 
	l_Clob   Clob; 
	v_SQL	Varchar2(2000); 
	v_Buffer Varchar2(32767); 
	n_Amount Number := 2000; 
	n_Offset Number := 1; 
	a_Return t_Strlist := t_Strlist(); 
	--------------------------------------------------------------------------------------------------------------- 
	Function GetSplitString(Str_In In Varchar2) Return t_Strlist As 
		v_Str   Long Default Str_In || ','; 
		v_Index Number; 
		v_List  t_Strlist := t_Strlist(); 
 
		Begin 
		Loop 
			v_Index := Instr(v_Str, ','); 
		Exit When(Nvl(v_Index, 0) = 0); 
			v_List.Extend; 
			v_List(v_List.Count) := Trim(Substr(v_Str, 1, v_Index - 1)); 
			v_Str := Substr(v_Str, v_Index + 1); 
		End Loop; 
		Return v_List; 
	End; 
Begin 
	 
	If 表名_In='检验报告图像' And 字段_In='图像点' Then 
		a_Return:=GetSplitString(参数_In); 
		v_SQL := 'Select 图像点 From 检验报告图像 Where ID=To_Number(:1)'; 
		Execute Immediate v_SQL Into l_Clob Using a_Return(0); 
	End If; 
	 
	n_Offset := n_Offset + 位置_In * n_Amount; 
	Dbms_Lob.Read(l_Clob, n_Amount, n_Offset, v_Buffer); 
	Return v_Buffer; 
Exception 
  When Others Then 
    Return Null; 
End zl_PeisOutsideCLobRead;
/

