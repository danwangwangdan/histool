create Function Zl_排队叫号队列_插入 
( 
  队列名称_In In 排队叫号队列.队列名称%Type, 
  业务类型_In In 排队叫号队列.业务类型%Type, 
  排队号码_In In 排队叫号队列.排队号码%Type := Null, 
  业务id_In   In 排队叫号队列.业务id%Type := Null, 
  患者姓名_In In 排队叫号队列.患者姓名%Type := Null, 
  诊室_In     In 排队叫号队列.诊室%Type := Null, 
  排队序号_In In 排队叫号队列.排队序号%Type := Null, 
  扩展数据_In In Varchar2 := Null 
) Return Number Is 
  Pragma Autonomous_Transaction; 
  v_Id       排队叫号队列.Id%Type; 
  v_Temp     Varchar2(100); 
  v_Sql      Varchar2(1000); 
  v_排队序号 排队叫号队列.排队序号%Type; 
  v_排队号码 排队叫号队列.排队号码%Type; 
  v_业务id   排队叫号队列.业务id%Type; 
Begin 
  Select 排队叫号队列_Id.Nextval Into v_Id From Dual; 
 
  v_排队序号 := 排队序号_In; 
  If 排队序号_In Is Null Then 
    v_排队序号 := Zl_排队叫号队列_Getqueuenum(业务类型_In, 队列名称_In); 
  End If; 
 
  v_排队号码 := 排队号码_In; 
  If v_排队号码 Is Null Then 
    v_排队号码 := zl_排队叫号队列_获取排队号(业务类型_In, 队列名称_In); -- Select Nvl(Max(lpad(排队号码, 8, 0)), 0) + 1 Into v_排队号码 From 排队叫号队列 where 队列名称=队列名称_In; 
  End If; 
 
  v_业务id := 业务id_In; 
  If v_业务id Is Null Then 
    --如果没有传入业务id，则将业务id的值设置为排队id 
    v_业务id := v_Id; 
  End If; 
 
  Insert Into 排队叫号队列 
    (ID, 业务类型, 队列名称, 排队号码, 业务id, 患者姓名, 诊室, 排队序号, 排队状态, 排队时间) 
  Values 
    (v_Id, 业务类型_In, 队列名称_In, v_排队号码, v_业务id, 患者姓名_In, 诊室_In, v_排队序号, -1, Sysdate); 
 
  --扩展数据_in 格式为：'姓名='张四', 性别='女'，年龄=20....,' 
  If 扩展数据_In Is Not Null Then 
 
    --将句中的中文逗号、单引号换成英文的 
    v_Temp := Replace(扩展数据_In, '，', ','); 
    v_Temp := Replace(v_Temp, '‘', ''''); 
    v_Temp := Replace(v_Temp, '’', ''''); 
 
    --插入数据 
    v_Sql := 'update 排队叫号队列 set ' || v_Temp || ' where id =' || v_Id; 
    Execute Immediate v_Sql; 
  End If; 
  Commit; 
  Return v_Id; 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zl_排队叫号队列_插入;
/

