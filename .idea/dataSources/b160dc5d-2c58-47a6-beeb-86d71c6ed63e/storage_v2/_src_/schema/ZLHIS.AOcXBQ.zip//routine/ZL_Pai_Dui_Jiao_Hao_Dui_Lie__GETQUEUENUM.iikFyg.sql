create function zl_排队叫号队列_GetQueueNum 
( 
    业务类型_In in 排队叫号队列.业务类型%Type, 
    队列名称_In in 排队叫号队列.队列名称%Type 
) 
return varchar2 is 
v_排队序号 排队叫号队列.排队序号%type; 
begin 
  case 业务类型_In 
    when -1 then NULL; 
    else 
      select 排队叫号队列_排队序号.NEXTVAL into v_排队序号 from dual; 
      return lpad(v_排队序号,10,0); 
  end case; 
 
Exception 
  When Others Then 
    Return lpad(0,10,0); 
end zl_排队叫号队列_GetQueueNum;
/

