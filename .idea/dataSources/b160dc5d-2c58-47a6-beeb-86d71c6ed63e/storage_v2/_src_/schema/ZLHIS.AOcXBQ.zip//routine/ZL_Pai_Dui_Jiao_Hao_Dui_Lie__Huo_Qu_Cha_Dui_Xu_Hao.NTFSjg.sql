create Function Zl_排队叫号队列_获取插队序号 
( 
  队列id_In 排队叫号队列.Id%Type, 
  序号1_In  排队叫号队列.排队序号%Type, 
  序号2_In  排队叫号队列.排队序号%Type 
  --功能：获取插队序号 
  --参数： 
  --    队列ID：当前插队的队列ID数据 
  --    序号1：插入队列后的前一个排队序号，插入队列后的后一个排队序号 
) Return Varchar2 As 
  n_Decresult Number; 
  n_Div       Number; 
  n_Where     Number; 
  n_Result    Number; 
  v_result    排队叫号队列.排队序号%Type; 
Begin 
  ----------------------------------------------------------------------------------------------------------- 
  --插队的排队序号规则如下：                                                                               -- 
  --如需要在序号a和序号b之间插入一个数字，则这个数字c可通过以下方式取得                                    -- 
  --设置x:表示b-a的差，如26-25,此时X=1;  25.5-25,此时X=0.5                                                 -- 
  --设置y:表示b-a的差且只获取小数部分并转换为整数后的值，                                                  -- 
  --如25.5-25=0.5,获取小数部分转整，此时Y=5；25.68-25.65=0.03，获取小数部分转整，此时Y=3; 26-25=1,此时Y=1  -- 
  --那么要获取的序号C可以表示为：c=a+X/2+iif(Y=5,X/10,iif(Y=3,X/6,0))                                      -- 
  --只所以这么计算，是因为在同一个地方重复插队时，避免小数位数过快增长                                     -- 
  --注：该方法最多允许在同一个队列前面插入59条数据                                                         -- 
  ----------------------------------------------------------------------------------------------------------- 
 
  n_Decresult := To_Number(序号2_In) - To_Number(序号1_In); 
  n_Where     := Substr(n_Decresult, Instr(n_Decresult, '.') + 1, 6) * 1; 
 
  if 序号2_In = '-1' then 
    v_result := Zl_排队叫号队列_Getqueuenum(null, null); 
    return v_result; 
  end if; 
 
  If n_Where = 5 Or n_Where = 3 Then 
    n_Div := 10; 
    If n_Where = 3 Then 
      n_Div := 6; 
    End If; 
 
    n_Result := To_Number(序号1_In) + n_Decresult / 2 + n_Decresult / n_Div; 
  Else 
    n_Result := To_Number(序号1_In) + n_Decresult / 2; 
  End If; 
 
  If Instr(n_Result, '.') > 0 Then 
    v_result := LPad(Substr(n_Result, 1, Instr(n_Result, '.') - 1), 10, 0) || Substr(n_Result, Instr(n_Result, '.')); 
    if length(v_result) < 10 then 
       Return LPad('0', 10, 0) || v_result; 
    else 
       Return v_result; 
    end if; 
  Else 
    Return LPad(n_Result, 10, 0); 
  End If; 
 
Exception 
  When Others Then 
    Return - 1; 
End Zl_排队叫号队列_获取插队序号;
/

