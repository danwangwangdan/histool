create function zl_排队叫号队列_获取队列ID( 
  业务ID_In        排队叫号队列.业务ID%Type, 
  业务类型_In      排队叫号队列.业务类型%Type 
)return number is 
  n_QueueId    排队叫号队列.ID%Type; 
begin 
 
  select Id into n_QueueId 
  from 排队叫号队列 
  where 业务类型=业务类型_In and 业务ID=业务ID_In; 
 
  return n_QueueId; 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
end zl_排队叫号队列_获取队列ID;
/

