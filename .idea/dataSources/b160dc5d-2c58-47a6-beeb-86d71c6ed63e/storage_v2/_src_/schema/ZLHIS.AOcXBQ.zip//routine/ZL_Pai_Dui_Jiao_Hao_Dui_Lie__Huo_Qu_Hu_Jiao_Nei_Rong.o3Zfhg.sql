create Function Zl_排队叫号队列_获取呼叫内容 
( 
    队列Id_In In 排队叫号队列.Id%Type, 
    呼叫方式_In  in Number 
    --功能：获取语音播放时的播放内容 
    --参数： 
    --    呼叫方式_In:0-顺乎，1-直呼,2-广播,3-候诊呼叫 
) Return Varchar2 Is 
  v_姓名     排队叫号队列.患者姓名%Type; 
  v_诊室     排队叫号队列.诊室%Type; 
  v_呼叫内容 Varchar2(1000); 
Begin 
  Select a.患者姓名, a.诊室 Into v_姓名, v_诊室 From 排队叫号队列 A Where a.Id = 队列Id_In; 
 
  if 呼叫方式_In <> 3 then 
    v_呼叫内容 := '  请、' || v_姓名 || '、  ' || v_姓名 || '  、到' || v_诊室 || '就诊'; 
  else 
    v_呼叫内容 := '  请、' || v_姓名 || '、  ' || v_姓名 || '  、到' || v_诊室 || '侯诊'; 
  end if; 
 
  Return v_呼叫内容; 
Exception 
  When Others Then 
    Return Null; 
End Zl_排队叫号队列_获取呼叫内容;
/

