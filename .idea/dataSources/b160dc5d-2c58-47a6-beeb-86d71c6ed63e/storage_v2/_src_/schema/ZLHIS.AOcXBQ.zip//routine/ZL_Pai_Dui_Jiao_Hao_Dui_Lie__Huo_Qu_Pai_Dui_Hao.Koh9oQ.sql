create function zl_排队叫号队列_获取排队号 
( 
  业务类型_In In 排队叫号队列.业务类型%Type, 
  队列名称_In In 排队叫号队列.队列名称%Type, 
  排队时间_In in 排队叫号队列.排队时间%Type := sysdate 
) return varchar2 is 
  v_排队号码    排队叫号队列.排队号码%Type; 
begin 
  case 业务类型_In 
    when -1 then NULL; 
    else 
      Select Nvl(Max(lpad(排队号码, 8, 0)), 0) + 1 
      Into v_排队号码 From 排队叫号队列 
      where 业务类型=业务类型_In and 队列名称=队列名称_In 
            and 排队时间 between Trunc(排队时间_In) and Trunc(排队时间_In)+ 1 - 1 / 24 / 60 / 60; 
  end case; 
 
  return v_排队号码; 
 
end zl_排队叫号队列_获取排队号;
/

