create Function Zl_排队叫号队列_获取排序方式
( 
    业务类型_In 排队叫号队列.业务类型%Type 
    --获取不同业务分别所需的排序方式 
) Return Varchar2 Is 
Begin 
  Case 业务类型_In 
    When -1 Then NULL; 
    Else 
      Return 'to_number(排队号码) asc'; 
  End Case; 
 
Exception 
  When Others Then 
    Return ''; 
End Zl_排队叫号队列_获取排序方式;
/

