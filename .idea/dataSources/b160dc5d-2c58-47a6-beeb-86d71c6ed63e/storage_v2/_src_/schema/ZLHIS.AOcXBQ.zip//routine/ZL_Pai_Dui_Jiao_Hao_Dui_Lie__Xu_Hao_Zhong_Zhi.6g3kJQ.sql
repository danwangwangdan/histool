create function Zl_排队叫号队列_序号重置 
( 
  队列id_In       排队叫号队列.Id%Type, 
  排队序号_In     排队叫号队列.排队序号%Type := Null 
) return varchar2 Is 
Pragma Autonomous_Transaction; 
 
  v_排队序号 排队叫号队列.排队序号%Type; 
Begin 
  v_排队序号 := 排队序号_In; 
 
  If 排队序号_In Is Null Then 
    v_排队序号 := Zl_排队叫号队列_Getqueuenum(null, null); 
  End If; 
 
  Update 排队叫号队列 Set 排队序号 = v_排队序号 Where ID = 队列id_In; 
 
  commit; 
 
  return v_排队序号; 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zl_排队叫号队列_序号重置;
/

