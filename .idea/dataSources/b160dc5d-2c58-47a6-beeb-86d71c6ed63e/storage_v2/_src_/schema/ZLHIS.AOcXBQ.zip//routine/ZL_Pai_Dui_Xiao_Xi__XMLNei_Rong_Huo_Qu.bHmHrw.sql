create function zl_排队消息_XML内容获取 
( 
    队列ID_In 排队叫号队列.ID%Type, 
    消息类型_In Varchar2 
) return varchar2 IS 
  v_Context varchar2(4000); 
 
 
  --ZLHIS_QUEUE_001(入队消息通知) 
  function Get_ZLHIS_QUEUE_001 return varchar as 
    v_return varchar2(4000); 
  begin 
        select 
           '<queue_id>' || a.id || '</queue_id>' || 
           '<business_type>' || a.业务类型 || '</business_type>' || 
           '<business_id>' || a.业务id || '</business_id>' || 
           '<queue_no>' || a.排队号码 || '</queue_no>' || 
           '<queue_order>' || a.排队序号 || '</queue_order>' || 
           '<dept_id>' || nvl(a.科室id,0) || '</dept_id>' || 
           '<patient_id>' || nvl(a.病人id,0) || '</patient_id>' || 
           '<queue_name>' || a.队列名称 || '</queue_name>' || 
           '<patient_name>' || a.患者姓名 || '</patient_name>' || 
           '<doctor_name>' || a.医生姓名 || '</doctor_name>' || 
           '<doctor_room>' || a.诊室 || '</doctor_room>' || 
           '<queue_memo>' || a.备注 || '</queue_memo>' || 
           '<queue_time>' || a.排队时间 || '</queue_time>' 
        into v_return 
 
        from 排队叫号队列 a 
        where a.id = 队列ID_In; 
 
      return v_return; 
  end Get_ZLHIS_QUEUE_001; 
 
 
  --ZLHIS_QUEUE_002(完成消息通知) 
  function Get_ZLHIS_QUEUE_002 return varchar as 
    v_return varchar2(4000); 
  begin 
        select 
           '<queue_id>' || a.id || '</queue_id>' || 
           '<business_type>' || a.业务类型 || '</business_type>' || 
           '<business_id>' || a.业务id || '</business_id>' || 
           '<queue_no>' || a.排队号码 || '</queue_no>' || 
           '<queue_order>' || a.排队序号 || '</queue_order>' || 
           '<dept_id>' || nvl(a.科室id, 0) || '</dept_id>' || 
           '<patient_id>' || nvl(a.病人id,0) || '</patient_id>' || 
           '<queue_name>' || a.队列名称 || '</queue_name>' || 
           '<patient_name>' || a.患者姓名 || '</patient_name>' || 
           '<doctor_name>' || a.医生姓名 || '</doctor_name>' || 
           '<doctor_room>' || a.诊室 || '</doctor_room>' 
        into v_return 
 
        from 排队叫号队列 a 
        where a.id = 队列ID_In; 
 
      return v_return; 
  end Get_ZLHIS_QUEUE_002; 
 
  --ZLHIS_QUEUE_003(队列状态同步消息通知) 
  function Get_ZLHIS_QUEUE_003 return varchar as 
    v_return varchar2(4000); 
  begin 
        select 
           '<queue_id>' || a.id || '</queue_id>' || 
           '<business_type>' || a.业务类型 || '</business_type>' || 
           '<business_id>' || a.业务id || '</business_id>' || 
           '<queue_no>' || a.排队号码 || '</queue_no>' || 
           '<queue_order>' || a.排队序号 || '</queue_order>' || 
           '<dept_id>' || nvl(a.科室id,0) || '</dept_id>' || 
           '<patient_id>' || nvl(a.病人id, 0) || '</patient_id>' || 
           '<queue_name>' || a.队列名称 || '</queue_name>' || 
           '<patient_name>' || a.患者姓名 || '</patient_name>' || 
           '<queue_state>' || a.排队状态 || '</queue_state>' || 
           '<doctor_name>' || a.医生姓名 || '</doctor_name>' || 
           '<doctor_room>' || a.诊室 || '</doctor_room>' 
 
        into v_return 
 
        from 排队叫号队列 a 
        where a.id = 队列ID_In; 
 
      return v_return; 
  end Get_ZLHIS_QUEUE_003; 
 
 
  --ZLHIS_QUEUE_004(呼叫消息通知) 
  function Get_ZLHIS_QUEUE_004 return varchar as 
    v_return varchar2(4000); 
  begin 
 
        select 
           '<queue_id>' || a.id || '</queue_id>' || 
           '<business_type>' || a.业务类型 || '</business_type>' || 
           '<business_id>' || a.业务id || '</business_id>' || 
           '<dept_id>' || nvl(a.科室id,0) || '</dept_id>' || 
           '<queue_name>' || a.队列名称 || '</queue_name>' || 
           '<voice_id>' || b.id || '</voice_id>' || 
           '<voice_context>' || b.呼叫内容 || '</voice_context>' || 
           '<voice_station>' || b.站点 || '</voice_station>' || 
           '<voice_station_ip>' || c.ip || '</voice_station_ip>' 
        into v_return 
 
        from 排队叫号队列 a, 排队语音呼叫 b, zlClients c 
        where a.id=b.队列id and c.工作站=b.站点 and rownum <=1 and  a.id = 队列ID_In; 
 
      return v_return; 
  end Get_ZLHIS_QUEUE_004; 
 
 
begin 
  v_Context := ''; 
 
  case 消息类型_In 
    when 'ZLHIS_QUEUE_001' then 
        --ZLHIS_PACS_001(患者检查申请) 
        v_Context := Get_ZLHIS_QUEUE_001; 
 
    when 'ZLHIS_QUEUE_002' then 
        --ZLHIS_PACS_002(检查状态同步) 
        v_Context := Get_ZLHIS_QUEUE_002; 
 
    when 'ZLHIS_QUEUE_003' then 
        --ZLHIS_PACS_003(检查状态回退) 
        v_Context := Get_ZLHIS_QUEUE_003; 
 
    when 'ZLHIS_QUEUE_004' then 
        --ZLHIS_PACS_004(患者检查拒绝) 
        v_Context := Get_ZLHIS_QUEUE_004; 
 
    else 
      return ''; 
  end case; 
 
  return v_Context; 
end zl_排队消息_XML内容获取;
/

