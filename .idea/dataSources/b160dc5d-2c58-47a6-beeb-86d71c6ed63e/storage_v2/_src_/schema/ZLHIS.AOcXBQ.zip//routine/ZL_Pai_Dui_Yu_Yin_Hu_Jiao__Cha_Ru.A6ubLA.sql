create function Zl_排队语音呼叫_插入 
( 
  队列id_In   In 排队叫号队列.Id%Type, 
  业务类型_In in 排队语音呼叫.业务类型%Type, 
  站点_In     In 排队语音呼叫.站点%Type, 
  呼叫内容_In In 排队语音呼叫.呼叫内容%Type 
)return number Is 
Pragma Autonomous_Transaction; 
  V语音id 排队语音呼叫.Id%Type; 
Begin 
 
  --写入数据库表 
  Select 排队语音呼叫_Id.Nextval Into V语音id From Dual; 
 
  Insert Into 排队语音呼叫 
    (ID, 队列id, 业务类型, 呼叫内容, 站点, 生成时间) 
  Values 
    (V语音id, 队列id_In, 业务类型_In, 呼叫内容_In, 站点_In, Sysdate); 
 
  commit; 
 
  return V语音id; 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zl_排队语音呼叫_插入;
/

