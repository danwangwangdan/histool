create function Zl_排队语音呼叫_自定义插入 
( 
  呼叫内容_In In 排队语音呼叫.呼叫内容%Type, 
  站点_In     In 排队语音呼叫.站点%Type 
)return number Is 
Pragma Autonomous_Transaction; 
  v_Id 排队语音呼叫.Id%Type; 
Begin 
  Select 排队语音呼叫_Id.Nextval Into v_Id From Dual; 
  Insert Into 排队语音呼叫 (ID, 呼叫内容, 站点, 生成时间) Values (v_Id, 呼叫内容_In, 站点_In, Sysdate); 
 
  commit; 
  return v_Id; 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zl_排队语音呼叫_自定义插入;
/

