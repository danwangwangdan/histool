create Function Zl_QueuedateCheck 
 ( 
 挂号id_In 病人挂号记录.Id%Type 
 ) Return Varchar2 Is 
	--功能：对此挂号所在的队列进行有效检查 
	-- 
	-- 
	--参数： 
	--    挂号id_In：传入的是当前挂号ID 
	--    返回值:处理类型|提示信息 
	--         处理类型 0-不限制 1-提示 2-限制 
 
	Err_Custom Exception; 
	v_Returnmsg Varchar2(500); 
	n_提前接收  Number(18); 
	n_预约      Number(1); 
	d_排队时间  Date; 
Begin 
	v_Returnmsg := '0|'; 
	--这里直接返回,具体业务处理,请根据实际业务调整相应代码 
	Return v_Returnmsg; 
  --请根据实际业务做处理 
	n_提前接收  := Zl_Getsysparameter('预约有效时间', 1111); 
  If Nvl(n_提前接收, 0) = 0 Then 
    Return v_ReturnMsg; 
  End If; 
  Select Nvl(a.预约, 0) As 预约, b.排队时间 
  Into n_预约, d_排队时间 
  From 排队叫号队列 b, 病人挂号记录 a 
  Where a.Id = b.业务id And b.业务ID=挂号ID_in; 
 
	Return v_Returnmsg; 
End Zl_QueuedateCheck;
/

