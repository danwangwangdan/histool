create Function Zl_Replace_Element_Value 
( 
  元素名_In   In 诊治所见项目.中文名%Type, 
  病人id_In   In 电子病历记录.病人id%Type, 
  就诊id_In   In 电子病历记录.主页id%Type, 
  病人来源_In In 电子病历记录.病人来源%Type, 
  医嘱id_In   In 病人医嘱记录.Id%Type := Null, 
  婴儿_In     In Number := 0, 
  时间_In     In Date := Null 
) Return Varchar2 Is 
  v_Return Varchar2(4000) := Null; 
 
  Cursor c_Pati Is 
    Select 姓名, 性别, 年龄, 职业, 民族, 国籍, 婚姻状况, 出生日期, 出生地点, 身份证号, 身份, 学历, 家庭地址, 家庭电话, 工作单位, 单位电话, 门诊号, 住院次数, 联系人姓名, 联系人关系, 
           联系人地址, 联系人电话 
    From 病人信息 
    Where 病人id = 病人id_In; 
  r_Patient c_Pati%RowType; 
 
  Cursor c_Reg Is 
    Select 摘要, 登记时间, 急诊, 执行部门id From 病人挂号记录 Where 病人id + 0 = 病人id_In And ID = 就诊id_In; 
  r_Regist c_Reg%RowType; 
 
  Cursor c_Inpage Is 
    Select Nvl(b.姓名, a.姓名) 姓名, Nvl(b.性别, a.性别) 性别, Nvl(b.年龄, a.年龄) 年龄, b.住院号, b.入院日期, b.出院日期, b.住院目的, b.入院科室id, b.入院病区id, 
           b.出院病床, b.当前病区id, b.当前病况, b.住院医师, b.责任护士, b.二级院转入, b.入院方式, b.护理等级id, b.出院方式, b.入院病床, b.联系人姓名, b.联系人关系, 
           b.联系人地址, b.联系人电话, b.出院科室id 
    From 病人信息 A, 病案主页 B 
    Where a.病人id = b.病人id And b.病人id = 病人id_In And b.主页id = 就诊id_In; 
  r_Inpage c_Inpage%RowType; 
 
  Cursor c_Order Is 
    Select 婴儿, 紧急标志, 开嘱科室id, 开嘱医生, 开嘱时间, 执行科室id, 开始执行时间, 医生嘱托, 诊疗类别, 诊疗项目id, 标本部位, 检查方法 
 
 
 
    From 病人医嘱记录 
    Where 病人id + 0 = 病人id_In And ID = 医嘱id_In; 
  r_Order c_Order%RowType; 
 
  Cursor c_Signs Is 
    Select b.项目名称, b.记录内容 
    From 病人护理记录 A, 病人护理内容 B 
    Where a.病人id = 病人id_In And a.主页id = 就诊id_In And a.病人来源 = 病人来源_In And a.Id = b.记录id And b.记录类型 = 1 And 
          b.项目名称 = 元素名_In; 
  r_Signs c_Signs%RowType; 
 
  v_Subtype 诊疗项目目录.操作类型%Type := Null; 
 
  Type t_Str_Table Is Table Of Varchar2(2000); 
  a_Return t_Str_Table := t_Str_Table(); 
 
  n_主页id 病案主页.主页id%Type; 
  n_Times  Number; 
  n_Have   Number(3); 
  v_Sql    Varchar2(2000); 
 
  --获取指定表的行类型 
  Procedure p_Get_Rowtype(Table_In In Varchar2) Is 
  Begin 
    If Table_In = '病人信息' Then 
      Open c_Pati; 
      Fetch c_Pati 
        Into r_Patient; 
    Elsif Table_In = '病人挂号记录' Then 
      Open c_Reg; 
      Fetch c_Reg 
        Into r_Regist; 
    Elsif Table_In = '病案主页' Then 
      Open c_Inpage; 
      Fetch c_Inpage 
        Into r_Inpage; 
    Elsif Table_In = '病人医嘱记录' Then 
      Open c_Order; 
      Fetch c_Order 
        Into r_Order; 
    Elsif Table_In = '病人护理内容' Then 
      Open c_Signs; 
      Fetch c_Signs 
        Into r_Signs; 
    End If; 
  Exception 
    When Others Then 
      Null; 
  End p_Get_Rowtype; 
 
  --从电子病历内容获取指定预制提纲的最新内容 
  Function f_Latest_Epr_Content(提纲标题_In In 病历文件结构.内容文本%Type) Return Varchar2 Is 
    v_Content Varchar2(32767); 
    n_预制id  病历文件结构.Id%Type; 
  Begin 
    Select ID Into n_预制id From 病历文件结构 Where 内容文本 = 提纲标题_In And 文件id Is Null; 
    Select c.内容文本 || Decode(c.要素类型, 0, c.要素单位) Bulk Collect 
    Into a_Return 
    From 电子病历内容 C, 
         (Select ID 
           From (Select r.Id 记录id, c.Id 
                  From 电子病历记录 R, 电子病历内容 C 
                  Where r.Id = c.文件id And r.病人id = 病人id_In And c.预制提纲id + 0 = n_预制id 
                  Order By r.创建时间 Desc) 
           Where Rownum = 1) P 
    Where c.父id = p.Id And (c.对象类型 = 2 Or c.对象类型 = 4) 
    Order By c.对象序号, c.内容行次; 
    v_Content := Null; 
    For n_Count In 1 .. a_Return.Count Loop 
      v_Content := v_Content || a_Return(n_Count); 
    End Loop; 
    v_Content := Replace(v_Content, ' ', ''); 
    Return v_Content; 
  Exception 
    When Others Then 
      Return Null; 
  End f_Latest_Epr_Content; 
 
  --从病人医嘱附件获取指定要素的最新内容，实际只有“病历摘要”需要 
  Function f_Latest_Advice_Annex Return Varchar2 Is 
    v_Content Varchar2(32767); 
    n_要素id  病人医嘱附件.要素id%Type; 
    v_挂号单  病人医嘱记录.挂号单%Type; 
  Begin 
    Select ID Into n_要素id From 诊治所见项目 Where 中文名 = 元素名_In; 
    If 病人来源_In = 1 Then 
      Select NO Into v_挂号单 From 病人挂号记录 Where ID = 就诊id_In; 
    End If; 
    Select 内容 
    Into v_Content 
    From (Select l.Id, a.内容, l.开嘱时间 
           From 病人医嘱记录 L, 病人医嘱附件 A 
           Where l.Id = a.医嘱id And l.病人id = 病人id_In And a.要素id = n_要素id 
           Order By l.开嘱时间 Desc) 
    Where Rownum = 1; 
    Return v_Content; 
  Exception 
    When Others Then 
      Return Null; 
  End f_Latest_Advice_Annex; 
 
  --获得病人指定就诊次数的最新诊断 
  Function f_Latest_Diagnose 
  ( 
    主页id_In In 病人诊断记录.主页id%Type, 
    时间_In   In Date := Null 
  ) Return Varchar2 Is 
    v_Content Varchar2(32767); 
  Begin 
    If 时间_In Is Null Then 
      --如果已经整理首页或病案中的诊断，则以这些诊断为最后诊断返回 
      Select 诊断描述 || Decode(Nvl(是否疑诊, 0), 0, '', ' (？)') Bulk Collect 
      Into a_Return 
      From 病人诊断记录 D, 
           (Select Max(记录来源) As 记录来源, Max(Mod(诊断类型, 10)) As 诊断类型 
             From 病人诊断记录 
             Where 病人id = 病人id_In And 主页id = 主页id_In And 病历id Is Null And 记录来源 > 1 And 诊断类型 In (1, 11, 2, 12, 3, 13)) F 
      Where d.病人id = 病人id_In And d.主页id = 主页id_In And d.记录来源 = f.记录来源 And Mod(d.诊断类型, 10) = f.诊断类型 
      Order By d.诊断次序; 
      v_Content := Null; 
      For n_Count In 1 .. a_Return.Count Loop 
        If a_Return.Count > 1 Then 
          v_Content := v_Content || '  ' || n_Count || '、' || a_Return(n_Count); 
        Else 
          v_Content := v_Content || a_Return(n_Count); 
        End If; 
      End Loop; 
      If v_Content Is Not Null Then 
        Return Trim(v_Content); 
      End If; 
 
      --否则，获取最后书写的病历中诊断作为最后诊断(隐含包括，如果还没有写病历，则以入院时填写的诊断为最后诊断)： 
      Select d.诊断描述 || Decode(Nvl(d.是否疑诊, 0), 0, '', ' (？)') Bulk Collect 
      Into a_Return 
      From 病人诊断记录 D, 
           (Select 病历id 
             From (Select Distinct a.病历id, b.创建时间 
                    From 病人诊断记录 A, 电子病历记录 B 
                    Where a.病人id = 病人id_In And a.主页id = 主页id_In And a.诊断类型 In (1, 11, 2, 12, 3, 13) And Nvl(a.病历id, 0) <> 0 And 
                          a.病历id = b.Id 
                    Order By b.创建时间 Desc) 
             Where Rownum = 1) M 
      Where d.病人id = 病人id_In And d.主页id = 主页id_In And d.诊断类型 In (1, 11, 2, 12, 3, 13) And d.病历id = m.病历id 
      Order By d.诊断次序; 
      For n_Count In 1 .. a_Return.Count Loop 
        If a_Return.Count > 1 Then 
          v_Content := v_Content || '  ' || n_Count || '、' || a_Return(n_Count); 
        Else 
          v_Content := v_Content || a_Return(n_Count); 
        End If; 
      End Loop; 
      Return Trim(v_Content); 
    Else 
      Select 诊断描述 || Decode(Nvl(是否疑诊, 0), 0, '', ' (？)') Bulk Collect 
      Into a_Return 
      From 病人诊断记录 D, 
           (Select Max(记录来源) As 记录来源, Max(Mod(诊断类型, 10)) As 诊断类型 
             From 病人诊断记录 
             Where 病人id = 病人id_In And 主页id = 主页id_In And 记录日期 < 时间_In And 诊断类型 In (1, 11, 2, 12, 3, 13)) F 
      Where d.病人id = 病人id_In And d.主页id = 主页id_In And d.记录来源 = f.记录来源 And Mod(d.诊断类型, 10) = f.诊断类型 
      Order By d.诊断次序; 
      v_Content := Null; 
      For n_Count In 1 .. a_Return.Count Loop 
        If a_Return.Count > 1 Then 
          v_Content := v_Content || '  ' || n_Count || '、' || a_Return(n_Count); 
        Else 
          v_Content := v_Content || a_Return(n_Count); 
        End If; 
      End Loop; 
      If v_Content Is Not Null Then 
        Return Trim(v_Content); 
      End If; 
    End If; 
 
  Exception 
    When Others Then 
      Return Null; 
  End f_Latest_Diagnose; 
 
  --获取病人最新疾病ID和诊断ID 
  Function f_Last_Diagnoseid(主页id_In In 病人诊断记录.主页id%Type) Return Varchar2 Is 
    v_Returndiagnose Varchar2(500); 
  Begin 
    For r_Diagnose In (Select 疾病id, 诊断id 
                       From 病人诊断记录 D, 
                            (Select Max(记录来源) As 记录来源, Max(Mod(诊断类型, 10)) As 诊断类型 
                              From 病人诊断记录 
                              Where 病人id = 病人id_In And 主页id = 主页id_In And 病历id Is Null And 记录来源 > 1 And 
                                    诊断类型 In (1, 11, 2, 12, 3, 13)) F 
                       Where d.病人id = 病人id_In And d.主页id = 主页id_In And d.记录来源 = f.记录来源 And Mod(d.诊断类型, 10) = f.诊断类型 
                       Order By d.诊断次序) Loop 
      v_Returndiagnose := r_Diagnose.疾病id || '|' || r_Diagnose.诊断id; 
      Return v_Returndiagnose; 
    End Loop; 
    --没取到则返回 
    v_Returndiagnose := '|'; 
    Return v_Returndiagnose; 
  Exception 
    When Others Then 
      Return Null; 
  End f_Last_Diagnoseid; 
 
  --获得病人指定住院诊断 
  Function f_Diagnose(Inttype_In In Number) Return Varchar2 Is 
    v_Content Varchar2(32767); 
  Begin 
    --intType_IN:1-西医门诊诊断;2-中医门诊诊断;3-西医入院诊断;4-中医入院诊断; 
    --       5,所有西医出院诊断;6,只取西医出院主要诊断(诊断次序)=1;7,只取西医出院其他诊断(诊断次序)>1;8-中医出院诊断 
    Select 诊断描述 || Decode(Nvl(是否疑诊, 0), 0, '', ' (？)') Bulk Collect 
    Into a_Return 
    From 病人诊断记录 D, 
         (Select Max(记录来源) As 记录来源, Max(诊断类型) As 诊断类型 
           From 病人诊断记录 
           Where 病人id = 病人id_In And 主页id = 就诊id_In And 病历id Is Null And 记录来源 > 1 And 
                 诊断类型 = Decode(Inttype_In, 1, 1, 2, 11, 3, 2, 4, 12, 8, 13, 3)) F 
    Where d.病人id = 病人id_In And d.主页id = 就诊id_In And d.记录来源 = f.记录来源 And d.诊断类型 = f.诊断类型 And 
          d.诊断次序 > Decode(Inttype_In, 7, 1, 0) And Rownum < Decode(Inttype_In, 6, 2, 10) 
    Order By d.诊断次序; 
 
    v_Content := Null; 
    For n_Count In 1 .. a_Return.Count Loop 
      If a_Return.Count > 1 Then 
        v_Content := v_Content || '  ' || n_Count || '、' || a_Return(n_Count); 
      Else 
        v_Content := v_Content || a_Return(n_Count); 
      End If; 
    End Loop; 
    If v_Content Is Not Null Then 
      Return Trim(v_Content); 
    End If; 
 
  Exception 
    When Others Then 
      Return Null; 
  End f_Diagnose; 
 
  --获取病人本次就诊的医嘱内容 
  Function f_Get_Advice_Text Return Varchar2 Is 
    v_Text   Varchar2(4000); 
    v_挂号单 病人挂号记录.No%Type; 
  Begin 
    If 病人来源_In = 1 Then 
      Begin 
        Select NO Into v_挂号单 From 病人挂号记录 Where ID = 就诊id_In; 
      Exception 
        When Others Then 
          Return Null; 
      End; 
    End If; 
 
    --提取病人医嘱：界面可见行医嘱内容，不含作废的 
    For r_Row In (Select a.医嘱内容 
                  From 病人医嘱记录 A, 诊疗项目目录 B 
                  Where a.诊疗项目id = b.Id And a.开始执行时间 Is Not Null And a.医嘱状态 <> 4 And Nvl(a.婴儿, 0) = 0 And 
                        Not (a.诊疗类别 In ('F', 'G', 'D', 'C', 'E') And a.相关id Is Not Null) And a.诊疗类别 <> '7' And 
                        Not (a.诊疗类别 = 'E' And b.操作类型 In ('2', '4')) And a.病人来源 = 病人来源_In And a.病人id = 病人id_In And 
                        (病人来源_In = 1 And a.挂号单 = v_挂号单 Or a.主页id = 就诊id_In) 
                  Order By a.序号) Loop 
      If Lengthb(v_Text || r_Row.医嘱内容) <= 4000 Then 
        v_Text := v_Text || Chr(13) || Chr(10) || r_Row.医嘱内容; 
      Else 
        Exit; 
      End If; 
    End Loop; 
 
    Return Substr(v_Text, 3); 
  End f_Get_Advice_Text; 
Begin 
  Case 
    When Instr('体温,呼吸,脉搏,收缩压,舒张压', 元素名_In) > 0 And 病人来源_In = 1 Then 
      p_Get_Rowtype('病人护理内容'); 
      v_Return := r_Signs.记录内容; 
    When Instr(',当前日期,当前时间,DQSJ', ',' || Upper(元素名_In)) > 0 Then 
      --无需读取任何表数据的元素 
      Case Upper(元素名_In) 
        When '当前日期' Then 
          v_Return := To_Char(Sysdate, 'yyyy-mm-dd'); 
          v_Return := Substr(v_Return, 1, 4) || '年' || Substr(v_Return, 6, 2) || '月' || Substr(v_Return, 9, 2) || '日'; 
        When '当前时间' Then 
          v_Return := To_Char(Sysdate, 'yyyy-mm-dd hh24:mi'); 
          v_Return := Substr(v_Return, 1, 4) || '年' || Substr(v_Return, 6, 2) || '月' || Substr(v_Return, 9, 2) || '日' || 
                      Substr(v_Return, 12, 2) || '时' || Substr(v_Return, 15, 2) || '分'; 
        When 'DQSJ' Then 
          v_Return := To_Char(Sysdate, 'yyyy-mm-dd hh24:mi'); 
          v_Return := Substr(v_Return, 1, 4) || '年' || Substr(v_Return, 6, 2) || '月' || Substr(v_Return, 9, 2) || '日' || 
                      Substr(v_Return, 12, 2) || '时' || Substr(v_Return, 15, 2) || '分'; 
      End Case; 
    When Instr(',职业,民族,国籍,婚姻状况,出生日期,出生地点,身份证号,身份,学历,家庭地址,家庭电话,工作单位,单位电话,门诊号,住院次数', ',' || 元素名_In) > 0 Then 
      --只查病人信息表的元素 
      p_Get_Rowtype('病人信息'); 
      Case 元素名_In 
        When '职业' Then 
          v_Return := r_Patient.职业; 
        When '民族' Then 
          v_Return := r_Patient.民族; 
        When '国籍' Then 
          v_Return := r_Patient.国籍; 
        When '婚姻状况' Then 
          v_Return := r_Patient.婚姻状况; 
        When '出生日期' Then 
          v_Return := To_Char(r_Patient.出生日期, 'yyyy-mm-dd'); 
          v_Return := Substr(v_Return, 1, 4) || '年' || Substr(v_Return, 6, 2) || '月' || Substr(v_Return, 9, 2) || '日'; 
        When '出生地点' Then 
          v_Return := r_Patient.出生地点; 
        When '身份证号' Then 
          v_Return := r_Patient.身份证号; 
        When '身份' Then 
          v_Return := r_Patient.身份; 
        When '学历' Then 
          v_Return := r_Patient.学历; 
        When '家庭地址' Then 
          v_Return := r_Patient.家庭地址; 
        When '家庭电话' Then 
          v_Return := r_Patient.家庭电话; 
        When '工作单位' Then 
          v_Return := r_Patient.工作单位; 
        When '单位电话' Then 
          v_Return := r_Patient.单位电话; 
        When '门诊号' Then 
          v_Return := r_Patient.门诊号; 
        When '住院次数' Then 
          v_Return := Nvl(r_Patient.住院次数, 0); 
        Else 
          v_Return := ''; 
      End Case; 
    When Instr(',住院号,入院日期,出院日期,住院目的,入院科室,入院病区,当前床号,当前病区,当前病况,住院医师,责任护士,住院天数,入院方式,护理等级,出院方式,入院病室,出院病室,当前病室', 
               ',' || 元素名_In) > 0 Then 
      --只查病人主页的元素 
      p_Get_Rowtype('病案主页'); 
      Case 元素名_In 
        When '住院号' Then 
          v_Return := r_Inpage.住院号; 
        When '入院日期' Then 
          If 病人来源_In = 2 Then 
            v_Return := To_Char(r_Inpage.入院日期, 'yyyy-mm-dd hh24:mi'); 
            v_Return := Substr(v_Return, 1, 4) || '年' || Substr(v_Return, 6, 2) || '月' || Substr(v_Return, 9, 2) || '日' || 
                        Substr(v_Return, 12, 2) || '时' || Substr(v_Return, 15, 2) || '分'; 
          End If; 
        When '出院日期' Then 
          If 病人来源_In = 2 Then 
            v_Return := To_Char(r_Inpage.出院日期, 'yyyy-mm-dd hh24:mi'); 
            v_Return := Substr(v_Return, 1, 4) || '年' || Substr(v_Return, 6, 2) || '月' || Substr(v_Return, 9, 2) || '日' || 
                        Substr(v_Return, 12, 2) || '时' || Substr(v_Return, 15, 2) || '分'; 
          End If; 
        When '住院目的' Then 
          If 病人来源_In = 2 Then 
            v_Return := r_Inpage.住院目的; 
          End If; 
 
        When '入院科室' Then 
          If 病人来源_In = 2 Then 
            Select Max(d.名称) 
            Into v_Return 
            From 部门表 D, 病人变动记录 P 
            Where d.Id = p.科室id And p.病人id = 病人id_In And p.主页id = 就诊id_In And p.开始原因 = 9; 
            If v_Return Is Null Then 
              Select 名称 Into v_Return From 部门表 Where ID = r_Inpage.入院科室id; 
            End If; 
          End If; 
        When '入院病区' Then 
          If 病人来源_In = 2 Then 
            Select Max(d.名称) 
            Into v_Return 
            From 部门表 D, 病人变动记录 P 
            Where d.Id = p.病区id And p.病人id = 病人id_In And p.主页id = 就诊id_In And p.开始原因 = 9; 
            If v_Return Is Null Then 
              Select 名称 Into v_Return From 部门表 Where ID = r_Inpage.入院病区id; 
            End If; 
          End If; 
        When '当前床号' Then 
          If 病人来源_In = 2 Then 
            v_Return := r_Inpage.出院病床; 
          End If; 
        When '当前病区' Then 
          If 病人来源_In = 2 Then 
            Select 名称 Into v_Return From 部门表 Where ID = r_Inpage.当前病区id; 
          End If; 
        When '当前病况' Then 
          If 病人来源_In = 2 Then 
            v_Return := r_Inpage.当前病况; 
          End If; 
        When '住院医师' Then 
          If 病人来源_In = 2 Then 
            v_Return := r_Inpage.住院医师; 
          End If; 
        When '责任护士' Then 
          If 病人来源_In = 2 Then 
            v_Return := r_Inpage.责任护士; 
          End If; 
        When '住院天数' Then 
          If 病人来源_In = 2 Then 
            v_Return := Trunc(Nvl(r_Inpage.出院日期, Sysdate)) - Trunc(r_Inpage.入院日期); 
          End If; 
        When '入院方式' Then 
          If 病人来源_In = 2 Then 
            If r_Inpage.二级院转入 = 1 Then 
              v_Return := '转入'; 
            Else 
              v_Return := r_Inpage.入院方式; 
            End If; 
          End If; 
        When '护理等级' Then 
          If 病人来源_In = 2 Then 
            Select 名称 Into v_Return From 收费项目目录 Where ID = r_Inpage.护理等级id; 
          End If; 
        When '出院方式' Then 
          If 病人来源_In = 2 Then 
            v_Return := r_Inpage.出院方式; 
          End If; 
        When '入院病室' Then 
          If 病人来源_In = 2 Then 
            If v_Return Is Null And r_Inpage.入院病床 Is Not Null Then 
              Begin 
                Select 房间号 
                Into v_Return 
                From 床位状况记录 
                Where 病区id = r_Inpage.入院病区id And 床号 = r_Inpage.入院病床; 
              Exception 
                When Others Then 
                  Null; 
              End; 
            End If; 
          End If; 
        When '出院病室' Then 
          If 病人来源_In = 2 Then 
            If v_Return Is Null And r_Inpage.出院病床 Is Not Null Then 
              Begin 
                Select 房间号 
                Into v_Return 
                From 床位状况记录 
                Where 病区id = r_Inpage.当前病区id And 床号 = r_Inpage.出院病床; 
              Exception 
                When Others Then 
                  Null; 
              End; 
            End If; 
          End If; 
        When '当前病室' Then 
          If 病人来源_In = 2 Then 
            If v_Return Is Null And r_Inpage.出院病床 Is Not Null Then 
              Begin 
                Select 房间号 
                Into v_Return 
                From 床位状况记录 
                Where 病区id = r_Inpage.当前病区id And 床号 = r_Inpage.出院病床; 
              Exception 
                When Others Then 
                  Null; 
              End; 
            End If; 
          End If; 
        Else 
          v_Return := ''; 
      End Case; 
    When Instr(',姓名,性别,年龄', ',' || 元素名_In) > 0 Then 
      p_Get_Rowtype('病人医嘱记录'); 
      p_Get_Rowtype('病人信息'); 
      If Nvl(r_Order.婴儿, 0) = 0 And 婴儿_In = 0 Then 
        If 病人来源_In = 2 Then 
          p_Get_Rowtype('病案主页'); 
          If 元素名_In = '姓名' Then 
            v_Return := r_Inpage.姓名; 
          Elsif 元素名_In = '性别' Then 
            v_Return := r_Inpage.性别; 
          Elsif 元素名_In = '年龄' Then 
            v_Return := r_Inpage.年龄; 
          End If; 
        Else 
          If 元素名_In = '姓名' Then 
            v_Return := r_Patient.姓名; 
          Elsif 元素名_In = '性别' Then 
            v_Return := r_Patient.性别; 
          Elsif 元素名_In = '年龄' Then 
            v_Return := r_Patient.年龄; 
          End If; 
        End If; 
      Else 
        If 元素名_In = '姓名' Then 
          p_Get_Rowtype('病案主页'); 
          Select Decode(婴儿姓名, Null, r_Inpage.姓名 || '之婴' || Trim(To_Char(序号, '9')), 婴儿姓名) As 婴儿姓名 
          Into v_Return 
          From 病人新生儿记录 
          Where 病人id = 病人id_In And 主页id = 就诊id_In And 序号 = Decode(婴儿_In, 0, Nvl(r_Order.婴儿, 0), 婴儿_In); 
        Elsif 元素名_In = '性别' Then 
          Select 婴儿性别 
          Into v_Return 
          From 病人新生儿记录 
          Where 病人id = 病人id_In And 主页id = 就诊id_In And 序号 = Decode(婴儿_In, 0, Nvl(r_Order.婴儿, 0), 婴儿_In); 
        Elsif 元素名_In = '年龄' Then 
          Select To_Char(出生时间, 'yyyy-mm-dd hh24:mi') 
          Into v_Return 
          From 病人新生儿记录 
          Where 病人id = 病人id_In And 主页id = 就诊id_In And 序号 = Decode(婴儿_In, 0, Nvl(r_Order.婴儿, 0), 婴儿_In); 
        End If; 
      End If; 
    When Instr(',标识号,联系人姓名,联系人关系,联系人地址,联系人电话', ',' || 元素名_In) > 0 Then 
      If 病人来源_In = 2 Then 
        p_Get_Rowtype('病案主页'); 
        If 元素名_In = '标识号' Then 
          v_Return := r_Inpage.住院号; 
        Elsif 元素名_In = '联系人姓名' Then 
          v_Return := r_Inpage.联系人姓名; 
        Elsif 元素名_In = '联系人关系' Then 
          v_Return := r_Inpage.联系人关系; 
        Elsif 元素名_In = '联系人地址' Then 
          v_Return := r_Inpage.联系人地址; 
        Elsif 元素名_In = '联系人电话' Then 
          v_Return := r_Inpage.联系人电话; 
        End If; 
      Else 
        p_Get_Rowtype('病人信息'); 
        If 元素名_In = '标识号' Then 
          v_Return := r_Patient.门诊号; 
        Elsif 元素名_In = '联系人姓名' Then 
          v_Return := r_Patient.联系人姓名; 
        Elsif 元素名_In = '联系人关系' Then 
          v_Return := r_Patient.联系人关系; 
        Elsif 元素名_In = '联系人地址' Then 
          v_Return := r_Patient.联系人地址; 
        Elsif 元素名_In = '联系人电话' Then 
          v_Return := r_Patient.联系人电话; 
        End If; 
      End If; 
    When Instr(',门诊就诊摘要,就诊科室,就诊时间,是否急诊,当前科室', ',' || 元素名_In) > 0 Then 
      --只查病人挂号记录的元素 
      If 病人来源_In = 1 Then 
        p_Get_Rowtype('病人挂号记录'); 
        If 元素名_In = '门诊就诊摘要' Then 
          v_Return := r_Regist.摘要; 
        Elsif 元素名_In = '就诊科室' Then 
          Select 名称 Into v_Return From 部门表 Where ID = r_Regist.执行部门id; 
        Elsif 元素名_In = '就诊时间' Then 
          v_Return := To_Char(r_Regist.登记时间, 'yyyy-mm-dd hh24:mi'); 
          v_Return := Substr(v_Return, 1, 4) || '年' || Substr(v_Return, 6, 2) || '月' || Substr(v_Return, 9, 2) || '日' || 
                      Substr(v_Return, 12, 2) || '时' || Substr(v_Return, 15, 2) || '分'; 
        Elsif 元素名_In = '是否急诊' Then 
          If r_Regist.急诊 = 1 Then 
            v_Return := '急诊'; 
          End If; 
        Elsif 元素名_In = '当前科室' Then 
          Select 名称 Into v_Return From 部门表 Where ID = r_Regist.执行部门id; 
        End If; 
      Else 
        If 元素名_In = '当前科室' Then 
          p_Get_Rowtype('病案主页'); 
          Select 名称 Into v_Return From 部门表 Where ID = r_Inpage.出院科室id; 
        End If; 
      End If; 
    When Instr(',紧急程度,开单科室,开单医生,开单时间,开单时间,执行科室,要求时间,医生嘱托,诊疗类别,申请项目,检查类型,部位方法,检验标本', ',' || 元素名_In) > 0 Then 
      --只查病人医嘱记录的元素 
      p_Get_Rowtype('病人医嘱记录'); 
      If 元素名_In = '紧急程度' Then 
        If r_Order.紧急标志 = 1 Then 
          v_Return := '急'; 
        End If; 
      Elsif 元素名_In = '开单科室' Then 
        Select 名称 Into v_Return From 部门表 Where ID = r_Order.开嘱科室id; 
      Elsif 元素名_In = '开单医生' Then 
        v_Return := r_Order.开嘱医生; 
      Elsif 元素名_In = '开单时间' Then 
        v_Return := To_Char(r_Order.开嘱时间, 'yyyy-mm-dd hh24:mi'); 
        v_Return := Substr(v_Return, 1, 4) || '年' || Substr(v_Return, 6, 2) || '月' || Substr(v_Return, 9, 2) || '日' || 
                    Substr(v_Return, 12, 2) || '时' || Substr(v_Return, 15, 2) || '分'; 
      Elsif 元素名_In = '执行科室' Then 
        Select 名称 Into v_Return From 部门表 Where ID = r_Order.执行科室id; 
      Elsif 元素名_In = '要求时间' Then 
        v_Return := To_Char(r_Order.开始执行时间, 'yyyy-mm-dd hh24:mi'); 
        v_Return := Substr(v_Return, 1, 4) || '年' || Substr(v_Return, 6, 2) || '月' || Substr(v_Return, 9, 2) || '日' || 
                    Substr(v_Return, 12, 2) || '时' || Substr(v_Return, 15, 2) || '分'; 
      Elsif 元素名_In = '医生嘱托' Then 
        v_Return := r_Order.医生嘱托; 
      Elsif 元素名_In = '诊疗类别' Then 
        Select 名称 Into v_Return From 诊疗项目类别 Where 编码 = r_Order.诊疗类别; 
      Elsif 元素名_In = '申请项目' Then 
        Select 操作类型 Into v_Subtype From 诊疗项目目录 Where ID = r_Order.诊疗项目id; 
        If r_Order.诊疗类别 = 'E' And v_Subtype = '6' Then 
          Select i.名称 Bulk Collect 
          Into a_Return 
          From 诊疗项目目录 I, (Select 序号, 诊疗项目id From 病人医嘱记录 Where 相关id = 医嘱id_In) A 
          Where i.Id = a.诊疗项目id 
          Order By a.序号; 
        Else 
          Select i.名称 Bulk Collect 
          Into a_Return 
          From 诊疗项目目录 I, 
               (Select 序号, 诊疗项目id 
                 From 病人医嘱记录 
                 Where ID = 医嘱id_In 
                 Union All 
                 Select 序号, 诊疗项目id 
                 From 病人医嘱记录 
                 Where 相关id = 医嘱id_In And 诊疗类别 <> 'G') A 
          Where i.Id = a.诊疗项目id 
          Group By i.名称 
          Order By Max(a.序号); 
        End If; 
        If a_Return.Count > 1 Then 
          For n_Count In 1 .. a_Return.Count Loop 
            v_Return := v_Return || ' ' || n_Count || ')' || a_Return(n_Count); 
          End Loop; 
        Else 
          v_Return := a_Return(1); 
        End If; 
        v_Return := Trim(v_Return); 
      Elsif 元素名_In = '检查类型' Then 
        Select 操作类型 Into v_Return From 诊疗项目目录 Where ID = r_Order.诊疗项目id And 类别 = 'D'; 
      Elsif 元素名_In = '部位方法' Then 
        Select 部位 || Chr(9) || 方法 Bulk Collect 
        Into a_Return 
        From (Select 标本部位 As 部位, 检查方法 As 方法 
               From 病人医嘱记录 
               Where 相关id = 医嘱id_In And 诊疗类别 = 'D' 
               Union All 
               Select r_Order.标本部位, r_Order.检查方法 
               From Dual) A, 
             (Select p.编码, p.名称 
               From 诊疗检查部位 P, 诊疗项目目录 I 
               Where p.类型 = i.操作类型 And ID = r_Order.诊疗项目id And 类别 = 'D') P 
        Where a.部位 = p.名称 
        Order By p.编码; 
        For n_Count In 1 .. a_Return.Count Loop 
          If Instr(v_Return, ' ' || Substr(a_Return(n_Count), 1, Instr(a_Return(n_Count), Chr(9)))) > 0 Then 
            v_Return := v_Return || '、' || Substr(a_Return(n_Count), Instr(a_Return(n_Count), Chr(9)) + 1); 
          Else 
            v_Return := v_Return || '  ' || a_Return(n_Count); 
          End If; 
        End Loop; 
        v_Return := Replace(v_Return, Chr(9), ':'); 
      Elsif 元素名_In = '检验标本' Then 
        v_Return := r_Order.标本部位; 
      Else 
        v_Return := ''; 
      End If; 
    Else 
      --自行查询SQL返回值的元素 
      If 元素名_In = '单位名称' Then 
        Select 内容 Into v_Return From Zlregaudit Where 项目 = '单位名称'; 
        If Instr(v_Return, ';') > 0 Then 
          v_Return := Substr(v_Return, 1, Instr(v_Return, ';') - 1); 
        End If; 
      Elsif 元素名_In = '入科时间' Then 
        If 病人来源_In = 2 Then 
          Select Count(*) 
          Into n_Times 
          From 病人变动记录 
          Where 病人id = 病人id_In And 主页id = 就诊id_In And 开始原因 = 2; 
          If n_Times = 0 Then 
            Select To_Char(开始时间, 'yyyy-mm-dd hh24:mi') 
            Into v_Return 
            From 病人变动记录 
            Where 病人id = 病人id_In And 主页id = 就诊id_In And 开始原因 = 1; 
          Else 
            Select To_Char(开始时间, 'yyyy-mm-dd hh24:mi') 
            Into v_Return 
            From 病人变动记录 
            Where 病人id = 病人id_In And 主页id = 就诊id_In And 开始原因 = 2; 
          End If; 
          v_Return := Substr(v_Return, 1, 4) || '年' || Substr(v_Return, 6, 2) || '月' || Substr(v_Return, 9, 2) || '日' || 
                      Substr(v_Return, 12, 2) || '时' || Substr(v_Return, 15, 2) || '分'; 
        End If; 
 
      Elsif 元素名_In = 'ABO' Or 元素名_In = 'RH' Then 
        Select 信息值 Into v_Return From 病人信息从表 P Where p.病人id = 病人id_In And p.信息名 = 元素名_In; 
      Elsif 元素名_In = '一次住院时间' Or 元素名_In = '二次住院时间' Or 元素名_In = '上次住院时间' Then 
        If 病人来源_In = 2 Then 
          Select To_Char(入院日期, 'yyyy-mm-dd hh24:mi') Bulk Collect 
          Into a_Return 
          From 病案主页 
          Where 病人id = 病人id_In And 主页id < 就诊id_In 
          Order By 入院日期; 
          If 元素名_In = '一次住院时间' And a_Return.Count > 0 Then 
            v_Return := a_Return(1); 
          Elsif 元素名_In = '二次住院时间' And a_Return.Count > 1 Then 
            v_Return := a_Return(2); 
          Elsif 元素名_In = '上次住院时间' And a_Return.Count > 0 Then 
            v_Return := a_Return(a_Return.Count); 
          Else 
            Return Null; 
          End If; 
          v_Return := Substr(v_Return, 1, 4) || '年' || Substr(v_Return, 6, 2) || '月' || Substr(v_Return, 9, 2) || '日' || 
                      Substr(v_Return, 12, 2) || '时' || Substr(v_Return, 15, 2) || '分'; 
        End If; 
      Elsif 元素名_In = '最后诊断' Then 
        v_Return := f_Latest_Diagnose(就诊id_In, 时间_In); 
      Elsif 元素名_In = '最后诊断ID' Then 
        v_Return := f_Last_Diagnoseid(就诊id_In); 
      Elsif 元素名_In = '门诊诊断' Then 
        v_Return := f_Diagnose(1); 
      Elsif 元素名_In = '一次住院诊断' Or 元素名_In = '二次住院诊断' Or 元素名_In = '上次住院诊断' Then 
        Select 主页id Bulk Collect 
        Into a_Return 
        From 病案主页 
        Where 病人id = 病人id_In And 主页id < 就诊id_In 
        Order By 入院日期; 
        If 元素名_In = '一次住院诊断' And a_Return.Count > 0 Then 
          n_主页id := To_Number(a_Return(1)); 
        Elsif 元素名_In = '二次住院诊断' And a_Return.Count > 1 Then 
          n_主页id := To_Number(a_Return(2)); 
        Elsif 元素名_In = '上次住院诊断' And a_Return.Count > 0 Then 
          n_主页id := To_Number(a_Return(a_Return.Count)); 
        Else 
          Return Null; 
        End If; 
        v_Return := f_Latest_Diagnose(n_主页id); 
      Elsif 元素名_In = '西医门诊诊断' Then 
        v_Return := f_Diagnose(1); 
      Elsif 元素名_In = '中医门诊诊断' Then 
        v_Return := f_Diagnose(2); 
      Elsif 元素名_In = '西医入院诊断' Then 
        v_Return := f_Diagnose(3); 
      Elsif 元素名_In = '中医入院诊断' Then 
        v_Return := f_Diagnose(4); 
      Elsif 元素名_In = '西医出院诊断' Then 
        v_Return := f_Diagnose(5); 
      Elsif 元素名_In = '西医出院主要诊断' Then 
        v_Return := f_Diagnose(6); 
      Elsif 元素名_In = '西医出院其他诊断' Then 
        v_Return := f_Diagnose(7); 
      Elsif 元素名_In = '中医出院诊断' Then 
        v_Return := f_Diagnose(8); 
      Elsif 元素名_In = '过敏药物' Then 
        Select d.药物名 Bulk Collect 
        Into a_Return 
        From 病人过敏记录 D, (Select Max(记录时间) As 时间 From 病人过敏记录 Where 病人id = 病人id_In And 结果 = 1) M 
        Where d.病人id = 病人id_In And d.结果 = 1 And d.记录时间 = m.时间; 
        For n_Count In 1 .. a_Return.Count Loop 
          v_Return := v_Return || '；' || a_Return(n_Count); 
        End Loop; 
        If v_Return Is Not Null Then 
          v_Return := Substr(v_Return, 2); 
        End If; 
      Elsif 元素名_In = '病人主诉' Then 
        v_Return := f_Latest_Epr_Content(元素名_In); 
        v_Return := Replace(Replace(Replace(v_Return, '病人主诉：'), '病人主诉:'), '病人主诉'); 
        v_Return := Replace(Replace(Replace(v_Return, '主诉：'), '主诉:'), '主诉'); 
        v_Return := Replace(Replace(Replace(v_Return, Chr(13)), Chr(10)), ' '); 
      Elsif 元素名_In = '病历摘要' Then 
        v_Return := f_Latest_Epr_Content(元素名_In); 
        If v_Return Is Null Then 
          v_Return := f_Latest_Advice_Annex(); 
        End If; 
        If v_Return Is Null Then 
          v_Return := f_Latest_Epr_Content('病人主诉'); 
          v_Return := Replace(Replace(Replace(v_Return, '病人主诉：'), '病人主诉:'), '病人主诉'); 
          v_Return := Replace(Replace(Replace(v_Return, '主诉：'), '主诉:'), '主诉'); 
        End If; 
      Elsif 元素名_In = '现病史' Or 元素名_In = '体格检查' Or 元素名_In = '辅助检查' Or 元素名_In = '专科检查' Or 元素名_In = '既往史' Then 
        v_Return := f_Latest_Epr_Content(元素名_In); 
        v_Return := Replace(Replace(Replace(v_Return, Chr(13)), Chr(10)), ' '); 
      Elsif 元素名_In = '检验类型' Then 
        Select 操作类型 
        Into v_Return 
        From 诊疗项目目录 I, 
             (Select 序号, 诊疗项目id From 病人医嘱记录 Where 相关id = 医嘱id_In And 诊疗类别 = 'C' And Rownum < 2) A 
        Where i.Id = a.诊疗项目id; 
      Elsif 元素名_In = '麻醉方式' Then 
        Select i.名称 
        Into v_Return 
        From 病人医嘱记录 A, 诊疗项目目录 I 
        Where a.诊疗项目id = i.Id And a.相关id = 医嘱id_In And a.诊疗类别 = 'G'; 
      Elsif 元素名_In = '本次医嘱' Then 
        v_Return := f_Get_Advice_Text(); 
      Elsif 元素名_In = '报到时间' Then 
        Select To_Char(Max(报到时间), 'yyyy-mm-dd hh24:mi') Into v_Return From 病人医嘱发送 Where 医嘱id = 医嘱id_In; 
        v_Return := Substr(v_Return, 1, 4) || '年' || Substr(v_Return, 6, 2) || '月' || Substr(v_Return, 9, 2) || '日' || 
                    Substr(v_Return, 12, 2) || '时' || Substr(v_Return, 15, 2) || '分'; 
      Elsif 元素名_In = '执行间' Then 
        Select Max(执行间) Into v_Return From 病人医嘱发送 Where 医嘱id = 医嘱id_In; 
      Elsif 元素名_In = '费用单号' Then 
        Select Max(记录性质 || NO) Into v_Return From 病人医嘱发送 Where 医嘱id = 医嘱id_In; 
      Elsif 元素名_In = '执行人' Then 
        Select Max(执行人) Into v_Return From 病人医嘱执行 Where 医嘱id = 医嘱id_In; 
      Elsif 元素名_In = '执行时间' Then 
        Select To_Char(Max(执行时间), 'yyyy-mm-dd hh24:mi') Into v_Return From 病人医嘱执行 Where 医嘱id = 医嘱id_In; 
        v_Return := Substr(v_Return, 1, 4) || '年' || Substr(v_Return, 6, 2) || '月' || Substr(v_Return, 9, 2) || '日' || 
                    Substr(v_Return, 12, 2) || '时' || Substr(v_Return, 15, 2) || '分'; 
      Elsif 元素名_In = '设备型号' Then 
        Select 名称 Bulk Collect 
        Into a_Return 
        From (Select a.名称 
               From (Select r.仪器id 
                      From 检验标本记录 L, 检验普通结果 R 
                      Where r.检验标本id = l.Id And l.医嘱id = 医嘱id_In 
                      Union 
                      Select l.仪器id 
                      From 检验标本记录 L 
                      Where l.医嘱id = 医嘱id_In) L, 检验仪器 A 
               Where l.仪器id = a.Id 
               Union All 
               Select 检查设备 
               From 影像检查记录 
               Where 医嘱id = 医嘱id_In); 
        For n_Count In 1 .. a_Return.Count Loop 
          v_Return := v_Return || ' ' || a_Return(n_Count); 
        End Loop; 
        v_Return := Trim(v_Return); 
 
      Elsif 元素名_In = '采样人' Then 
        Select Max(采样人) Into v_Return From 检验标本记录 Where 医嘱id = 医嘱id_In; 
      Elsif 元素名_In = '采样时间' Then 
        Select To_Char(Max(采样时间), 'yyyy-mm-dd hh24:mi') Into v_Return From 检验标本记录 Where 医嘱id = 医嘱id_In; 
      Elsif 元素名_In = '样本条码' Then 
        Select Max(样本条码) Into v_Return From 检验标本记录 Where 医嘱id = 医嘱id_In; 
      Elsif 元素名_In = '标本序号' Then 
        Select Max(标本序号) Into v_Return From 检验标本记录 Where 医嘱id = 医嘱id_In; 
      Elsif 元素名_In = '标本类型' Then 
        Select Max(标本类型) Into v_Return From 检验标本记录 Where 医嘱id = 医嘱id_In; 
      Elsif 元素名_In = '核收人' Then 
        Select Max(核收人) Into v_Return From 检验标本记录 Where 医嘱id = 医嘱id_In; 
      Elsif 元素名_In = '核收时间' Then 
        Select To_Char(Max(核收时间), 'yyyy-mm-dd hh24:mi') Into v_Return From 检验标本记录 Where 医嘱id = 医嘱id_In; 
      Elsif 元素名_In = '检验人' Then 
        Select Max(检验人) Into v_Return From 检验标本记录 Where 医嘱id = 医嘱id_In; 
      Elsif 元素名_In = '检验时间' Then 
        Select To_Char(Max(检验时间), 'yyyy-mm-dd hh24:mi') Into v_Return From 检验标本记录 Where 医嘱id = 医嘱id_In; 
      Elsif 元素名_In = '审核人' Then 
        Select Max(审核人) Into v_Return From 检验标本记录 Where 医嘱id = 医嘱id_In; 
      Elsif 元素名_In = '审核时间' Then 
        Select To_Char(Max(审核时间), 'yyyy-mm-dd hh24:mi') Into v_Return From 检验标本记录 Where 医嘱id = 医嘱id_In; 
      Elsif 元素名_In = '检验评语' Then 
        Select Max(备注) Into v_Return From 检验标本记录 Where 医嘱id = 医嘱id_In; 
      Elsif 元素名_In = '检验备注' Then 
        Select Max(检验备注) Into v_Return From 检验标本记录 Where 医嘱id = 医嘱id_In; 
      Elsif 元素名_In = '检验项目' Then 
        Select 名称 Bulk Collect 
        Into a_Return 
        From (Select i.名称 
               From 诊疗项目目录 I, 病人医嘱记录 A, 
                    (Select r.医嘱id From 检验标本记录 L, 检验项目分布 R Where r.标本id = l.Id And l.医嘱id = 医嘱id_In) L 
               Where i.Id = a.诊疗项目id And a.相关id = l.医嘱id 
               Order By a.序号); 
        For n_Count In 1 .. a_Return.Count Loop 
          v_Return := v_Return || ' ' || a_Return(n_Count); 
        End Loop; 
        v_Return := Trim(v_Return); 
 
      Elsif 元素名_In = '影像类别' Then 
        Select Max(影像类别) Into v_Return From 影像检查记录 Where 医嘱id = 医嘱id_In; 
      Elsif 元素名_In = '检查号' Then 
        Select Max(检查号) Into v_Return From 影像检查记录 Where 医嘱id = 医嘱id_In; 
      Elsif 元素名_In = '服用造影剂' Then 
        Select 造影剂 || '  用量:' || 用量 || '  浓度:' || 浓度 Into v_Return From 服用造影剂 Where 医嘱id = 医嘱id_In; 
 
      Elsif 元素名_In = '手术规模' Or 元素名_In = '手术执行间' Or 元素名_In = '手术麻醉质量' Or 元素名_In = '手术麻醉方式' Or 元素名_In = '手术开始时间' Or 
            元素名_In = '手术结束时间' Or 元素名_In = '麻醉开始时间' Or 元素名_In = '麻醉结束时间' Or 元素名_In = '输氧开始时间' Or 元素名_In = '输氧结束时间' Or 
            元素名_In = '主刀医生' Or 元素名_In = '助手医生' Or 元素名_In = '麻醉医生' Or 元素名_In = '洗手护士' Or 元素名_In = '巡回护士' Or 
            元素名_In = '其他手术人员' Or 元素名_In = '拟行主手术' Or 元素名_In = '拟行附手术' Or 元素名_In = '已行主手术' Or 元素名_In = '已行附手术' Or 
            元素名_In = '术前主诊断' Or 元素名_In = '术前次诊断' Or 元素名_In = '术后主诊断' Or 元素名_In = '术后次诊断' Or 元素名_In = '输液总量' Or 
            元素名_In = '拟施手术时间' Or 元素名_In = '拟施麻醉方式' Then 
 
        --这些要素从手麻子系统中获取 
 
        n_Have := 0; 
        Begin 
          Select 1 Into n_Have From zlSystems Where Floor(编号 / 100) = 24; 
        Exception 
          When Others Then 
            Null; 
        End; 
 
        If n_Have = 1 Then 
          If 医嘱id_In Is Null Then 
            v_Sql := 'Select Zl24_Replace_Element_Value(:v1,:v2,:v3,:v4,Null) From Dual'; 
            Begin 
              Execute Immediate v_Sql 
                Into v_Return 
                Using 元素名_In, Trim(To_Char(病人id_In)), Trim(To_Char(就诊id_In)), Trim(To_Char(病人来源_In)); 
            Exception 
              When Others Then 
                Null; 
            End; 
          Else 
            v_Sql := 'Select Zl24_Replace_Element_Value(:v1,:v2,:v3,:v4,:v5) From Dual'; 
            Begin 
              Execute Immediate v_Sql 
                Into v_Return 
                Using 元素名_In, Trim(To_Char(病人id_In)), Trim(To_Char(就诊id_In)), Trim(To_Char(病人来源_In)), Trim(To_Char(医嘱id_In)); 
            Exception 
              When Others Then 
                Null; 
            End; 
          End If; 
        End If; 
 
      Else 
        v_Sql := 'Select Zl_Replace_Element_Value_User(:v1,:v2,:v3,:v4,:v5,:v6) From Dual'; 
        Begin 
          Execute Immediate v_Sql 
            Into v_Return 
            Using 元素名_In, 病人id_In, 就诊id_In, 病人来源_In, 医嘱id_In, 婴儿_In; 
        Exception 
          When Others Then 
            Null; 
        End; 
      End If; 
  End Case; 
 
  Return Trim(v_Return); 
Exception 
  When Others Then 
    Return Null; 
End Zl_Replace_Element_Value;
/

