create Function Zl_Rollingcurtain_Lastdate 
( 
  收款员_In 人员收缴记录.收款员%Type, 
  类别_In   人员收缴记录.类别%Type 
) Return Date Is 
  d_规零时间 Date; 
  d_终止时间 Date; 
 
Begin 
  -------------------------------------------------------------------------------- 
  --功能:获取指定用户的最后一次有效的轧帐时间 
  --入参:类别_In:0-所有类别(按全额轧帐),1-收费,2-预交,3-结帐,4-挂号,5-就诊卡 
  --     收款员_IN:具体的收费人员 
  --获取规则: 
  --    1.如果当前按指定类别轧帐时,则按下规则处理(以终止时间为准): 
  --      1) 如果存在有效的轧帐记录时 
  --          a)如果当前轧帐人员不存在所有类别的轧帐记录的,则以最后一次轧帐时间为准 
  --          b)如果当前轧帐人员存在所有类别的轧帐记录且最后一次轧帐记录的终止时间>当前类别的最后一次轧帐记录的终卡时间的,则以所有类别的最后一次轧帐记录的终止时间为准 
  --          c)如果当前轧帐人员存在所有类别的轧帐记录且最后一次轧帐记录的终止时间<当前类别的最后一次轧帐记录的终卡时间的,则以当前类别的最后一次轧帐记录的终卡时间为准 
  --      2)如果不存在有效轧帐记录时 
  --          a)如果当前轧帐人员存在按所有类别轧帐的有效记录时,则以最后一次轧帐记录的终止时间为准 
  --          b)如果不存在按所有类别轧帐的有效记录时,按下面的3以下规则处理 
  --    2.如果当前按所有类别轧帐时,则按以下规则处理 
  --          a)如果存在按所有类别轧帐的有效记录时,则以最后一次轧帐记录的终止时间为准 
  --          b)如果不存在按所有类别轧帐的有效记录时,按下面的3以下规则处理 
  --    3.如果存在轧帐规零记录,则以轧帐规零记录的登记时间为准 
  --    4.未轧过的,缺省为领取备用金时间 
  --    5.如果未领用备用金的,返回NULL,由界面处理(缺省时间为当前时间-1个月的且允许更改上次转帐时间) 
  -------------------------------------------------------------------------------- 
  If 类别_In = 22 Or 类别_In = 21 Then 
    Select Max(Decode(记录性质, 6, 登记时间, Null)), Max(Decode(记录性质, 1, 终止时间, Null)) 
    Into d_规零时间, d_终止时间 
    From 人员收缴记录 A 
    Where 收款员 = 收款员_In And 作废时间 Is Null And 
          (记录性质 = 6 Or ((a.记录性质 = 1 And Nvl(类别, 0) = 2) Or (a.记录性质 = 1 And Nvl(类别, 0) = 0) Or 
          (a.记录性质 = 1 And Nvl(类别, 0) = Nvl(类别_In, 0)))); 
  Else 
    Select Max(Decode(记录性质, 6, 登记时间, Null)), Max(Decode(记录性质, 1, 终止时间, Null)) 
    Into d_规零时间, d_终止时间 
    From 人员收缴记录 A 
    Where 收款员 = 收款员_In And 作废时间 Is Null And 
          (记录性质 = 6 Or ((a.记录性质 = 1 And Nvl(类别, 0) = 0) Or (a.记录性质 = 1 And Nvl(类别, 0) = Nvl(类别_In, 0)))); 
  End If; 
 
  If d_终止时间 Is Not Null Then 
    Return d_终止时间; 
  End If; 
  If d_规零时间 Is Not Null Then 
    Return d_规零时间; 
  End If; 
 
  --取备用金的时间 
  Select Min(领用时间) 
  Into d_终止时间 
  From 人员暂存记录 
  Where 收款员 = 收款员_In And (记录性质 = 1 Or 记录性质 = 11) And 收回时间 Is Null; 
  If d_终止时间 Is Not Null Then 
    Return d_终止时间; 
  End If; 
 
  --当前时间减少1个月 
  If d_终止时间 Is Not Null Then 
    Return d_终止时间; 
  End If; 
 
  Return Null; 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zl_Rollingcurtain_Lastdate;
/

