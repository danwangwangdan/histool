create function zl_Split
(
  Expression in varchar2,  --需要分割字符串
  Delimiter in varchar2,   --分割字符串
  Mimit  in number:=-1   --分割位
)
--功能：通过函数实现字符串分割，根据传入分割位实现分割字符。
--参数：Expression【需要分割字符串】、Delimiter【分割字符】、Mimit【分割后的子串数】
--返回：返回分割位置的字符串
--程序：谢荣
--日期：2010-12-24
--修改：
--修改日期
return varchar2      --返回分割字符串
as
  intMimit number;         --Mimit
  strExpression varchar2(4000);
  strDelimiter varchar2(4000);
  strResult    varchar2(4000);
  strTmp       varchar2(4000);
  intTmp       number(3);
  v_Error    Varchar2(255);
  Err_Custom Exception;
BEGIN
  strExpression := Expression;
  strDelimiter := Delimiter;
  intMimit := Mimit;
  strTmp:=strExpression || strDelimiter;
  intTmp:=0;
  WHILE intTmp<intMimit loop
    IF instr(strTmp, strDelimiter) >0 then
      strTmp := substr(strtmp,lengthb(strDelimiter)+instr(strtmp, strDelimiter));
    else
      strTmp:='';
      v_Error := '下标值越界！';
      --Raise Err_Custom;
    end if;
    intTmp:=intTmp+1;
  end loop;
  strTmp := substr(strtmp,1,instr(strtmp, strDelimiter)-1);
  strResult:=strTmp;
  IF Mimit = -1 then
     strResult := Expression;
  End if;
  return strResult;
Exception
  When Err_Custom Then
    Raise_Application_Error(-20999, '[ZLSOFT]' || v_Error || '[ZLSOFT]');
  When Others Then
    Zl_Errorcenter(Sqlcode, Sqlerrm);
END;


/

