create Function       Zl_手术添加
(
	手术名称_In  Varchar2
) Return Varchar2 As
	v_Return Varchar2(50) := '手术名称添加成功！';
  v_诊疗项目ID Number;
  v_诊疗项目编码 Varchar2(20);
	Pragma Autonomous_Transaction;
Begin
  Select 诊疗项目目录_ID.Nextval Into v_诊疗项目ID From dual;
  Select nvl(max(编码),'700001')+1 Into v_诊疗项目编码 From 诊疗项目目录 Where 类别 >= 'A' and 编码 like '7%';
  Insert Into 诊疗项目目录 values('F',1081,v_诊疗项目ID,v_诊疗项目编码,手术名称_In,Null,'次',3,Null,1,0,1,0,1,0,4,3,Null,Null,Null,Sysdate,to_date('3000-1-1','yyyy-mm-dd'),Null,Null,Null,Null,Null,Null,Null);
  Insert Into 诊疗执行科室 values(v_诊疗项目ID,Null,Null,138);
  Insert Into 诊疗项目别名 values(v_诊疗项目ID,手术名称_In,1,zlspellcode(手术名称_In),1);
  Insert Into 诊疗项目别名 values(v_诊疗项目ID,手术名称_In,1,zlwbcode(手术名称_In),2);
  Commit;
  Return(v_Return);
Exception
	When Others Then
    v_Return := '手术名称添加失败！';
		Return(v_Return);
End Zl_手术添加;
/

