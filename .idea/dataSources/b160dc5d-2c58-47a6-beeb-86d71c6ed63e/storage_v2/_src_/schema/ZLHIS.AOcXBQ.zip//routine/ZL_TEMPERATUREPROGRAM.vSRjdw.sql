create Function Zl_Temperatureprogram 
( 
  文件id_In   In 病人护理文件.Id%Type, 
  科室id_In   In 部门表.Id%Type, 
  项目序号_In In 病人护理明细.项目序号%Type, 
  时间_In     In Date := Sysdate 
) Return Number --返回1说明此项目同步，0说明此项目不同步 
 As 
  v_Sql      Varchar2(1000); 
  v_Age      Varchar2(100); 
  n_Age      Number(5, 2); 
  n_Synchro  Number(1) := 1; 
  d_出生日期 Date; 
  d_时间     Date; 
  v_年龄     病案主页.年龄%Type; 
  n_病人id   病人护理文件.病人id%Type; 
  n_主页id   病人护理文件.主页id%Type; 
  n_婴儿     病人护理文件.婴儿%Type; 
  n_护理等级 Number(3); 
  d_开始时间 病人变动记录.开始时间%Type; 
  d_终止时间 病人变动记录.终止时间%Type; 
 
  Cursor Cur_Nursitem Is 
    Select 护理等级, 
           Replace(Replace(Replace(Replace(Replace(Replace(Replace(年龄范围, '小于等于', '<='), '小于', '<'), 
                                                    '大于等于', 
                                                    '>='), 
                                            '大于', 
                                            '>'), 
                                    '并且', 
                                    ' AND '), 
                            '或者', 
                            ' OR '), 
                    Chr(9), 
                    '') 年龄范围, 禁用项目, 适用科室 
    From 体温同步项目 
    Where (护理等级 = -1 Or 护理等级 = n_护理等级) And Instr(';' || 禁用项目 || ';', ';' || 项目序号_In || ';', 1) > 0 And 
          (Nvl(适用科室, '-1') = '-1' Or Instr(';' || 适用科室 || ';', ';' || 科室id_In || ';', 1) > 0); 
 
  v_Error Varchar2(255); 
  Err_Custom Exception; 
Begin 
  --根据文件ID提取病人ID、主页ID、婴儿 
  Begin 
    Select Max(a.病人id) 病人id, Max(a.主页id) 主页id, Max(Nvl(a.婴儿, 0)) 婴儿, Min(b.开始时间) 开始时间, Max(Nvl(b.终止时间, Sysdate)) 终止时间 
    Into n_病人id, n_主页id, n_婴儿, d_开始时间, d_终止时间 
    From 病人护理文件 a, 病人变动记录 b 
    Where a.病人id = b.病人id And a.主页id = b.主页id And a.Id = 文件id_In And b.开始时间 Is Not Null; 
  Exception 
    When Others Then 
      n_病人id := 0; 
  End; 
  If n_病人id = 0 Then 
    v_Error := '文件ID[' || 文件id_In || ']错误，没有找到任何信息！'; 
    Raise Err_Custom; 
  End If; 
  --检查时间是否在病人变动时间之内，如果不在重新赋值 
  d_时间 := 时间_In; 
  If d_时间 < d_开始时间 Then 
    d_时间 := d_开始时间; 
  End If; 
  If d_时间 > d_终止时间 Then 
    d_时间 := d_终止时间; 
  End If; 
  --提取病人的护理等级 
  Select Zl_Patittendgrade(n_病人id, n_主页id, d_时间) Into n_护理等级 From Dual; 
  --提取病人的年龄(以入院时的年龄为准) 
  Select 年龄 Into v_年龄 From 病案主页 Where 病人id = n_病人id And 主页id = n_主页id; 
  If n_婴儿 <> 0 Then 
    Begin 
      Select Nvl(出生时间, Sysdate) 
      Into d_出生日期 
      From 病人新生儿记录 
      Where 病人id = n_病人id And 主页id = n_主页id And 序号 = n_婴儿; 
    Exception 
      When Others Then 
        d_出生日期 := Null; 
    End; 
    If d_出生日期 Is Not Null Then 
      v_年龄 := Zl_Age_Calc(0, d_出生日期, Sysdate); 
    End If; 
  End If; 
 
  n_Age := 0; 
  --开始分解年龄，获取有多少岁 
  Begin 
    If Replace(Translate(v_年龄, '0123456789.', '0'), '0', '') Is Null Then 
      n_Age := Round(v_年龄, 2); 
    Else 
      If Instr(v_年龄, '周岁', 1) > 0 Then 
        n_Age := Round(Substr(v_年龄, 1, Instr(v_年龄, '周岁', 1) - 1), 2); 
        If Instr(v_年龄, '周岁', 1) + 1 = Length(v_年龄) Then 
          v_年龄 := ''; 
        Else 
          v_年龄 := Substr(v_年龄, Instr(v_年龄, '周岁', 1) + 2); 
        End If; 
      End If; 
      If Instr(v_年龄, '岁', 1) > 0 Then 
        n_Age := Round(Substr(v_年龄, 1, Instr(v_年龄, '岁', 1) - 1), 2); 
        If Instr(v_年龄, '岁', 1) = Length(v_年龄) Then 
          v_年龄 := ''; 
        Else 
          v_年龄 := Substr(v_年龄, Instr(v_年龄, '岁', 1) + 1); 
        End If; 
      End If; 
      If Instr(v_年龄, '月', 1) > 0 Then 
        n_Age := Round(n_Age + Round(Substr(v_年龄, 1, Instr(v_年龄, '月', 1) - 1) / 12, 2), 2); 
        If Instr(v_年龄, '月', 1) = Length(v_年龄) Then 
          v_年龄 := ''; 
        Else 
          v_年龄 := Substr(v_年龄, Instr(v_年龄, '月', 1) + 1); 
        End If; 
      End If; 
      If Instr(v_年龄, '天', 1) > 0 Then 
        n_Age := Round(n_Age + 0.01, 2); 
      End If; 
    End If; 
  Exception 
    When Others Then 
      n_Age := 0; 
  End; 
 
  For Row_Nursitem In Cur_Nursitem Loop 
    v_Age := n_Age || Replace(Replace(Row_Nursitem.年龄范围, ' AND ', ' AND ' || n_Age), ' OR ', ' OR ' || n_Age); 
    --DBMS_OUTPUT.PUT_LINE(V_AGE); 
    v_Sql := 'SELECT 0  FROM  DUAL WHERE ' || v_Age; 
    Begin 
      Execute Immediate v_Sql 
        Into n_Synchro; 
    Exception 
      When Others Then 
        n_Synchro := 1; 
    End; 
    --DBMS_OUTPUT.PUT_LINE(N_SYNCHRO); 
    --如果检查到符合条件不同步的项目直接返回 
    If n_Synchro = 0 Then 
      Return(n_Synchro); 
    End If; 
  End Loop; 
 
  Return(n_Synchro); 
Exception 
  When Err_Custom Then 
    Raise_Application_Error(-20101, '[ZLSOFT]' || v_Error || '[ZLSOFT]'); 
  When Others Then 
    Zl_Errorcenter(Sqlcode, Sqlerrm); 
End Zl_Temperatureprogram;
/

