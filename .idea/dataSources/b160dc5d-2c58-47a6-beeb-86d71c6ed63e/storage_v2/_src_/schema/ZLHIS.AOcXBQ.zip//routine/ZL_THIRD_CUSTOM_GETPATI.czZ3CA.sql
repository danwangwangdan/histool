create Function Zl_Third_Custom_Getpati 
( 
  卡类别_In Varchar2, 
  卡号_In   Varchar2 
) Return Number As 
  -------------------------------------------------------------------------------------------------- 
  --功能:获取病人ID(用户自定义） 
  --入参: 
  --  卡类别_In : 卡类别名称 
  --  卡号_In   : 卡号 
  --返回:病人ID 
  -------------------------------------------------------------------------------------------------- 
  v_Temp    Varchar2(32767); 
  v_Err_Msg Varchar2(200); 
  Err_Item Exception; 
Begin 
  Return 0; 
Exception 
  When Err_Item Then 
    v_Temp := '[ZLSOFT]' || v_Err_Msg || '[ZLSOFT]'; 
    Raise_Application_Error(-20101, v_Temp); 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End;
/

