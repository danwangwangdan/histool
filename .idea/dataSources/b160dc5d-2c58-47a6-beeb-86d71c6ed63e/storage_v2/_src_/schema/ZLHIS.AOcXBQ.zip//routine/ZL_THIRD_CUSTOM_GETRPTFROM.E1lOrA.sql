create Function Zl_Third_Custom_Getrptfrom(医嘱id_In In 病人医嘱记录.Id%Type) Return Varchar2 As 
  ---------------------------------------- 
  --功能：返回当前医嘱对应的诊疗项目是否外检项目 
  --入参：医嘱ID 
  --出参：<BGLY>标志<BGLY><BGLYSM>提醒信息</BGLYSM> 
  --   标志：1-HIS项目，2-外检项目 
  --   提醒信息：自定义文字说明，如取报告的地址，提示信息等 
  --说明：如果传入的医嘱ID为组医嘱ID，只要该组医嘱下有1个医嘱为外检项目，则整个医嘱全部为外检项目。 
  ---------------------------------------- 
  v_Return  Varchar2(200); 
  v_Temp    Varchar2(32767); 
  v_Err_Msg Varchar2(200); 
  Err_Item Exception; 
Begin 
  v_Return := '<BGLY>1</BGLY><BGLYSM></BGLYSM>'; --医院项目返回内容 
  Return(v_Return); 
Exception 
  When Err_Item Then 
    v_Temp := '[ZLSOFT]' || v_Err_Msg || '[ZLSOFT]'; 
    Raise_Application_Error(-20101, v_Temp); 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zl_Third_Custom_Getrptfrom;
/

