create Function Zl_Third_Custom_Rptlimit 
( 
  病人id_In 病人信息.病人id%Type, 
  医嘱id_In 病人医嘱记录.Id%Type 
) Return Varchar2 As 
 
  ---------------------------------------------------- 
  --功能:设置不允许查看的报告 
  --入参:病人ID 
  --     医嘱ID，如果是一组医嘱，则传入组医嘱ID（即相关ID） 
  --通过医嘱ID，判断组医嘱中是否有不允许查看报告的项目 
  --返回值:<JZBG></JZBG>    //禁止显示报告。0-允许，1-禁止 
  --       <JZTS></JZTS>    //禁止提示文字。对于禁止查看的报告，可返回用于提示病人的文字信息 
  ---------------------------------------------------- 
  v_Tmp     Varchar2(100); 
  v_Temp    Varchar2(32767); 
  v_Err_Msg Varchar2(200); 
  Err_Item Exception; 
Begin 
  v_Tmp := '<JZBG>0</JZBG><JZTS></JZTS>'; 
  Return(v_Tmp); 
Exception 
  When Err_Item Then 
    v_Temp := '[ZLSOFT]' || v_Err_Msg || '[ZLSOFT]'; 
    Raise_Application_Error(-20101, v_Temp); 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zl_Third_Custom_Rptlimit;
/

