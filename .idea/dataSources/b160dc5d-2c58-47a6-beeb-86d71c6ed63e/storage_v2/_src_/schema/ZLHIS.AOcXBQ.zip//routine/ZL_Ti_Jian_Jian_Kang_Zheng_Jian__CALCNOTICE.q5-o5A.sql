create Function Zl_体检健康证件_Calcnotice 
( 
  任务id_In In 体检任务人员.任务id%Type, 
  病人id_In In 体检任务人员.病人id%Type 
) 
 Return VarChar2 
 Is 
  Cursor c_Rules Is 
    Select c.Id, b.体检规则id, b.规则组号, b.性别限制, b.婚姻状况, b.年龄上限, b.年龄下限, b.体检指标id, b.判断条件,b.取值公式, 
           b.指标结果, c.名称 As 指标项目, c.正常结果, 
           Decode(c.类型, 1, '文本', 2, '数值', 3, '日期', 4, '逻辑') As 类型, c.单位, '规则' As 图标, 
           Decode(c.撤档时间, Null, 0, 255) As 前景色 
    From 体检规则记录 a, 体检规则内容 b, 体检指标目录 c 
    Where a.规则性质 = 4 And a.Id = b.体检规则id And b.体检指标id = c.Id 
    Order By b.规则组号; 
 
  v_Sql            Varchar2(2000); 
  v_Sqlgroup       Varchar2(2000); 
  v_指标结果       体检规则内容.指标结果%Type; 
  v_正常结果       体检指标目录.正常结果%Type; 
  v_报警           体检任务结果.报警%Type; 
  v_Agenumberbegin Varchar2(20); 
  v_Agenumberend   Varchar2(20); 
  n_Have           Number(1) := 0; 
  v_规则组号       Varchar2(20); 
  v_ResultField  Varchar2(100); 
 
  Function Exexsql(v_Groupsql Varchar2) Return Number Is 
    v_Sql Varchar2(2000); 
  Begin 
    v_Sql := v_Groupsql; 
    If v_Sql Is Not Null Then 
      v_Sql := 'With t As (Select :3 As 任务id,:4 As 病人id From Dual) Select 清单id From (' || v_Sql || ')'; 
      v_Sql := 'select Count(*) as 超限 from 体检任务发送 x Where x.任务id =:1 And x.病人id=:2 And Nvl(x.提醒状态,0) In (0,1) And x.清单id In (' || v_Sql || ')'; 
      v_Sql := v_Sql || 
               ' And Exists (Select 1 From 体检任务人员 Where 任务id =:5 And 病人id=:6 And 体检状态=3 And 总检状态=3)'; 
 
      Execute Immediate v_Sql Into n_Have 
        Using 任务id_In, 病人id_In, 任务id_In, 病人id_In, 任务id_In, 病人id_In; 
    End If; 
 
    Return n_Have; 
  End; 
 
  Function Getagedays(v_年龄 In 病人信息.年龄%Type) Return Varchar2 Is 
    v_Tmp       Varchar2(50); 
    v_Agenumber Varchar2(50); 
    v_Ageunit   Varchar2(10); 
  Begin 
 
    If v_年龄 Is Null Or v_年龄 = '岁' Then 
      Return Null; 
    End If; 
 
    If Instr(v_年龄, '岁') > 0 Then 
 
      If Instr(v_年龄, '岁') = Length(v_年龄) Then 
        v_Tmp       := Substr(v_年龄, 1, Instr(v_年龄, '岁') - 1); 
        v_Agenumber := v_Tmp; 
        v_Ageunit   := '岁'; 
      Else 
        v_Agenumber := v_年龄; 
        v_Ageunit   := Null; 
      End If; 
 
    Elsif Instr(v_年龄, '月') > 0 Then 
 
      If Instr(v_年龄, '月') = Length(v_年龄) Then 
        v_Tmp       := Substr(v_年龄, 1, Instr(v_年龄, '月') - 1); 
        v_Agenumber := v_Tmp; 
        v_Ageunit   := '月'; 
      Else 
        v_Agenumber := v_年龄; 
        v_Ageunit   := Null; 
      End If; 
 
    Elsif Instr(v_年龄, '天') > 0 Then 
      If Instr(v_年龄, '天') = Length(v_年龄) Then 
        v_Tmp       := Substr(v_年龄, 1, Instr(v_年龄, '天') - 1); 
        v_Agenumber := v_Tmp; 
        v_Ageunit   := '天'; 
      Else 
        v_Agenumber := v_年龄; 
        v_Ageunit   := Null; 
      End If; 
    Else 
      v_Agenumber := Trim(To_Char(Zl_To_Number(v_年龄))); 
      v_Ageunit   := '岁'; 
    End If; 
 
    If v_Ageunit = '月' Then 
      v_Agenumber := Trim(To_Char(Zl_To_Number(v_Agenumber) * 30)); 
    Elsif v_Ageunit = '岁' Then 
      v_Agenumber := Trim(To_Char(Zl_To_Number(v_Agenumber) * 365)); 
    End If; 
 
    Return v_Agenumber; 
 
  Exception 
    When Others Then 
      Return Null; 
  End Getagedays; 
 
Begin 
 
  --首先检查病人是否总检 
  Select Nvl(Max(1), 0) 
  Into n_Have 
  From 体检任务人员 
  Where 任务id = 任务id_In And 病人id = 病人id_In And 体检状态 = 3 And 总检状态 =3; 
  If n_Have = 1 Then 
    For r_Rule In c_Rules Loop 
 
      If v_规则组号 <> r_Rule.规则组号 Or v_规则组号 Is Null Then 
 
        If v_Sqlgroup Is Not Null Then 
 
          v_Sql := '(' || v_Sqlgroup || ')'; 
 
          If Exexsql(v_Sql)=1 Then 
             v_Sqlgroup := ''; 
          End If; 
 
 
          v_Sqlgroup := ''; 
        End If; 
 
        v_规则组号 := r_Rule.规则组号; 
        v_Sqlgroup := ''; 
      End If; 
 
      If v_Sqlgroup Is Not Null Then 
        v_Sqlgroup := v_Sqlgroup || Chr(10) || Chr(13) || 'Intersect' || Chr(10) || Chr(13); 
      End If; 
 
      v_Sqlgroup := v_Sqlgroup || 
                    'Select a.清单id From t,体检任务结果 a,病人信息 b Where t.任务id=a.任务id And t.病人id=a.病人id And a.病人id=b.病人id And a.体检指标id=' || 
                    Trim(To_Char(r_Rule.体检指标id)) || ' '; 
 
      v_指标结果 := r_Rule.指标结果; 
      v_正常结果 := r_Rule.正常结果; 
      v_报警     := Null; 
 
      If v_指标结果 = '[最低值]' Then 
        If v_正常结果 Is Not Null Then 
          v_指标结果 := Zl_To_Number(Trim(Substr(v_正常结果, 1, Instr(v_正常结果, '～') - 1))); 
        End If; 
      Elsif v_指标结果 = '[最高值]' Then 
        If v_正常结果 Is Not Null Then 
          v_指标结果 := Zl_To_Number(Trim(Substr(v_正常结果, Instr(v_正常结果, '～') + 1, 100))); 
        End If; 
      Elsif v_指标结果 = '[偏低]' Then 
        v_报警 := '偏低'; 
      Elsif v_指标结果 = '[偏高]' Then 
        v_报警 := '偏高'; 
      Elsif v_指标结果 = '[异常]' Then 
        v_报警 := '异常'; 
      End If; 
 
      If r_Rule.取值公式 Is Not Null Then 
 
        v_ResultField:=Upper(r_Rule.取值公式); 
        v_ResultField:=Replace(v_ResultField,'[R]','a.结果'); 
 
      Else 
        v_ResultField:='a.结果'; 
      End If; 
 
 
 
      If r_Rule.类型 = '文本' Then 
 
        If r_Rule.判断条件 = '等于' Then 
          If v_报警 Is Not Null Then 
            v_Sqlgroup := v_Sqlgroup || ' And a.报警 = ''' || v_报警 || ''''; 
          Else 
            v_Sqlgroup := v_Sqlgroup || ' And '||v_ResultField||' = ''' || v_指标结果 || ''''; 
          End If; 
        Elsif r_Rule.判断条件 = '大于' Then 
          v_Sqlgroup := v_Sqlgroup || ' And Lpad('||v_ResultField||',50,'' '') > Lpad(''' || v_指标结果 || ''',50,'' '')'; 
        Elsif r_Rule.判断条件 = '小于' Then 
          v_Sqlgroup := v_Sqlgroup || ' And Lpad('||v_ResultField||',50,'' '') < Lpad(''' || v_指标结果 || ''',50,'' '')'; 
        Elsif r_Rule.判断条件 = '大于等于' Then 
          v_Sqlgroup := v_Sqlgroup || ' And Lpad('||v_ResultField||',50,'' '') >= Lpad(''' || v_指标结果 || ''',50,'' '')'; 
        Elsif r_Rule.判断条件 = '小于等于' Then 
          v_Sqlgroup := v_Sqlgroup || ' And Lpad('||v_ResultField||',50,'' '') <= Lpad(''' || v_指标结果 || ''',50,'' '')'; 
        Elsif r_Rule.判断条件 = '不等于' Then 
          v_Sqlgroup := v_Sqlgroup || ' And Lpad('||v_ResultField||',50,'' '') <> Lpad(''' || v_指标结果 || ''',50,'' '')'; 
        Elsif r_Rule.判断条件 = '包含' Then 
          v_Sqlgroup := v_Sqlgroup || ' And '||v_ResultField||' Like ''%' || v_指标结果 || '%'''; 
        End If; 
 
      Elsif r_Rule.类型 = '数值' Then 
 
        If v_指标结果 Is Null Then 
          v_指标结果:='0'; 
        End If; 
 
        If r_Rule.判断条件 = '等于' Then 
          If v_报警 Is Not Null Then 
            v_Sqlgroup := v_Sqlgroup || ' And a.报警 = ''' || v_报警 || ''''; 
          Else 
            v_Sqlgroup := v_Sqlgroup || ' And zl_To_Number('||v_ResultField||') = ' || To_Char(Zl_To_Number(v_指标结果)); 
          End If; 
        Elsif r_Rule.判断条件 = '大于' Then 
          v_Sqlgroup := v_Sqlgroup || ' And zl_To_Number('||v_ResultField||') >' || To_Char(Zl_To_Number(v_指标结果)); 
        Elsif r_Rule.判断条件 = '小于' Then 
          v_Sqlgroup := v_Sqlgroup || ' And zl_To_Number('||v_ResultField||') < ' || To_Char(Zl_To_Number(v_指标结果)); 
        Elsif r_Rule.判断条件 = '大于等于' Then 
          v_Sqlgroup := v_Sqlgroup || ' And zl_To_Number('||v_ResultField||') >= ' || To_Char(Zl_To_Number(v_指标结果)); 
        Elsif r_Rule.判断条件 = '小于等于' Then 
          v_Sqlgroup := v_Sqlgroup || ' And zl_To_Number('||v_ResultField||') <= ' || To_Char(Zl_To_Number(v_指标结果)); 
        Elsif r_Rule.判断条件 = '不等于' Then 
          v_Sqlgroup := v_Sqlgroup || ' And zl_To_Number('||v_ResultField||') <> ' || To_Char(Zl_To_Number(v_指标结果)); 
        Elsif r_Rule.判断条件 = '在范围内' Then 
          v_Sqlgroup := v_Sqlgroup || ' And zl_To_Number('||v_ResultField||') Between ' || 
                        Trim(Substr(v_指标结果, 1, Instr(v_指标结果, '至') - 1)) || ' And ' || 
                        Trim(Substr(v_指标结果, Instr(v_指标结果, '至') + 1, 100)); 
        End If; 
 
      Elsif r_Rule.类型 = '逻辑' Then 
 
        If r_Rule.判断条件 = '等于' Then 
          v_Sqlgroup := v_Sqlgroup || ' And zl_To_Number('||v_ResultField||') = ''' || v_指标结果 || ''''; 
        Elsif r_Rule.判断条件 = '不等于' Then 
          v_Sqlgroup := v_Sqlgroup || ' And '||v_ResultField||' <> ''' || v_指标结果 || ''''; 
        Elsif r_Rule.判断条件 = '包含' Then 
          v_Sqlgroup := v_Sqlgroup || ' And '||v_ResultField||' Like ''%' || v_指标结果 || '%'''; 
        End If; 
 
      End If; 
 
      If r_Rule.性别限制 Is Not Null Then 
        v_Sqlgroup := v_Sqlgroup || ' And Instr(b.性别,''' || r_Rule.性别限制 || ''')>0'; 
      End If; 
 
      If r_Rule.婚姻状况 Is Not Null Then 
        v_Sqlgroup := v_Sqlgroup || ' And Instr(b.婚姻状况,''' || r_Rule.婚姻状况 || ''')>0'; 
      End If; 
 
      If r_Rule.年龄上限 Is Not Null And r_Rule.年龄下限 Is Not Null Then 
 
        v_Agenumberbegin := Getagedays(r_Rule.年龄上限); 
        v_Agenumberend   := Getagedays(r_Rule.年龄下限); 
 
        v_Sqlgroup := v_Sqlgroup || ' And (Sysdate-b.出生日期) Between ' || v_Agenumberbegin || ' And ' || 
                      v_Agenumberend; 
 
      Elsif r_Rule.年龄上限 Is Not Null Then 
 
        v_Agenumberbegin := Getagedays(r_Rule.年龄上限); 
        v_Sqlgroup       := v_Sqlgroup || ' And (Sysdate-b.出生日期) >= ' || v_Agenumberbegin; 
 
      Elsif r_Rule.年龄下限 Is Not Null Then 
 
        v_Agenumberend := Getagedays(r_Rule.年龄下限); 
        v_Sqlgroup     := v_Sqlgroup || ' And (Sysdate-b.出生日期) <= ' || v_Agenumberend; 
 
      End If; 
 
    End Loop; 
 
    If v_Sqlgroup Is Not Null Then 
 
      v_Sql := '(' || v_Sqlgroup || ')'; 
 
      If Exexsql(v_Sql) = 1 Then 
        Return 1; 
      End If; 
 
      v_Sqlgroup := ''; 
 
    End If; 
    Return 0; 
  Else 
    Return 1; 
  End If; 
Exception 
  When Others Then 
    Return 0; 
End Zl_体检健康证件_Calcnotice;
/

