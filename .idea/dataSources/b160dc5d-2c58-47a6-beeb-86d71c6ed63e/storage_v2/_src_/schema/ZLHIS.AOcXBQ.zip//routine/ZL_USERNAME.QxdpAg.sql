create Function Zl_Username Return Varchar2 Is 
--功能:获取当前用户的姓名 
  v_Name 人员表.姓名%Type; 
  v_Temp Varchar2(255); 
Begin 
  --操作员信息:;人员id,人员编号,人员姓名 
  v_Temp := Zl_Identity(1); 
  If Nvl(v_Temp, '0') = '0' Or v_Temp = '' Then 
    v_Name := ''; 
  Else 
    v_Temp := Substr(v_Temp, Instr(v_Temp, ';') + 1); 
    v_Temp := Substr(v_Temp, Instr(v_Temp, ',') + 1); 
    v_Name := Substr(v_Temp, Instr(v_Temp, ',') + 1); 
  End If; 
  Return v_Name; 
End;
/

