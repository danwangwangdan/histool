create Function Zl_Val(Vstr In Varchar2) Return Number Is 
    Result Number(16, 6); 
    Intbit Number(8); 
    Strnum Varchar(10); 
  Begin 
    Strnum := ''; 
    For Intbit In 1 .. 10 Loop 
      If Instr('0123456789.', Substr(Vstr, Intbit, 1)) = 0 Then 
        Exit; 
      End If; 
      Strnum := Strnum || Substr(Vstr, Intbit, 1); 
      Null; 
    End Loop; 
    Result := To_Number(Strnum); 
    Return(Result); 
End Zl_Val;
/

