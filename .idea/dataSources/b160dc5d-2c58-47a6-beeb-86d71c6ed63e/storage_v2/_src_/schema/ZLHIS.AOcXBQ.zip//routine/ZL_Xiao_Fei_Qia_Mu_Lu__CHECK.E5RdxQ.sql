create Function Zl_消费卡目录_Check 
( 
  编号_In     卡消费接口目录.编号%Type, 
  卡号_In     病人预交记录.卡号%Type, 
  消费卡id_In In Out 消费卡目录.Id%Type, 
  信息_In     In Out Varchar2 
) Return Number Is 
  v_Err_Msg Varchar2(255); 
  Err_Item Exception; 
  n_Check_Valied Number(1); 
  n_序号         消费卡目录.序号%Type; 
  v_名称         卡消费接口目录.名称%Type; 
Begin 
  n_Check_Valied := 0; 
  --插入卡结算记录 
  n_序号 := Null; 
 
  Begin 
    Select 名称 Into v_名称 From 卡消费接口目录 Where 编号 = 编号_In; 
  Exception 
    When Others Then 
      v_名称 := '-'; 
  End; 
  If Nvl(消费卡id_In, 0) = 0 Then 
    For c_消费卡 In (Select a.Id, a.序号, a.有效期, a.回收时间, 可否充值, Decode(a.当前状态, 2, '回收', 3, '退卡', '回收') As 当前状态, a.停用日期, a.限制类别 
                  From 消费卡目录 A 
                  Where a.卡号 = 卡号_In And a.接口编号 = 编号_In And 
                        序号 = (Select Max(序号) From 消费卡目录 B Where 卡号 = a.卡号 And 接口编号 = a.接口编号) 
                  Order By a.序号) Loop 
      If Nvl(c_消费卡.回收时间, Sysdate + 1) < Sysdate Then 
        v_Err_Msg := '卡号为' || 卡号_In || '的' || v_名称 || '已经被' || Nvl(c_消费卡.当前状态, '回收') || ',不能退费!'; 
 
        Raise Err_Item; 
      End If; 
 
      If Nvl(c_消费卡.停用日期, Sysdate + 1) < Sysdate Then 
        v_Err_Msg := '卡号为' || 卡号_In || '的' || v_名称 || '已经被停用,不能退费!'; 
        Raise Err_Item; 
      End If; 
      If Nvl(c_消费卡.可否充值, 0) = 0 Then 
        If Nvl(c_消费卡.有效期, Sysdate + 1) < Sysdate Then 
          v_Err_Msg := '卡号为' || 卡号_In || '的' || v_名称 || '已经失效,不能退费!'; 
          Raise Err_Item; 
        End If; 
      End If; 
      n_序号      := Nvl(c_消费卡.序号, 0); 
      消费卡id_In := Nvl(c_消费卡.Id, 0); 
    End Loop; 
    If n_序号 Is Null Then 
      v_Err_Msg := '卡号为' || 卡号_In || '的' || v_名称 || '未找到,不能退费!'; 
      Raise Err_Item; 
    End If; 
    n_Check_Valied := 1; 
    Return n_Check_Valied; 
  End If; 
 
  For c_消费卡 In (Select a.Id, a.序号, a.有效期, a.回收时间, 可否充值, Decode(a.当前状态, 2, '回收', 3, '退卡', '回收') As 当前状态, a.停用日期, a.限制类别 
                From 消费卡目录 A 
                Where ID = Nvl(消费卡id_In, 0)) Loop 
    If Nvl(c_消费卡.回收时间, Sysdate + 1) < Sysdate Then 
      v_Err_Msg := '卡号为' || 卡号_In || '的' || v_名称 || '已经被' || Nvl(c_消费卡.当前状态, '回收') || ',不能退费!'; 
 
      Raise Err_Item; 
    End If; 
 
    If Nvl(c_消费卡.停用日期, Sysdate + 1) < Sysdate Then 
      v_Err_Msg := '卡号为' || 卡号_In || '的' || v_名称 || '已经被停用,不能退费!'; 
      Raise Err_Item; 
    End If; 
    If Nvl(c_消费卡.可否充值, 0) = 0 Then 
      If Nvl(c_消费卡.有效期, Sysdate + 1) < Sysdate Then 
        v_Err_Msg := '卡号为' || 卡号_In || '的' || v_名称 || '已经失效,不能退费!'; 
        Raise Err_Item; 
      End If; 
    End If; 
    n_序号      := Nvl(c_消费卡.序号, 0); 
    消费卡id_In := Nvl(c_消费卡.Id, 0); 
  End Loop; 
  If n_序号 Is Null Then 
    v_Err_Msg := '卡号为' || 卡号_In || '的' || v_名称 || '未找到,不能退费!'; 
    Raise Err_Item; 
  End If; 
 
  n_Check_Valied := 1; 
  Return n_Check_Valied; 
Exception 
  When Err_Item Then 
    信息_In := v_Err_Msg; 
    Return n_Check_Valied; 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zl_消费卡目录_Check;
/

