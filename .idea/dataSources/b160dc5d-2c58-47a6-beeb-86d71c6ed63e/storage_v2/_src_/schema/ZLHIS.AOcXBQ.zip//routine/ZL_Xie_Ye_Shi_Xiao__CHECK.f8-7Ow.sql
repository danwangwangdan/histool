create Function Zl_血液失效_Check 
( 
  效期报警_In Number, 
  效期单位_In Varchar2, 
  效期_In     In Date 
) Return Varchar2 Is 
  Result         Number(18); 
  v_效期报警_Tmp Number(20, 2); 
  ------------------------------------------------------------------------ 
  --  功能：检查指定库存血液是否未失效或已失效或即将失效 
  --  输入：效期报警_In:血液目录中建立的效期预报警值 
  --        效期单位_In:效期的表示单位，如年、月、天、周等 
  --        效期_In:库存血液的效期 
  --  输出：0:未失效;1:已失效;2:即将失效 
  --  调用窗体列表：frmBloodStorgeQuery、frmPubSelDialog 
  --  注意：无 
  -------------------------------------------------------------------------- 
Begin 
 
  Begin 
 
    --由于效期报警_In有可能是小时或周或月，因此统一转换成天 
    Select Decode(效期单位_In, 
                   '天', 
                   效期报警_In * 24, 
                   '周', 
                   效期报警_In * 7 * 24, 
                   '月', 
                   效期报警_In * 30 * 24, 
                   '小时', 
                   效期报警_In, 
                   效期报警_In) 
    Into v_效期报警_Tmp 
    From Dual; 
 
    Result := Trunc((Nvl(效期_In, Sysdate) - Sysdate) * 24); 
    If Result <= 0 Then 
      --效期-SysDate<=0时表示已经失效 
      Result := 1; 
    Else 
      -- 效期-SysDate<=效期报警值表示即将失效 
      If Result > v_效期报警_Tmp Then 
        Result := 0; 
      Else 
        Result := 2; 
      End If; 
    End If; 
  Exception 
    When Others Then 
      Result := 0; 
  End; 
  Return(Result); 
End Zl_血液失效_Check;
/

