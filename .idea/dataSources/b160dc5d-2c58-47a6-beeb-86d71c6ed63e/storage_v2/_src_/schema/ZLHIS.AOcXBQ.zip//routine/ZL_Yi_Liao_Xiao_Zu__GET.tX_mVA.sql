create Function Zl_医疗小组_Get 
( 
  开单科室id_In 临床医疗小组.科室id%Type, 
  开单人_In     人员表.姓名%Type, 
  病人id_In     病人信息.病人id%Type, 
  主页id_In     病案主页.主页id%Type, 
  发生时间_In   住院费用记录.发生时间%Type 
  --功能：获取医疗小组ID 
  --     本函数主要供其他过程调用,读取相关的医疗小组的ID 
  --     获取规则: 
  --     0.当病人在医疗小组A的住院期间，所有发生时间在本期间内时，医疗小组id均为A组的id ； 
  --       当病人从医疗小组A转移到医疗小组B后，A组补录病人的费用时，只要费用的发生时间在病人 
  --       在医疗小组A的住院期间，则医疗小组id均为A组的id 
  --     老规则： 
  --     1.开单人只有一个组;医疗小组ID就为开单人的医疗小组. 
  --     2.如果开单人从属多个医疗小组的或不存在开单人时,则缺省取病人所属医疗小组 
  --说明：如果当前规则没有取到医疗小组ID，则按老规则再取一次 
) Return Number Is 
  n_Count Number(18); 
  n_组id  Number(18); 
Begin 
  Begin 
    Select 医疗小组id 
    Into n_组id 
    From 病人变动记录 
    Where 病人id = 病人id_In And 主页id = 主页id_In 
          And 发生时间_In Between 开始时间 And Nvl(终止时间, To_Date('3000-01-01', 'yyyy-mm-dd')); 
  Exception 
    When Others Then 
      n_组id := Null; 
  End; 
  If Nvl(n_组id, 0) <> 0 Then 
    Return n_组id; 
  End If; 
 
  Select Max(a.Id), Count(Distinct a.Id) 
  Into n_组id, n_Count 
  From 临床医疗小组 A, 医疗小组人员 B, 人员表 C 
  Where a.Id = b.小组id And b.人员id = c.Id And a.科室id = 开单科室id_In And c.姓名 = 开单人_In; 
  If n_Count = 1 And Nvl(n_组id, 0) <> 0 Then 
    Return n_组id; 
  End If; 
 
  --取病人信息的医疗小组ID 
  Begin 
    Select 医疗小组id Into n_组id From 病案主页 Where 病人id = 病人id_In And 主页id = 主页id_In; 
  Exception 
    When Others Then 
      n_组id := Null; 
  End; 
  Return n_组id; 
End Zl_医疗小组_Get;
/

