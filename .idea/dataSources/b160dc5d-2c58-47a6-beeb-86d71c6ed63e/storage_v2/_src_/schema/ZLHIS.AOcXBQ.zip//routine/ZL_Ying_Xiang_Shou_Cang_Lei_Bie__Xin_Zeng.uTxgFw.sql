create Function Zl_影像收藏类别_新增 
( 
  上级id_In   影像收藏类别.上级id%Type, 
  收藏类别_In 影像收藏类别.收藏类别%Type, 
  是否共享_In 影像收藏类别.是否共享%Type, 
  创建人id_In 影像收藏类别.创建人id%Type, 
  创建时间_In 影像收藏类别.创建时间%Type 
) Return Number Is 
  Pragma Autonomous_Transaction; 
 
  v_收藏id 影像收藏类别.Id%Type; 
 
Begin 
  Select 影像收藏类别_Id.Nextval Into v_收藏id From Dual; 
 
  Insert Into 影像收藏类别 
    (ID, 上级id, 收藏类别, 是否共享, 创建人id, 创建时间) 
  Values 
    (v_收藏id, 上级id_In, 收藏类别_In, 是否共享_In, 创建人id_In, 创建时间_In); 
 
  Commit; 
 
  Return v_收藏id; 
Exception 
  When Others Then 
    zl_ErrorCenter(SQLCode, SQLErrM); 
End Zl_影像收藏类别_新增;
/

