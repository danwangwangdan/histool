create Function zl_影像消息_XML内容获取 
( 
    医嘱ID_In 病人医嘱记录.id%Type, 
    消息类型_In Varchar2, 
    当前用户_In Varchar2, 
    消息标记_In Varchar2:=Null         --新版：检查报告ID 
) Return Varchar2 IS 
  v_Context Varchar2(4000); 
 
  --ZLHIS_CIS_005(医技执行安排完成) 
  Function Get_ZLHIS_CIS_005 Return Varchar As 
    v_Return Varchar2(4000); 
  Begin 
        Select 
          '<patient_info>' || 
             '<patient_id>' || a.病人id || '</patient_id>' || 
             '<patient_name>' || a.姓名 ||'</patient_name>' || 
          '</patient_info>' || 
          '<patient_clinic>' || 
             '<patient_source>' || b.病人来源 ||'</patient_source>' || 
             '<clinic_dept_id>' || b.病人科室id || '</clinic_dept_id>' || 
          '</patient_clinic>' || 
          '<patient_order>' || 
             '<order_id>' || c.医嘱id || '</order_id>' || 
             '<order_expiry>' || b.医嘱期效 ||'</order_expiry>' || 
             '<order_kind>' || b.诊疗类别 || '</order_kind>' || 
             '<operation_kind>' || d.操作类型 ||'</operation_kind>' || 
             '<order_item_id>' || c.医嘱id || '</order_item_id>' || 
             '<order_item_title>' || b.医嘱内容 ||'</order_item_title>' || 
          '</patient_order>' || 
          '<arrange_result>' || 
             '<arrange_time>' ||To_Char(c.安排时间,'yyyy/mm/dd hh24:mi:ss')|| '</arrange_time>' || 
          '</arrange_result>'   Into v_Return 
 
      From 病人信息 A, 病人医嘱记录 B, 病人医嘱发送 C, 诊疗项目目录 D 
      Where a.病人id = b.病人id And c.医嘱id = b.Id And b.诊疗项目id = d.Id And c.安排时间 Is Not Null And b.相关id Is Null And 
          b.诊疗类别 = 'D' And b.Id = 医嘱id_In; 
    Return v_Return; 
  End Get_ZLHIS_CIS_005; 
 
  --ZLHIS_CIS_017(患者检查申请) 
  Function Get_ZLHIS_CIS_017 Return Varchar As 
    v_return Varchar2(4000); 
  Begin 
        Select 
           '<patient_info>' || 
               '<patient_id>' || a.病人id || '</patient_id>' || 
               '<patient_name>' || a.姓名 || '</patient_name>' || 
               '<in_number>' || nvl(a.住院号,0) || '</in_number>' || 
               '<out_number>' || nvl(a.门诊号,0) || '</out_number>' || 
           '</patient_info>' || 
           '<patient_clinic>' || 
               '<patient_source>' || b.病人来源 || '</patient_source>' || 
               '<clinic_id>' || Case b.病人来源 When 1 Then nvl(d.id,0) When 2 Then nvl(b.主页id, 0) Else 0 End || '</clinic_id>' || 
               '<clinic_dept_id>' || nvl(a.当前科室id,0) || '</clinic_dept_id>' || 
           '</patient_clinic>' || 
           '<check_request>' || 
               '<request_id>' || b.id || '</request_id>' || 
               '<check_item_id>' || b.诊疗项目id || '</check_item_id>' || 
               '<check_item_title>' || b.医嘱内容 || '</check_item_title>' || 
               '<execute_dept_id>' || nvl(c.执行部门id,0) || '</execute_dept_id>' || 
               '<send_serial>' || c.发送号 || '</send_serial>' || 
               '<bill_no>' || c.NO || '</bill_no>' || 
               '<bill_kind>' || c.记录性质 || '</bill_kind>' || 
               '<create_doctor>' || b.开嘱医生 || '</create_doctor>' || 
               '<create_time>' || b.开嘱时间 || '</create_time>' || 
               '<create_dept_id>' || nvl(b.开嘱科室id,0) || '</create_dept_id>' || 
           '</check_request>' into v_return 
 
        From 病人信息 a, 病人医嘱记录 b, 病人医嘱发送 c, 病人挂号记录 d 
        Where a.病人id=b.病人id And b.id=c.医嘱id And b.挂号单=d.no(+) And b.相关ID Is Null 
              And a.病人id=b.病人id And b.id=医嘱ID_In; 
 
      Return v_return; 
  End Get_ZLHIS_CIS_017; 
 
  --ZLHIS_CIS_024(患者医嘱撤销) 
  Function Get_ZLHIS_CIS_024 Return Varchar As 
    v_return Varchar2(4000); 
  Begin 
       Select 
           '<patient_info>' || 
               '<patient_id>' || a.病人id || '</patient_id>' || 
               '<patient_name>' || a.姓名 || '</patient_name>' || 
               '<in_number>' || nvl(a.住院号,0) || '</in_number>' || 
               '<out_number>' || nvl(a.门诊号,0) || '</out_number>' || 
           '</patient_info>' || 
           '<patient_clinic>' || 
               '<patient_source>' || b.病人来源 || '</patient_source>' || 
               '<clinic_id>' || Case b.病人来源 When 1 Then nvl(e.id,0) When 2 Then nvl(b.主页id, 0) Else 0 End || '</clinic_id>' || 
               '<clinic_dept_id>' || nvl(a.当前科室id,0) || '</clinic_dept_id>' || 
           '</patient_clinic>' || 
           '<cancel_order>' || 
               '<order_id>' || b.id || '</order_id>' || 
               '<order_kind>' || b.诊疗类别 || '</order_kind>' || 
               '<operation_kind>' || d.操作类型 || '</operation_kind>' || 
           '</cancel_order>' Into v_return 
 
       From 病人信息 a, 病人医嘱记录 b, 病人医嘱发送 c, 诊疗项目目录 d, 病人挂号记录 e 
       Where a.病人id=b.病人id And b.id=c.医嘱id And b.诊疗项目id=d.id And b.挂号单=e.no(+) And b.相关ID Is Null 
              And a.病人id=b.病人id And b.id=医嘱ID_In; 
 
      Return v_return; 
  End Get_ZLHIS_CIS_024; 
 
 
  --ZLHIS_PACS_001(检查报告完成) 
  Function Get_ZLHIS_PACS_001 Return Varchar As 
    v_return Varchar2(4000); 
  Begin 
    If 消息标记_In Is Null Then 
        Select 
           '<patient_info>' || 
               '<patient_id>' || a.病人id || '</patient_id>' || 
               '<patient_name>' || a.姓名 || '</patient_name>' || 
               '<in_number>' || nvl(a.住院号,0) || '</in_number>' || 
               '<out_number>' || nvl(a.门诊号,0) || '</out_number>' || 
           '</patient_info>' || 
           '<patient_clinic>' || 
               '<patient_source>' || b.病人来源 || '</patient_source>' || 
               '<clinic_id>' || Case b.病人来源 When 1 Then nvl(e.id,0) When 2 Then nvl(b.主页id, 0) Else 0 End || '</clinic_id>' || 
               '<clinic_dept_id>' || nvl(a.当前科室id,0) || '</clinic_dept_id>' || 
           '</patient_clinic>' || 
           '<advice_info>' || 
               '<order_id>' || b.id || '</order_id>' || 
               '<check_item_id>' || b.诊疗项目id || '</check_item_id>' || 
               '<check_item_title>' || b.医嘱内容 || '</check_item_title>' || 
               '<create_doctor>' || b.开嘱医生 || '</create_doctor>' || 
               '<create_dept_id>' || nvl(b.开嘱科室id, 0) || '</create_dept_id>' || 
               '<study_execute_id>' || nvl(b.执行科室id,0) || '</study_execute_id>' || 
           '</advice_info>' || 
           '<report_inf>' || 
               '<report_id>' || d.病历id || '</report_id>' || 
               '<report_doctor>' || c.完成人 || '</report_doctor>' || 
               '<result_positive>' || c.结果阳性 || '</result_positive>' || 
           '</report_inf>'  Into v_return 
 
        From 病人信息 a, 病人医嘱记录 b, 病人医嘱发送 c, 病人医嘱报告 d, 病人挂号记录 e 
        Where a.病人id=b.病人id And b.id=c.医嘱id And b.id=d.医嘱id And b.挂号单=e.no(+) And b.相关ID Is Null 
              And d.检查报告id Is Null And a.病人id=b.病人id And b.id=医嘱ID_In; 
    Else 
        Select 
           '<patient_info>' || 
               '<patient_id>' || a.病人id || '</patient_id>' || 
               '<patient_name>' || a.姓名 || '</patient_name>' || 
               '<in_number>' || nvl(a.住院号,0) || '</in_number>' || 
               '<out_number>' || nvl(a.门诊号,0) || '</out_number>' || 
           '</patient_info>' || 
           '<patient_clinic>' || 
               '<patient_source>' || b.病人来源 || '</patient_source>' || 
               '<clinic_id>' || Case b.病人来源 When 1 Then nvl(e.id,0) When 2 Then nvl(b.主页id, 0) Else 0 End || '</clinic_id>' || 
               '<clinic_dept_id>' || nvl(a.当前科室id,0) || '</clinic_dept_id>' || 
           '</patient_clinic>' || 
           '<advice_info>' || 
               '<order_id>' || b.id || '</order_id>' || 
               '<check_item_id>' || b.诊疗项目id || '</check_item_id>' || 
               '<check_item_title>' || b.医嘱内容 || '</check_item_title>' || 
               '<create_doctor>' || b.开嘱医生 || '</create_doctor>' || 
               '<create_dept_id>' || nvl(b.开嘱科室id, 0) || '</create_dept_id>' || 
               '<study_execute_id>' || nvl(b.执行科室id,0) || '</study_execute_id>' || 
           '</advice_info>' || 
           '<report_inf>' || 
               '<report_id>' || d.检查报告id || '</report_id>' || 
               '<report_doctor>' || c.完成人 || '</report_doctor>' || 
               '<result_positive>' || c.结果阳性 || '</result_positive>' || 
           '</report_inf>'  Into v_return 
 
        From 病人信息 a, 病人医嘱记录 b, 病人医嘱发送 c, 病人医嘱报告 d, 病人挂号记录 e 
        Where a.病人id=b.病人id And b.id=c.医嘱id And b.id=d.医嘱id And b.挂号单=e.no(+) And b.相关ID Is Null 
              And d.病历id Is Null And a.病人id=b.病人id And b.id=医嘱ID_In And d.检查报告id=消息标记_In; 
    End If; 
 
    Return v_return; 
  End Get_ZLHIS_PACS_001; 
 
  --ZLHIS_PACS_002(患者状态同步) 
  Function Get_ZLHIS_PACS_002 Return Varchar As 
    v_return Varchar2(4000); 
  Begin 
        Select 
           '<patient_info>' || 
               '<patient_id>' || a.病人id || '</patient_id>' || 
               '<patient_name>' || a.姓名 || '</patient_name>' || 
               '<identity_card>' || a.身份证号 || '</identity_card>' || 
               '<in_number>' || nvl(a.住院号,0) || '</in_number>' || 
               '<out_number>' || nvl(a.门诊号,0) || '</out_number>' || 
           '</patient_info>' || 
           '<patient_clinic>' || 
               '<patient_source>' || b.病人来源 || '</patient_source>' || 
               '<clinic_id>' || Case b.病人来源 When 1 Then nvl(d.id,0) When 2 Then nvl(b.主页id, 0) Else 0 End || '</clinic_id>' || 
               '<clinic_dept_id>' || nvl(a.当前科室id,0) || '</clinic_dept_id>' || 
           '</patient_clinic>' || 
           '<study_state>' || 
               '<study_cur_state>' || nvl(c.执行过程,0) || '</study_cur_state>' || 
               '<study_cur_time>' || sysdate || '</study_cur_time>' || 
               '<order_id>' || b.id || '</order_id>' || 
               '<study_item_id>' || b.诊疗项目id || '</study_item_id>' || 
               '<study_item_title>' || b.医嘱内容 || '</study_item_title>' || 
               '<study_oper_person>' || 当前用户_In || '</study_oper_person>' || 
               '<study_execute_id>' || nvl(b.执行科室id,0) || '</study_execute_id>' || 
           '</study_state>' Into v_return 
 
        From 病人信息 a, 病人医嘱记录 b, 病人医嘱发送 c, 病人挂号记录 d 
        Where a.病人id=b.病人id And b.id=c.医嘱id And b.挂号单=d.no(+) And b.相关ID Is Null 
              And a.病人id=b.病人id And b.id=医嘱ID_In; 
 
      Return v_return; 
  End Get_ZLHIS_PACS_002; 
 
 
  --ZLHIS_PACS_003(检查状态回退) 
  Function Get_ZLHIS_PACS_003 Return Varchar As 
    v_return Varchar2(4000); 
  Begin 
        Select 
           '<patient_info>' || 
               '<patient_id>' || a.病人id || '</patient_id>' || 
               '<patient_name>' || a.姓名 || '</patient_name>' || 
               '<identity_card>' || a.身份证号 || '</identity_card>' || 
               '<in_number>' || nvl(a.住院号,0) || '</in_number>' || 
               '<out_number>' || nvl(a.门诊号,0) || '</out_number>' || 
           '</patient_info>' || 
           '<patient_clinic>' || 
               '<patient_source>' || b.病人来源 || '</patient_source>' || 
               '<clinic_id>' || Case b.病人来源 When 1 Then nvl(d.id,0) When 2 Then nvl(b.主页id, 0) Else 0 End || '</clinic_id>' || 
               '<clinic_dept_id>' || nvl(a.当前科室id, 0) || '</clinic_dept_id>' || 
           '</patient_clinic>' || 
           '<study_state>' || 
               '<study_cur_state>' || nvl(c.执行过程,0) || '</study_cur_state>' || 
               '<study_cur_time>' || Sysdate || '</study_cur_time>' || 
               '<study_order_id>' || b.id || '</study_order_id>' || 
               '<study_item_id>' || b.诊疗项目id || '</study_item_id>' || 
               '<study_item_title>' || b.医嘱内容 || '</study_item_title>' || 
               '<study_oper_person>' || 当前用户_In || '</study_oper_person>' || 
               '<study_execute_id>' || nvl(b.执行科室id,0) || '</study_execute_id>' || 
           '</study_state>' Into v_return 
 
        From 病人信息 a, 病人医嘱记录 b, 病人医嘱发送 c, 病人挂号记录 d 
        Where a.病人id=b.病人id And b.id=c.医嘱id And b.挂号单=d.no(+) And b.相关ID Is Null 
              And a.病人id=b.病人id And b.id=医嘱ID_In; 
 
      Return v_return; 
  End Get_ZLHIS_PACS_003; 
 
 
  --ZLHIS_PACS_004(检查报告撤销) 
  Function Get_ZLHIS_PACS_004 Return Varchar As 
    v_return Varchar2(4000); 
  Begin 
    If 消息标记_In Is Null Then 
        Select 
           '<patient_info>' || 
               '<patient_id>' || a.病人id || '</patient_id>' || 
               '<patient_name>' || a.姓名 || '</patient_name>' || 
               '<in_number>' || nvl(a.住院号,0) || '</in_number>' || 
               '<out_number>' || nvl(a.门诊号,0) || '</out_number>' || 
           '</patient_info>' || 
           '<patient_clinic>' || 
               '<patient_source>' || b.病人来源 || '</patient_source>' || 
               '<clinic_id>' || Case b.病人来源 When 1 Then nvl(e.id,0) When 2 Then nvl(b.主页id, 0) Else 0 End || '</clinic_id>' || 
               '<clinic_dept_id>' || nvl(a.当前科室id,0) || '</clinic_dept_id>' || 
           '</patient_clinic>' || 
           '<advice_info>' || 
               '<order_id>' || b.id || '</order_id>' || 
               '<cur_state>' || nvl(c.执行过程,0) || '</cur_state>' || 
               '<check_item_id>' || b.诊疗项目id || '</check_item_id>' || 
               '<check_item_title>' || b.医嘱内容 || '</check_item_title>' || 
               '<create_doctor>' || b.开嘱医生 || '</create_doctor>' || 
               '<create_dept_id>' || nvl(b.开嘱科室id,0) || '</create_dept_id>' || 
               '<study_execute_id>' || nvl(b.执行科室id,0) || '</study_execute_id>' || 
           '</advice_info>' || 
           '<report_info>' || 
               '<report_id>' || d.病历id || '</report_id>' || 
           '</report_info>'  Into v_return 
 
        From 病人信息 a, 病人医嘱记录 b, 病人医嘱发送 c, 病人医嘱报告 d, 病人挂号记录 e 
        Where a.病人id=b.病人id And b.id=c.医嘱id And b.id=d.医嘱id And b.挂号单=e.no(+) And b.相关ID Is Null 
              And d.检查报告id Is Null And a.病人id=b.病人id And b.id=医嘱ID_In; 
    Else 
        Select 
           '<patient_info>' || 
               '<patient_id>' || a.病人id || '</patient_id>' || 
               '<patient_name>' || a.姓名 || '</patient_name>' || 
               '<in_number>' || nvl(a.住院号,0) || '</in_number>' || 
               '<out_number>' || nvl(a.门诊号,0) || '</out_number>' || 
           '</patient_info>' || 
           '<patient_clinic>' || 
               '<patient_source>' || b.病人来源 || '</patient_source>' || 
               '<clinic_id>' || Case b.病人来源 When 1 Then nvl(e.id,0) When 2 Then nvl(b.主页id, 0) Else 0 End || '</clinic_id>' || 
               '<clinic_dept_id>' || nvl(a.当前科室id,0) || '</clinic_dept_id>' || 
           '</patient_clinic>' || 
           '<advice_info>' || 
               '<order_id>' || b.id || '</order_id>' || 
               '<cur_state>' || nvl(c.执行过程,0) || '</cur_state>' || 
               '<check_item_id>' || b.诊疗项目id || '</check_item_id>' || 
               '<check_item_title>' || b.医嘱内容 || '</check_item_title>' || 
               '<create_doctor>' || b.开嘱医生 || '</create_doctor>' || 
               '<create_dept_id>' || nvl(b.开嘱科室id,0) || '</create_dept_id>' || 
               '<study_execute_id>' || nvl(b.执行科室id,0) || '</study_execute_id>' || 
           '</advice_info>' || 
           '<report_info>' || 
               '<report_id>' || d.检查报告id || '</report_id>' || 
           '</report_info>'  Into v_return 
 
        From 病人信息 a, 病人医嘱记录 b, 病人医嘱发送 c, 病人医嘱报告 d, 病人挂号记录 e 
        Where a.病人id=b.病人id And b.id=c.医嘱id And b.id=d.医嘱id And b.挂号单=e.no(+) And b.相关ID Is Null 
              And d.病历id Is Null And a.病人id=b.病人id And b.id=医嘱ID_In And d.检查报告id=消息标记_In; 
    End If; 
 
    Return v_return; 
  End Get_ZLHIS_PACS_004; 
 
  --ZLHIS_PACS_005(检查危急值通知) 
  Function Get_ZLHIS_PACS_005 Return Varchar As 
    v_return Varchar2(4000); 
  Begin 
        With t As (Select id, 姓名 From 人员表) 
        Select 
           '<patient_info>' || 
               '<patient_id>' || a.病人id || '</patient_id>' || 
               '<patient_name>' || a.姓名 || '</patient_name>' || 
               '<in_number>' || nvl(a.住院号,0) || '</in_number>' || 
               '<out_number>' || nvl(a.门诊号,0) || '</out_number>' || 
           '</patient_info>' || 
           '<patient_clinic>' || 
               '<patient_source>' || b.病人来源 || '</patient_source>' || 
               '<clinic_id>' || Case b.病人来源 When 1 Then nvl(i.id,0) When 2 Then nvl(b.主页id, 0) Else 0 End || '</clinic_id>' || 
               '<clinic_area_id>' || nvl(a.当前病区id,0) || '</clinic_area_id>' || 
               '<clinic_dept_id>' || nvl(b.开嘱科室id,0) || '</clinic_dept_id>' || 
               '<in_doctor_id>' || nvl(e.id,0) || '</in_doctor_id>' || 
               '<director_doctor_id>' || nvl(g.id,0) || '</director_doctor_id>' || 
               '<treat_doctor_id>' || nvl(h.id,0) || '</treat_doctor_id>' || 
               '<duty_nurse_id>' || nvl(f.id,0) || '</duty_nurse_id>' || 
           '</patient_clinic>' || 
           '<check_order>' || 
               '<order_id>' || b.id || '</order_id>' || 
               '<check_item_id>' || b.诊疗项目id || '</check_item_id>' || 
               '<check_item_title>' || b.医嘱内容 || '</check_item_title>' || 
               '<study_execute_id>' || nvl(b.执行科室id,0) || '</study_execute_id>' || 
           '</check_order>'  Into v_return 
 
        From 病人信息 a, 病人医嘱记录 b, 病案主页 c, 病人挂号记录 i, 
             (Select a.病人ID,a.主页ID,主任医师,主治医师 From 病人变动记录 a,病人医嘱记录 b 
              Where a.病人id=b.病人id And a.开始原因 Is Not Null And a.终止时间 Is Null And b.id=0) d, 
              t e, t f, t g, t h 
        Where b.病人id = a.病人id And b.挂号单=i.no(+) 
              And b.病人id=c.病人id(+) And b.主页id=c.主页id(+) 
              And c.住院医师=e.姓名(+) And c.责任护士=f.姓名(+) 
              And c.病人id =d.病人id(+) And c.主页id=d.主页id(+) 
              And d.主任医师=g.姓名(+) And d.主治医师=h.姓名(+) 
              And b.相关id Is Null And a.病人id=b.病人id And b.id=医嘱ID_In; 
 
      Return v_return; 
  End Get_ZLHIS_PACS_005; 
 
Begin 
  v_Context := ''; 
 
  Case 消息类型_In 
    When 'ZLHIS_CIS_005' Then 
      --ZLHIS_CIS_005(医技执行安排完成) 
      v_Context := Get_ZLHIS_CIS_005; 
 
    When 'ZLHIS_CIS_017' Then 
        --ZLHIS_CIS_017(患者检查申请) 
        v_Context := Get_ZLHIS_CIS_017; 
 
    When 'ZLHIS_CIS_024' Then 
        --ZLHIS_PACS_024(患者医嘱撤销) 
        v_Context := Get_ZLHIS_CIS_024; 
 
    When 'ZLHIS_PACS_001' Then 
        --ZLHIS_PACS_001(检查报告完成) 
        v_Context := Get_ZLHIS_PACS_001; 
 
    When 'ZLHIS_PACS_002' Then 
        --ZLHIS_PACS_002(检查状态同步) 
        v_Context := Get_ZLHIS_PACS_002; 
 
    When 'ZLHIS_PACS_003' Then 
        --ZLHIS_PACS_003(检查状态回退) 
        v_Context := Get_ZLHIS_PACS_003; 
 
    When 'ZLHIS_PACS_004' Then 
        --ZLHIS_PACS_004(检查报告撤销) 
        v_Context := Get_ZLHIS_PACS_004; 
 
    When 'ZLHIS_PACS_005' Then 
        --ZLHIS_PACS_005(检查危急值通知) 
        v_Context := Get_ZLHIS_PACS_005; 
    Else 
      Return ''; 
  End Case; 
 
  Return v_Context; 
End zl_影像消息_XML内容获取;
/

