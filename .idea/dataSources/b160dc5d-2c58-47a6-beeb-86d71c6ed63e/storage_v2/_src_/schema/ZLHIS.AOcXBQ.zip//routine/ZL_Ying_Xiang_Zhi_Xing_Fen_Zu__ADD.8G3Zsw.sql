create function zl_影像执行分组_Add 
( 
    分组名称_In  影像执行分组.组名%Type, 
    分组前缀_In  影像执行分组.分组前缀%Type, 
    科室Id_In  影像执行分组.科室ID%Type, 
    所含执行间_In Varchar2 := null 
) return number Is 
PRAGMA AUTONOMOUS_TRANSACTION; 
  n_GroupId 影像执行分组.ID%Type; 
begin 
  select 影像执行分组_Id.Nextval into n_GroupId from dual; 
 
  insert into 影像执行分组(ID, 科室ID, 组名, 分组前缀) 
              values(n_GroupId, 科室Id_In, 分组名称_In, 分组前缀_In); 
 
  if  所含执行间_In is not null  then 
    zl_影像执行分组_Association(所含执行间_In, 科室Id_In, n_GroupId); 
  end if; 
 
  commit; 
 
  return n_GroupId; 
Exception 
	When Others Then 
		Zl_Errorcenter(Sqlcode, Sqlerrm); 
end zl_影像执行分组_Add;
/

