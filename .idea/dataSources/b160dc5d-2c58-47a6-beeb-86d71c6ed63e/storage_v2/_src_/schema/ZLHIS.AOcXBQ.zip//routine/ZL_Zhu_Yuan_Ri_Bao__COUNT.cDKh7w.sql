create Function Zl_住院日报_Count 
( 
  科室id_In In Number, 
  时间_In   In Date 
) Return Number Is 
  V_Count Number := 0; 
  V_Sql   Varchar2(100); 
Begin 
  V_Sql := 'Select Count(科室id)  From 住院日报 Where 科室id =:1 And 日期 >=:2'; 
  Execute Immediate V_Sql 
    Into V_Count 
    Using 科室id_In, Trunc(时间_In); 
 
  Return V_Count; 
Exception 
  When Others Then 
    Null; 
    Return 0; 
End Zl_住院日报_Count;
/

