create trigger TU_BAXXZ
  after update
  on "病人信息"
  for each row
  declare
  ln_xtrz_id number;
begin
   Select xtrz_id.nextval Into ln_xtrz_id From Dual;
   If :old.姓名<>:New.姓名
   Then
   insert into 病人信息修改日志记录 values (ln_xtrz_id,
   :Old.住院号,
 :old.姓名,:new.姓名,User,Sysdate);
End If;
end tu_baxxz;
/

