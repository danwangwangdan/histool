create view "病案评分标准视图" as
  select decode(T.上级序号,null,序号,T.上级序号) as 上级序号, decode(T.序号,null,T.ID,T.序号) as 序号,T.ID,T.上级ID,T.方案ID,T.项目,T.标准分值,T.基本要求,T.缺陷内容,T.扣分标准,decode(T.子项个数,0,'否','是') as 隐藏,T.否决等级 
from 
( 
  select B.上级序号,A.序号,A.方案ID, 
  A.ID, 
  A.上级ID, 
  decode(A.子项个数,0,decode(A.上级ID,Null,A.名称,B.名称),A.名称) as 项目, 
  decode(A.子项个数,0,decode(A.上级ID,Null,A.标准分值,B.标准分值),B.标准分值) as 标准分值, 
  decode(A.子项个数,0,decode(A.上级ID,Null,A.描述,B.描述),A.描述) as 基本要求, 
  decode(A.上级ID,Null,'',A.描述) as 缺陷内容, 
  DECODE(A.缺陷等级,NULL,decode(sign(A.标准分值-1),-1,To_CHAR(A.标准分值,'0.9'),To_Char(A.标准分值))||decode(A.评分单位,NULL,'','/'||A.评分单位),A.缺陷等级) as 扣分标准, 
  A.子项个数, 
  A.否决等级 
  from 
      ( 
          select AA.序号,AA.ID,AA.方案ID,AA.上级ID,AA.名称,AA.描述,AA.标准分值,AA.缺陷等级,AA.评分单位,AA.否决等级,count(BB.ID) as 子项个数 
          from 病案评分标准 AA,病案评分标准 BB 
          where AA.ID=BB.上级ID(+) 
          group by AA.序号,AA.ID,AA.方案ID,AA.上级ID,AA.名称,AA.描述,AA.标准分值,AA.缺陷等级,AA.评分单位,AA.否决等级 
      ) A, 
      ( 
          select 序号 as 上级序号,ID,名称,标准分值,描述 from 病案评分标准 
      ) B 
  where A.上级ID=B.ID(+) 
) T 
order by decode(T.上级序号,null,序号,T.上级序号),decode(T.序号,null,T.ID,T.序号)
/

