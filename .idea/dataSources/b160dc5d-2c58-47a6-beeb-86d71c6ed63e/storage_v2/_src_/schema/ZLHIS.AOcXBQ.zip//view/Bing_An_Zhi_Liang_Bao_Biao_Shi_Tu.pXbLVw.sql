create view "病案质量报表视图" as
  Select   Tb.姓名, Tb.性别, Ta."病人ID",Ta."主页ID",Ta."住院号",Ta."入院日期",Ta."出院日期",Ta."入院科室",Ta."出院科室",Ta."门诊医师",Ta."责任护士",Ta."住院医师",Ta."编目日期",Ta."结果ID",Ta."方案ID",Ta."总分",Ta."等级",Ta."评分人",Ta."评分时间",Ta."审核人",Ta."审核时间",Ta."返回修改",Ta."备注",Ta."病理类型" 
From (Select T1.病人id, T1.主页id,T1.住院号, T1.入院日期, T1.出院日期, T2.名称 As 入院科室, T3.名称 As 出院科室, T1.门诊医师, 
              T1.责任护士, T1.住院医师, T1.编目日期, T1.结果id, T1.方案id, T1.总分, T1.等级, T1.评分人, 
              To_Char(T1.评分时间, 'YYYY-MM-DD') As 评分时间, T1.审核人, To_Char(T1.审核时间, 'YYYY-MM-DD') As 审核时间, 
              T1.返回修改, T1.备注 ,T1.病理类型 
       From (Select A.病人id, A.主页id, A.入院科室id, A.出院科室id, A.入院日期, A.出院日期, A.门诊医师, A.责任护士, 
                     A.住院医师, A.编目日期, B.ID As 结果id, B.方案id, B.总分, B.等级, B.评分人, B.评分时间, B.审核人, 
                     B.审核时间, B.返回修改, B.备注,B.病理类型,A.住院号 
              From 病案主页 A, 病案评分结果 B 
              Where A.病人id = B.病人id(+) And A.主页id = B.主页id(+)) T1, 部门表 T2, 部门表 T3 
       Where T1.入院科室id = T2.ID And T1.出院科室id = T3.ID) Ta, 病人信息 Tb 
Where Ta.病人id = Tb.病人id
/

