create view "病人费用明细" as
  Select L.病人id, 
	   L.Id As 顺序号, 
	   S.项目编码, 
	   S.项目名称, 
	   L.标准单价, 
	   L.登记时间 As 收费日期 
  From  (Select Id, 病人ID,收费细目ID,标准单价,登记时间 From  门诊费用记录 
	     Union ALL Select Id, 病人ID,收费细目ID,标准单价,登记时间 From  住院费用记录 
	     )  L, 收费项目目录 I, 标准医价规范 S 
 Where L.收费细目id = I.Id And I.标识主码 = S.项目编码(+) And 
	   I.类别 Not In ('4', '5', '6', '7')
/

