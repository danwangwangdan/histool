create view "挂号病人" as
  Select Distinct NO As 挂号单号, 病人id, 姓名, 性别, 年龄, 收费细目id As 挂号项目, 加班标志 As 急诊, 登记时间 As 日期, 执行部门id As 科室id, 发药窗口 As 诊室, 
                  执行人 As 医生, 执行状态 As 状态 
  From 门诊费用记录 
  Where 记录性质 = 4 And 记录状态 = 1 And 收费类别 = '1' And 病人id Is Not Null And 
        登记时间 > (Select Trunc(Sysdate) - To_Number(参数值) 
                From zlParameters 
                Where 系统 = (Select 编号 
                            From zlSystems 
                            Where Upper(所有者) = (Select Username From All_Users Where User_Id = Userenv('SchemaID')) And 
                                  Trunc(编号 / 100) = 1) And 模块 Is Null And Nvl(私有, 0) = 0 And 参数号 = 21)
/

