create view "H报告查阅记录" as
  Select "医嘱ID","病历ID","查阅人","查阅时间","查阅次数","取消时间","待转出","检查报告ID" From ZLBAK2012.报告查阅记录
/

