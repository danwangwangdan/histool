create view "H病理归档信息" as
  Select "ID","资料来源","病理医嘱ID","材块ID","制片ID","特检ID","档案ID","存放状态","借阅状态" From ZLBAK2012.病理归档信息
/

