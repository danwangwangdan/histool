create view "H病理脱钙信息" as
  Select "ID","标本ID","开始时间","所需时长","当前缸次","完成状态","操作员" From ZLBAK2012.病理脱钙信息
/

