create view "H病人挂号汇总" as
  Select "日期","科室ID","项目ID","医生姓名","医生ID","号码","已挂数","已约数","其中已接收","待转出" From ZLBAK2012.病人挂号汇总
/

