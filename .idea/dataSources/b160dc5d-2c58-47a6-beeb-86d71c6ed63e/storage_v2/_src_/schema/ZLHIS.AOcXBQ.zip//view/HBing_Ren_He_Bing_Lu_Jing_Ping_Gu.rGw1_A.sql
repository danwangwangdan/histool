create view "H病人合并路径评估" as
  Select "路径记录ID","阶段ID","日期","合并路径记录ID","合并路径阶段ID","合并路径天数","登记时间","待转出" From ZLBAK2012.病人合并路径评估
/

