create view "H病人护理要素内容" as
  Select "文件ID","页号","名称","内容","操作员","操作时间","待转出" From ZLBAK2012.病人护理要素内容
/

