create view "H病人路径变异" as
  Select "路径记录ID","阶段ID","日期","变异原因","待转出" From ZLBAK2012.病人路径变异
/

