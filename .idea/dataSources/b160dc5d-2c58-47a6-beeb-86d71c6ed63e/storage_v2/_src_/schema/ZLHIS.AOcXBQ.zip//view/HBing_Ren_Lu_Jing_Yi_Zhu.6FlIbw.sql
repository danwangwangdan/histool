create view "H病人路径医嘱" as
  Select "路径执行ID","病人医嘱ID","待转出" From ZLBAK2012.病人路径医嘱
/

