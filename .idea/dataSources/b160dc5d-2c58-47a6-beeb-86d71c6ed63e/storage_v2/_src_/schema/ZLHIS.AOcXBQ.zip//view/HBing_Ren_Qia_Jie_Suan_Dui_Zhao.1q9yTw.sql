create view "H病人卡结算对照" as
  Select "预交ID","卡结算ID","待转出" From ZLBAK2012.病人卡结算对照
/

