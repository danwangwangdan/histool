create view "H病人手麻单据" as
  Select "ID","手麻主页ID","开单人","开单科室ID","发生地点","登记人","登记时间","费用标志","单据号码","单据性质","是否收集","待转出" From ZLBAKZLOPER.病人手麻单据
/

