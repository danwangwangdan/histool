create view "H病人手麻分布" as
  Select "手麻手术ID","岗位","姓名","待转出" From ZLBAKZLOPER.病人手麻分布
/

