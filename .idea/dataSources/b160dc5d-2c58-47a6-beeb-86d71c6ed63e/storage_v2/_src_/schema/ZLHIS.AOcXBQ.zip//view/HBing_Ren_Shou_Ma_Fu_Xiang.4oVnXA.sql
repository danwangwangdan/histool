create view "H病人手麻附项" as
  Select "手麻主页ID","记录性质","应用场合","手麻事件ID","诊治项目ID","内容文本","待转出" From ZLBAKZLOPER.病人手麻附项
/

