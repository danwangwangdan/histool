create view "H病人手麻麻醉" as
  Select "手麻主页ID","序号","诊疗项目ID","主要麻醉","待转出" From ZLBAKZLOPER.病人手麻麻醉
/

