create view "H病人手麻人员" as
  Select "手麻主页ID","期间","岗位","姓名","换班时间","被换人员","是否换班","标志","来源","序号","待转出" From ZLBAKZLOPER.病人手麻人员
/

