create view "H病人手麻手术" as
  Select "ID","手麻主页ID","记录性质","手术名称","诊疗项目ID","手术操作ID","主手术","切口分类","愈合情况","手术类型","待转出" From ZLBAKZLOPER.病人手麻手术
/

