create view "H病人手麻准备" as
  Select "ID","手麻主页ID","记录性质","序号","类型","准备项目ID","准备数量","添加数量","执行科室ID","登记时间","登记人","备注说明","待转出" From ZLBAKZLOPER.病人手麻准备
/

