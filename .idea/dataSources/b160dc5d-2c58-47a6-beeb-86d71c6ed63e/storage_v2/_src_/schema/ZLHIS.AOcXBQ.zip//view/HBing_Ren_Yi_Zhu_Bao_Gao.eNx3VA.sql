create view "H病人医嘱报告" as
  Select "医嘱ID","病历ID","查阅状态","待转出","检查报告ID","RISID" From ZLBAK2012.病人医嘱报告
/

