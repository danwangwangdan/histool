create view "H病人医嘱附费" as
  Select "医嘱ID","发送号","记录性质","NO","待转出" From ZLBAK2012.病人医嘱附费
/

