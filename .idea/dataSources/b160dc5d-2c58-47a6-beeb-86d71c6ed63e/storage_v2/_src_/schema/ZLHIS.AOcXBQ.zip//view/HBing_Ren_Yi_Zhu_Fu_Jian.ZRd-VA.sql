create view "H病人医嘱附件" as
  Select "医嘱ID","项目","必填","排列","要素ID","内容","待转出" From ZLBAK2012.病人医嘱附件
/

