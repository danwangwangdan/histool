create view "H病人医嘱计价" as
  Select "医嘱ID","收费细目ID","数量","单价","从项","执行科室ID","费用性质","收费方式","待转出" From ZLBAK2012.病人医嘱计价
/

