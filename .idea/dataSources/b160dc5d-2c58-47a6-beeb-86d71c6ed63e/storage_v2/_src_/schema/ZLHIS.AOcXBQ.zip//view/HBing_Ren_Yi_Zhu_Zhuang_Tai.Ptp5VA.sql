create view "H病人医嘱状态" as
  Select "医嘱ID","操作类型","操作人员","操作时间","操作说明","签名ID","待转出" From ZLBAK2012.病人医嘱状态
/

