create view "H病人转诊记录" as
  Select "NO","申请科室ID","申请医生","接收科室ID","接收医生","接收时间","挂号ID","待转出" From ZLBAK2012.病人转诊记录
/

