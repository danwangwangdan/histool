create view "H产程要素内容" as
  Select "文件ID","婴儿","名称","内容","待转出" From ZLBAK2012.产程要素内容
/

