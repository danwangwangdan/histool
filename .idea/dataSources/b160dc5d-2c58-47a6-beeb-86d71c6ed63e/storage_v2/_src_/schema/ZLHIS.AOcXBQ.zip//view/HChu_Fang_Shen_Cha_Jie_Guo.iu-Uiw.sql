create view "H处方审查结果" as
  Select "审方ID","医嘱ID","审查项目ID","最后提交","药师审查","自动审查","理由","待转出" From ZLBAK2012.处方审查结果
/

