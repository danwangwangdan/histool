create view "H处方审查明细" as
  Select "审方ID","医嘱ID","最后提交","待转出" From ZLBAK2012.处方审查明细
/

