create view "H电子病历附件" as
  Select "病历ID","序号","文件名","内容","大小","创建人","日期","待转出" From ZLBAK2012.电子病历附件
/

