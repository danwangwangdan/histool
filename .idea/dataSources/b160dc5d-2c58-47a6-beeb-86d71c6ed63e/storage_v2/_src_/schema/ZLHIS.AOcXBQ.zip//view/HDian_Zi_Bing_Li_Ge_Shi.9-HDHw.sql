create view "H电子病历格式" as
  Select "文件ID","内容","待转出" From ZLBAK2012.电子病历格式
/

