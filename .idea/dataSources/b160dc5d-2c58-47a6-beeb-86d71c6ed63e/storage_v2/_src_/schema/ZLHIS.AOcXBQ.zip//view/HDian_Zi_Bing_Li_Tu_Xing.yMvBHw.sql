create view "H电子病历图形" as
  Select "对象ID","图形","待转出" From ZLBAK2012.电子病历图形
/

