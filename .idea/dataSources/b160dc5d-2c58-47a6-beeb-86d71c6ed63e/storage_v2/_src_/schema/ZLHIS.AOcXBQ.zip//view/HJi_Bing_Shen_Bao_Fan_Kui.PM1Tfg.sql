create view "H疾病申报反馈" as
  Select "申报ID","反馈信息","登记人","登记时间","处理情况说明","待转出" From ZLBAK2012.疾病申报反馈
/

