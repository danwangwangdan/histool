create view "H检验操作记录" as
  Select "ID","标本ID","操作类型","操作员","操作时间","待转出" From ZLBAK2012.检验操作记录
/

