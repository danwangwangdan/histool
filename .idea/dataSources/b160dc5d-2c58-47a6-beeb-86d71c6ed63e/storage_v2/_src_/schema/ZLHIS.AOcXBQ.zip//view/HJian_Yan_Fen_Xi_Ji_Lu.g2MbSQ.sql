create view "H检验分析记录" as
  Select "标本ID","用途","待转出","ID" From ZLBAK2012.检验分析记录
/

