create view "H检验拒收记录" as
  Select "医嘱ID","拒收人","拒收时间","拒收理由","重采人","重采时间","待转出","ID" From ZLBAK2012.检验拒收记录
/

