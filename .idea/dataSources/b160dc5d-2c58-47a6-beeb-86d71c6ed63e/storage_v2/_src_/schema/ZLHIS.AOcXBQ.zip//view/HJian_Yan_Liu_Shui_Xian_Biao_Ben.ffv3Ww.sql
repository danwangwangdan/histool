create view "H检验流水线标本" as
  Select "ID","标本ID","仪器是否审核","待转出" From ZLBAK2012.检验流水线标本
/

