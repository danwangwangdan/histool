create view "H检验流水线指标" as
  Select "ID","标本ID","项目ID","仪器是否审核","审核内容","待转出" From ZLBAK2012.检验流水线指标
/

