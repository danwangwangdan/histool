create view "H检验申请项目" as
  Select "标本ID","诊疗项目ID","序号","待转出" From ZLBAK2012.检验申请项目
/

