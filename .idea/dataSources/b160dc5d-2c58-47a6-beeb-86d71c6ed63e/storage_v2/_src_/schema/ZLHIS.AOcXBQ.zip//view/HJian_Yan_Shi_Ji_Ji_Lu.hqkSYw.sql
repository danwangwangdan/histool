create view "H检验试剂记录" as
  Select "医嘱ID","NO","序号","材料ID","数量","固定","待转出" From ZLBAK2012.检验试剂记录
/

