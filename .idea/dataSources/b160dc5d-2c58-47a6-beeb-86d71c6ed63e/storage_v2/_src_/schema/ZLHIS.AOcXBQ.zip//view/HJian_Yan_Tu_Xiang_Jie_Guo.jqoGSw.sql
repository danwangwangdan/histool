create view "H检验图像结果" as
  Select "ID","标本ID","图像类型","待转出","图像点","图像位置" From ZLBAK2012.检验图像结果
/

