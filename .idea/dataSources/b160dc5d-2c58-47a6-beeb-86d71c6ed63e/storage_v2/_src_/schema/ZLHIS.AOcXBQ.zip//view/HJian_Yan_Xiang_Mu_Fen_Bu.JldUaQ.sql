create view "H检验项目分布" as
  Select "ID","标本ID","项目ID","医嘱ID","细菌ID","范围","待转出" From ZLBAK2012.检验项目分布
/

