create view "H票据打印明细" as
  Select "使用ID","票种","NO","票号","是否回收","关联票号序号","序号","待转出" From ZLBAK2012.票据打印明细
/

