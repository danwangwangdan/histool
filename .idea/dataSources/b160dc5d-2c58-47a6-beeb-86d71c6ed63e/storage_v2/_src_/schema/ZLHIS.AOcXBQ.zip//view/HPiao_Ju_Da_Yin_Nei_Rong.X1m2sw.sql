create view "H票据打印内容" as
  Select "ID","数据性质","NO","待转出","打印类型" From ZLBAK2012.票据打印内容
/

