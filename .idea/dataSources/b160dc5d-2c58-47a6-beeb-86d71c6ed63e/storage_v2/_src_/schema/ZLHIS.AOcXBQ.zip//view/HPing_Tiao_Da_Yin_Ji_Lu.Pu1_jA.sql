create view "H凭条打印记录" as
  Select "NO","记录性质","打印时间","打印类型","打印人","机器名","IP地址","备注","待转出" From ZLBAK2012.凭条打印记录
/

