create view "H人员收缴对照" as
  Select "收缴ID","性质","记录ID","待转出" From ZLBAK2012.人员收缴对照
/

