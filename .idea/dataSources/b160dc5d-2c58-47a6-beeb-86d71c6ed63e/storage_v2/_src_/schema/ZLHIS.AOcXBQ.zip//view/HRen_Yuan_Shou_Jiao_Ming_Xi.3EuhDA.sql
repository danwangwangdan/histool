create view "H人员收缴明细" as
  Select "收缴ID","结算方式","结算号","金额","余额","待转出" From ZLBAK2012.人员收缴明细
/

