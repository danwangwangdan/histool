create view "H三方结算交易" as
  Select "交易ID","交易项目","交易内容","待转出" From ZLBAK2012.三方结算交易
/

