create view "H三方退款信息" as
  Select "结帐ID","记录ID","金额","卡号","交易流水号","交易说明","待转出" From ZLBAK2012.三方退款信息
/

