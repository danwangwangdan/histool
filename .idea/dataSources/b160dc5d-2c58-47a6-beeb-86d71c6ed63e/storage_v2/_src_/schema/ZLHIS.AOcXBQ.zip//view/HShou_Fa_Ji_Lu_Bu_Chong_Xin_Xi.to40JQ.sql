create view "H收发记录补充信息" as
  Select "收发ID","科室","病人姓名","住院号","床号","待转出" From ZLBAK2012.收发记录补充信息
/

