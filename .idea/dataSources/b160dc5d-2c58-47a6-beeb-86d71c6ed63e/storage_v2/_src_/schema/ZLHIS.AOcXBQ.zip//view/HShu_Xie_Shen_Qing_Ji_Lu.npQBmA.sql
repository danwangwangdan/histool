create view "H输血申请记录" as
  Select "医嘱ID","是否待诊","输血性质","即往输血史","孕产情况","受血者属地","输血血型","RHD","受血者血型","HCT","ALT","HBSAG","梅毒","血红蛋白","血小板","ANTIHCV","ANTIHIV12","待转出" From ZLBAK2012.输血申请记录
/

