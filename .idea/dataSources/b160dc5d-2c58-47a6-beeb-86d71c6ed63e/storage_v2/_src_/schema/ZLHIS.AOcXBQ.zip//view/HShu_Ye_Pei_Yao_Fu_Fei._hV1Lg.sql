create view "H输液配药附费" as
  Select "配药ID","NO","待转出","病人ID" From ZLBAK2012.输液配药附费
/

