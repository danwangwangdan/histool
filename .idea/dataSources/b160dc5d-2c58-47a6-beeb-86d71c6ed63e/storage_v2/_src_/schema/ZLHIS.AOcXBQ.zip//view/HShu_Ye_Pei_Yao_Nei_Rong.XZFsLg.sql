create view "H输液配药内容" as
  Select "记录ID","收发ID","数量","待转出" From ZLBAK2012.输液配药内容
/

