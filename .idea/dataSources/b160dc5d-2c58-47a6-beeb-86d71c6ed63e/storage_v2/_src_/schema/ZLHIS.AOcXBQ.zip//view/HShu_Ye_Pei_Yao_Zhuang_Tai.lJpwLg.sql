create view "H输液配药状态" as
  Select "配药ID","操作类型","操作人员","操作时间","操作说明","待转出" From ZLBAK2012.输液配药状态
/

