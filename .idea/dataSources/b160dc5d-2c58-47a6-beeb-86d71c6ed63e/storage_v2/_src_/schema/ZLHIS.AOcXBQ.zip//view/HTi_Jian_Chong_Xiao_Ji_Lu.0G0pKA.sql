create view "H体检冲消记录" as
  Select "结帐ID","预交ID","记录性质","冲消金额","冲消时间","冲消人","待转出" From ZLBAKZLPEIS.体检冲消记录
/

