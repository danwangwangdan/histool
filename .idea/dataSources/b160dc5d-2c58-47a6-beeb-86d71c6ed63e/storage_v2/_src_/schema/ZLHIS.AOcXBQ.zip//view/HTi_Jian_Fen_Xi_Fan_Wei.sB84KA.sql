create view "H体检分析范围" as
  Select "分析任务ID","体检任务ID","体检人员ID","待转出" From ZLBAKZLPEIS.体检分析范围
/

