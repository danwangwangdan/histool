create view "H体检分析结果" as
  Select "分析任务ID","报告组件ID","结论描述","结论参数","分析人员","分析时间","待转出" From ZLBAKZLPEIS.体检分析结果
/

