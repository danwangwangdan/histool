create view "H体检健康发放" as
  Select "健康证件ID","发放次数","发放时间","发放人员","费用单据","费用性质","证卡编号","待转出" From ZLBAKZLPEIS.体检健康发放
/

