create view "H体检结帐记录" as
  Select "ID","NO","实际票号","病人ID","团体ID","记录性质","记录状态","结帐金额","体检部门ID","是否付款","结帐ID","结帐人","结帐时间","待转出" From ZLBAKZLPEIS.体检结帐记录
/

