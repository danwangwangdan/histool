create view "H体检禁忌记录" as
  Select "任务ID","病人ID","记录序号","危害因素ID","危害因素","异常结果","待转出" From ZLBAKZLPEIS.体检禁忌记录
/

