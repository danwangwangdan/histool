create view "H体检任务费用" as
  Select "清单ID","任务ID","病人ID","体检项目ID","费用对象","费用性质","记录性质","NO","检查部位","医嘱ID","待转出" From ZLBAKZLPEIS.体检任务费用
/

