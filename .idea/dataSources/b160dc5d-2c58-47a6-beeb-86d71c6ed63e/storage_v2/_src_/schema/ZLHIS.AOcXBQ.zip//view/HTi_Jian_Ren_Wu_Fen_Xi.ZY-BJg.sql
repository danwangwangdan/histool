create view "H体检任务分析" as
  Select "任务ID","病人ID","报告组件ID","分析结果","分析人员","分析时间","分析参数","待转出" From ZLBAKZLPEIS.体检任务分析
/

