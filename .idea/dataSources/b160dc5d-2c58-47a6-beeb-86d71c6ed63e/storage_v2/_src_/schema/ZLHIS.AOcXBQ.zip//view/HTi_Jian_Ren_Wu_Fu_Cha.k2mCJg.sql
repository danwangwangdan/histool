create view "H体检任务复查" as
  Select "任务ID","病人ID","体检项目ID","复查时间","复查任务ID","待转出" From ZLBAKZLPEIS.体检任务复查
/

