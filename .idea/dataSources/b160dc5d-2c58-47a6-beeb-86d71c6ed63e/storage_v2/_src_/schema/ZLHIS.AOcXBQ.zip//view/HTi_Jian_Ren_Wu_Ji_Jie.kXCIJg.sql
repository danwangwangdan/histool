create view "H体检任务计价" as
  Select "清单ID","任务ID","体检项目ID","收费项目ID","收费对象","收费数次","基本价格","体检价格","执行科室ID","固定","标本部位","待转出" From ZLBAKZLPEIS.体检任务计价
/

