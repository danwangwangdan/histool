create view "H体检任务细菌" as
  Select "ID","任务ID","清单ID","病人ID","细菌名称","细菌结果","耐药机制","培养描述","待转出" From ZLBAKZLPEIS.体检任务细菌
/

