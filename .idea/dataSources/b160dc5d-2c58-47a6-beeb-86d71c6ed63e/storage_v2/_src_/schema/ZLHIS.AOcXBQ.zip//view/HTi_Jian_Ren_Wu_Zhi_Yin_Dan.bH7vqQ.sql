create view "H体检任务指引单" as
  Select "NO","任务ID","病人ID","环节","接收人员","接收时间","待转出" From ZLBAKZLPEIS.体检任务指引单
/

