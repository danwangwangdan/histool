create view "H体检任务组别" as
  Select "体检任务ID","任务组名","待转出","适用人员" From ZLBAKZLPEIS.体检任务组别
/

