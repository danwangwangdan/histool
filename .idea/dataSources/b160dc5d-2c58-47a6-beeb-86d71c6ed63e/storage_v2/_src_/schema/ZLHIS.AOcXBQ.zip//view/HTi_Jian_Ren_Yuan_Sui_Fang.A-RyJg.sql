create view "H体检人员随访" as
  Select "体检部门ID","任务ID","病人ID","NO","序号","诊断描述","随访结果","随访情况","随访人","随访时间","登记时间","随访记录ID","待转出" From ZLBAKZLPEIS.体检人员随访
/

