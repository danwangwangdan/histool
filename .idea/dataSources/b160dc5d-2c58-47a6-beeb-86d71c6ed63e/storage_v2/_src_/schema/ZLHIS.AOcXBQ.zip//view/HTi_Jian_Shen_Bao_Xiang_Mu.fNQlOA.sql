create view "H体检申报项目" as
  Select "申报ID","体检项目ID","待转出" From ZLBAKZLPEIS.体检申报项目
/

