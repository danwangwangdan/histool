create view "H体检外检变动" as
  Select "外检记录ID","外检关系ID","数据表名","变动类型","数据行号","字段名称","原始数值","最新数值","待转出" From ZLBAKZLPEIS.体检外检变动
/

