create view "H体检外检操作" as
  Select "外检记录ID","操作类型","操作人员","操作时间","待转出" From ZLBAKZLPEIS.体检外检操作
/

