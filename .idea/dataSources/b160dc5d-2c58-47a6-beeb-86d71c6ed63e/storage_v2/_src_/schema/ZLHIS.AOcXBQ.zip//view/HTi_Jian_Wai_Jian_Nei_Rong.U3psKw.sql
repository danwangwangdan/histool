create view "H体检外检内容" as
  Select "外检记录ID","体检任务ID","待转出" From ZLBAKZLPEIS.体检外检内容
/

