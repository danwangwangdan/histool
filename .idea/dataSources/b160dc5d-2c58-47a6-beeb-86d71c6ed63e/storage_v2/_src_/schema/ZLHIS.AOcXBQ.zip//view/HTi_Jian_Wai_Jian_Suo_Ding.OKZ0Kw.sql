create view "H体检外检锁定" as
  Select "外检记录ID","序号","记录性质","医嘱ID","单据号码","单据性质","待转出" From ZLBAKZLPEIS.体检外检锁定
/

