create view "H体检问卷记录" as
  Select "任务ID","病人ID","问卷项目ID","记录类型","问卷人","问卷时间","登记人","登记时间","待转出" From ZLBAKZLPEIS.体检问卷记录
/

