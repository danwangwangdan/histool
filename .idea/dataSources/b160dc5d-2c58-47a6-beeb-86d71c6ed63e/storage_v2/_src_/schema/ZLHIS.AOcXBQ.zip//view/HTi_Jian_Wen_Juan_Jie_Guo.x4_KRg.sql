create view "H体检问卷结果" as
  Select "任务ID","病人ID","问卷项目ID","记录行号","记录组名","排列顺序","体检指标ID","记录结果","记录单位","待转出" From ZLBAKZLPEIS.体检问卷结果
/

