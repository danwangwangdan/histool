create view "H危害因素任务" as
  Select "任务ID","危害因素ID","待转出" From ZLBAKZLPEIS.危害因素任务
/

