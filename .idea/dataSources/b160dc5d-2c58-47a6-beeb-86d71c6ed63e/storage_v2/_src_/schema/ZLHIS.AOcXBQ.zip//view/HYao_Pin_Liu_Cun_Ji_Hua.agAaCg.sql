create view "H药品留存计划" as
  Select "部门ID","库房ID","药品ID","留存数量","留存ID","状态","登记人","登记时间","待转出" From ZLBAK2012.药品留存计划
/

