create view "H药品签名明细" as
  Select "签名ID","收发ID","待转出" From ZLBAK2012.药品签名明细
/

