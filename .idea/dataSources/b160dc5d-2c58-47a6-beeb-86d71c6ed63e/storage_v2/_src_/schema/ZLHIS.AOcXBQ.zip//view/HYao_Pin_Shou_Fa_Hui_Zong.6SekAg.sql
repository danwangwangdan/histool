create view "H药品收发汇总" as
  Select "日期","库房ID","药品ID","类别ID","单据","数量","金额","差价","待转出" From ZLBAK2012.药品收发汇总
/

