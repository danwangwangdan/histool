create view "H药品收发门诊标志" as
  Select "处方号","单据","库房ID","业务分类","标志","待转出" From ZLBAK2012.药品收发门诊标志
/

