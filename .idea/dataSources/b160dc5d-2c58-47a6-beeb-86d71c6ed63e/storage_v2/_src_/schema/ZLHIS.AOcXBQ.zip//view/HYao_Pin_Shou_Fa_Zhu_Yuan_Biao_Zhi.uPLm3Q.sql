create view "H药品收发住院标志" as
  Select "收发ID","业务分类","标志","待转出" From ZLBAK2012.药品收发住院标志
/

