create view "H医保结算明细" as
  Select "结帐ID","NO","结算方式","金额","备注","待转出" From ZLBAK2012.医保结算明细
/

