create view "H医嘱执行打印" as
  Select "医嘱ID","报表ID","上次打印时间","待转出" From ZLBAK2012.医嘱执行打印
/

