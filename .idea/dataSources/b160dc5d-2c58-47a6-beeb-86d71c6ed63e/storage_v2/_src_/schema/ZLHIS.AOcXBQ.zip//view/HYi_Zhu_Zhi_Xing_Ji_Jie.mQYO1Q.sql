create view "H医嘱执行计价" as
  Select "医嘱ID","发送号","要求时间","收费细目ID","费用性质","数量","待转出","执行状态" From ZLBAK2012.医嘱执行计价
/

