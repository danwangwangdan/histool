create view "H医嘱执行时间" as
  Select "要求时间","医嘱ID","发送号","待转出" From ZLBAK2012.医嘱执行时间
/

