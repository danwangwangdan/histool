create view "H影像报告驳回" as
  Select "ID","医嘱ID","病历ID","驳回理由","驳回时间","驳回人","待转出","检查报告ID","是否撤销" From ZLBAK2012.影像报告驳回
/

