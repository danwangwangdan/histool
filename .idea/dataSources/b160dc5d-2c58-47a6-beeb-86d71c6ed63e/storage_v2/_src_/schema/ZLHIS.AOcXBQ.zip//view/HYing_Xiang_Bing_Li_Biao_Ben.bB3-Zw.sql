create view "H影像病理标本" as
  Select "ID","医嘱ID","发送号","编号","标本部位","块数" From ZLBAK2012.影像病理标本
/

