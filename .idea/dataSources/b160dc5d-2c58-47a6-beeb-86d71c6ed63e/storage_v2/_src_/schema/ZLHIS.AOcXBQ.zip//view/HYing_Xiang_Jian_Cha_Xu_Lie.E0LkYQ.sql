create view "H影像检查序列" as
  Select "序列UID","检查UID","序列号","序列描述","采集时间","待转出" From ZLBAK2012.影像检查序列
/

