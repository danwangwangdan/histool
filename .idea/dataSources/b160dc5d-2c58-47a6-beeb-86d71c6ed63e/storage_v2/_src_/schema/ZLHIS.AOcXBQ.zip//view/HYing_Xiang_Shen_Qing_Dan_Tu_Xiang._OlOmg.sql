create view "H影像申请单图像" as
  Select "ID","医嘱ID","申请单图像","FTP路径","设备号","扫描人","扫描时间","待转出" From ZLBAK2012.影像申请单图像
/

