create view "H影像收藏内容" as
  Select "ID","收藏ID","医嘱ID","收藏时间","待转出" From ZLBAK2012.影像收藏内容
/

