create view "H诊疗单据打印" as
  Select "记录性质","NO","打印内容","打印人","打印时间","待转出" From ZLBAK2012.诊疗单据打印
/

