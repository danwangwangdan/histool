create view "H执行打印记录" as
  Select "医嘱ID","发送号","流水号","打印说明","打印时间","打印人","待转出" From ZLBAK2012.执行打印记录
/

