create view "护理等级" as
  SELECT I.ID AS 序号, I.编码, I.名称, I.计算单位, N.简码, I.项目特性-1 AS 基本护理, I.说明, I.建档时间, I.撤档时间 
    FROM 收费项目目录 I, 收费项目别名 N 
    WHERE I.ID=N.收费细目id And I.类别='H' And I.项目特性>=1 And N.性质=1 And N.码类=1
/

