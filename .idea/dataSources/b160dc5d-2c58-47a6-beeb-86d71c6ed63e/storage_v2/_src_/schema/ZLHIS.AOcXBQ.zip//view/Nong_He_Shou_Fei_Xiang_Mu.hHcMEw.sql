create view "农合收费项目" as
  Select A.编码 As 编码,A.名称 As 项目名称, C.类别 As 类别名称 ,A.规格,A.计算单位 As 单位,'' As 剂型,  max(d.现价)  As 单价,'' As 拼音码,'' As 五笔码,'' As 备注 From 收费细目 A,(Select Max(Id) As maxID,收费细目ID From 收费价目 Where 执行日期 <= Sysdate Group By  收费细目ID) B,收费类别 C, 收费价目 d Where B.收费细目ID = A.Id And A.类别 = C.编码 And d.Id=b.maxid  Group By A.编码,A.名称,C.类别,A.规格,A.计算单位
/

