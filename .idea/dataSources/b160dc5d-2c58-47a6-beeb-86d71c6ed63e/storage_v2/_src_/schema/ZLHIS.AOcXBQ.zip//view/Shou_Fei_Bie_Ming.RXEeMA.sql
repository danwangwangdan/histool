create view "收费别名" as
  SELECT 收费细目id,名称,简码 
    FROM 收费项目别名
/

