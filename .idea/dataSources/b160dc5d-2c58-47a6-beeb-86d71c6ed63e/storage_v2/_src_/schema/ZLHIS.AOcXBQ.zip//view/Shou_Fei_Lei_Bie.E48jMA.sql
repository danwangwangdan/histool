create view "收费类别" as
  SELECT 编码,名称 AS 类别,简码 AS 说明,固定 AS 系统标志,0 AS 独立编辑 
    FROM 收费项目类别
/

