create view "收费执行部门" as
  SELECT 收费细目id,执行科室id as 执行部门id 
    FROM 收费执行科室
/

