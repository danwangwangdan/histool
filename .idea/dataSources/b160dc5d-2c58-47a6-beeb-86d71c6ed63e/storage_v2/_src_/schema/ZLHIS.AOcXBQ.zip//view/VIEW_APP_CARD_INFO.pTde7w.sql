create view VIEW_APP_CARD_INFO as
  Select '3500001' As HOSPITAL_MARK,B.身份证号 As ID_NO,A.卡号 As CARD_NO,A.病人ID As PATIENT_ID,
       				B.姓名 As PATIENT_NAME,A.卡类别ID As CARD_TYPE,B.家庭电话 As PHONE_NUMBER
       From 病人医疗卡信息 A,病人信息 B
       Where A.卡类别ID=1 And A.状态=0 And A.病人Id=B.病人ID
/

