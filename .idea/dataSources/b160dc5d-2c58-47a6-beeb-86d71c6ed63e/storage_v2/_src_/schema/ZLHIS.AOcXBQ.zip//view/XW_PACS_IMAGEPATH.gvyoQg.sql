create view XW_PACS_IMAGEPATH as
  Select a.医嘱ID As OrderID,b.IP地址 As ServerIP,b.FTP目录 As RootPath,b.共享目录用户名 As ServerUserName, 
         b.共享目录密码 As ServerPassWord,Decode(a.接收日期,Null,'',to_Char(a.接收日期,'YYYYMMDD')||'\')||a.检查UID||'\'||d.图像Uid As ImagePathName, 
         a.检查UID As StudyUID,c.序列UID As SeriesUID,d.图像Uid As ImageUID, 
         'FTP[;]'||b.IP地址||'[;]21[;]'||b.FTP用户名||'[;]'||b.FTP密码||'[;]'||'\'||b.FTP目录||'\[;]'||d.图像Uid As FTPString 
  From 影像检查记录 a,影像设备目录 b,影像检查序列 c,影像检查图象 d 
  Where a.位置一 =b.设备号 And C.检查UID = A.检查UID And D.序列UID = C.序列UID
/

