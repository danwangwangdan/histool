create view XW_RIS_STUDYINFO as
  Select b.医嘱ID As OrderID,a.病人ID As PatientID,a.门诊号 As OutPatientID,a.住院号 As InPatientID,a.健康号 As HealthID, 
        a.姓名 As Name,a.性别 As Sex ,a.年龄 As Age,a.出生日期 As DateOfBirth,b.英文名 As PYName,b.影像类别 As Modality, 
        b.检查号 As StudyID,c.病人来源 As Source,c.执行科室ID As DeptID,c.医嘱内容 As MedicalOrder, 
        c.开嘱时间 As ApplyTime,d.首次时间 As CheckInTime 
  From 病人信息 a,影像检查记录 b,病人医嘱记录 c,病人医嘱发送 d 
  Where b.医嘱ID = c.Id And c.Id = d.医嘱ID And c.病人ID =a.病人ID
/

