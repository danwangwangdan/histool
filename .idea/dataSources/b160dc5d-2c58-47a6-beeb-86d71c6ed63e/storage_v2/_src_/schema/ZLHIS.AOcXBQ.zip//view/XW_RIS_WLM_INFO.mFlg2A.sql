create view XW_RIS_WLM_INFO as
  Select '' As F_MACHINE_AET,'' As F_MACHINE_NAME , 影像类别 As F_MODALITY_DCMTYPE ,to_char(出生日期,'YYYYMMDD') As F_PAT_BIRTH ,英文名 As F_PAT_NAME ,英文名 As F_PAT_NAME_EN 
         ,'' As F_PAT_ADDRESS,检查号 As F_PAT_NO,'' As F_PAT_OT_ID,'' As F_PAT_LOCATION,'' As F_ADD_HISTORY,'' As F_PAT_REGION,'' As F_MEDICAL_ALERTS,'' As F_CONTRAST,'' As F_PLACE_NO 
         ,decode(性别,'男','M','女','F','O') As F_SEX,体重 As F_WEIGHT,身高 As F_HEIGHT,'' As F_PERFORM_DOC,'' As F_REQUEST_DOC,'' As F_DIAGNOSES,'' As F_STU_REASON,'' As F_STU_COMMENT 
         ,'' As F_MEN_DATE,'' As F_LATERALITY,to_char(b.首次时间,'YYYYMMDD') As F_STU_DATE_DCM,a.医嘱ID As F_STU_ID,a.医嘱ID As F_STU_NO,to_char(b.首次时间,'hh24:mi:ss') As F_STU_TIME_DCM 
         ,a.医嘱ID || '.' || a.发送号 As F_STU_UID,b.执行间 as F_ROOM_NAME, c.名称 as F_DEPT_NAME 
  From  影像检查记录 a ,病人医嘱发送 b,部门表 c 
  Where a.医嘱ID=b.医嘱ID And a.发送号 = b.发送号 And b.执行部门id=c.Id And  b.执行状态=3 And b.执行过程=2 And a.检查UID IS Null AND b.首次时间>=SysDate-10
/

