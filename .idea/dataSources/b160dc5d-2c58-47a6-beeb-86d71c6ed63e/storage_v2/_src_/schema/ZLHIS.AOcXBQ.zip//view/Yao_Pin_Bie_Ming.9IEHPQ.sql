create view "药品别名" as
  Select T.药名id,N.名称,N.简码,decode(性质,3,N.收费细目id,Null) As 药品id, 
           decode(N.码类,3,2,1) As 码类 
    From 收费项目别名 N,药品规格 T 
    Where N.收费细目id=T.药品id And N.码类<>2
/

