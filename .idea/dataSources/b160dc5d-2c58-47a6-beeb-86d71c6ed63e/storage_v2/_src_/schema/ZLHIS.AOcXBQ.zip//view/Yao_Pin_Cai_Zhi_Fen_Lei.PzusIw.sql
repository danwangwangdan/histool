create view "药品材质分类" as
  SELECT decode(编码,'5','1','6','2','3') AS 编码,名称, 简码 
    FROM 诊疗项目类别 
    WHERE 编码 in ('5','6','7')
/

