create view "药品配伍禁忌" as
  SELECT R.组编号, R.项目ID AS 药名ID, R.类型 
    FROM 诊疗互斥项目  R, 诊疗项目目录  I 
    WHERE R.项目ID=I.ID And I.类别 In ('5','6','7')
/

