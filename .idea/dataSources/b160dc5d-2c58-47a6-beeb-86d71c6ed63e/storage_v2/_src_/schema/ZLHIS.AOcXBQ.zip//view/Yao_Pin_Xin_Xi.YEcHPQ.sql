create view "药品信息" as
  SELECT decode(I.类别,'5','西成药','6','中成药','中草药') AS 材质分类, S.药名ID, null as 药典id,I.分类ID AS 用途分类ID, 
        K.编码 AS 剂型,I.编码, I.名称 AS 通用名称, I.计算单位 AS 剂量单位, S.毒理分类, S.货源情况, S.价值分类, S.用药梯次, 
        S.处方职务, S.急救药否, S.是否新药, S.是否皮试, S.是否原料, S.处方限量, S.药品类型, I.建档时间, I.撤档时间 
    FROM 诊疗项目目录 I, 药品特性 S,药品剂型 K 
    WHERE I.ID=S.药名ID AND S.药品剂型=K.名称(+) And I.类别 In ('5','6','7')
/

