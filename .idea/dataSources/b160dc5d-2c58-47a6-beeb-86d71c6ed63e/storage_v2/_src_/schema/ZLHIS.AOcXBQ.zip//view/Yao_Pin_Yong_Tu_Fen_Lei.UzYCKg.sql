create view "药品用途分类" as
  SELECT decode(类型,1,'西成药',2,'中成药','中草药') AS 材质, ID, 编码, 名称, 简码, 上级id,1 AS 末级 
    FROM 诊疗分类目录 
    WHERE 类型 in (1,2,3) And (撤档时间 Is Null Or 撤档时间=To_Date('3000-01-01','YYYY-MM-DD'))
/

