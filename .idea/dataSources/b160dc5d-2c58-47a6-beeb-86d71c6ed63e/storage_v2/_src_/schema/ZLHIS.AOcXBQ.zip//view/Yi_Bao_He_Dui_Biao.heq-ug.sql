create view "医保核对表" as
  Select 结帐ID,结算方式,金额 From 保险结算明细 Where 标志=1
/

