create view ZLBAKINFO as
  Select "系统","版本号","更新日期","最后转储日期","最后复制日期","中止语句","提前执行","提前中止语句" From ZLBAK2012.ZLBAKINFO
/

