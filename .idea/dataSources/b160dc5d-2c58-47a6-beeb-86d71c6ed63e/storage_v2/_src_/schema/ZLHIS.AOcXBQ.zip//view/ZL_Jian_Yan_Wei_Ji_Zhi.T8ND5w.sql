create view "ZL_检验危急值" as
  Select
          '检验' as 类别,
           a.医嘱id 医嘱id,
           nvl(e.病历id,0) As 病历ID,
           NVL(a.申请科室id,0)  As 申请科室,
           NVL(a.病人科室,0) As 病人科室,
           NVL(a.床号,0) As 床号,
           NVL(a.标识号,0) As 标识号,
           NVL(a.姓名,' ') As 姓名,
           d.中文名 As 项目，
           b.检验结果 As 结果值,
           b.结果参考 As 参考值,
           a.审核人,
           a.审核时间,
           e.查阅状态
      From 检验标本记录 a, 检验普通结果 b, 检验项目 c, 诊治所见项目 d,病人医嘱报告 e
     Where a.Id = b.检验标本id
       And b.检验项目id = c.诊治项目id
       And c.诊治项目id = d.Id
       And a.医嘱id=e.医嘱id
       And (结果标志 In (5, 6))
       And a.审核时间 between Sysdate-7 And Sysdate
/

