create view "在院病人自动记帐" as
  Select p.病人id, p.主页id, i.姓名, i.性别, i.年龄, i.住院号, a.费别, p.科室id, p.病区id, p.床号, p.附加床位, p.收费细目id, p.收入项目id, 1 As 标志, 
       p.现价 As 标准单价, p.开始日期, p.终止日期, p.终止日期 - p.开始日期 As 天数, p.数量, p.经治医师, p.责任护士, p.操作员编号, p.操作员姓名 
From 病人信息 I, 病案主页 A, 
     (Select b.病人id, b.主页id, b.科室id, b.病区id, b.床号, b.附加床位, p.收费细目id, p.收入项目id, p.现价, b.经治医师, b.责任护士, b.操作员编号, b.操作员姓名, 
              Zl_Date_Half(Greatest(Least(Nvl(b.上次计算时间, b.开始时间), Nvl(b.终止时间, Greatest(Nvl(b.上次计算时间, b.开始时间))), 
                                           Greatest(Nvl(b.上次计算时间, b.开始时间))), p.执行日期, Nvl(a.启用日期, Add_Months(Sysdate, -2)))) As 开始日期, 
              Zl_Date_Half(Least(Nvl(b.终止时间, Greatest(b.开始时间, Sysdate)), Nvl(p.终止日期, Sysdate + 30) + 1)) As 终止日期, b.数量 
       From 自动计价项目 A, 
            (Select a.病人id, a.主页id, a.开始时间, a.附加床位, a.病区id, a.科室id, a.床号, a.床位等级id, 1 As 数量, a.责任护士, a.经治医师, a.终止时间, 
                     a.操作员编号, a.操作员姓名, a.上次计算时间 
              From 病人变动记录 A, 病人信息 B 
              Where a.开始原因 <> 10 And a.病人id = b.病人id And a.主页id = b.主页id And b.在院 = 1 
              Union All 
              Select b.病人id, b.主页id, 开始时间, 附加床位, b.病区id, b.科室id, 床号, i.从项id As 床位等级id, i.从项数次 As 数量, 责任护士, 经治医师, 终止时间, 操作员编号, 
                     操作员姓名, 上次计算时间 
              From 病人变动记录 B, 收费从属项目 I, 病人信息 C 
              Where b.病人id = c.病人id And b.主页id = c.主页id And c.在院 = 1 And b.床位等级id = i.主项id And b.开始原因 <> 10 And i.固有从属 > 0) B, 
            收费价目 P 
       Where a.病区id = b.病区id And Zl_Date_Half(Nvl(b.上次计算时间, b.开始时间)) <> Zl_Date_Half(Nvl(b.终止时间, Sysdate)) And p.现价 <> 0 And 
             a.计算标志 = 1 And b.床位等级id = p.收费细目id And Zl_Date_Half(Nvl(b.终止时间, Sysdate)) >= Zl_Date_Half(p.执行日期) And 
             Zl_Date_Half(b.开始时间) <= Zl_Date_Half(Nvl(p.终止日期, Sysdate) + 1) And 
             Zl_Date_Half(Least(Nvl(b.终止时间, Sysdate), Nvl(p.终止日期, Sysdate + 30) + 1)) >= 
             Zl_Date_Half(Nvl(a.启用日期, Add_Months(Sysdate, -2))) 
       Union All 
       Select b.病人id, b.主页id, b.科室id, b.病区id, b.床号, b.附加床位, p.收费细目id, p.收入项目id, p.现价, b.经治医师, b.责任护士, b.操作员编号, b.操作员姓名, 
              Zl_Date_Half(Greatest(Least(Nvl(b.上次计算时间, b.开始时间), Nvl(b.终止时间, Greatest(Nvl(b.上次计算时间, b.开始时间))), 
                                           Greatest(Nvl(b.上次计算时间, b.开始时间))), p.执行日期, Nvl(a.启用日期, Add_Months(Sysdate, -2)))) As 开始日期, 
              Zl_Date_Half(Least(Nvl(b.终止时间, Greatest(b.开始时间, Sysdate)), Nvl(p.终止日期, Sysdate + 30) + 1)) As 终止日期, b.数量 
       From 自动计价项目 A, 
            (Select a.病人id, a.主页id, 开始时间, 附加床位, a.病区id, a.科室id, 床号, 护理等级id, 1 As 数量, 责任护士, 经治医师, 终止时间, 操作员编号, 操作员姓名, 上次计算时间 
              From 病人变动记录 A, 病人信息 B 
              Where 开始原因 <> 10 And a.病人id = b.病人id And a.主页id = b.主页id And b.在院 = 1 
              Union All 
              Select b.病人id, b.主页id, 开始时间, 附加床位, b.病区id, b.科室id, 床号, i.从项id As 护理等级id, i.从项数次 As 数量, 责任护士, 经治医师, 终止时间, 操作员编号, 
                     操作员姓名, 上次计算时间 
              From 病人变动记录 B, 收费从属项目 I, 病人信息 C 
              Where b.护理等级id = i.主项id And b.病人id = c.病人id And b.主页id = c.主页id And c.在院 = 1 And b.开始原因 <> 10 And i.固有从属 > 0) B, 
            收费价目 P, 收费项目目录 C 
       Where a.病区id = b.病区id And b.附加床位 <> 1 And 
             Zl_Date_Half(Nvl(b.上次计算时间, b.开始时间)) <> Zl_Date_Half(Nvl(b.终止时间, Sysdate)) And p.现价 <> 0 And a.计算标志 = 2 And 
             b.护理等级id = p.收费细目id And b.护理等级id = c.Id And Nvl(c.计算方式, 0) <> 1 And 
             Zl_Date_Half(Nvl(b.终止时间, Sysdate)) >= Zl_Date_Half(p.执行日期) And 
             Zl_Date_Half(b.开始时间) <= Zl_Date_Half(Nvl(p.终止日期, Sysdate) + 1) And 
             Zl_Date_Half(Least(Nvl(b.终止时间, Sysdate), Nvl(p.终止日期, Sysdate + 30) + 1)) >= 
             Zl_Date_Half(Nvl(a.启用日期, Add_Months(Sysdate, -2))) 
       Union All 
       Select b.病人id, b.主页id, b.科室id, b.病区id, b.床号, b.附加床位, p.收费细目id, p.收入项目id, p.现价, b.经治医师, b.责任护士, b.操作员编号, b.操作员姓名, 
              Zl_Date_Half(Greatest(Least(Nvl(b.上次计算时间, b.开始时间), Nvl(b.终止时间, Greatest(Nvl(b.上次计算时间, b.开始时间))), 
                                           Greatest(Nvl(b.上次计算时间, b.开始时间))), p.执行日期, Nvl(a.启用日期, Add_Months(Sysdate, -2)))) As 开始日期, 
              Zl_Date_Half(Least(Nvl(b.终止时间, Greatest(b.开始时间, Sysdate)), Nvl(p.终止日期, Sysdate + 30) + 1)) As 终止日期, a.数量 
       From (Select 病区id, 计算标志, 收费细目id, 1 As 数量, 启用日期 
              From 自动计价项目 
              Union All 
              Select 病区id, 计算标志, 从项id, i.从项数次 As 数量, 启用日期 
              From 自动计价项目 A, 收费从属项目 I 
              Where a.收费细目id = i.主项id And i.固有从属 > 0) A, 病人变动记录 B, 收费价目 P, 病人信息 C 
       Where a.病区id = b.病区id And b.病人id = c.病人id And b.主页id = c.主页id And c.在院 = 1 And b.附加床位 <> 1 And b.开始原因 <> 10 And 
             Zl_Date_Half(Nvl(b.上次计算时间, b.开始时间)) <> Zl_Date_Half(Nvl(b.终止时间, Sysdate)) And p.现价 <> 0 And 
             a.收费细目id = p.收费细目id And (a.计算标志 = 6 And b.床位等级id Is Not Null Or a.计算标志 = 7) And 
             Zl_Date_Half(Nvl(b.终止时间, Sysdate)) >= Zl_Date_Half(p.执行日期) And 
             Zl_Date_Half(b.开始时间) <= Zl_Date_Half(Nvl(p.终止日期, Sysdate) + 1) And 
             Zl_Date_Half(Least(Nvl(b.终止时间, Sysdate), Nvl(p.终止日期, Sysdate + 30) + 1)) >= 
             Zl_Date_Half(Nvl(a.启用日期, Add_Months(Sysdate, -2)))) P 
Where i.病人id = p.病人id And a.病人id = p.病人id And a.主页id = p.主页id
/

