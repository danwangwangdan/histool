create view "诊断情况" as
  Select 病人id, 主页Id,疾病id,诊断描述 As 描述信息,诊断类型, 
   出院情况,诊断次序,编码序号, 是否未治, 是否疑诊 
From 病人诊断记录 Where 记录来源=2
/

